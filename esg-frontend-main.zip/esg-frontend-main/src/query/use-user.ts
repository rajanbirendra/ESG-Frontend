import {
  meAuthMeGetOptions,
  updateProfileUsersPutMutation,
} from "./../api/@tanstack/react-query.gen";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@chakra-ui/react";

export const useUserAPI = () => {
  const toast = useToast();
  const queryClient = useQueryClient();
  return {
    updateProfile: useMutation({
      ...updateProfileUsersPutMutation(),
      onSuccess: () => {
        queryClient.invalidateQueries(
          // @ts-ignore
          meAuthMeGetOptions({})
        );
        toast({
          title: "Profile updated successfully!",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
      },
      onError: (error: any) => {
        toast({
          title: "Error updating profile",
          description: error?.message,
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      },
    }),
  };
};
