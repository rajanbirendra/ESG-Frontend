import { addUserToCompanyCompanyAddUserToCompanyPostMutation } from "./../api/@tanstack/react-query.gen";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  changePasswordAuthChangePasswordPostMutation,
  meAuthMeGetOptions,
  getCompanyUsersCompanyUsersGetOptions,
  signupAuthSignupPostMutation,
  loginAuthLoginPostMutation,
  forgotPasswordAuthForgotPasswordPostMutation,
  resetPasswordAuthResetPasswordPostMutation,
} from "../api/@tanstack/react-query.gen";
import { useToast } from "@chakra-ui/react";

import { useRouter } from "next/router";



export const useAuthAPI = () => {
  const toast = useToast();
  const queryClient = useQueryClient();
  const router = useRouter();

  return {
    login: useMutation({
      ...loginAuthLoginPostMutation(),
      onSuccess: (data: any) => {
        toast({
          title: "Login Successful",
          description: "Redirecting to your dashboard...",
          status: "success",
          duration: 3000,
          isClosable: true,
        });

        const token = data?.data?.token;
        const role = token.split(".")[1];
        const decoded = JSON.parse(atob(role));
        const userRole = decoded?.role;

        if (userRole === "ADMIN") {
          router.push("/admin-dashboard");
        } else if (userRole === "USER" || userRole === "SUB_USER") {
          router.push("/dashboard/");
        }
      },
    }),
    registerUser: useMutation({
      ...signupAuthSignupPostMutation(),
      onSuccess: (data) => {
        toast({
          title: "Success",
          description:
            "Account created successfully! Please check your email to verify your account.",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
        router.push("/email/verification");
      },
      onError: (error: any) => {
        toast({
          title: "Error",
          description:
            error.data.data.message ||
            "Something went wrong. Please try again.",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
      },
    }),
    getMe: () => useQuery({
      // @ts-ignore
      ...meAuthMeGetOptions({}),
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes (garbage collection time)
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      refetchOnReconnect: false,
    }),
    addSubUser: useMutation({
      ...addUserToCompanyCompanyAddUserToCompanyPostMutation(),
      onSuccess: () => {
        queryClient.invalidateQueries(
          // @ts-ignore
          getCompanyUsersCompanyUsersGetOptions({})
        );
        toast({
          title: "Success",
          description: "User created successfully!",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "bottom",
        });
      },
      onError: (error: any) => {
        console.log("error on add sub user", error);
        toast({
          title: "Error",
          description: error?.data?.data?.message,
        });
      },
    }),
    changePassword: useMutation({
      ...changePasswordAuthChangePasswordPostMutation(),
      onSuccess: () => {
        toast({
          title: "Success",
          description: "Password changed successfully!",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "bottom",
        });
      },
      onError: (error: any) => {
        console.log("error on change password", error);
        toast({
          title: "Error",
          description:
            error.data?.data?.message ||
            "Something went wrong. Please try again.",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "bottom",
        });
      },
    }),
    forgotPassword: useMutation({
      ...forgotPasswordAuthForgotPasswordPostMutation(),
      onSuccess: () => {
        toast({
          title: "Reset Link Sent",
          description: "Check your email for password reset instructions.",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
      },
      onError: (error: any) => {
        console.log("error on forgot password", error);
        toast({
          title: "Error",
          description:
            error.data?.data?.message ||
            "Failed to send reset email. Please try again.",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
      },
    }),
    resetPassword: useMutation({
      ...resetPasswordAuthResetPasswordPostMutation(),
      onSuccess: () => {
        toast({
          title: "Password Reset Successful",
          description: "Your password has been reset successfully. You can now login with your new password.",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
        router.push("/");
      },
      onError: (error: any) => {
        console.log("error on reset password", error);
        toast({
          title: "Error",
          description:
            error.data?.data?.message ||
            "Failed to reset password. Please try again.",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
      },
    }),

  };
};
