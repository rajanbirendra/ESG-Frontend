import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@chakra-ui/react";
import { uploadMediaMiscMediaPostMutation } from "../api/@tanstack/react-query.gen";

export const useMediaAPI = () => {
  const toast = useToast();
  const queryClient = useQueryClient();
  return {
    upload: useMutation({
      ...uploadMediaMiscMediaPostMutation(),
    }),
  };
};
