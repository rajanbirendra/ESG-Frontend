import {
  listNotificationsNotificationsGetOptions,
  createNotificationNotificationsPostMutation,
  deleteNotificationNotificationsNotificationIdDeleteMutation,
  getNotificationNotificationsNotificationIdGetOptions,
  updateNotificationNotificationsNotificationIdPutMutation,
  markAsReadNotificationsNotificationIdReadPatchMutation,
  markAllAsReadNotificationsReadAllPatchMutation,
  getUnreadCountNotificationsUnreadCountGetOptions,
  getNotificationTypesNotificationsTypesGetOptions,
} from "@/api/@tanstack/react-query.gen";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type {
  CreateNotificationValidator,
  UpdateNotificationValidator,
} from "@/api/types.gen";
import { useToast } from "@chakra-ui/react";

// List notifications
export function useNotificationsList(
  options: Parameters<typeof listNotificationsNotificationsGetOptions>[0]
) {
  return useQuery(listNotificationsNotificationsGetOptions(options));
}

// Create notification
export function useCreateNotification(
  mutationOptions?: Parameters<
    typeof createNotificationNotificationsPostMutation
  >[0]
) {
  const queryClient = useQueryClient();
  const toast = useToast();
  return useMutation({
    ...createNotificationNotificationsPostMutation(mutationOptions),
    onSuccess: () => {
      queryClient.invalidateQueries(
        //   @ts-ignore
        listNotificationsNotificationsGetOptions({})
      );

      queryClient.invalidateQueries(
        // @ts-ignore
        getUnreadCountNotificationsUnreadCountGetOptions({})
      );
    },
    onError: (err) => {
      toast({
        title: "Error",
        description:
          // @ts-ignore
          err?.data?.error ||
          "Failed to create notification. Please try again.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    },
  });
}

// Delete notification
export function useDeleteNotification(
  mutationOptions?: Parameters<
    typeof deleteNotificationNotificationsNotificationIdDeleteMutation
  >[0]
) {
  const queryClient = useQueryClient();
  const toast = useToast();
  return useMutation({
    ...deleteNotificationNotificationsNotificationIdDeleteMutation(
      mutationOptions
    ),
    onSuccess: () => {
      queryClient.invalidateQueries(
        //   @ts-ignore
        listNotificationsNotificationsGetOptions({})
      );

      queryClient.invalidateQueries(
        // @ts-ignore
        getUnreadCountNotificationsUnreadCountGetOptions({})
      );
    },
    onError: (err) => {
      toast({
        title: "Error",
        description:
          // @ts-ignore
          err?.data?.error ||
          "Failed to delete notification. Please try again.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    },
  });
}

// Get single notification
export function useNotificationDetail(
  options: Parameters<
    typeof getNotificationNotificationsNotificationIdGetOptions
  >[0]
) {
  return useQuery(
    getNotificationNotificationsNotificationIdGetOptions(options)
  );
}

// Update notification
export function useUpdateNotification(
  mutationOptions?: Parameters<
    typeof updateNotificationNotificationsNotificationIdPutMutation
  >[0]
) {
  const queryClient = useQueryClient();
  const toast = useToast();
  return useMutation({
    ...updateNotificationNotificationsNotificationIdPutMutation(
      mutationOptions
    ),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["listNotificationsNotificationsGet"],
      });
      queryClient.invalidateQueries({
        queryKey: ["getUnreadCountNotificationsUnreadCountGet"],
      });
    },
    onError: (err) => {
      toast({
        title: "Error",
        description:
          // @ts-ignore
          err?.data?.error ||
          "Failed to update notification. Please try again.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    },
  });
}

// Mark notification as read
export function useMarkAsRead(
  mutationOptions?: Parameters<
    typeof markAsReadNotificationsNotificationIdReadPatchMutation
  >[0]
) {
  const queryClient = useQueryClient();
  const toast = useToast();
  return useMutation({
    ...markAsReadNotificationsNotificationIdReadPatchMutation(mutationOptions),
    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["listNotificationsNotificationsGet"],
      });
      queryClient.invalidateQueries({
        queryKey: ["getUnreadCountNotificationsUnreadCountGet"],
      });
    },
    onError: (err) => {
      toast({
        title: "Error",
        description:
          // @ts-ignore
          err?.data?.error ||
          "Failed to mark notification as read. Please try again.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    },
  });
}

// Mark all notifications as read
export function useMarkAllAsRead(
  mutationOptions?: Parameters<
    typeof markAllAsReadNotificationsReadAllPatchMutation
  >[0]
) {
  const queryClient = useQueryClient();
  const toast = useToast();
  return useMutation({
    ...markAllAsReadNotificationsReadAllPatchMutation(mutationOptions),
    onSuccess: () => {
      queryClient.invalidateQueries(
        //   @ts-ignore
        listNotificationsNotificationsGetOptions({})
      );

      queryClient.invalidateQueries(
        // @ts-ignore
        getUnreadCountNotificationsUnreadCountGetOptions({})
      );
    },
    onError: (err) => {
      toast({
        title: "Error",
        description:
          // @ts-ignore
          err?.data?.error ||
          "Failed to mark all notifications as read. Please try again.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    },
  });
}

// Get unread count
export function useUnreadCount(
  options?: Parameters<
    typeof getUnreadCountNotificationsUnreadCountGetOptions
  >[0]
) {
  return useQuery(
    // @ts-ignore
    getUnreadCountNotificationsUnreadCountGetOptions(options)
  );
}

// Get notification types
export function useNotificationTypes(
  options?: Parameters<
    typeof getNotificationTypesNotificationsTypesGetOptions
  >[0]
) {
  return useQuery(getNotificationTypesNotificationsTypesGetOptions(options));
}

// Helper function to create notification data
export function createNotificationData(data: CreateNotificationValidator) {
  return {
    body: data,
    headers: {
      authorization: "", // This will be automatically handled by the API client
    },
  };
}

// Helper function to update notification data
export function updateNotificationData(data: UpdateNotificationValidator) {
  return {
    body: data,
    headers: {
      authorization: "", // This will be automatically handled by the API client
    },
  };
}
