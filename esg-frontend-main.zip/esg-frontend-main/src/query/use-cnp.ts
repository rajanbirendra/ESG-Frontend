import { useToast } from "@chakra-ui/react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { deleteCnpCarbonNeutralityPlanCnpIdDeleteMutation } from "../api/@tanstack/react-query.gen";
import {
  createCarbonNeutralityPlanPostMutation,
  getAllCarbonNeutralityPlanGetOptions,
} from "../api/@tanstack/react-query.gen";
import { useRouter } from "next/router";
import { updateCnpCarbonNeutralityPlanIdPatchMutation } from "../api/@tanstack/react-query.gen";
import {
  getPercentageInfoCarbonNeutralityPlanIdInfoGetOptions,
  getCarbonNeutralityPlanBaseYearsCarbonNeutralityPlanBaseYearsGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  getOneCarbonNeutralityPlanIdGetOptions,
  getPercentageInfoAssessmentInfoGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  GetPercentageInfoCarbonNeutralityPlanIdInfoGetData,
  Options,
} from "@/api";

export const useCNPAPI = () => {
  const toast = useToast();
  const queryClient = useQueryClient();
  const router = useRouter();

  return {
    create: useMutation({
      ...createCarbonNeutralityPlanPostMutation(),
      onSuccess: (data: any) => {
        toast({
          title: "Carbon Neutrality Plan Created",
          description: `Plan for year ${data?.data?.year} created successfully.`,
          status: "success",
          duration: 3000,
          isClosable: true,
        });

        router.push(
          "/dashboard/carbon-neutrality-plan/details/" + data?.data?.id
        );
      },
      onError: (error: any) => {
        toast({
          title: error.message,
          description: error?.data?.data?.message || "Something went wrong",
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      },
    }),

    getAll: () =>
      useQuery({
        ...getAllCarbonNeutralityPlanGetOptions(
          // @ts-ignore
          {}
        ),
      }),

    getPercentageOfCNPScopeAssessment: (
      options: Options<GetPercentageInfoCarbonNeutralityPlanIdInfoGetData>
    ) => {
      return useQuery({
        ...getPercentageInfoCarbonNeutralityPlanIdInfoGetOptions(options),
      });
    },

    getBaseYears: () =>
      useQuery({
        // @ts-ignore
        ...getCarbonNeutralityPlanBaseYearsCarbonNeutralityPlanBaseYearsGetOptions(),
      }),

    getOne: (id) =>
      useQuery({
        ...getOneCarbonNeutralityPlanIdGetOptions(
          // @ts-ignore
          {
            path: {
              id,
            },
          }
        ),
      }),

    update: useMutation({
      ...updateCnpCarbonNeutralityPlanIdPatchMutation(),
      // onSuccess: (data: any) => {
      //   toast({
      //     title: "Carbon Neutrality Plan Updated",
      //     description: `Plan for year ${data?.data?.year} updated successfully.`,
      //     status: "success",
      //     duration: 3000,
      //     isClosable: true,
      //   });
      //   // @ts-ignore
      //   queryClient.invalidateQueries(getAllCarbonNeutralityPlanGetOptions({}));
      // },
      // onError: (error: any) => {
      //   toast({
      //     title: "Failed to update plan",
      //     description: error?.data?.message || "Something went wrong",
      //     status: "error",
      //     duration: 3000,
      //     isClosable: true,
      //   });
      // },
    }),

    delete: useMutation({
      ...deleteCnpCarbonNeutralityPlanCnpIdDeleteMutation(),
      onSuccess: (data: any) => {
        toast({
          title: data.message,
          description: `Plan for year ${data?.data?.year} deleted successfully.`,
          status: "success",
          duration: 3000,
          isClosable: true,
        });
        // @ts-ignore
        queryClient.invalidateQueries(getAllCarbonNeutralityPlanGetOptions({}));
      },
      onError: (error: any) => {
        toast({
          title: "Failed to delete plan",
          description: error?.data?.message || "Something went wrong",
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      },
    }),
  };
};
