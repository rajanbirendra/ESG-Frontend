import {
  getCountryListMiscGetCountryListGetOptions,
  getFormResponsesMiscGetFormResponsesAssessmentIdGetOptions,
  verifyAssessmentIdAssessmentVerifyAssessmentIdAssessmentIdGetOptions,
} from "@/api/@tanstack/react-query.gen";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  getStationaryFuelTypesMiscStationaryFuelTypesGetOptions,
  getCountryStateMiscGetCountryStateCountryNameGetOptions,
} from "../api/@tanstack/react-query.gen";
import { useToast } from "@chakra-ui/react";
import {
  addFormMiscAddFormAssessmentIdPostMutation,
  deleteFormResponseMiscDeleteFormResponseFormIdPostOptions,
  deleteFormResponseMiscDeleteFormResponseFormIdPostMutation,
} from "../api/@tanstack/react-query.gen";
import { getFormResponsesMiscGetFormResponsesAssessmentIdGet } from "../api/sdk.gen";
import {
  getTypesMiscTypesTypeNameGetOptions,
  getAllTypesMiscAllTypesGetOptions,
} from "../api/@tanstack/react-query.gen";

export const useMiscAPI = () => {
  const toast = useToast();
  return {
    getAllTypes: useQuery({
      ...getAllTypesMiscAllTypesGetOptions(),
    }),

    getTypeList: (type: string) => {
      return useQuery({
        ...getTypesMiscTypesTypeNameGetOptions({
          path: {
            type_name: type,
          },
        }),
        enabled: !!type,
      });
    },
    verifyAssessmentById: (assessmentId: string) =>
      useQuery({
        ...verifyAssessmentIdAssessmentVerifyAssessmentIdAssessmentIdGetOptions(
          {
            path: {
              assessment_id: assessmentId,
            },
          }
        ),
        retry: false,
      }),

    getStationaryFuelTypes: useQuery({
      ...getStationaryFuelTypesMiscStationaryFuelTypesGetOptions(),
    }),

    addFormResponse: useMutation({
      ...addFormMiscAddFormAssessmentIdPostMutation(),
      onSuccess: () => {
        toast({
          title: "Form submitted successfully",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
      },
    }),

    getFormResponse: (assessmentId: string) =>
      useQuery({
        ...getFormResponsesMiscGetFormResponsesAssessmentIdGetOptions(
          // @ts-ignore

          {
            path: {
              assessment_id: assessmentId,
            },
          }
        ),
      }),

    deleteFormResponse: useMutation({
      ...deleteFormResponseMiscDeleteFormResponseFormIdPostMutation(),
      onSuccess: () => {
        toast({
          title: "Form response removed successfully",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
      },
    }),

    getCountryList: useQuery({
      ...getCountryListMiscGetCountryListGetOptions(),
    }),

    getStateListByCountryName: (countryName: string) =>
      useQuery({
        ...getCountryStateMiscGetCountryStateCountryNameGetOptions({
          path: {
            country_name: countryName,
          },
        }),
        enabled: !!countryName,
      }),
  };
};
