import { useMutation, useQuery } from "@tanstack/react-query";
import {
  createAssessmentAssessmentPostMutation,
  getAllAssessmentGetOptions,
  getAssessmentDetailsAssessmentIdGetOptions,
} from "../api/@tanstack/react-query.gen";
import { Options } from "@hey-api/client-fetch";
import {
  GetAllAssessmentGetData,
  GetAllForAdminAssessmentAdminGetData,
  GetAssessmentDetailsAssessmentIdGetData,
  GetPercentageInfoAssessmentInfoGetData,
} from "@/api";
import { useToast } from "@chakra-ui/react";
import { useRouter } from "next/router";
import { AssessmentType } from "@/types/index.types";
import {
  getAllForAdminAssessmentAdminGetOptions,
  updateStatusAssessmentUpdateStatusPatchMutation,
} from "../api/@tanstack/react-query.gen";
import {
  getPercentageInfoAssessmentInfoGetOptions,
  downloadReportAssessmentDownloadReportAssessmentIdPostMutation,
} from "../api/@tanstack/react-query.gen";
import { downloadReportAssessmentDownloadReportAssessmentIdPost } from "../api/sdk.gen";
import { getAssessmentYearsAssessmentAssessmentYearsGetOptions } from "../api/@tanstack/react-query.gen";

export function useAssessmentsAPI() {
  const toast = useToast();
  const router = useRouter();

  return {
    updateAssessmentStatus: useMutation({
      ...updateStatusAssessmentUpdateStatusPatchMutation(),
      onSuccess: (res: any) => {
        toast({
          title: res?.message,
          status: "success",
          duration: 5000,
          isClosable: true,
        });
      },
      onError: (error: any) => {
        console.log("error", error);
        toast({
          title: error?.data?.data?.message,
          status: "error",
          duration: 5000,
          isClosable: true,
        });
      },
    }),

    getPercentageOfAssessment: (
      options: Options<GetPercentageInfoAssessmentInfoGetData>
    ) => {
      return useQuery({
        ...getPercentageInfoAssessmentInfoGetOptions(options),
      });
    },

    getAssessments: (options: Options<GetAllAssessmentGetData>) => {
      return useQuery({
        ...getAllAssessmentGetOptions(options),
      });
    },

    getAllAssessmentForAdmin: (
      options: Options<GetAllForAdminAssessmentAdminGetData>
    ) => {
      return useQuery({
        ...getAllForAdminAssessmentAdminGetOptions(options),
      });
    },

    getAssessmentDoneYears: () =>
      useQuery({
        // @ts-ignore
        ...getAssessmentYearsAssessmentAssessmentYearsGetOptions({}),
      }),

    getAssessmentDetails: (
      options: Options<GetAssessmentDetailsAssessmentIdGetData>
    ) => {
      return useQuery({
        ...getAssessmentDetailsAssessmentIdGetOptions(options),
      });
    },

    downloadAssessmentReport: async (assessmentId: string) => {
      const response = await fetch(
        `${
          process.env.NEXT_PUBLIC_API_URL ?? "https://backend.paudyals.com/api"
        }/assessment/download-report/${assessmentId}`,
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            Accept:
              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData?.data?.message || "Download failed");
      }

      const blob = await response.blob();

      try {
        // Create a blob URL
        const url = window.URL.createObjectURL(blob);

        // Create a temporary link element
        const link = document.createElement("a");
        link.href = url;
        link.download = `assessment_report_${new Date().getTime()}.xlsx`;

        // Append to body, click, and remove
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Clean up the blob URL
        window.URL.revokeObjectURL(url);

        toast({
          title: "Download Started",
          description: "Assessment report download has started",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
      } catch (error) {
        console.error("Error processing download:", error);
        toast({
          title: "Download Failed",
          description: "Failed to process the downloaded file",
          status: "error",
          duration: 5000,
          isClosable: true,
        });
      }
    },
    onError: (error: any) => {
      console.error("Download error:", error);
      toast({
        title: "Download Failed",
        description: error?.message || "Failed to download assessment report",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    },

    createAssessment: useMutation({
      ...createAssessmentAssessmentPostMutation(),
      onSuccess: (res: any) => {
        toast({
          title:
            "Assessment instance successfully. Please start the assessment.",
          status: "success",
          duration: 5000,
          isClosable: true,
        });
        console.log("res", res);
        if (res.assessment_type === AssessmentType.SELF_ASSESSMENT) {
          router.push("/dashboard/self-assessment/start/" + res.id);
        } else router.push("/dashboard/assessment/start/" + res.id);
      },
      onError: (error: any) => {
        toast({
          title: "Error creating assessment",
          description: error?.data?.data?.message,
          status: "error",
          duration: 5000,
          isClosable: true,
        });
      },
    }),
  };
}
