import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@chakra-ui/react";
import { updateEfValueEfIdPatchMutation } from "../api/@tanstack/react-query.gen";
import {
  getEfGetOptions,
  importExcelEfImportExcelPostMutation,
} from "../api/@tanstack/react-query.gen";

export const useEFAPI = () => {
  const toast = useToast();
  const queryClient = useQueryClient();
  return {
    updateEmissionFactor: useMutation({
      ...updateEfValueEfIdPatchMutation(),

      onSuccess: () => {
        toast({
          title: "Success",
          description: "Emission values updated successfully",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
        // @ts-ignore
        queryClient.invalidateQueries(getEfGetOptions({}));
      },
      onError: (error: any) => {
        toast({
          title: "Error",
          description: error?.message || "Failed to update emission factor",
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      },
    }),

    //
    getEmissionFactors: (country, state, categoryName) =>
      useQuery({
        ...getEfGetOptions(
          // @ts-ignore
          {
            query: {
              country_name: country,
              state_name: state,
              category_name: categoryName,
            },
          }
        ),
      }),

    importExcel: useMutation({
      ...importExcelEfImportExcelPostMutation(),
      onSuccess: () => {
        toast({
          title: "Import Successful",
          description: "Emission factors have been imported successfully",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
      },
      onError: (error) => {
        console.error("Import error:", error);
        toast({
          title: "Import Failed",
          description: "Failed to import emission factors. Please try again.",
          status: "error",
          duration: 3000,
          isClosable: true,
        });
      },
    }),
  };
};
