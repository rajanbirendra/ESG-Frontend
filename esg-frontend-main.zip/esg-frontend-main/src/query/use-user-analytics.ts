import { GetCarbonNeutralityChartsMetricsAnalyticsUserCnpChartGetResponses } from "./../api/types.gen";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  branchWiseEnergyMixAnalyticsUserBranchWiseEnergyMixPostOptions,
  getGovernanceBoardAndCommitteeMetricsAnalyticsUserGovernanceBoardAndCommitteeChartPostOptions,
  getScope1EmissionAnalyticsUserScope1EmissionsPostOptions,
  getSocialEmployeeTurnoverRateAnalyticsUserSocialEmployeeTurnoverRatePostOptions,
  getSocialHealthInsuredEmployeeAnalyticsUserSocialHealthInsuranceCoveredEmployeePostOptions,
  getSocialPermanentContractualEmployeeAnalyticsUserSocialPermanentContractualEmployeePostOptions,
  getSocialWorkDayLostAnalyticsUserSocialWorkDaysLostPostOptions,
  getUpstreamDownstreamEmissionsAnalyticsUserEnvironmentUpstreamDownstreamEmissionsPostOptions,
} from "../api/@tanstack/react-query.gen";
import {
  getGeneralAnalyticsAnalyticsUserGeneralGetOptions,
  getCarbonNeutralityCardMetricsAnalyticsUserCnpCardsGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  getSocialMetricsAnalyticsUserSocialCardsGetOptions,
  getScope2EmissionAnalyticsUserScope2EmissionsGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  getRecentlyCreatedAssessmentRecentlyCreatedGetOptions,
  getCarbonNeutralityChartsMetricsAnalyticsUserCnpChartGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  getGovernanceMetricsAnalyticsUserGovernanceCardsGetOptions,
  getGovernancePolicyMetricsAnalyticsUserGovernancePolicyGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  branchWiseWasteTotalGeneratedAnalyticsUserBranchWiseWasteGeneratedTotalGetOptions,
  wasteTypeMetricsAnalyticsUserWasteTypeMetricsGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  getTotalEnergyConsumedAnalyticsUserTotalEnergyConsumedGetOptions,
  scopeEmissionAnalyticsUserScopeEmissionsGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  scopeWiseEnergyAnalyticsUserScopeWiseEnergyGetOptions,
  wasteTotalGenerateAnalyticsUserWasteTotalGetOptions,
} from "../api/@tanstack/react-query.gen";
import { getEnergyMixAnalyticsUserEnergyMixGetOptions } from "../api/@tanstack/react-query.gen";
import { format, getYear, getMonth, eachMonthOfInterval } from "date-fns";
import { getSelfAssessmentChartMetricsAnalyticsUserSelfAssessmentChartMetricsGetOptions } from "../api/@tanstack/react-query.gen";
import { getCarbonNeutralityCardMetricsAnalyticsUserCnpCardsGet } from "../api/sdk.gen";

export function useUserAnalyticsAPI() {
  return {
    /*
     *
     * For General
     *
     */

    getGeneralAnalytics: () =>
      useQuery({
        // @ts-ignore
        ...getGeneralAnalyticsAnalyticsUserGeneralGetOptions(),
      }),

    getRecentlyCreatedAssessments: () =>
      useQuery({
        // @ts-ignore
        ...getRecentlyCreatedAssessmentRecentlyCreatedGetOptions(),
      }),

    /*
     *
     * For Environment
     *
     */

    getScope1Emission: (
      branch: string | null = null,
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) => {
      return useQuery({
        ...getScope1EmissionAnalyticsUserScope1EmissionsPostOptions(
          // @ts-ignore
          {
            // @ts-ignore
            body: {
              branch,
              start_date: startDate,
              end_date: endDate,
            },
          }
        ),
      });
    },

    getScope2Emission: (
      branch: string | null = null,
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) =>
      // @ts-ignore
      useQuery({
        // @ts-ignore
        ...getScope2EmissionAnalyticsUserScope2EmissionsGetOptions({
          // @ts-ignore
          query: {
            branch,
            start_date: startDate,
            end_date: endDate,
          },
        }),
      }),

    getEnergyMixData: () =>
      useQuery({
        // @ts-ignore
        ...getEnergyMixAnalyticsUserEnergyMixGetOptions(),
      }),
    getBranchWiseEnergyMixData: (
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) =>
      useQuery({
        // @ts-ignore
        ...branchWiseEnergyMixAnalyticsUserBranchWiseEnergyMixPostOptions({
          body: {
            start_date: startDate,
            end_date: endDate,
          },
        }),

        retry: 0,
      }),
    getScopeWiseEnergyData: () =>
      useQuery({
        // @ts-ignore
        ...scopeWiseEnergyAnalyticsUserScopeWiseEnergyGetOptions(),
      }),
    getScopeEmissionData: () =>
      useQuery({
        // @ts-ignore
        ...scopeEmissionAnalyticsUserScopeEmissionsGetOptions(),
      }),

    getTotalWasteGenerated: () =>
      useQuery({
        // @ts-ignore
        ...wasteTotalGenerateAnalyticsUserWasteTotalGetOptions(),
      }),

    getBranchWiseWasteGenerated: useQuery({
      // @ts-ignore
      ...branchWiseWasteTotalGeneratedAnalyticsUserBranchWiseWasteGeneratedTotalGetOptions(),
    }),

    getWasteTypeMetrics: (branch) =>
      useQuery({
        ...wasteTypeMetricsAnalyticsUserWasteTypeMetricsGetOptions(
          // @ts-ignore
          {
            query: {
              branch,
            },
          }
        ),
      }),

    getUpstreamDownstreamEmissions: (
      branch: any = null,
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) =>
      useQuery({
        ...getUpstreamDownstreamEmissionsAnalyticsUserEnvironmentUpstreamDownstreamEmissionsPostOptions(
          // @ts-ignore
          {
            body: {
              branch,
              start_date: startDate,
              end_date: endDate,
            },
          }
        ),
      }),

    /*
     *
     * For Governance
     *
     */

    getGovernanceCardMetrics: () =>
      useQuery({
        // @ts-ignore
        ...getGovernanceMetricsAnalyticsUserGovernanceCardsGetOptions(),
      }),

    getGovernancePolicyMetrics: () =>
      useQuery({
        // @ts-ignore
        ...getGovernancePolicyMetricsAnalyticsUserGovernancePolicyGetOptions(),
      }),

    getGovernanceChart: (
      branch: string | null = null,
      startDate: string | null = null,
      endDate: string | null = null
    ) =>
      useQuery({
        ...getGovernanceBoardAndCommitteeMetricsAnalyticsUserGovernanceBoardAndCommitteeChartPostOptions(
          // @ts-ignore
          {
            body: {
              branch,
              start_date: startDate,
              end_date: endDate,
            },
          }
        ),
      }),

    /**
     *
     * FOR SOCIAL
     *
     */

    getSocialHealthInsuredEmployee: (
      branch: any = null,
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) => {
      const years: number[] = [];

      return useQuery({
        ...getSocialHealthInsuredEmployeeAnalyticsUserSocialHealthInsuranceCoveredEmployeePostOptions(
          // @ts-ignore
          {
            body: {
              branch,
              start_date: startDate,
              end_date: endDate,
            },
          }
        ),
      });
    },

    getSocialPermanentContractualEmployee: (
      branch: any = null,
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) => {
      return useQuery({
        ...getSocialPermanentContractualEmployeeAnalyticsUserSocialPermanentContractualEmployeePostOptions(
          // @ts-ignore
          {
            body: {
              branch,
              start_date: startDate,
              end_date: endDate,
            },
          }
        ),
      });
    },

    getSocialWorkDayLost: (
      branch: any = null,
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) => {
      return useQuery({
        ...getSocialWorkDayLostAnalyticsUserSocialWorkDaysLostPostOptions(
          // @ts-ignore
          {
            body: {
              branch,
              start_date: startDate,
              end_date: endDate,
            },
          }
        ),
      });
    },

    getSocialCards: () =>
      useQuery({
        // @ts-ignore
        ...getSocialMetricsAnalyticsUserSocialCardsGetOptions(),
      }),

    getSocialEmployeeTurnoverRate: (
      branch: any = null,
      startDate: string | undefined = undefined,
      endDate: string | undefined = undefined
    ) => {
      return useQuery({
        ...getSocialEmployeeTurnoverRateAnalyticsUserSocialEmployeeTurnoverRatePostOptions(
          // @ts-ignore
          {
            body: {
              branch,
              start_date: startDate,
              end_date: endDate,
            },
          }
        ),
      });
    },

    /*
     * For Carbon Neutrality Plan
     *
     */

    getCNPCardsMetrices: (selectedYear) =>
      useQuery({
        ...getCarbonNeutralityCardMetricsAnalyticsUserCnpCardsGetOptions(
          // @ts-ignore
          {
            query: {
              base_year: selectedYear,
            },
          }
        ),
      }),

    getCNPChartMetrices: (baseYear, term) => {
      return useQuery({
        // @ts-ignore
        ...getCarbonNeutralityChartsMetricsAnalyticsUserCnpChartGetOptions({
          query: {
            base_year: baseYear,
            term: term,
          },
        }),
      });
    },

    /**
     *
     * FOR SELF-ASSESSMENT
     *
     */

    getSelfAssessmentChartMetrics: (year, branch) => {
      return useQuery({
        ...getSelfAssessmentChartMetricsAnalyticsUserSelfAssessmentChartMetricsGetOptions(
          // @ts-ignore
          {
            query: {
              year,
              branch,
            },
          }
        ),
      });
    },
  };
}
