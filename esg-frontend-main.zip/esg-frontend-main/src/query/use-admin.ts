import { useMutation, useQuery } from "@tanstack/react-query";
import { getAdminAnalyticsAnalyticsAdminGetOptions } from "@/api/@tanstack/react-query.gen";
import {
  getAllUsersAdminGetUsersGetOptions,
  updateQuestionAdminUpdateQuestionPostMutation,
} from "../api/@tanstack/react-query.gen";
import { Options } from "@hey-api/client-fetch";
import { GetAllUsersAdminGetUsersGetData } from "@/api";
import { useToast } from "@chakra-ui/react";
import { updatePlanAdminUpdateUserPlanPatchMutation } from "../api/@tanstack/react-query.gen";

export const useAdminAPI = () => {
  const toast = useToast();
  return {
    getAdminAnalytics: useQuery({
      ...getAdminAnalyticsAnalyticsAdminGetOptions(),
    }),

    updateQuestion: useMutation({
      ...updateQuestionAdminUpdateQuestionPostMutation(),
      onSuccess: () => {
        toast({
          title: "Question updated",
          description: "The question has been updated successfully.",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
      },
    }),

    updateUserPlan: useMutation({
      ...updatePlanAdminUpdateUserPlanPatchMutation(),
      onSuccess: () => {
        toast({
          title: "Plan updated",
          description: "The user's plan has been updated successfully.",
          status: "success",
          duration: 3000,
          isClosable: true,
        });
      },
    }),

    getUsers: (options: Options<GetAllUsersAdminGetUsersGetData> | {} = {}) => {
      return useQuery({
        // @ts-ignore
        ...getAllUsersAdminGetUsersGetOptions(options),
      });
    },
  };
};
