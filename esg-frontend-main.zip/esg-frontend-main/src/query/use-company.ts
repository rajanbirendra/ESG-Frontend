import { getCompanyUsersCompanyUsersGetOptions } from "@/api/@tanstack/react-query.gen";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  getBranchesCompanyBranchesGetOptions,
  createBranchCompanyCreateBranchPostMutation,
} from "../api/@tanstack/react-query.gen";
import {
  GetBranchesCompanyBranchesGetData,
  GetCompanyUsersCompanyUsersGetData,
  Options,
} from "@/api";
import { useToast } from "@chakra-ui/react";

export const useGetCompanyBranches = () => {
  return useQuery({
    // @ts-ignore
    ...getBranchesCompanyBranchesGetOptions(),
  });
};

export const useCompanyAPI = () => {
  const toast = useToast();
  const queryClient = useQueryClient();

  return {
    getAllCompanyBranches: (
      options: Options<GetBranchesCompanyBranchesGetData>
    ) => {
      return useQuery({
        ...getBranchesCompanyBranchesGetOptions(options),
      });
    },
    getCompanyUsers: (options: Options<GetCompanyUsersCompanyUsersGetData>) => {
      return useQuery({
        ...getCompanyUsersCompanyUsersGetOptions(options),
      });
    },
    createCompanyBranch: useMutation({
      ...createBranchCompanyCreateBranchPostMutation(),
      onSuccess: (data) => {
        toast({
          title: "Branch created",
          description: "Branch created successfully",
          status: "success",
        });
        // @ts-ignore
        queryClient.invalidateQueries(getBranchesCompanyBranchesGetOptions({}));
      },
      onError: () => {
        toast({
          title: "Branch creation failed",
          description: "Please try again",
          status: "error",
        });
      },
    }),
  };
};
