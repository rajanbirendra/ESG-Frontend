import { useMutation, useQuery } from "@tanstack/react-query";
import { useToast } from "@chakra-ui/react";
import { useRouter } from "next/router";
import {
  verifyEmailEmailVerifyGetOptions,
  resendVerificationEmailEmailResendVerificationEmailPostMutation,
} from "../api/@tanstack/react-query.gen";

export const useEmailAPI = () => {
  const toast = useToast();
  const router = useRouter();

  return {
    // Verify email with token
    verifyEmail: useQuery({
      ...verifyEmailEmailVerifyGetOptions({
        query: {
          t: typeof window !== 'undefined' ? new URLSearchParams(window.location.search).get('token') || '' : '',
        },
      }),
      enabled: typeof window !== 'undefined' && !!new URLSearchParams(window.location.search).get('token'),
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 10 * 60 * 1000, // 10 minutes
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      refetchOnReconnect: false,
    }),

    // Resend verification email
    resendVerificationEmail: useMutation({
      ...resendVerificationEmailEmailResendVerificationEmailPostMutation(),
      onSuccess: (data) => {
        toast({
          title: "Email Sent",
          description: "Verification email has been sent to your inbox. Please check your email and click the verification link.",
          status: "success",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
      },
      onError: (error: any) => {
        toast({
          title: "Error",
          description: error?.data?.data?.message || "Failed to send verification email. Please try again.",
          status: "error",
          duration: 5000,
          isClosable: true,
          position: "top",
        });
      },
    }),
  };
};
