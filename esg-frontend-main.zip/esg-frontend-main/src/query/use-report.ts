import {
  listReportsReportsGetOptions,
  createReportReportsPostMutation,
  getReportTypesReportsTypesGetOptions,
  getYearlySummaryReportsSummaryGetOptions,
  deleteReportReportsReportIdDeleteMutation,
  getReportReportsReportIdGetOptions,
  updateReportReportsReportIdPutMutation,
  updateReportStatusReportsReportIdStatusPatchMutation,
} from "@/api/@tanstack/react-query.gen";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import type {
  CreateReportValidator,
  UpdateReportValidator,
  UpdateReportStatusValidator,
} from "@/api/types.gen";
import { useToast } from "@chakra-ui/react";

// List reports
export function useReportsList(
  options: Parameters<typeof listReportsReportsGetOptions>[0]
) {
  return useQuery(listReportsReportsGetOptions(options));
}

// Create report
export function useCreateReport(
  mutationOptions?: Parameters<typeof createReportReportsPostMutation>[0]
) {
  const queryClient = useQueryClient();
  const toast = useToast();
  return useMutation({
    ...createReportReportsPostMutation(mutationOptions),
    onSuccess: () => {
      // @ts-ignore
      queryClient.invalidateQueries(listReportsReportsGetOptions({}));
    },
    onError: (err) => {
      toast({
        title: "Error",
        description:
          // @ts-ignore
          err?.data?.error || "Failed to request report. Please try again.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
    },
  });
}

// Get report types
export function useReportTypes(
  options?: Parameters<typeof getReportTypesReportsTypesGetOptions>[0]
) {
  return useQuery(getReportTypesReportsTypesGetOptions(options));
}

// Get yearly summary
export function useYearlySummary(
  options: Parameters<typeof getYearlySummaryReportsSummaryGetOptions>[0]
) {
  return useQuery(getYearlySummaryReportsSummaryGetOptions(options));
}

// Delete report
export function useDeleteReport(
  mutationOptions?: Parameters<
    typeof deleteReportReportsReportIdDeleteMutation
  >[0]
) {
  const queryClient = useQueryClient();
  return useMutation({
    ...deleteReportReportsReportIdDeleteMutation(mutationOptions),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["listReportsReportsGet"] });
    },
  });
}

// Get single report
export function useReportDetail(
  options: Parameters<typeof getReportReportsReportIdGetOptions>[0]
) {
  return useQuery(getReportReportsReportIdGetOptions(options));
}

// Update report
export function useUpdateReport(
  mutationOptions?: Parameters<typeof updateReportReportsReportIdPutMutation>[0]
) {
  const queryClient = useQueryClient();
  return useMutation({
    ...updateReportReportsReportIdPutMutation(mutationOptions),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["listReportsReportsGet"] });
    },
  });
}

// Update report status
export function useUpdateReportStatus(
  mutationOptions?: Parameters<
    typeof updateReportStatusReportsReportIdStatusPatchMutation
  >[0]
) {
  const queryClient = useQueryClient();
  return useMutation({
    ...updateReportStatusReportsReportIdStatusPatchMutation(mutationOptions),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["listReportsReportsGet"] });
    },
  });
}

// Helper function to create report data
export function createReportData(data: CreateReportValidator) {
  return {
    body: data,
    headers: {
      authorization: "", // This will be automatically handled by the API client
    },
  };
}

// Helper function to update report data
export function updateReportData(data: UpdateReportValidator) {
  return {
    body: data,
    headers: {
      authorization: "", // This will be automatically handled by the API client
    },
  };
}

// Helper function to update report status data
export function updateReportStatusData(data: UpdateReportStatusValidator) {
  return {
    body: data,
    headers: {
      authorization: "", // This will be automatically handled by the API client
    },
  };
}
