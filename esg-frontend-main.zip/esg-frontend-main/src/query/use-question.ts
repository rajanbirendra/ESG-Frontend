import { useQuery } from "@tanstack/react-query";
import { getQuestionsQuestionsGetOptions } from "../api/@tanstack/react-query.gen";
import { GetQuestionsQuestionsGetData, Options } from "@/api";

export const useQuestionAPI = () => {
  return {
    getQuestions: (options: Options<GetQuestionsQuestionsGetData>) =>
      useQuery({
        ...getQuestionsQuestionsGetOptions(options),
      }),
  };
};
