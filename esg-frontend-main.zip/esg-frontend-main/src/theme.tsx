import { extendTheme } from "@chakra-ui/react";

const fonts = { mono: `'Menlo', monospace` };

const breakpoints = {
  sm: "40em",
  md: "52em",
  lg: "64em",
  xl: "80em",
};

// Logo color palette
const logoBlue = "#1976d2"; // Blue (outer arcs/dot)
const logoTeal = "#17635a"; // Teal (inner arc)
const logoGreen = "#b3d464"; // Green (leaf)

const theme = extendTheme({
  colors: {
    primary: {
      50: "#e3f0fb",
      100: "#b3d4f3",
      200: "#81b7ea",
      300: "#4e99e1",
      400: "#277fd9",
      500: logoBlue, // main
      600: "#1561b8",
      700: "#124e97",
      800: "#0e3a75",
      900: "#0a2653",
    },
    secondary: {
      50: "#e3f6f4",
      100: "#b3e1db",
      200: "#81ccc2",
      300: "#4eb7a9",
      400: "#279e91",
      500: logoTeal, // main
      600: "#13534a",
      700: "#10433c",
      800: "#0c322d",
      900: "#08221f",
    },
    success: {
      50: "#f6fae7",
      100: "#e3f3c2",
      200: "#cde99a",
      300: "#b3d464", // main (logoGreen)
      400: "#a0c24e",
      500: logoGreen,
      600: "#7e9a3a",
      700: "#5c7227",
      800: "#3a4a13",
      900: "#192200",
    },
    blue: {
      50: "#ebf8ff",
      100: "#bee3f8",
      200: "#90cdf4",
      300: "#63b3ed",
      400: "#4299e1",
      500: "#3182ce",
      600: "#2b6cb0",
      700: "#2c5282",
      800: "#2a4365",
      900: "#1A365D",
    },
    teal: {
      50: "#e6fffa",
      100: "#b2f5ea",
      200: "#81e6d9",
      300: "#4fd1c5",
      400: "#38b2ac",
      500: "#319795",
      600: "#2c7a7b",
      700: "#285e61",
      800: "#234e52",
      900: "#1D4044",
    },
    // Chakra default colors for status
    warning: {
      500: "#f6c343",
    },
    error: {
      500: "#e53e3e",
    },
    info: {
      500: "#3182ce",
    },
  },
  semanticTokens: {
    colors: {
      sidebarBg: {
        default: "white",
        _dark: "gray.800",
      },
      iconColor: {
        default: "primary.600",
        _dark: "primary.300",
      },
      mainBg: {
        default: "primary.50",
        _dark: "gray.900",
      },
      borderColor: {
        default: "gray.200",
        _dark: "gray.700",
      },
      textColor: {
        default: "primary.800",
        _dark: "primary.100",
      },
      headingColor: {
        default: "primary.900",
        _dark: "white",
      },
      activeBg: {
        default: "primary.100",
        _dark: "primary.900",
      },
      activeColor: {
        default: "primary.600",
        _dark: "primary.300",
      },
      hoverBg: {
        default: "primary.50",
        _dark: "primary.800",
      },
      searchBg: {
        default: "white",
        _dark: "primary.900",
      },
      searchBorderColor: {
        default: "primary.200",
        _dark: "primary.700",
      },
      headerBg: {
        default: "white",
        _dark: "gray.800",
      },
      headerBorderColor: {
        default: "primary.100",
        _dark: "primary.800",
      },
      success: {
        default: "success.500",
        _dark: "success.400",
      },
      warning: {
        default: "warning.500",
        _dark: "warning.400",
      },
      error: {
        default: "error.500",
        _dark: "error.400",
      },
      info: {
        default: "info.500",
        _dark: "info.400",
      },
      lowEmission: {
        default: "success.400",
        _dark: "success.300",
      },
      mediumEmission: {
        default: "warning.500",
        _dark: "warning.400",
      },
      highEmission: {
        default: "error.500",
        _dark: "error.400",
      },
    },
  },
  fonts,
  breakpoints,
  config: {
    initialColorMode: "light",
    useSystemColorMode: true,
  },
});

export default theme;
