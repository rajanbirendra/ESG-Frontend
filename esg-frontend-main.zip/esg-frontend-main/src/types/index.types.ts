export enum AssessmentType {
  SELF_ASSESSMENT = "SELF_ASSESSMENT",
  ASSESSMENT = "ASSESSMENT",
}

export enum Roles {
  USER = "USER",
  SUB_USER = "SUB_USER",
  ADMIN = "ADMIN",
}
