import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import {
  Box,
  Button,
  Flex,
  Heading,
  Image,
  Input,
  Text,
  VStack,
  HStack,
  useToast,
  InputGroup,
  InputRightElement,
  useColorModeValue,
  Container,
  FormControl,
  FormLabel,
  FormErrorMessage,
} from "@chakra-ui/react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { EyeIcon, EyeOffIcon, Mail, Lock } from "lucide-react";
import { useAuthAPI } from "../../query/use-auth";

export default function LoginPage() {
  const router = useRouter();
  const toast = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const { login } = useAuthAPI();

  // Theme colors
  const bgColor = useColorModeValue("white", "gray.800");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const headingColor = useColorModeValue("gray.700", "white");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const inputBg = useColorModeValue("gray.50", "gray.700");
  const inputBorder = useColorModeValue("gray.200", "gray.600");
  const inputHoverBorder = useColorModeValue("blue.400", "blue.300");
  const inputFocusBorder = useColorModeValue("blue.500", "blue.400");

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      setIsLoading(false);
      return;
    }

    if (token) {
      const role = token.split(".")[1];
      const decoded = JSON.parse(atob(role));
      const userRole = decoded?.role;

      if (userRole === "ADMIN") {
        router.replace("/admin-dashboard");
      } else if (userRole === "USER" || userRole === "SUB_USER") {
        router.replace("/dashboard/");
      }
    }
  }, []);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm({
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const handleLogin = (data) => {
    login.mutate({
      body: {
        ...data,
      },
    });
  };

  const [showPassword, setShowPassword] = useState(false);

  if (isLoading) {
    return (
      <Flex minH="100vh" align="center" justify="center">
        <Text>Please wait...</Text>
      </Flex>
    );
  }

  return (
    <Flex
      minH="100vh"
      align="center"
      justify="center"
      bgImage="url('/bgsignup.webp')"
      bgSize="cover"
      bgPosition="center"
      bgRepeat="no-repeat"
      bgAttachment="fixed"
      position="relative"
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        bg: "rgba(0, 0, 0, 0.4)",
        backdropFilter: "blur(4px)",
      }}
    >
      <Container maxW="container.sm" position="relative" zIndex={1}>
        <Box
          bg={bgColor}
          p={8}
          borderRadius="2xl"
          boxShadow="2xl"
          maxW="md"
          w="100%"
          mx="auto"
          position="relative"
          _before={{
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            borderRadius: "2xl",
            border: "1px solid",
            borderColor: borderColor,
            opacity: 0.1,
          }}
        >
          {/* Logo */}
          <Flex justify="center" mb={8}>
            <Image
              src="/logo.webp"
              alt="Company Logo"
              boxSize="70px"
              transition="all 0.3s ease"
              _hover={{
                transform: "scale(1.1)",
              }}
            />
          </Flex>

          {/* Heading */}
          <Heading
            size="lg"
            textAlign="center"
            mb={8}
            color={headingColor}
            fontWeight="bold"
          >
            Login to ESG Portal
          </Heading>

          {/* Form Fields */}
          <form onSubmit={handleSubmit(handleLogin)}>
            <VStack spacing={6} align="stretch">
              <FormControl isInvalid={!!errors.username}>
                <FormLabel fontWeight="medium" color={textColor}>
                  Username
                </FormLabel>
                <InputGroup>
                  <Input
                    placeholder="Enter your username"
                    bg={inputBg}
                    borderColor={inputBorder}
                    _hover={{
                      borderColor: inputHoverBorder,
                    }}
                    _focus={{
                      borderColor: inputFocusBorder,
                      boxShadow: "0 0 0 1px var(--chakra-colors-blue-500)",
                    }}
                    transition="all 0.2s ease"
                    {...register("username", { required: true })}
                  />
                </InputGroup>
                <FormErrorMessage>
                  {errors.username && "Username is required"}
                </FormErrorMessage>
              </FormControl>

              <FormControl isInvalid={!!errors.password}>
                <FormLabel fontWeight="medium" color={textColor}>
                  Password
                </FormLabel>
                <InputGroup>
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter your password"
                    bg={inputBg}
                    borderColor={inputBorder}
                    _hover={{
                      borderColor: inputHoverBorder,
                    }}
                    _focus={{
                      borderColor: inputFocusBorder,
                      boxShadow: "0 0 0 1px var(--chakra-colors-blue-500)",
                    }}
                    transition="all 0.2s ease"
                    {...register("password", { required: true })}
                  />
                  <InputRightElement width="3rem">
                    <Button
                      onClick={() => setShowPassword((v) => !v)}
                      variant="ghost"
                      size="sm"
                      aria-label={
                        showPassword ? "Hide password" : "Show password"
                      }
                      px={2}
                      _hover={{
                        bg: "transparent",
                        color: "blue.500",
                      }}
                      transition="all 0.2s ease"
                    >
                      {showPassword ? (
                        <EyeOffIcon size={18} />
                      ) : (
                        <EyeIcon size={18} />
                      )}
                    </Button>
                  </InputRightElement>
                </InputGroup>
                <FormErrorMessage>
                  {errors.password && "Password is required"}
                </FormErrorMessage>
              </FormControl>
            </VStack>

            {/* Forgot Password */}
            <HStack justify="flex-end" mt={4}>
              <Button
                variant="link"
                color="blue.500"
                fontSize="sm"
                cursor="pointer"
                _hover={{
                  color: "blue.600",
                  textDecoration: "underline",
                }}
                transition="all 0.2s ease"
                onClick={() => {
                  router.push("/forgot-password");
                }}
              >
                Forgot password ?
              </Button>
            </HStack>

            {/* Login Button */}
            <Button
              colorScheme="blue"
              width="100%"
              mt={8}
              type="submit"
              isLoading={login.isPending}
              loadingText="Logging in..."
              size="lg"
              fontWeight="medium"
              _hover={{
                transform: "translateY(-1px)",
                boxShadow: "lg",
              }}
              transition="all 0.2s ease"
            >
              Login
            </Button>
          </form>

          {/* Register Link */}
          <Text textAlign="center" fontSize="sm" mt={6} color={textColor}>
            Don't have an account?{" "}
            <Button
              variant="link"
              color="blue.500"
              fontWeight="medium"
              p={0}
              h="auto"
              minH="auto"
              onClick={() => {
                router.push("/signup");
              }}
              _hover={{
                color: "blue.600",
                textDecoration: "underline",
              }}
              transition="all 0.2s ease"
            >
              Register
            </Button>
          </Text>
        </Box>
      </Container>

      {/* Footer */}
      <Box
        position="absolute"
        bottom={0}
        left={0}
        right={0}
        py={4}
        textAlign="center"
        zIndex={2}
      >
        <Flex
          direction={{ base: "column", md: "row" }}
          justify="center"
          align="center"
          gap={{ base: 2, md: 4 }}
        >
          <Text
            color="white"
            fontSize="sm"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
          >
            © {new Date().getFullYear()} Cleaffo. All rights reserved.
          </Text>

          <Text
            as="span"
            color="white"
            fontSize="sm"
            fontWeight="medium"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
            _hover={{
              color: "blue.200",
              textDecoration: "underline",
              textShadow: "0 1px 2px rgba(0,0,0,0.7)",
            }}
            textDecoration="none"
            transition="all 0.2s ease"
            cursor="pointer"
          >
            |
          </Text>

          <Link href="/privacy-policy" passHref legacyBehavior>
            <Text
              as="span"
              color="white"
              fontSize="sm"
              fontWeight="medium"
              textShadow="0 1px 2px rgba(0,0,0,0.5)"
              _hover={{
                color: "blue.200",
                textDecoration: "underline",
                textShadow: "0 1px 2px rgba(0,0,0,0.7)",
              }}
              textDecoration="none"
              transition="all 0.2s ease"
              cursor="pointer"
            >
              Privacy Policy
            </Text>
          </Link>
        </Flex>
      </Box>
    </Flex>
  );
}
