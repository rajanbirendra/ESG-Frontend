import React, { useState, useEffect, useRef } from "react";
import {
  Box,
  Input,
  Spinner,
  Text,
  Checkbox,
  VStack,
  IconButton,
  InputGroup,
  InputRightElement
} from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

const FuelSearchDropdown = ({
  category,           // One of "refrigerants", "stationary_fuels", "mobile_fuels", "process_emission_fuels"
  placeholder = "Search fuels...",
  onSelect,           // Callback that receives an array of selected fuel objects
  token,              // Authorization token
  debounceTime = 300  // Delay to debounce API calls (ms)
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const containerRef = useRef();

  // Function to perform fetch from the API with a given search string.
  const fetchResults = (term) => {
    setLoading(true);
    const url = `https://backend.paudyals.com/api/search-fuels?category=${category}&search=${encodeURIComponent(term)}`;
    console.log("[FuelSearchDropDown] Fetch URL:", url);
    fetch(url, {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${token}`
      }
    })
      .then((res) => {
        console.log("[FuelSearchDropDown] Received response:", res);
        return res.json();
      })
      .then((data) => {
        console.log("[FuelSearchDropDown] Data received:", data);
        setResults(data.results || []);
        setLoading(false);
        setMenuOpen(true);
      })
      .catch((err) => {
        console.error("[FuelSearchDropDown] Error fetching data:", err);
        setLoading(false);
        setResults([]);
      });
  };

  // useEffect to debounce automatic search when typing.
  useEffect(() => {
    console.log("[FuelSearchDropDown] useEffect triggered. searchTerm:", searchTerm);
    let isMounted = true;
    // If the user clears the text, close the menu.
    if (searchTerm.trim() === "") {
      if (isMounted) {
        setResults([]);
        setMenuOpen(false);
      }
      return;
    }
    const timer = setTimeout(() => {
      if (!isMounted) return;
      console.log("[FuelSearchDropDown] Debounced search for:", searchTerm);
      fetchResults(searchTerm);
    }, debounceTime);
    return () => {
      console.log("[FuelSearchDropDown] Clearing debounce timer.");
      isMounted = false;
      clearTimeout(timer);
    };
  }, [searchTerm, category, token, debounceTime]);

  // Document click listener: close dropdown when clicking outside.
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        console.log("[FuelSearchDropDown] Click outside detected, closing menu.");
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  // This function is called when the down button is pressed.
  // It performs a search with an empty string.
  const listAllResults = () => {
    console.log("[FuelSearchDropDown] Down button pressed, listing all results.");
    setSearchTerm(""); // Optionally, clear any existing text.
    fetchResults("");
  };

  // Toggle selection when a fuel option is clicked.
  const handleToggleOption = (fuel) => {
    console.log("[FuelSearchDropDown] Toggling fuel:", fuel);
    const exists = selectedOptions.find((opt) => opt.id === fuel.id);
    let newSelections;
    if (exists) {
      newSelections = selectedOptions.filter((opt) => opt.id !== fuel.id);
    } else {
      newSelections = [...selectedOptions, fuel];
    }
    console.log("[FuelSearchDropDown] Updated selections:", newSelections);
    setSelectedOptions(newSelections);
    if (onSelect) onSelect(newSelections);
  };

  return (
    <Box position="relative" ref={containerRef}>
      <InputGroup>
        <Input
          placeholder={placeholder}
          value={searchTerm}
          onChange={(e) => {
            console.log("[FuelSearchDropDown] Input changed:", e.target.value);
            setSearchTerm(e.target.value);
          }}
          onFocus={() => {
            console.log("[FuelSearchDropDown] Input focused.");
            if (results.length > 0) setMenuOpen(true);
          }}
        />
        <InputRightElement width="3rem">
          <IconButton
            aria-label="Show all fuels"
            icon={<ChevronDownIcon />}
            size="xs"
            onClick={listAllResults}
            variant="ghost"
          />
        </InputRightElement>
      </InputGroup>
      {loading && (
        <Spinner
          size="sm"
          position="absolute"
          right="3rem"
          top="50%"
          transform="translateY(-50%)"
        />
      )}
      {menuOpen && results.length > 0 && (
        <Box
          position="absolute"
          zIndex="10"
          width="100%"
          bg="white"
          border="1px solid"
          borderColor="gray.200"
          borderRadius="md"
          mt="2"
          maxH="200px"
          overflowY="auto"
        >
          <VStack spacing={0} align="stretch">
            {results.map((fuel) => (
              <Box
                key={fuel.id}
                px={4}
                py={2}
                as="button"
                textAlign="left"
                _hover={{ bg: "gray.100" }}
                onClick={() => handleToggleOption(fuel)}
              >
                <Checkbox
                  isChecked={!!selectedOptions.find((opt) => opt.id === fuel.id)}
                  pointerEvents="none"  // prevent checkbox from interfering with click handling
                >
                  {fuel.value}
                </Checkbox>
              </Box>
            ))}
          </VStack>
        </Box>
      )}
      {menuOpen && !loading && results.length === 0 && (
        <Box
          position="absolute"
          zIndex="10"
          width="100%"
          bg="white"
          border="1px solid"
          borderColor="gray.200"
          borderRadius="md"
          mt="2"
          p="2"
        >
          <Text fontSize="sm" color="gray.500">
            No results found.
          </Text>
        </Box>
      )}
    </Box>
  );
};

export default FuelSearchDropdown;
