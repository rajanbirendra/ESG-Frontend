import React, { useState } from "react";
import {
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Button,
  Checkbox,
  Box,
  Flex,
  Input,
  useToast,
} from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

export default function FormatDropdown({ selectedFormats, onFormatsChange }) {
  const [formats, setFormats] = useState<any>([]);
  const [hasFetched, setHasFetched] = useState(false);

  const [isAddingFormat, setIsAddingFormat] = useState(false);
  const [tempNewFormat, setTempNewFormat] = useState("");

  const toast = useToast();

  const token =
    typeof window !== "undefined" ? localStorage.getItem("token") : "";

  const handleMenuOpen = async () => {
    if (hasFetched) return;
    try {
      const response = await fetch(
        "https://backend.paudyals.com/api/admin/upload-formats",
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (!response.ok) {
        throw new Error("Failed to fetch upload formats");
      }
      const data = await response.json();
      setFormats(data.upload_formats);
      setHasFetched(true);
    } catch (error) {
      console.error("Error fetching formats:", error);
      toast({
        title: "Error fetching formats",
        description: error.message,
        status: "error",
        duration: 3000,
        isClosable: true,
      });
    }
  };

  const handleToggleFormat = (formatName) => {
    if (selectedFormats.includes(formatName)) {
      onFormatsChange(selectedFormats.filter((f) => f !== formatName));
    } else {
      onFormatsChange([...selectedFormats, formatName]);
    }
  };

  const handleAddFormatClick = () => {
    setIsAddingFormat(true);
  };

  const handleConfirmNewFormat = async () => {
    const newFormatName = tempNewFormat.trim();
    if (!newFormatName) return;

    try {
      const response = await fetch(
        "https://backend.paudyals.com/api/admin/upload-formats",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            format_name: newFormatName,
          }),
        }
      );
      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.message || "Failed to add new format");
      }
      const data = await response.json();
      setFormats((prev: any) => [
        ...prev,
        { id: data.format_id, format_name: newFormatName },
      ]);
      onFormatsChange([...selectedFormats, newFormatName]);
      toast({
        title: data.message || "Upload format added successfully",
        status: "success",
        duration: 3000,
        isClosable: true,
      });
    } catch (error) {
      console.error("Error adding format:", error);
      toast({
        title: "Error adding format",
        description: error.message,
        status: "error",
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setIsAddingFormat(false);
      setTempNewFormat("");
    }
  };

  const displayText =
    selectedFormats.length > 0
      ? selectedFormats.join(", ")
      : "Select acceptable formats";

  return (
    <Box>
      <Menu onOpen={handleMenuOpen} closeOnSelect={false}>
        <MenuButton
          as={Button}
          variant="outline"
          colorScheme="blue"
          rightIcon={<ChevronDownIcon />}
          isDisabled={isAddingFormat}
        >
          {displayText}
        </MenuButton>
        {!isAddingFormat && (
          <MenuList minW="200px">
            {formats.map((item) => {
              const isChecked = selectedFormats.includes(item.format_name);
              return (
                <MenuItem
                  key={item.id}
                  closeOnSelect={false}
                  onClick={() => handleToggleFormat(item.format_name)}
                >
                  <Checkbox
                    isChecked={isChecked}
                    onChange={() => handleToggleFormat(item.format_name)}
                  >
                    {item.format_name}
                  </Checkbox>
                </MenuItem>
              );
            })}
            <MenuItem onClick={handleAddFormatClick}>+ Add a format</MenuItem>
          </MenuList>
        )}
      </Menu>
      {isAddingFormat && (
        <Box mt={2}>
          <Input
            placeholder="Enter new format"
            value={tempNewFormat}
            onChange={(e) => setTempNewFormat(e.target.value)}
          />
          <Flex justify="flex-end" mt={2} gap={2}>
            <Button
              size="sm"
              colorScheme="blue"
              onClick={handleConfirmNewFormat}
            >
              Confirm
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={() => {
                setIsAddingFormat(false);
                setTempNewFormat("");
              }}
            >
              Cancel
            </Button>
          </Flex>
        </Box>
      )}
    </Box>
  );
}
