import React from "react";
import { Menu, MenuButton, MenuList, MenuItem, Button } from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

export default function QuestionTypeDropdown({ selectedType, onTypeSelected }) {
  const options = ["Default Questions", "Custom Questions"];
  return (
    <Menu>
      <MenuButton
        as={Button}
        variant="outline"
        colorScheme="blue"
        rightIcon={<ChevronDownIcon />}
      >
        {selectedType || "Default Questions"}
      </MenuButton>
      <MenuList>
        {options.map((option, idx) => (
          <MenuItem key={idx} onClick={() => onTypeSelected(option)}>
            {option}
          </MenuItem>
        ))}
      </MenuList>
    </Menu>
  );
}
