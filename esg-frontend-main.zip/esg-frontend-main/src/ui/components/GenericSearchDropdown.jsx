// src/components/GenericSearchDropdown.jsx
import React, { useState, useEffect, useRef } from "react";
import {
  Box,
  Input,
  Spinner,
  Text,
  Checkbox,
  VStack,
  IconButton,
  InputGroup,
  InputRightElement
} from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

const GenericSearchDropdown = ({
  searchEndpoint,       // The API endpoint URL (without query parameters)
  placeholder = "Search...",
  onSelect,             // Callback that receives an array of selected option objects
  token,                // Authorization token
  debounceTime = 300    // Delay in milliseconds to debounce API calls
}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState([]);
  const containerRef = useRef();

  // Function to fetch results from the dynamic API endpoint.
  const fetchResults = (term) => {
    setLoading(true);
    const url = `${searchEndpoint}?search=${encodeURIComponent(term)}`;
    // Debug log:
    console.log("[GenericSearchDropdown] Fetching:", url);
    fetch(url, {
      headers: {
        Accept: "application/json",
        Authorization: `Bearer ${token}`
      }
    })
      .then((res) => res.json())
      .then((data) => {
        setResults(data.results || []);
        setLoading(false);
        setMenuOpen(true);
      })
      .catch((err) => {
        console.error("[GenericSearchDropdown] Error fetching data:", err);
        setLoading(false);
        setResults([]);
      });
  };

  // Debounce the search input.
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchTerm.trim() === "") {
        setResults([]);
        setMenuOpen(false);
      } else {
        fetchResults(searchTerm);
      }
    }, debounceTime);
    return () => clearTimeout(timer);
  }, [searchTerm, debounceTime, searchEndpoint, token]);

  // Close the dropdown if clicking outside.
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (containerRef.current && !containerRef.current.contains(event.target)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Function to toggle selection of an option.
  const handleToggleOption = (option) => {
    const alreadySelected = selectedOptions.find((opt) => opt.id === option.id);
    let newSelections;
    if (alreadySelected) {
      newSelections = selectedOptions.filter((opt) => opt.id !== option.id);
    } else {
      newSelections = [...selectedOptions, option];
    }
    setSelectedOptions(newSelections);
    if (onSelect) onSelect(newSelections);
  };

  // Function to list all results (by triggering a search with an empty term).
  const listAllResults = () => {
    setSearchTerm("");
    fetchResults("");
  };

  return (
    <Box position="relative" ref={containerRef}>
      <InputGroup>
        <Input
          placeholder={placeholder}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onFocus={() => {
            if (results.length > 0) {
              setMenuOpen(true);
            }
          }}
        />
        <InputRightElement width="3rem">
          <IconButton
            aria-label="Show all"
            icon={<ChevronDownIcon />}
            size="xs"
            onClick={listAllResults}
            variant="ghost"
          />
        </InputRightElement>
      </InputGroup>
      {loading && (
        <Spinner
          size="sm"
          position="absolute"
          right="3rem"
          top="50%"
          transform="translateY(-50%)"
        />
      )}
      {menuOpen && results.length > 0 && (
        <Box
          position="absolute"
          zIndex="10"
          width="100%"
          bg="white"
          border="1px solid"
          borderColor="gray.200"
          borderRadius="md"
          mt="2"
          maxH="200px"
          overflowY="auto"
        >
          <VStack spacing={0} align="stretch">
            {results.map((option) => (
              <Box
                key={option.id}
                px={4}
                py={2}
                as="button"
                textAlign="left"
                _hover={{ bg: "gray.100" }}
                onClick={() => handleToggleOption(option)}
              >
                <Checkbox
                  isChecked={!!selectedOptions.find((opt) => opt.id === option.id)}
                  pointerEvents="none"
                >
                  {option.value}
                </Checkbox>
              </Box>
            ))}
          </VStack>
        </Box>
      )}
      {menuOpen && !loading && results.length === 0 && (
        <Box
          position="absolute"
          zIndex="10"
          width="100%"
          bg="white"
          border="1px solid"
          borderColor="gray.200"
          borderRadius="md"
          mt="2"
          p="2"
        >
          <Text fontSize="sm" color="gray.500">
            No results found.
          </Text>
        </Box>
      )}
    </Box>
  );
};

export default GenericSearchDropdown;
