import React from "react";
import { Box } from "@chakra-ui/react";
import { Download } from "lucide-react";
import html2canvas from "html2canvas";

interface ChartDownloadButtonProps {
  targetRef: React.RefObject<HTMLElement>;
  filename?: string;
  size?: number;
  title?: string;
  branch?: string;
  date?: string;
  forceHtml2Canvas?: boolean;
}

function svgStringToImage(
  svgString: string,
  width: number,
  height: number,
  callback: (img: HTMLImageElement) => void
) {
  const img = new window.Image();
  const svg = new Blob([svgString], { type: "image/svg+xml;charset=utf-8" });
  const url = URL.createObjectURL(svg);
  img.onload = function () {
    callback(img);
    URL.revokeObjectURL(url);
  };
  img.onerror = function () {
    URL.revokeObjectURL(url);
  };
  img.src = url;
}

const ChartDownloadButton: React.FC<ChartDownloadButtonProps> = ({
  targetRef,
  filename = "chart.png",
  size = 18,
  title,
  branch,
  date,
  forceHtml2Canvas = false,
}) => {
  const handleDownload = async () => {
    if (targetRef.current) {
      if (!forceHtml2Canvas) {
        // Try to find the SVG node inside the chart container
        const svg = targetRef.current.querySelector("svg");
        if (svg) {
          // Clone the SVG to avoid modifying the DOM
          const clonedSvg = svg.cloneNode(true) as SVGSVGElement;
          // Get width/height
          const bbox = svg.getBoundingClientRect();
          const width = bbox.width || 800;
          const height = bbox.height || 400;
          // Add header if needed
          let headerHeight = 0;
          if (title || branch || date) {
            headerHeight = 56; // px, increased for better spacing
            clonedSvg.setAttribute("height", String(height + headerHeight));

            // Wrap all original children (except defs/rect) in a <g> and translate down
            const g = document.createElementNS(
              "http://www.w3.org/2000/svg",
              "g"
            );
            g.setAttribute("transform", `translate(0,${headerHeight})`);
            const childrenToMove = Array.from(clonedSvg.childNodes).filter(
              (child) =>
                child.nodeType === 1 &&
                (child as Element).tagName !== "defs" &&
                (child as Element).tagName !== "rect"
            );
            for (const child of childrenToMove) {
              g.appendChild(child); // This removes from root automatically
            }
            // Insert the group after defs/rect
            const insertAfter =
              clonedSvg.querySelector("rect") ||
              clonedSvg.querySelector("defs");
            if (insertAfter && insertAfter.nextSibling) {
              clonedSvg.insertBefore(g, insertAfter.nextSibling);
            } else {
              clonedSvg.appendChild(g);
            }

            // Create header group
            const headerGroup = document.createElementNS(
              "http://www.w3.org/2000/svg",
              "g"
            );
            // Title
            if (title) {
              const titleText = document.createElementNS(
                "http://www.w3.org/2000/svg",
                "text"
              );
              titleText.setAttribute("x", "24");
              titleText.setAttribute("y", "32");
              titleText.setAttribute("font-size", "20");
              titleText.setAttribute("font-weight", "600");
              titleText.setAttribute("fill", "#2d3748");
              titleText.textContent = title;
              headerGroup.appendChild(titleText);
            }
            // Branch and date
            if (branch || date) {
              const metaText = document.createElementNS(
                "http://www.w3.org/2000/svg",
                "text"
              );
              metaText.setAttribute("x", "24");
              metaText.setAttribute("y", "50");
              metaText.setAttribute("font-size", "14");
              metaText.setAttribute("font-weight", "400");
              metaText.setAttribute("fill", "#4a5568");
              let meta = branch ? `Branch: ${branch}` : "";
              if (branch && date) meta += " | ";
              if (date) meta += `Date: ${date}`;
              metaText.textContent = meta;
              headerGroup.appendChild(metaText);
            }
            // Insert header group at the top
            clonedSvg.insertBefore(headerGroup, clonedSvg.firstChild);
          }
          // Optionally, add a white background
          const rect = document.createElementNS(
            "http://www.w3.org/2000/svg",
            "rect"
          );
          rect.setAttribute("width", String(width));
          rect.setAttribute("height", String(height + headerHeight));
          rect.setAttribute("fill", "#fff");
          clonedSvg.insertBefore(rect, clonedSvg.firstChild);
          // Serialize SVG
          const serializer = new XMLSerializer();
          const svgString = serializer.serializeToString(clonedSvg);
          // Draw SVG to canvas
          svgStringToImage(svgString, width, height + headerHeight, (img) => {
            const canvas = document.createElement("canvas");
            canvas.width = width;
            canvas.height = height + headerHeight;
            const ctx = canvas.getContext("2d");
            if (ctx) {
              ctx.drawImage(img, 0, 0, width, height + headerHeight);
              const link = document.createElement("a");
              link.download = filename;
              link.href = canvas.toDataURL();
              link.click();
            }
          });
          // NOTE: Recharts legend is often rendered as HTML, not SVG, so it may not appear in the SVG export. For full legend capture, use html2canvas instead.
          return;
        }
      }
      // Always use html2canvas if forceHtml2Canvas is true or SVG is not found
      const canvas = await html2canvas(targetRef.current, {
        backgroundColor: null,
        useCORS: true,
        scale: 2,
      });
      const link = document.createElement("a");
      link.download = filename;
      link.href = canvas.toDataURL();
      link.click();
    }
  };

  return (
    <Box
      as="button"
      aria-label="Download chart"
      onClick={handleDownload}
      ml={2}
      p={1}
      borderRadius="md"
      _hover={{ bg: "gray.100" }}
      transition="all 0.2s"
      display="flex"
      alignItems="center"
      justifyContent="center"
    >
      <Download size={size} style={{ color: "#2B6CB0" }} />
    </Box>
  );
};

export default ChartDownloadButton;
