import React, { useState } from "react";
import { Menu, MenuButton, MenuList, MenuItem, Button } from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

export default function Dropdown({ selectedBranch, onBranchSelected }) {
  const [companies, setCompanies] = useState([]);
  const [hasFetched, setHasFetched] = useState(false);

  // Retrieve token from localStorage
  const token =
    typeof window !== "undefined" ? localStorage.getItem("token") : "";

  // Fetch companies from backend when the menu opens (only once)
  const handleMenuOpen = async () => {
    if (hasFetched) return;
    try {
      const response = await fetch(
        "https://backend.paudyals.com/api/admin/companies",
        {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (!response.ok) throw new Error("Failed to fetch companies");
      const data = await response.json();
      setCompanies(data.companies);
      setHasFetched(true);
    } catch (error) {
      console.error("Error fetching companies:", error);
    }
  };

  // Pass the whole company object so its id and name are available
  const handleSelectBranch = (company) => {
    onBranchSelected(company);
  };

  return (
    <Menu onOpen={handleMenuOpen}>
      <MenuButton
        as={Button}
        variant="outline"
        colorScheme="blue"
        rightIcon={<ChevronDownIcon />}
      >
        {selectedBranch && selectedBranch.company_name
          ? selectedBranch.company_name
          : "Select a company"}
      </MenuButton>
      <MenuList>
        {companies.map((company) => (
          <MenuItem
            // @ts-ignore
            key={company?.id}
            onClick={() => handleSelectBranch(company)}
          >
            {/* @ts-ignore */}
            {company?.company_name}
          </MenuItem>
        ))}
      </MenuList>
    </Menu>
  );
}
