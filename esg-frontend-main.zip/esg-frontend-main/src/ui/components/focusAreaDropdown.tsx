import React from "react";
import { Menu, MenuButton, MenuList, MenuItem, Button } from "@chakra-ui/react";
import { ChevronDownIcon } from "@chakra-ui/icons";

export default function FocusAreaDropdown({ selectedFocus, onFocusSelected }) {
  const focusAreas = ["Environment", "Social", "Governance"];

  return (
    <Menu>
      <MenuButton
        as={Button}
        variant="outline"
        colorScheme="blue"
        rightIcon={<ChevronDownIcon />}
      >
        {selectedFocus || "Focus area"}
      </MenuButton>
      <MenuList>
        {focusAreas.map((area, idx) => (
          <MenuItem key={idx} onClick={() => onFocusSelected(area)}>
            {area}
          </MenuItem>
        ))}
      </MenuList>
    </Menu>
  );
}
