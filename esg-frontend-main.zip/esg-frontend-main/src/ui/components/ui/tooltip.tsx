import { Tooltip as ChakraTooltip, Portal } from "@chakra-ui/react";
import * as React from "react";

// @ts-ignore
export interface TooltipProps extends ChakraTooltip.RootProps {
  showArrow?: boolean;
  portalled?: boolean;
  portalRef?: React.RefObject<HTMLElement>;
  content: React.ReactNode;
  // @ts-ignore
  contentProps?: ChakraTooltip.ContentProps;
  disabled?: boolean;
}

export const Tooltip = React.forwardRef<HTMLDivElement, TooltipProps>(
  function Tooltip(props, ref) {
    const {
      showArrow,
      // @ts-ignore
      children,
      disabled,
      portalled = true,
      content,
      contentProps,
      portalRef,
      ...rest
    } = props;

    if (disabled) return children;

    // @ts-ignore
    return (
      // @ts-ignore
      <ChakraTooltip.Root {...rest}>
        {/* @ts-ignore */}
        <ChakraTooltip.Trigger asChild>{children}</ChakraTooltip.Trigger>
        {/* @ts-ignore */}
        <Portal disabled={!portalled} container={portalRef}>
          {/* @ts-ignore */}
          <ChakraTooltip.Positioner>
            {/* @ts-ignore */}
            <ChakraTooltip.Content ref={ref} {...contentProps}>
              {showArrow && (
                <>
                  {/* @ts-ignore */}
                  <ChakraTooltip.Arrow />
                  {/* @ts-ignore*/}
                  <ChakraTooltip.ArrowTip />
                </>
              )}
              {content}
              {/* @ts-ignore */}
            </ChakraTooltip.Content>
            {/* @ts-ignore */}
          </ChakraTooltip.Positioner>
          {/* @ts-ignore */}
        </Portal>
        {/* @ts-ignore */}
      </ChakraTooltip.Root>
    );
  }
);
