import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  AlertDialogCloseButton,
  Button,
  FormControl,
  FormErrorMessage,
  FormLabel,
  Textarea,
  VStack,
  useDisclosure,
  Select,
  useToast,
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  HStack,
  IconButton,
  Box,
  Text,
  Divider,
  Badge,
  Input,
} from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import React, { useRef, useState, useEffect } from "react";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";
import CustomYearDropdown from "@/ui/molecules/dropdown/CustomYearDropdown";
import { Plus, Info } from "lucide-react";
import {
  useCreateReport,
  createReportData,
  useReportTypes,
} from "@/query/use-report";
import { useAssessmentsAPI } from "@/query/use-assessments";

interface RequestReportProps {
  buttonText?: string;
}

interface FormData {
  framework: string;
  legal_company_name: string;
  cin_number: string;
  report_person_name: string;
  remarks: string;
}

// Framework information data
const frameworkInfo = {
  GRI: {
    name: "Global Reporting Initiative (GRI)",
    focus: "Stakeholder impact and materiality",
    coverage:
      "Broad ESG topics (environment, labor, human rights, anti-corruption)",
    audience: "Stakeholders (customers, community, investors)",
    voluntary: "Voluntary, but widely adopted globally",
    bestFor: "Comprehensive sustainability disclosure",
    icon: "🌍",
  },
  SASB: {
    name: "Sustainability Accounting Standards Board (SASB)",
    focus: "Financial materiality and industry-specific ESG issues",
    coverage: "77 industry-specific standards",
    audience: "Investors",
    voluntary: "Voluntary, increasingly integrated with financial disclosures",
    bestFor: "Public companies and investor-focused reporting",
    icon: "📈",
  },
  TCFD: {
    name: "Task Force on Climate-related Financial Disclosures (TCFD)",
    focus: "Climate-related financial risk",
    coverage:
      "Governance, strategy, risk management, and metrics related to climate",
    audience: "Investors, lenders, insurers",
    voluntary: "Voluntary, but mandatory in some jurisdictions (UK, Japan)",
    bestFor: "Climate risk and opportunity disclosure",
    icon: "📊",
  },
  "ISSB - IFRS S1 & S2": {
    name: "International Sustainability Standards Board (ISSB – IFRS S1 & S2)",
    focus: "Unified global baseline for sustainability disclosure",
    coverage: "General ESG (IFRS S1) + climate-related disclosure (IFRS S2)",
    audience: "Investors",
    voluntary: "Voluntary, becoming regulatory in some jurisdictions",
    bestFor: "Companies seeking harmonized and investor-relevant ESG reporting",
    icon: "📃",
  },
  CDP: {
    name: "CDP (Carbon Disclosure Project)",
    focus: "Environmental disclosure – climate, water, forests",
    coverage: "Detailed GHG emissions, environmental risks, and opportunities",
    audience: "Investors, customers, governments",
    voluntary: "Voluntary; often used by large global brands and suppliers",
    bestFor: "Environmental disclosure and benchmarking",
    icon: "♻️",
  },
  ESRS: {
    name: "European Sustainability Reporting Standards (ESRS) – under CSRD",
    focus: "Double materiality (impact + financial) for EU companies",
    coverage: "Environment, social, governance with mandatory metrics",
    audience: "Regulators, investors, public",
    voluntary: "Mandatory under CSRD (starting 2024 for large companies)",
    bestFor: "EU-based companies or those operating significantly in the EU",
    icon: "🇪🇺",
  },
  BRSR: {
    name: "Business Responsibility and Sustainability Report (BRSR)",
    focus: "Indian sustainability and responsibility reporting",
    coverage: "Environmental, social, and governance performance",
    audience: "Indian companies and stakeholders",
    voluntary: "Mandatory for top 1000 Indian companies",
    bestFor: "Indian sustainability compliance",
    icon: "🇮🇳",
  },
  Others: {
    name: "Other ESG Reporting Frameworks",
    focus: "Various specialized reporting needs",
    coverage: "Depends on specific framework",
    audience: "Varies by framework",
    voluntary: "Varies by framework and jurisdiction",
    bestFor: "Specialized or emerging reporting needs",
    icon: "📋",
  },
};

export default function RequestReport({
  buttonText = "Request Report",
}: RequestReportProps) {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const {
    isOpen: isInfoOpen,
    onOpen: onInfoOpen,
    onClose: onInfoClose,
  } = useDisclosure();
  const cancelRef = useRef<HTMLButtonElement>(null);
  const toast = useToast();
  const [selectedFramework, setSelectedFramework] = useState<string>("");

  // Month/year logic
  const monthOptions = [
    { value: "01", label: "Jan" },
    { value: "04", label: "Apr" },
  ];
  const [startMonth, setStartMonth] = useState("");
  const [startYear, setStartYear] = useState("");
  const [endMonth, setEndMonth] = useState("");
  const [endYear, setEndYear] = useState("");

  // Handler for starting month/year change
  const handleStartChange = (month: string, year: string) => {
    setStartMonth(month);
    setStartYear(year);
    if (month === "01") {
      setEndMonth("12");
      setEndYear(year);
    } else if (month === "04") {
      setEndMonth("03");
      setEndYear((parseInt(year) + 1).toString());
    } else {
      setEndMonth("");
      setEndYear("");
    }
  };

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm<FormData>();

  const createReportMutation = useCreateReport();
  const { data: reportTypes, isLoading: isLoadingReportTypes } =
    useReportTypes();
  const { data: assessmentDoneYears, isLoading: isLoadingYears } =
    useAssessmentsAPI().getAssessmentDoneYears();

  // Remove watchedYear, setSelectedYear, etc.

  const handleRequestReport = async (data: FormData) => {
    if (!startMonth || !startYear || !endMonth || !endYear) {
      toast({
        title: "Please select a valid period",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
      return;
    }
    try {
      await createReportMutation.mutateAsync(
        createReportData({
          type: data.framework as any,
          starting_year_month: `${startYear}-${startMonth}`,
          ending_year_month: `${endYear}-${endMonth}`,
          legal_company_name: data.legal_company_name,
          cin_number: data.cin_number,
          report_person_name: data.report_person_name,
          remarks: data.remarks || null,
        })
      );

      toast({
        title: "Report Requested",
        description: "Your report request has been submitted successfully.",
        status: "success",
        duration: 5000,
        isClosable: true,
      });

      onClose();
      reset();
      setStartMonth("");
      setStartYear("");
      setEndMonth("");
      setEndYear("");
      setSelectedFramework("");
    } catch (error) {
      console.error("Error requesting report:", error);
    }
  };

  // handleYearChange function removed as it's no longer needed

  const handleInfoClick = (framework: string) => {
    setSelectedFramework(framework);
    onInfoOpen();
  };

  return (
    <>
      <Button
        onClick={onOpen}
        leftIcon={<Plus size={20} />}
        colorScheme="blue"
        size="lg"
        fontWeight="bold"
        borderRadius="xl"
        _hover={{
          transform: "translateY(-2px)",
          boxShadow: "lg",
        }}
        transition="all 0.2s"
      >
        {buttonText}
      </Button>

      <AlertDialog
        isOpen={isOpen}
        leastDestructiveRef={cancelRef}
        onClose={onClose}
        isCentered
      >
        <AlertDialogOverlay>
          <AlertDialogContent maxW="500px">
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              Request Report
              <AlertDialogCloseButton />
            </AlertDialogHeader>

            <form onSubmit={handleSubmit(handleRequestReport)}>
              <AlertDialogBody>
                <VStack spacing={4}>
                  {/* Framework field moved to the top */}
                  <FormControl isInvalid={!!errors.framework}>
                    <FormLabel fontWeight="semibold">
                      Framework <span style={{ color: "red" }}>*</span>
                    </FormLabel>
                    <HStack spacing={2}>
                      <Select
                        placeholder={
                          isLoadingReportTypes
                            ? "Loading frameworks..."
                            : "Select framework"
                        }
                        {...register("framework", {
                          required: "Framework is required",
                        })}
                        isDisabled={isLoadingReportTypes}
                        flex={1}
                        onChange={(e) => {
                          setSelectedFramework(e.target.value);
                          setValue("framework", e.target.value);
                        }}
                        value={selectedFramework}
                      >
                        {Array.isArray(reportTypes) &&
                          reportTypes.map((type) => {
                            const typeValue =
                              typeof type === "object" ? type.value : type;
                            const typeLabel =
                              typeof type === "object" ? type.label : type;

                            return (
                              <option key={typeValue} value={typeValue}>
                                {typeValue === "GRI" &&
                                  "GRI - Global Reporting Initiative Standards"}
                                {typeValue === "SASB" &&
                                  "SASB - Sustainability Accounting Standards Board"}
                                {typeValue === "TCFD" &&
                                  "TCFD - Task Force on Climate-related Financial Disclosures"}
                                {typeValue === "ISSB - IFRS S1 & S2" &&
                                  "ISSB - IFRS S1 & S2 - International Sustainability Standards Board"}
                                {typeValue === "CDP" &&
                                  "CDP - Carbon Disclosure Project"}
                                {typeValue === "ESRS" &&
                                  "ESRS - European Sustainability Reporting Standards"}
                                {typeValue === "BRSR" &&
                                  "BRSR - Business Responsibility and Sustainability Report"}
                                {typeValue === "Others" &&
                                  "Others - Other ESG reporting frameworks"}
                                {![
                                  "GRI",
                                  "SASB",
                                  "TCFD",
                                  "ISSB - IFRS S1 & S2",
                                  "CDP",
                                  "ESRS",
                                  "BRSR",
                                  "Others",
                                ].includes(typeValue) && typeLabel}
                              </option>
                            );
                          })}
                      </Select>
                      <IconButton
                        aria-label="Framework information"
                        icon={<Info size={16} />}
                        size="md"
                        variant="outline"
                        colorScheme="primary"
                        onClick={() => handleInfoClick(selectedFramework)}
                        isDisabled={!selectedFramework || isLoadingReportTypes}
                        _hover={{ bg: "primary.50" }}
                      />
                    </HStack>
                    <FormErrorMessage>
                      {errors.framework && errors.framework.message}
                    </FormErrorMessage>
                  </FormControl>

                  {/* Legal Company Name */}
                  <FormControl isRequired>
                    <FormLabel fontWeight="semibold">
                      Legal Company Name
                    </FormLabel>
                    <Input
                      placeholder="Enter legal company name"
                      {...register("legal_company_name", {
                        required: "Legal company name is required",
                      })}
                      isInvalid={!!errors.legal_company_name}
                    />
                    <FormErrorMessage>
                      {errors.legal_company_name &&
                        errors.legal_company_name.message}
                    </FormErrorMessage>
                  </FormControl>

                  {/* CIN Number */}
                  <FormControl isRequired>
                    <FormLabel fontWeight="semibold">CIN Number</FormLabel>
                    <Input
                      placeholder="Enter CIN number"
                      {...register("cin_number", {
                        required: "CIN number is required",
                      })}
                      isInvalid={!!errors.cin_number}
                    />
                    <FormErrorMessage>
                      {errors.cin_number && errors.cin_number.message}
                    </FormErrorMessage>
                  </FormControl>

                  {/* Report Person Name */}
                  <FormControl isRequired>
                    <FormLabel fontWeight="semibold">
                      Report Person Name
                    </FormLabel>
                    <Input
                      placeholder="Enter report person name"
                      {...register("report_person_name", {
                        required: "Report person name is required",
                      })}
                      isInvalid={!!errors.report_person_name}
                    />
                    <FormErrorMessage>
                      {errors.report_person_name &&
                        errors.report_person_name.message}
                    </FormErrorMessage>
                  </FormControl>

                  {/* Starting Month */}
                  <FormControl isRequired>
                    <FormLabel fontWeight="semibold">
                      Select Starting Year and Month
                    </FormLabel>
                    <HStack spacing={1} width="100%">
                      <Box flex={1}>
                        <CustomYearDropdown
                          selectedYear={startYear}
                          onSelectYear={(year) =>
                            handleStartChange(startMonth, year)
                          }
                          years={assessmentDoneYears as string[]}
                        />
                      </Box>
                      <Box flex={1}>
                        <Select
                          value={startMonth}
                          onChange={(e) =>
                            handleStartChange(e.target.value, startYear)
                          }
                          placeholder="Month"
                          width="100%"
                        >
                          {monthOptions.map((opt) => (
                            <option key={opt.value} value={opt.value}>
                              {opt.label}
                            </option>
                          ))}
                        </Select>
                      </Box>
                    </HStack>
                    <Text fontSize="sm" color="gray.500" mt={2}>
                      It can be either Jan or April of any year
                    </Text>
                    <Text
                      fontSize="sm"
                      color="blue.600"
                      mt={1}
                      fontWeight="medium"
                    >
                      Note: Years will only appear for completed assessments
                    </Text>
                  </FormControl>

                  {/* Last Month as label */}
                  <FormControl isRequired>
                    <FormLabel fontWeight="semibold">Upto</FormLabel>
                    <Box
                      px={2}
                      py={2}
                      bg="gray.50"
                      borderRadius="md"
                      border="1px solid"
                      borderColor="gray.200"
                      minW="120px"
                    >
                      <Text fontWeight="medium" color="gray.700">
                        {endMonth && endYear
                          ? `${
                              endMonth === "12"
                                ? "Dec"
                                : endMonth === "03"
                                ? "Mar"
                                : endMonth
                            } ${endYear}`
                          : "-"}
                      </Text>
                    </Box>
                    <Text fontSize="sm" color="gray.500" mt={2}>
                      {startMonth === "01"
                        ? "If you select Jan, last month is Dec of the same year."
                        : startMonth === "04"
                        ? "If you select Apr, last month is Mar of the next year."
                        : ""}
                    </Text>
                  </FormControl>

                  <FormControl isInvalid={!!errors.remarks}>
                    <FormLabel fontWeight="semibold">Remarks</FormLabel>
                    <Textarea
                      placeholder="Enter any additional remarks (optional)"
                      {...register("remarks")}
                      rows={3}
                    />
                    <FormErrorMessage>
                      {errors.remarks && errors.remarks.message}
                    </FormErrorMessage>
                  </FormControl>
                </VStack>
              </AlertDialogBody>

              <AlertDialogFooter>
                <Button ref={cancelRef} onClick={onClose}>
                  Cancel
                </Button>
                <Button
                  colorScheme="blue"
                  ml={3}
                  type="submit"
                  isLoading={createReportMutation.isPending}
                  loadingText="Requesting..."
                >
                  Request
                </Button>
              </AlertDialogFooter>
            </form>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>

      {/* Framework Information Drawer */}
      <Drawer
        isOpen={isInfoOpen}
        placement="right"
        onClose={onInfoClose}
        size="md"
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader borderBottomWidth="1px">
            <HStack spacing={3}>
              <Text fontSize="2xl">
                {
                  frameworkInfo[selectedFramework as keyof typeof frameworkInfo]
                    ?.icon
                }
              </Text>
              <Text fontWeight="bold" color="primary.700">
                {
                  frameworkInfo[selectedFramework as keyof typeof frameworkInfo]
                    ?.name
                }
              </Text>
            </HStack>
          </DrawerHeader>

          <DrawerBody py={6}>
            {selectedFramework &&
              frameworkInfo[
                selectedFramework as keyof typeof frameworkInfo
              ] && (
                <VStack spacing={6} align="stretch">
                  <Box>
                    <Text fontWeight="semibold" color="gray.700" mb={2}>
                      Focus
                    </Text>
                    <Text color="gray.600" lineHeight="tall">
                      {
                        frameworkInfo[
                          selectedFramework as keyof typeof frameworkInfo
                        ].focus
                      }
                    </Text>
                  </Box>

                  <Divider />

                  <Box>
                    <Text fontWeight="semibold" color="gray.700" mb={2}>
                      Coverage
                    </Text>
                    <Text color="gray.600" lineHeight="tall">
                      {
                        frameworkInfo[
                          selectedFramework as keyof typeof frameworkInfo
                        ].coverage
                      }
                    </Text>
                  </Box>

                  <Divider />

                  <Box>
                    <Text fontWeight="semibold" color="gray.700" mb={2}>
                      Target Audience
                    </Text>
                    <Text color="gray.600" lineHeight="tall">
                      {
                        frameworkInfo[
                          selectedFramework as keyof typeof frameworkInfo
                        ].audience
                      }
                    </Text>
                  </Box>

                  <Divider />

                  <Box>
                    <Text fontWeight="semibold" color="gray.700" mb={2}>
                      Regulatory Status
                    </Text>
                    <Badge
                      colorScheme={
                        frameworkInfo[
                          selectedFramework as keyof typeof frameworkInfo
                        ].voluntary.includes("Mandatory")
                          ? "red"
                          : "green"
                      }
                      variant="subtle"
                      px={3}
                      py={1}
                      borderRadius="md"
                    >
                      {
                        frameworkInfo[
                          selectedFramework as keyof typeof frameworkInfo
                        ].voluntary
                      }
                    </Badge>
                  </Box>

                  <Divider />

                  <Box>
                    <Text fontWeight="semibold" color="gray.700" mb={2}>
                      Best For
                    </Text>
                    <Text color="gray.600" lineHeight="tall">
                      {
                        frameworkInfo[
                          selectedFramework as keyof typeof frameworkInfo
                        ].bestFor
                      }
                    </Text>
                  </Box>
                </VStack>
              )}
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </>
  );
}
