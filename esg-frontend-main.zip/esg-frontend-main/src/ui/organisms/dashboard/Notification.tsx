import React from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Button,
  Text,
  Box,
  VStack,
  HStack,
  Badge,
  Skeleton,
  Flex,
  IconButton,
  Tooltip,
} from "@chakra-ui/react";
import { Bell, Trash2 } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useDeleteNotification } from "@/query/use-notification";

interface NotificationProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: any;
  unreadCount: any;
  isLoadingNotifications: boolean;
  isMarkingAllAsRead: boolean;
  onMarkAllAsRead: () => void;
  onDeleteNotification?: (notificationId: string) => void;
}

const Notification: React.FC<NotificationProps> = ({
  isOpen,
  onClose,
  notifications,
  unreadCount,
  isLoadingNotifications,
  isMarkingAllAsRead,
  onMarkAllAsRead,
  onDeleteNotification,
}) => {
  const { t } = useTranslation();

  // Delete notification mutation
  const { mutate: deleteNotification, isPending: isDeletingNotification } =
    useDeleteNotification();

  const handleDeleteNotification = (notificationId: string) => {
    deleteNotification(
      {
        path: {
          notification_id: notificationId,
        },
        headers: { authorization: "" },
      },
      {
        onSuccess: () => {
          // Call the parent callback if provided
          if (onDeleteNotification) {
            onDeleteNotification(notificationId);
          }
        },
        onError: (err: any) => {
          console.error("Failed to delete notification:", err);
        },
      }
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered size="md">
      <ModalOverlay backdropFilter="blur(4px)" />
      <ModalContent>
        <ModalHeader>
          <Flex align="center" gap={3}>
            <Bell size={24} />
            <Text>{t("Notifications")}</Text>
            {unreadCount?.unread_count > 0 && (
              <Badge colorScheme="red" borderRadius="full">
                {unreadCount.unread_count}
              </Badge>
            )}
          </Flex>
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          {isLoadingNotifications ? (
            <VStack spacing={4} align="stretch">
              {Array.from({ length: 3 }).map((_, i) => (
                <Box
                  key={i}
                  p={4}
                  border="1px"
                  borderColor="gray.200"
                  borderRadius="md"
                >
                  <Skeleton height="16px" width="60%" mb={2} />
                  <Skeleton height="14px" width="100%" mb={1} />
                  <Skeleton height="12px" width="40%" />
                </Box>
              ))}
            </VStack>
          ) : notifications?.notifications?.length > 0 ? (
            <VStack spacing={3} align="stretch" maxH="400px" overflowY="auto">
              {notifications.notifications.map((notification: any) => (
                <Box
                  key={notification.id}
                  p={4}
                  border="1px"
                  borderColor={notification.is_read ? "gray.200" : "blue.200"}
                  borderRadius="md"
                  bg={notification.is_read ? "white" : "blue.50"}
                  _hover={{
                    bg: notification.is_read ? "gray.50" : "blue.100",
                  }}
                  transition="all 0.2s ease"
                  cursor="pointer"
                >
                  <Flex justify="space-between" align="start" mb={2}>
                    <Text fontWeight="semibold" color="gray.700" fontSize="sm">
                      {notification.title}
                    </Text>
                    <HStack spacing={2}>
                      {!notification.is_read && (
                        <Box
                          w="8px"
                          h="8px"
                          bg="blue.500"
                          borderRadius="full"
                          flexShrink={0}
                          mt={1}
                        />
                      )}
                      <Tooltip label={t("Delete notification")}>
                        <IconButton
                          aria-label="Delete notification"
                          icon={<Trash2 size={14} />}
                          size="xs"
                          variant="ghost"
                          colorScheme="red"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteNotification(notification.id);
                          }}
                          isLoading={isDeletingNotification}
                          _hover={{
                            bg: "red.50",
                            color: "red.600",
                          }}
                        />
                      </Tooltip>
                    </HStack>
                  </Flex>
                  <Text color="gray.600" fontSize="sm" mb={2}>
                    {notification.message}
                  </Text>
                  <Flex justify="space-between" align="center">
                    <Text fontSize="xs" color="gray.500">
                      {new Date(notification.created_at).toLocaleDateString(
                        "en-US",
                        {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                          minute: "2-digit",
                        }
                      )}
                    </Text>
                    {/* <Badge
                      size="sm"
                      colorScheme={
                        notification.type === "REPORT_STATUS_UPDATED"
                          ? "blue"
                          : notification.type === "REPORT_FILE_ADDED"
                          ? "green"
                          : notification.type === "ASSESSMENT_COMPLETED"
                          ? "purple"
                          : "gray"
                      }
                      fontSize="xs"
                    >
                      {notification.type?.replace(/_/g, " ")}
                    </Badge> */}
                  </Flex>
                </Box>
              ))}
            </VStack>
          ) : (
            <Box p={8} textAlign="center" color="gray.500">
              <Bell size={48} style={{ margin: "0 auto 16px", opacity: 0.5 }} />
              <Text fontSize="lg" fontWeight="medium" mb={2}>
                {t("No notifications")}
              </Text>
              <Text fontSize="sm">
                {t("You're all caught up! Check back later for updates.")}
              </Text>
            </Box>
          )}
        </ModalBody>
        <ModalFooter>
          <Button variant="ghost" onClick={onClose}>
            {t("Close")}
          </Button>
          {notifications?.notifications?.length > 0 && (
            <Button
              colorScheme="blue"
              ml={3}
              onClick={onMarkAllAsRead}
              isLoading={isMarkingAllAsRead}
              loadingText={t("Marking...")}
              isDisabled={
                isMarkingAllAsRead ||
                !notifications?.notifications?.some(
                  (notification: any) => !notification.is_read
                )
              }
            >
              {t("Mark all as read")}
            </Button>
          )}
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default Notification;
