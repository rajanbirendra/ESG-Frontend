import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay as AlertDialogOverlayType,
  Button,
  FormControl,
  FormErrorMessage,
  FormLabel,
  Input,
  Textarea,
  VStack,
  Grid,
  GridItem,
  useToast,
} from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CreateAssessmentSchema } from "@/schemas/assessment.schema";
import { useAssessmentsAPI } from "@/query/use-assessments";
import { AssessmentType, Roles } from "@/types/index.types";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";
import MonthDropdown from "@/ui/molecules/dropdown/MonthDropdown";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import { useRef, useState } from "react";
import { getParsedToken } from "@/utils/withAuth";

interface CreateNewAssessmentModelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FormData {
  title: string;
  description: string;
  month: number;
  year: number;
  branch: string;
}

export default function CreateNewAssessmentModel({
  isOpen,
  onClose,
}: CreateNewAssessmentModelProps) {
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    getValues,
    formState: { errors },
  } = useForm<FormData>({
    defaultValues: {
      month: 1,
      year: new Date().getFullYear(),
      branch: "",
    },
    // @ts-ignore
    resolver: zodResolver(CreateAssessmentSchema),
  });

  const token = getParsedToken();
  const [userRole, setUserRole] = useState(token?.role || null);
  const selectedBranch = watch("branch");
  const selectedMonth = watch("month");

  const { mutate: createAssessment, isPending: isCreating } =
    useAssessmentsAPI().createAssessment;
  const closeRef = useRef<HTMLButtonElement>(null);

  const toast = useToast();
  console.log("token", token);
  const handleAddAssessment = (data: FormData) => {
    const branch_id =
      userRole === Roles.USER ? data.branch : token?.company.branch_id;
    if (!branch_id) {
      toast({
        title: "Branch is required",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
      return;
    }
    createAssessment(
      // @ts-ignore
      {
        body: {
          title: data.title,
          description: data.description,
          assessment_type: AssessmentType.ASSESSMENT,
          assessment_year: data.year,
          assessment_month: data.month,
          branch_id,
        },
      }
    );
  };

  return (
    <AlertDialog
      isOpen={isOpen}
      leastDestructiveRef={closeRef}
      onClose={onClose}
      isCentered
    >
      <AlertDialogOverlayType>
        <AlertDialogContent>
          <AlertDialogHeader fontSize="lg" fontWeight="bold">
            Create New Assessment
          </AlertDialogHeader>
          <AlertDialogBody>
            {/* @ts-ignore */}
            <form onSubmit={handleSubmit(handleAddAssessment)}>
              <VStack
                spacing={4}
                style={{
                  display: "flex",
                  justifyContent: "start",
                  alignItems: "start",
                }}
              >
                <FormControl isInvalid={!!errors.title}>
                  <FormLabel>Title</FormLabel>
                  <Input
                    {...register("title")}
                    placeholder="Enter assessment title"
                  />
                  <FormErrorMessage>
                    {errors.title && errors.title.message}
                  </FormErrorMessage>
                </FormControl>

                <FormControl isInvalid={!!errors.description}>
                  <FormLabel>Description</FormLabel>
                  <Textarea
                    {...register("description")}
                    placeholder="Enter assessment description"
                  />
                  <FormErrorMessage>
                    {errors.description && errors.description.message}
                  </FormErrorMessage>
                </FormControl>

                {userRole === Roles.USER && (
                  <div>
                    <FormLabel>Branch</FormLabel>
                    <BranchDropdown
                      // @ts-ignore
                      value={selectedBranch}
                      // @ts-ignore
                      onChange={(branch) => setValue("branch", branch)}
                      error={errors.branch?.message || ""}
                    />
                  </div>
                )}

                <Grid templateColumns="1fr 1fr" gap={4} width="full">
                  <GridItem>
                    <FormControl isInvalid={!!errors.year}>
                      <FormLabel>Year</FormLabel>
                      <YearDropdown
                        selectedYear={getValues("year").toString()}
                        onSelectYear={(year) => {
                          watch("year");
                          setValue("year", +year);
                        }}
                        maxCurrentYear={true}
                      />
                      <FormErrorMessage>
                        {errors.year && errors.year.message}
                      </FormErrorMessage>
                    </FormControl>
                  </GridItem>
                  <GridItem>
                    <FormControl isInvalid={!!errors.month}>
                      <FormLabel>Month</FormLabel>
                      <MonthDropdown
                        selectedMonth={selectedMonth}
                        onSelectMonth={(month) => {
                          setValue("month", month);
                        }}
                        label="Select Month"
                      />
                      <FormErrorMessage>
                        {errors.month && errors.month.message}
                      </FormErrorMessage>
                    </FormControl>
                  </GridItem>
                </Grid>
              </VStack>
            </form>
          </AlertDialogBody>
          <AlertDialogFooter>
            <Button ref={closeRef} onClick={onClose}>
              Cancel
            </Button>
            <Button
              colorScheme="primary"
              // @ts-ignore
              onClick={handleSubmit(handleAddAssessment)}
              ml={3}
              isLoading={isCreating}
            >
              Create
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialogOverlayType>
    </AlertDialog>
  );
}
