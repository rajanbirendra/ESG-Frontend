import {
  getStatusDisplay,
  getStatusIcon,
} from "@/ui/molecules/assessmentStatus";
import {
  Box,
  Heading,
  Text,
  Flex,
  VStack,
  Divider,
  ListItem,
  DrawerContent,
  DrawerHeader,
  DrawerOverlay,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  List,
} from "@chakra-ui/react";

const AssessmentHistoryDrawer = ({
  selectedAssessment,
  isHistoryOpen,
  onHistoryClose,
}) => {
  return (
    <Drawer
      isOpen={isHistoryOpen}
      placement="right"
      onClose={onHistoryClose}
      size="md"
    >
      <DrawerOverlay />
      <DrawerContent>
        <DrawerCloseButton />
        <DrawerHeader borderBottomWidth="1px">Status History</DrawerHeader>

        <DrawerBody>
          {selectedAssessment && (
            <VStack spacing={4} align="stretch">
              <Box>
                <Heading size="sm" mb={2}>
                  {selectedAssessment.title}
                </Heading>
                <Text color="gray.500" fontSize="sm">
                  {selectedAssessment.description}
                </Text>
              </Box>
              <Divider />
              <List spacing={4}>
                {selectedAssessment?.status_history?.map(
                  (item: any, index: number) => (
                    <ListItem key={index}>
                      <Flex align="start" gap={3}>
                        <Box flex={1}>
                          <Flex justify="space-between" align="center" mb={1}>
                            <Text fontWeight="medium" display={"flex"} gap={2}>
                              {getStatusIcon(item.status)}{" "}
                              {getStatusDisplay(item.status)}
                            </Text>
                            <Text fontSize="sm" color="gray.500">
                              {new Date(item.timestamp).toLocaleDateString()}
                            </Text>
                          </Flex>
                          {item.updated_by && (
                            <Box bg="gray.50" p={2} borderRadius="md">
                              <Text fontSize="sm" color="gray.600">
                                Updated by: {item.updated_by.first_name}{" "}
                                {item.updated_by.last_name}
                              </Text>
                              <Text fontSize="sm" color="gray.500">
                                {item.updated_by.company?.name} -{" "}
                                {item.updated_by.company?.branch}
                              </Text>
                              <Text fontSize="sm" color="gray.500">
                                Role: {item.updated_by.company?.role}
                              </Text>
                            </Box>
                          )}
                          {item.from_status && (
                            <Text fontSize="sm" color="gray.500" mt={1}>
                              Changed from: {getStatusDisplay(item.from_status)}
                            </Text>
                          )}
                        </Box>
                      </Flex>
                    </ListItem>
                  )
                )}
              </List>
            </VStack>
          )}
        </DrawerBody>
      </DrawerContent>
    </Drawer>
  );
};

export default AssessmentHistoryDrawer;
