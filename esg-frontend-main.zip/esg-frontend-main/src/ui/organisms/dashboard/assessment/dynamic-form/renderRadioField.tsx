import { Radio, RadioGroup } from "@chakra-ui/react";
import { renderFields } from "./handleRenderingField";

export function renderRadioInput(
  formData: any,
  setFormData: (data: any) => void,
  handleSync: (data: any) => void,
  setDeleteDialogState: (state: any) => void,
  question: any,
  questionIndex: number,
  field: any,
  fieldIndex: null | number = null
) {
  const defaultValue = formData[question.id]?.["value"] || "";

  return (
    <div key={"radio_field_" + question.id}>
      <RadioGroup
        value={defaultValue}
        style={{ marginTop: "24px" }}
        onChange={(value) => {
          setFormData((prev) => ({
            ...prev,
            [question.id]: {
              ...prev[question.id],
              value: value,
            },
          }));

          handleSync({
            questionId: question.id,
            values: {
              value: value,
            },
          });
        }}
      >
        {field.options?.map((option) => (
          <Radio
            key={"radio_option_" + question.id + "_" + option}
            value={option}
            style={{ marginLeft: 40 }}
          >
            {option}
          </Radio>
        ))}
      </RadioGroup>

      {field?.conditional?.[formData[question.id]?.["value"]]?.map(
        (conditionalField) =>
          renderFields(
            formData,
            setFormData,
            handleSync,
            setDeleteDialogState,
            question,
            questionIndex,
            conditionalField
          )
      )}
    </div>
  );
}
