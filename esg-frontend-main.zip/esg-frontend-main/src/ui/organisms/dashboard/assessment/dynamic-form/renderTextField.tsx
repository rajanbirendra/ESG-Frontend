import { FormLabel, Input } from "@chakra-ui/react";

export function renderTextField(
  formData: any,
  setFormData: (data: any) => void,
  handleSync: (data: any) => void,
  question: any,
  questionIndex: number,
  field: any,
  fieldIndex: null | number = null
) {
  const defaultValue =
    fieldIndex !== null
      ? formData[question.id]?.value?.[0]?.[fieldIndex]?.[field.label]
      : formData[question.id]?.[field.label];

  const handleChange = (newValue: string) => {
    console.log("fileIndex", fieldIndex);
    if (fieldIndex !== null) {
      const newFormData = { ...formData };
      if (!newFormData[question.id]) {
        newFormData[question.id] = { value: [{}] };
      }

      const currentValues = newFormData[question.id].value?.[0] || {};
      const updatedValues = {
        ...currentValues,
        [fieldIndex]: {
          ...currentValues[fieldIndex],
          [field.label]: newValue,
        },
      };

      // Update form state
      newFormData[question.id] = {
        ...newFormData[question.id],
        value: [updatedValues],
      };

      setFormData(newFormData);

      handleSync({
        questionId: question.id,
        values: {
          ...newFormData[question.id],
          value: [updatedValues],
        },
      });
    } else {
      setFormData((prev) => ({
        ...prev,
        [question.id]: {
          ...prev[question.id],
          [field.label]: newValue,
        },
      }));

      handleSync({
        questionId: question.id,
        values: {
          ...formData[question.id],
          [field.label]: newValue,
        },
      });
    }
  };

  return (
    <div
      key={"text_field_" + question.id + "_" + fieldIndex}
      style={{ marginTop: "10px" }}
    >
      <FormLabel
        fontWeight="medium"
        fontSize={"sm"}
        style={{
          minHeight: "30px",
          maxHeight: "30px",
          textOverflow: "ellipsis",
        }}
      >
        {field.label || <br />}
      </FormLabel>
      <Input
        type="text"
        style={{ marginBottom: "15px" }}
        value={defaultValue || ""}
        onChange={(e) => handleChange(e.target.value)}
        onKeyDown={(e) => {
          // Prevent + and - characters
          if (e.key === "+" || e.key === "-") {
            e.preventDefault();
          }
        }}
        size="md"
        variant="filled"
        _hover={{ borderColor: "blue.500" }}
        _focus={{
          borderColor: "blue.500",
          boxShadow: "0 0 0 1px blue.500",
        }}
        placeholder="Enter value"
      />
    </div>
  );
}
