import {
  PopoverTrigger,
  Box,
  VStack,
  PopoverContent,
  Button,
  Text,
  Input,
  InputLeftElement,
  PopoverBody,
  InputGroup,
  Popover,
  FormControl,
  FormLabel,
  Tag,
  TagLabel,
  TagCloseButton,
  HStack,
  Flex,
} from "@chakra-ui/react";
import { ChevronDown, Search, X, Check } from "lucide-react";
import { useCallback, useMemo, useRef, useState } from "react";
import React from "react";

const MultiSelectInputField = ({
  formData,
  setFormData,
  handleSync,
  question,
  questionIndex,
  field,
  fieldIndex,
}: {
  formData: any;
  setFormData: any;
  handleSync: any;
  question: any;
  questionIndex: number;
  field: any;
  fieldIndex: number | null;
}) => {
  const value =
    fieldIndex !== null
      ? formData[question.id]?.value?.[0]?.[fieldIndex]?.[field.label] || []
      : formData[question.id]?.[field.label] || [];

  const handleChange = useCallback(
    (selectedValue: string) => {
      const currentValues = Array.isArray(value) ? value : [];
      const newSelectedValues = currentValues.includes(selectedValue)
        ? currentValues.filter((v) => v !== selectedValue)
        : [...currentValues, selectedValue];

      if (fieldIndex !== null) {
        const newFormData = { ...formData };
        if (!newFormData[question.id]) {
          newFormData[question.id] = { value: [{}] };
        }

        const currentValues = newFormData[question.id].value?.[0] || {};
        const updatedFormValues = {
          ...currentValues,
          [fieldIndex]: {
            ...currentValues[fieldIndex],
            [field.label]: newSelectedValues,
          },
        };

        newFormData[question.id] = {
          ...newFormData[question.id],
          value: [updatedFormValues],
        };

        setFormData(newFormData);

        handleSync({
          questionId: question.id,
          values: {
            ...newFormData[question.id],
            value: [updatedFormValues],
          },
        });
      } else {
        setFormData((prev) => ({
          ...prev,
          [question.id]: {
            ...prev[question.id],
            [field.label]: newSelectedValues,
          },
        }));

        handleSync({
          questionId: question.id,
          values: {
            ...formData[question.id],
            [field.label]: newSelectedValues,
          },
        });
      }
    },
    [
      value,
      fieldIndex,
      formData,
      setFormData,
      handleSync,
      question.id,
      field.label,
    ]
  );

  const handleRemoveValue = useCallback(
    (valueToRemove: string) => {
      const newSelectedValues = value.filter((v) => v !== valueToRemove);

      if (fieldIndex !== null) {
        const newFormData = { ...formData };
        if (!newFormData[question.id]) {
          newFormData[question.id] = { value: [{}] };
        }

        const currentValues = newFormData[question.id].value?.[0] || {};
        const updatedFormValues = {
          ...currentValues,
          [fieldIndex]: {
            ...currentValues[fieldIndex],
            [field.label]: newSelectedValues,
          },
        };

        newFormData[question.id] = {
          ...newFormData[question.id],
          value: [updatedFormValues],
        };

        setFormData(newFormData);

        handleSync({
          questionId: question.id,
          values: {
            ...newFormData[question.id],
            value: [updatedFormValues],
          },
        });
      } else {
        setFormData((prev) => ({
          ...prev,
          [question.id]: {
            ...prev[question.id],
            [field.label]: newSelectedValues,
          },
        }));

        handleSync({
          questionId: question.id,
          values: {
            ...formData[question.id],
            [field.label]: newSelectedValues,
          },
        });
      }
    },
    [
      value,
      fieldIndex,
      formData,
      setFormData,
      handleSync,
      question.id,
      field.label,
    ]
  );

  return (
    <SearchableMultiSelect
      questionId={question.id}
      field={field}
      fieldIndex={fieldIndex}
      value={value}
      onChange={handleChange}
      onRemove={handleRemoveValue}
    />
  );
};

const SearchableMultiSelect = React.memo(
  ({
    questionId,
    field,
    fieldIndex,
    value,
    onChange,
    onRemove,
  }: {
    questionId: string;
    field: any;
    fieldIndex: number | null;
    value: string[];
    onChange: (value: string) => void;
    onRemove: (value: string) => void;
  }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const inputRef = useRef<HTMLInputElement>(null);

    // Memoize filtered options
    const filteredOptions = useMemo(
      () =>
        field?.options?.filter((option: string) =>
          option.toLowerCase().includes(searchTerm.toLowerCase())
        ),
      [field?.options, searchTerm]
    );

    const handleSelect = useCallback(
      (selectedValue: string) => {
        onChange(selectedValue);
        // Keep search term if adding, clear if removing
        if (value.includes(selectedValue)) {
          setSearchTerm("");
        } // else keep search term
      },
      [onChange, value]
    );

    return (
      <FormControl
        key={`multiselect_field_${questionId}_${fieldIndex}_${field.label}`}
        isRequired
        style={{ marginTop: "10px" }}
      >
        <FormLabel
          fontWeight="medium"
          fontSize={"sm"}
          style={{
            minHeight: "30px",
            maxHeight: "30px",
            textOverflow: "ellipsis",
          }}
        >
          {field?.label}
        </FormLabel>
        <Popover
          isOpen={isOpen}
          onClose={() => {
            setIsOpen(false);
            setSearchTerm("");
          }}
          placement="bottom-start"
        >
          <PopoverTrigger>
            <Button
              w="100%"
              minH="40px"
              variant="filled"
              bg="white"
              borderWidth="1px"
              borderColor="gray.200"
              _hover={{ borderColor: "blue.500" }}
              _focus={{
                borderColor: "blue.500",
                boxShadow: "0 0 0 1px blue.500",
              }}
              fontWeight={"normal"}
              onClick={() => setIsOpen(true)}
              justifyContent="space-between"
              px={4}
              py={2}
              position="relative"
              height="auto" // Allow height to adjust
            >
              <Flex
                wrap="wrap"
                gap={2}
                flex={1}
                // Removed maxH and overflowY
                pr={8}
                // Removed sx for scrollbar
              >
                {value.length > 0 ? (
                  value.map((v) => (
                    <Tag
                      key={v}
                      size="sm"
                      borderRadius="full"
                      variant="solid"
                      colorScheme="blue"
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemove(v);
                      }}
                      maxW="100%"
                    >
                      <TagLabel isTruncated>{v}</TagLabel>
                      <TagCloseButton />
                    </Tag>
                  ))
                ) : (
                  <Text color="gray.500">Select options</Text>
                )}
              </Flex>
              <ChevronDown
                size={20}
                style={{
                  position: "absolute",
                  right: "12px",
                  top: "50%",
                  transform: "translateY(-50%)",
                  pointerEvents: "none",
                }}
              />
            </Button>
          </PopoverTrigger>
          <PopoverContent
            minW="300px"
            maxH="300px"
            overflowY="auto"
            style={{ overflowY: "hidden" }}
          >
            <PopoverBody p={0}>
              <VStack align="stretch" spacing={0}>
                <Box p={2} borderBottomWidth="1px">
                  <InputGroup>
                    <InputLeftElement pointerEvents="none">
                      <Search size={16} />
                    </InputLeftElement>
                    <Input
                      ref={inputRef}
                      placeholder="Search..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      size="sm"
                      autoFocus
                    />
                  </InputGroup>
                </Box>
                <VStack align="stretch" maxH="250px" overflowY="auto">
                  {filteredOptions?.map((option: string, index: number) => (
                    <Button
                      key={`${questionId}_${fieldIndex}_${field.label}_${option}_${index}`}
                      variant="ghost"
                      justifyContent="space-between"
                      px={4}
                      py={2}
                      h="auto"
                      whiteSpace="normal"
                      textAlign="left"
                      onClick={() => handleSelect(option)}
                      _hover={{ bg: "blue.50" }}
                      bg={value.includes(option) ? "blue.50" : "transparent"}
                    >
                      <Text>{option}</Text>
                      {value.includes(option) && <Check size={16} />}
                    </Button>
                  ))}
                </VStack>
              </VStack>
            </PopoverBody>
          </PopoverContent>
        </Popover>
      </FormControl>
    );
  }
);

export default MultiSelectInputField;
