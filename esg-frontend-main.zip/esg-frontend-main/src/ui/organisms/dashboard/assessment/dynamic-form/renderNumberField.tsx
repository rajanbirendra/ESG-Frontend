import { FormLabel, Input, Text } from "@chakra-ui/react";

export function renderNumberInput(
  formData: any,
  setFormData: (data: any) => void,
  handleSync: (data: any) => void,

  question: any,
  questionIndex: number,
  field: any,
  fieldIndex: null | number = null
) {
  const defaultValue =
    fieldIndex !== null
      ? formData[question.id]?.value?.[0]?.[fieldIndex]?.[field.label]
      : formData[question.id]?.[field.label];

  const handleChange = (value: string) => {
    // Allow empty value
    if (value === "") {
      updateFormValue(value);
      return;
    }

    // Check if the value contains 'e' or 'E' (exponential notation)
    if (value.toLowerCase().includes("e")) {
      return;
    }

    // Check if the value is a valid number
    if (!/^-?\d*\.?\d*$/.test(value)) {
      return;
    }

    const numValue = Number(value);

    // Check if the value is within min and max bounds
    if (
      numValue >= (field?.min || 0) &&
      numValue <= (field?.max || 10000000000)
    ) {
      updateFormValue(value);
    }
  };

  const updateFormValue = (value: string) => {
    if (fieldIndex !== null) {
      const newFormData = { ...formData };
      if (!newFormData[question.id]) {
        newFormData[question.id] = { value: [{}] };
      }

      const currentValues = newFormData[question.id].value?.[0] || {};
      const updatedValues = {
        ...currentValues,
        [fieldIndex]: {
          ...currentValues[fieldIndex],
          [field.label]: value,
        },
      };

      // Update form state
      newFormData[question.id] = {
        ...newFormData[question.id],
        value: [updatedValues],
      };

      setFormData(newFormData);

      handleSync({
        questionId: question.id,
        values: {
          ...newFormData[question.id],
          value: [updatedValues],
        },
      });
    } else {
      setFormData((prev) => ({
        ...prev,
        [question.id]: {
          ...prev[question.id],
          [field.label]: value,
        },
      }));

      handleSync({
        questionId: question.id,
        values: {
          ...formData[question.id],
          [field.label]: value,
        },
      });
    }
  };

  return (
    <div
      key={"number_field_" + question.id + "_" + fieldIndex}
      style={{ marginTop: "10px" }}
    >
      <FormLabel
        fontWeight="medium"
        fontSize={"sm"}
        style={{
          minHeight: "30px",
          maxHeight: "30px",
          textOverflow: "ellipsis",
        }}
      >
        {field.label === "" || field.label === null ? (
          <>
            <br />
            <br />
            <br />
          </>
        ) : (
          field.label
        )}
      </FormLabel>
      <Input
        type="number"
        style={{ marginBottom: "15px" }}
        min={field?.min || 0}
        max={field?.max || 10000000000}
        value={defaultValue || ""}
        onChange={(e) => handleChange(e.target.value)}
        onKeyDown={(e) => {
          // Prevent decimal point if not allowed
          // if (e.key === "." && !field?.allowDecimal) {
          //   e.preventDefault();
          // }
          // Prevent minus sign if not allowed
          if (e.key === "-" && !field?.allowNegative) {
            e.preventDefault();
          }
          // Prevent 'e' key
          if (e.key.toLowerCase() === "e") {
            e.preventDefault();
          }
          // Prevent '+' key
          if (e.key === "+") {
            e.preventDefault();
          }
        }}
        size="md"
        variant="filled"
        _hover={{ borderColor: "blue.500" }}
        _focus={{
          borderColor: "blue.500",
          boxShadow: "0 0 0 1px blue.500",
        }}
        placeholder="Enter value"
      />
      {(field?.min !== undefined || field?.max !== undefined) && (
        <Text fontSize="xs" color="gray.500" mt={1}>
          {field?.min !== undefined && field?.max !== undefined
            ? `Range: ${field.min} - ${field.max}`
            : field?.min !== undefined
            ? `Minimum: ${field.min}`
            : `Maximum: ${field.max}`}
        </Text>
      )}
    </div>
  );
}
