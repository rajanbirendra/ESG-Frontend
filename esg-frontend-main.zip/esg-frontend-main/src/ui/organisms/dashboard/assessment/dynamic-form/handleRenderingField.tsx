import {
  Box,
  Button,
  Input,
  Flex,
  FormLabel,
  useToast,
} from "@chakra-ui/react";
import { Plus, Trash2 } from "lucide-react";
import { renderSelectInput } from "./renderSelectInputField";
import { renderNumberInput } from "./renderNumberField";
import { renderRadioInput } from "./renderRadioField";
import { renderFileInput } from "./renderFileInput";
import { useRouter } from "next/router";
import Link from "next/link";
import RenderMultiSelectInputField from "./RenderMultiSelectInputField";
import { renderTextField } from "./renderTextField";

export function handleRenderingMultipleFields(
  formData: any,
  setFormData: (data: any) => void,
  handleSync: (data: any) => void,
  setDeleteDialogState: (state: any) => void,
  question: any,
  questionIndex: number,
  f: any,
  fieldIndex: number
) {
  // const toast = useToast();
  const handleAddField = () => {
    const newFormData = { ...formData };
    if (!newFormData[question.id]) {
      newFormData[question.id] = {
        value: [{}],
      };
    }

    const currentValues = newFormData[question.id].value?.[0] || {};
    const newIndex = Object.keys(currentValues).length;

    const updatedValues = {
      ...currentValues,
      [newIndex]: {
        ...Object.keys(f[0] || {}).reduce(
          (acc, key) => ({
            ...acc,
            [key]: {},
          }),
          {}
        ),
      },
    };

    newFormData[question.id] = {
      ...newFormData[question.id],
      value: [updatedValues],
    };

    setFormData(newFormData);

    handleSync({
      questionId: question.id,
      values: {
        value: [updatedValues],
      },
    });
  };

  const handleDeleteField = (indexToDelete: number) => {
    setDeleteDialogState({
      isOpen: true,
      questionId: question.id,
      indexToDelete,
    });
  };

  return (
    <>
      <Box
        key={`field_multiple_${question.id}_${questionIndex}_${fieldIndex}`}
        mb={4}
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "10px",
          width: "100%",
        }}
      >
        {/* If answer value exists,render field likewise.; else render empty fields */}
        {formData[question.id]?.value?.[0] ? (
          Object.entries(formData[question.id].value[0]).map(
            ([key, valueObj], index) => (
              <div
                key={`multiple_field_${question.id}_${questionIndex}_${fieldIndex}_${index}`}
                style={{
                  display: "flex",
                  gap: "10px",
                  flexDirection: "row",
                  width: "100%",
                  alignItems: "flex-start",
                }}
              >
                <div style={{ flex: 1, display: "flex", gap: "10px" }}>
                  {f.map((field, j) => (
                    <div
                      key={`field_${question.id}_${questionIndex}_${fieldIndex}_${index}_${j}`}
                      style={{
                        flex: "1",
                        minWidth: 0,
                      }}
                    >
                      {renderFields(
                        formData,
                        setFormData,
                        handleSync,
                        setDeleteDialogState,
                        question,
                        questionIndex,
                        field,
                        +key
                      )}
                    </div>
                  ))}
                </div>
                {Object.keys(formData[question.id].value[0]).length > 1 && (
                  <Button
                    size="sm"
                    colorScheme="red"
                    variant="ghost"
                    onClick={() => handleDeleteField(+key)}
                    p={2}
                  >
                    <Trash2 size={16} />
                  </Button>
                )}
              </div>
            )
          )
        ) : (
          // if no answer value exists, render empty fields
          <div
            key={`multiple_field_empty_${question.id}_${questionIndex}_${fieldIndex}`}
            style={{
              display: "flex",
              gap: "10px",
              width: "100%",
            }}
          >
            {f.map((multipleField, j) => (
              <div
                key={`field_empty_${question.id}_${questionIndex}_${fieldIndex}_${j}`}
                style={{
                  flex: "1",
                  minWidth: 0,
                }}
              >
                {renderFields(
                  formData,
                  setFormData,
                  handleSync,
                  setDeleteDialogState,
                  question,
                  questionIndex,
                  multipleField,
                  0
                )}
              </div>
            ))}
          </div>
        )}
      </Box>

      {/* Add Button */}
      <Button
        key={`add_button_${question.id}_${questionIndex}_${fieldIndex}`}
        colorScheme="blue"
        style={{ width: "100px" }}
        mt={2}
        onClick={handleAddField}
        leftIcon={<Plus size={16} />}
      >
        Add
      </Button>
    </>
  );
}

export function renderFields(
  formData: any,
  setFormData: (data: any) => void,
  handleSync: (data: any) => void,
  setDeleteDialogState: (state: any) => void,
  question: any,
  questionIndex: number,
  field: any,
  fieldIndex: null | number = null
) {
 

  console.log("field", field);
  switch (field?.input_type) {
    case "select":
      return renderSelectInput(
        formData,
        setFormData,
        handleSync,
        setDeleteDialogState,
        question,
        questionIndex,
        field,
        fieldIndex
      );
    case "multiselect":
      return (
        <RenderMultiSelectInputField
          formData={formData}
          setFormData={setFormData}
          handleSync={handleSync}
          question={question}
          questionIndex={questionIndex}
          field={field}
          fieldIndex={fieldIndex}
        />
      );

    // renderMultiSelectInput(
    //   formData,
    //   setFormData,
    //   handleSync,
    //   setDeleteDialogState,
    //   question,
    //   questionIndex,
    //   field,
    //   fieldIndex
    // );
    case "number":
      return renderNumberInput(
        formData,
        setFormData,
        handleSync,
        question,
        questionIndex,
        field,
        fieldIndex
      );

    case "text":
      return renderTextField(
        formData,
        setFormData,
        handleSync,
        question,
        questionIndex,
        field,
        fieldIndex
      );
    case "radio":
      return renderRadioInput(
        formData,
        setFormData,
        handleSync,
        setDeleteDialogState,
        question,
        questionIndex,
        field,
        fieldIndex
      );
    case "file":
      return renderFileInput(
        formData,
        setFormData,
        handleSync,
        question,
        questionIndex,
        field,
        fieldIndex
      );
    case "form_custom_type":
      console.log("custom", question.answer_field.for_user[0].form_link);

      const router = useRouter();

      const assessmentId = router.query.id as string;
      const formUrl = `${window.location.origin}/forms/employee-commute/${assessmentId}`;
      const viewResponseUrl = `${window.location.origin}/forms/employee-commute/${assessmentId}/view-response/`;

      return (
        <Flex flexDirection="row" gap={2} width="100%">
          <br />
          <div style={{ flex: 1 }}>
            <FormLabel>Click below URL to copy</FormLabel>
            <Input
              type="text"
              style={{ cursor: "pointer" }}
              onClick={() => {
                navigator.clipboard.writeText(formUrl);
              }}
              defaultValue={formUrl}
            />
          </div>
          <Link href={viewResponseUrl} target="_blank">
            <Button style={{ flex: 1, marginTop: "30px" }}>
              View form Responses
            </Button>
          </Link>
        </Flex>
      );
    default:
      return null;
  }
}
