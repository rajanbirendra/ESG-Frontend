import { AttachmentIcon } from "@chakra-ui/icons";
import {
  Button,
  FormControl,
  FormLabel,
  Input,
  Text,
  InputGroup,
  InputRightElement,
  Link,
} from "@chakra-ui/react";

export function renderFileInput(
  formData: any,
  setFormData: any,
  handleSync: any,
  question: any,
  questionIndex: number,
  field: any,
  fieldIndex: number|null,
) {
  console.log("renderFileInput called with fieldIndex:", fieldIndex);
  console.log("field", field);
  let filePath = null;
  if (question) {
    if(fieldIndex!==null && question?.answer?.values.value[0][fieldIndex]?.file){
      filePath = question?.answer?.values.value[0][fieldIndex]?.file;
    }
    else if(questionIndex===null && question?.answer?.values.file){
      filePath = question?.answer?.values.file;
    }

  }

  const selectedFileName = fieldIndex !== null
    ? formData?.[question.id]?.value?.[0]?.[fieldIndex]?.file?.name || ""
    : formData?.[question.id]?.file?.name || "";

  console.log("ooooooo", filePath);
      return (
      <FormControl isRequired={field.required || false} key={`file_input_${question.id}_${fieldIndex}`}>
        <FormLabel
        fontWeight="medium"
        fontSize={"sm"}
        style={{
          minHeight: "30px",
          maxHeight: "30px",
          marginTop: "10px",
          textOverflow: "ellipsis",
        }}
      >
        {field.label || <br />}
      </FormLabel>
      <InputGroup>
        <Input
          type="file"
        key={`file_choose_${question.id}_${fieldIndex}`}
          multiple={field.multiple || false}
          accept={field.allowedExtensions?.map((ext) => `.${ext}`).join(",")}
          onChange={(e) => {
            const file = e.target.files?.[0] || null;
            if (!file) return;

            // Capture the current fieldIndex value to avoid closure issues
            const currentFieldIndex = fieldIndex;
            console.log("Captured fieldIndex for this onChange:", currentFieldIndex);

            if (currentFieldIndex !== null) {
              setFormData((prev: any) => {
                console.log("Previous form data:", prev);
                console.log("Updating fieldIndex:", currentFieldIndex);
                
                const newFormData = { ...prev };
                if (!newFormData[question.id]) {
                  newFormData[question.id] = { value: [{}] };
                }
                if (!newFormData[question.id].value) {
                  newFormData[question.id].value = [{}];
                }
                if (!newFormData[question.id].value[0]) {
                  newFormData[question.id].value[0] = {};
                }
                
                // Preserve existing data and update only the specific fieldIndex
                const currentValues = newFormData[question.id].value[0];
                console.log("Current values before update:", currentValues);
                
                const updatedFormValues = {
                  ...currentValues,
                  [currentFieldIndex]: {
                    ...currentValues[currentFieldIndex],
                    file,
                  },
                };
                
                console.log("Updated values after update:", updatedFormValues);
                
                newFormData[question.id] = {
                  ...newFormData[question.id],
                  value: [updatedFormValues],
                };
                
                console.log("Final newFormData:", newFormData);
                return newFormData;
              });
            } else {
              setFormData((prev: any) => ({
                ...prev,
                [question.id]: {
                  ...prev[question.id],
                  file,
                },
              }));
            }
            
            console.log("fieldIndex in handleChange:", currentFieldIndex);
            handleSync({
              questionId: question.id,
              values: {
                file: e.target.files?.[0],
                questionIndex: currentFieldIndex,
              },
            });
          }}
          display="none"
          id={`file-${field.label}`}
        />
        <Input
          value={selectedFileName}
          placeholder="Choose a file"
          readOnly
          size="md"
          variant="filled"
          _hover={{ borderColor: "blue.500" }}
          _focus={{
            borderColor: "blue.500",
            boxShadow: "0 0 0 1px blue.500",
          }}
        />
        <InputRightElement width="4.5rem">
          <Button
            h="1.75rem"
            size="sm"
                      onClick={() =>
            document.getElementById(`file-${field.label}`)?.click()
          }
            colorScheme="blue"
            variant="solid"
          >
            <AttachmentIcon boxSize={4} />
          </Button>
        </InputRightElement>
      </InputGroup>
      {filePath && typeof filePath === 'string' && (
        <Text fontSize="sm" mt={2}>
          <Link href={filePath} isExternal color="blue.500">
            View file
          </Link>
        </Text>
      )}
      {field.allowedExtensions && (
        <Text fontSize="sm" color="gray.500" mt={1}>
          Allowed formats: {field.allowedExtensions.join(", ")}
        </Text>
      )}
    </FormControl>
  );
}
