import {
  PopoverTrigger,
  Box,
  VStack,
  PopoverContent,
  Button,
  Text,
  Input,
  InputLeftElement,
  PopoverBody,
  InputGroup,
  Popover,
  FormControl,
  FormLabel,
} from "@chakra-ui/react";
import {
  handleRenderingMultipleFields,
  renderFields,
} from "./handleRenderingField";
import { ChevronDown, Search } from "lucide-react";
import { useCallback, useMemo, useRef, useState } from "react";
import React from "react";
import { set } from "lodash";

export function renderSelectInput(
  formData: any,
  setFormData: (data: any) => void,
  handleSync: (data: any) => void,
  setDeleteDialogState: (state: any) => void,

  question: any,
  questionIndex: number,
  field: any,
  fieldIndex: null | number = null
) {
  const value =
    fieldIndex !== null
      ? formData[question.id]?.value?.[0]?.[fieldIndex]?.[field.label]
      : formData[question.id]?.[field.label];

  const handleChange = (newValue: string) => {
    if (fieldIndex !== null) {
      const newFormData = { ...formData };
      if (!newFormData[question.id]) {
        newFormData[question.id] = { value: [{}] };
      }

      const currentValues = newFormData[question.id].value?.[0] || {};
      const updatedValues = {
        ...currentValues,
        [fieldIndex]: {
          ...currentValues[fieldIndex],
          [field.label]: newValue,
        },
      };

      newFormData[question.id] = {
        ...newFormData[question.id],
        value: [updatedValues],
      };

      setFormData(newFormData);

      handleSync({
        questionId: question.id,
        values: {
          ...newFormData[question.id],
          value: [updatedValues],
        },
      });
    } else {
      setFormData((prev) => ({
        ...prev,
        [question.id]: {
          ...prev[question.id],
          [field.label]: newValue,
        },
      }));

      handleSync({
        questionId: question.id,
        values: {
          ...formData[question.id],
          [field.label]: newValue,
        },
      });
    }
  };

  return (
    <>
      <SearchableSelect
        questionId={question.id}
        field={field}
        fieldIndex={fieldIndex}
        value={value || ""}
        onChange={handleChange}
      />
      {field?.conditional && formData[question.id]?.[field.label] && (
        <Box
          mt={4}
          ml={4}
          pl={4}
          borderLeft="2px solid"
          borderColor="blue.200"
          display={"flex"}
          width={"100%"}
          flexDirection={"column"}

          // display: "flex",
          //       gap: "10px",
          //       flexDirection: "row",
          //       width: "100%",
          //       alignItems: "flex-start",
        >
          {console.log("field.conditional", field.conditional)}
          {field?.conditional[formData[question.id]?.[field.label]]?.map(
            (conditionalField, i) => (
              <Box
                key={conditionalField.label}
                mb={4}
                display={"flex"}
                flexDirection={"column"}
              >
                {conditionalField?.multiple?.length > 0 ? (
                  <>
                    {console.log("renderFields multiple")}
                    {handleRenderingMultipleFields(
                      formData,
                      setFormData,
                      handleSync,
                      setDeleteDialogState,

                      question,
                      questionIndex,
                      conditionalField.multiple,
                      i
                    )}
                  </>
                ) : (
                  renderFields(
                    formData,
                    setFormData,
                    handleSync,
                    setDeleteDialogState,
                    question,
                    questionIndex,
                    conditionalField
                  )
                )}
              </Box>
            )
          )}
        </Box>
      )}

      {/* for multiple fields */}
      {fieldIndex !== null &&
        field?.conditional &&
        formData[question.id]?.value?.[0]?.[fieldIndex]?.[field.label] && (
          <Box
            mt={4}
            ml={4}
            pl={4}
            borderLeft="2px solid"
            borderColor="blue.200"
          >
            {field?.conditional[
              formData[question.id]?.value?.[0]?.[fieldIndex]?.[field.label]
            ]?.map((conditionalField) => (
              <Box key={conditionalField.label} mb={4}>
                {conditionalField.multiple &&
                  conditionalField.multiple.length > 0 &&
                  handleRenderingMultipleFields(
                    formData,
                    setFormData,
                    handleSync,
                    setDeleteDialogState,
                    question,
                    questionIndex,
                    conditionalField.multiple,
                    fieldIndex
                  )}

                {conditionalField?.conditional?.[
                  formData[question.id]?.value?.[0]?.[fieldIndex]?.[field.label]
                ]?.map((nestedConditionalField) =>
                  renderFields(
                    formData,
                    setFormData,
                    handleSync,
                    setDeleteDialogState,

                    question,
                    questionIndex,
                    nestedConditionalField
                  )
                )}

                {renderFields(
                  formData,
                  setFormData,
                  handleSync,
                  setDeleteDialogState,
                  question,
                  questionIndex,
                  conditionalField,
                  fieldIndex
                )}
              </Box>
            ))}
          </Box>
        )}
    </>
  );
}

const SearchableSelect = React.memo(
  ({
    questionId,
    field,
    fieldIndex,
    value,
    onChange,
  }: {
    questionId: string;
    field: any;
    fieldIndex: number | null;
    value: string;
    onChange: (value: string) => void;
  }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const inputRef = useRef<HTMLInputElement>(null);

    // Memoize filtered options
    const filteredOptions = useMemo(
      () =>
        field?.options?.filter((option: string) =>
          option.toLowerCase().includes(searchTerm.toLowerCase())
        ),
      [field?.options, searchTerm]
    );

    const handleSelect = useCallback(
      (selectedValue: string) => {
        onChange(selectedValue);
        setIsOpen(false);
        setSearchTerm("");
      },
      [onChange]
    );

    return (
      <FormControl
        key={`select_field_${questionId}_${fieldIndex}_${field.label}`}
        isRequired
        style={{ marginTop: "10px" }}
      >
        <FormLabel
          fontWeight="medium"
          fontSize={"sm"}
          style={{
            minHeight: "30px",
            maxHeight: "30px",
            textOverflow: "ellipsis",
          }}
        >
          {field?.label}
        </FormLabel>
        <Popover
          isOpen={isOpen}
          onClose={() => {
            setIsOpen(false);
            setSearchTerm("");
          }}
          placement="bottom-start"
        >
          <PopoverTrigger>
            <Button
              w="100%"
              h="40px"
              variant="filled"
              bg="white"
              borderWidth="1px"
              borderColor="gray.200"
              _hover={{ borderColor: "blue.500" }}
              _focus={{
                borderColor: "blue.500",
                boxShadow: "0 0 0 1px blue.500",
              }}
              fontWeight={"normal"}
              onClick={() => setIsOpen(true)}
              justifyContent="space-between"
              px={4}
            >
              <Text isTruncated>{value || "Select an option"}</Text>
              <ChevronDown size={20} />
            </Button>
          </PopoverTrigger>
          <PopoverContent
            minW="300px"
            maxH="300px"
            overflowY="auto"
            style={{ overflowY: "hidden" }}
          >
            <PopoverBody p={0}>
              <VStack align="stretch" spacing={0}>
                <Box p={2} borderBottomWidth="1px">
                  <InputGroup>
                    <InputLeftElement pointerEvents="none">
                      <Search size={16} />
                    </InputLeftElement>
                    <Input
                      ref={inputRef}
                      placeholder="Search..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      size="sm"
                      autoFocus
                    />
                  </InputGroup>
                </Box>
                <VStack align="stretch" maxH="250px" overflowY="auto">
                  {filteredOptions?.map((option: string, index: number) => (
                    <Button
                      key={`${questionId}_${fieldIndex}_${field.label}_${option}_${index}`}
                      variant="ghost"
                      justifyContent="flex-start"
                      px={4}
                      py={2}
                      h="auto"
                      whiteSpace="normal"
                      textAlign="left"
                      onClick={() => handleSelect(option)}
                      bg={value === option ? "blue.50" : "transparent"}
                      _hover={{ bg: "blue.50" }}
                    >
                      {option}
                    </Button>
                  ))}
                </VStack>
              </VStack>
            </PopoverBody>
          </PopoverContent>
        </Popover>
      </FormControl>
    );
  }
);
