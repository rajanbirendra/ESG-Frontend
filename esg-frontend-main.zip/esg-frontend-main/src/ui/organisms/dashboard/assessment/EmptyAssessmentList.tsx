import { Icon, Text, Button, VStack, Box, Heading } from "@chakra-ui/react";
import { Plus, FileText } from "lucide-react";

const EmptyAssessmentList = ({ selectedBranch, onOpen }) => {
  return (
    <VStack spacing={8} py={16} px={4} textAlign="center">
      <Box
        p={6}
        bg="primary.50"
        borderRadius="full"
        display="inline-flex"
        alignItems="center"
        justifyContent="center"
      >
        <Icon as={FileText} w={12} h={12} color="primary.500" />
      </Box>
      <VStack spacing={4}>
        <Heading size="lg" color="headingColor" fontWeight="600">
          No Assessments
        </Heading>
        <Text color="textColor" maxW="md" fontSize="md">
          {selectedBranch
            ? `No assessments found for ${selectedBranch}. Try selecting a different branch or create a new assessment.`
            : "Start your ESG journey by creating your first assessment. Track your progress and make a positive impact."}
        </Text>

        <Button
          size="lg"
          colorScheme="primary"
          onClick={onOpen}
          leftIcon={<Plus size={20} />}
          fontWeight="medium"
          _hover={{ transform: "translateY(-1px)", boxShadow: "md" }}
          transition="all 0.2s"
        >
          Start Assessment
        </Button>
      </VStack>
    </VStack>
  );
};

export default EmptyAssessmentList;
