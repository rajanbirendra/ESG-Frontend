import React, { useState, useEffect, useRef } from "react";
import {
  Icon,
  Box,
  Text,
  Flex,
  HStack,
  useColorModeValue,
  Select,
  VStack,
} from "@chakra-ui/react";
import { Cloud, Leaf, TrendingDown } from "lucide-react";
import CustomYearDropdown from "@/ui/molecules/dropdown/CustomYearDropdown";
import MultiSelectScopeDropdown from "@/ui/molecules/dropdown/multi-select/MultiSelectScopeDropdown";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useCNPAPI } from "@/query/use-cnp";
import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import ChartDownloadButton from "@/ui/components/ChartDownloadButton";

interface CNPCardsMetrics {
  total_emission: number;
  carbon_offset: number;
  residual_emission: number;
}

interface CNPChartMetrics {
  scope_1_emission: number;
  scope_2_emission: number;
  scope_3_emission: number;
  scope_1_emission_carbon_offset: number;
  scope_2_emission_carbon_offset: number;
  scope_3_emission_carbon_offset: number;
  scope_1_net: number;
  scope_2_net: number;
  scope_3_net: number;
  scope_1_estimated_project: number;
  scope_2_estimated_project: number;
  scope_3_estimated_project: number;
}

const CarbonNeutralityAnalytics = () => {
  // State for selected year, target type, and scopes
  const [selectedYear, setSelectedYear] = useState<string>("");
  const [selectedTargetType, setSelectedTargetType] =
    useState<string>("short_term");
  const [selectedScopes, setSelectedScopes] = useState<string[]>([]);

  const handleYearChange = (year: string) => {
    setSelectedYear(year);
    // TODO: Fetch data for selected year
    console.log("Selected year:", year);
  };

  const handleScopeChange = (scopes: string[]) => {
    setSelectedScopes(scopes);
    // TODO: Fetch data for selected scopes
    console.log("Selected scopes:", scopes);
  };

  const { data, isLoading } =
    useUserAnalyticsAPI().getCNPCardsMetrices(selectedYear);
  const { data: baseYears, isLoading: isLoadingBaseYears } =
    useCNPAPI().getBaseYears();
  const cnpData = data as CNPCardsMetrics | undefined;

  const { data: chartDataRaw, isLoading: isLoadingChartData } =
    useUserAnalyticsAPI().getCNPChartMetrices(selectedYear, selectedTargetType);

  const chartDataTyped = chartDataRaw as CNPChartMetrics | undefined;

  // Extract emission_trend data for solid lines
  const emissionTrend: Record<string, any> =
    (chartDataTyped as any)?.emission_trend || {};
  const emissionTrendChartData = React.useMemo(() => {
    return Object.entries(emissionTrend)
      .map(([year, values]) => {
        const v = values as any;
        return {
          year,
          Scope1: v.scope_1_net,
          Scope2: v.scope_2_net,
          Scope3: v.scope_3_net,
        };
      })
      .sort((a, b) => Number(a.year) - Number(b.year));
  }, [chartDataTyped]);

  // Calculate projected year based on selected target type
  const baseYear = Number(selectedYear);
  let projectedYear = baseYear;
  if (selectedTargetType === "short_term") projectedYear = baseYear + 5;
  else if (selectedTargetType === "medium_term") projectedYear = baseYear + 10;
  else if (selectedTargetType === "long_term") projectedYear = baseYear + 30;

  // Build the year range for the x-axis
  const yearRange: string[] = React.useMemo(() => {
    const arr: string[] = [];
    for (let y = baseYear; y <= projectedYear; y++) {
      arr.push(String(y));
    }
    return arr;
  }, [baseYear, projectedYear]);

  // Interpolate projected values for every year
  const scope1Start = emissionTrend[baseYear]?.scope_1_net ?? null;
  const scope1End = chartDataTyped?.scope_1_estimated_project ?? null;
  const scope2Start = emissionTrend[baseYear]?.scope_2_net ?? null;
  const scope2End = chartDataTyped?.scope_2_estimated_project ?? null;
  const scope3Start = emissionTrend[baseYear]?.scope_3_net ?? null;
  const scope3End = chartDataTyped?.scope_3_estimated_project ?? null;
  const yearCount = projectedYear - baseYear;

  const chartData = yearRange.map((year, idx) => {
    const v = emissionTrend[year];
    // Linear interpolation for projected value
    let scope1Projected = null;
    let scope2Projected = null;
    let scope3Projected = null;
    if (scope1Start !== null && scope1End !== null) {
      scope1Projected =
        scope1Start + ((scope1End - scope1Start) * idx) / yearCount;
    }
    if (scope2Start !== null && scope2End !== null) {
      scope2Projected =
        scope2Start + ((scope2End - scope2Start) * idx) / yearCount;
    }
    if (scope3Start !== null && scope3End !== null) {
      scope3Projected =
        scope3Start + ((scope3End - scope3Start) * idx) / yearCount;
    }
    return {
      year,
      Scope1: v?.scope_1_net ?? null,
      Scope2: v?.scope_2_net ?? null,
      Scope3: v?.scope_3_net ?? null,
      scope1Projected,
      scope2Projected,
      scope3Projected,
    };
  });

  // Set default selected year to first available year if not set
  useEffect(() => {
    // Only auto-select if no year is currently selected and we have base years
    const baseYearsData = (baseYears as any)?.data;
    if (baseYearsData?.length > 0 && selectedYear === "") {
      setSelectedYear(baseYearsData[0]);
    }
  }, [baseYears, selectedYear]);

  console.log("emissionTrend", emissionTrend);
  console.log("chartData", chartData);

  // Determine if long term is selected and set x-axis tick interval and style
  const isLongTerm = selectedTargetType === "long_term";
  const xAxisInterval = isLongTerm ? 4 : 0;
  // Custom XAxis tick renderer for long term
  const renderYearTick = (props: any) => {
    const { x, y, payload } = props;
    if (isLongTerm) {
      return (
        <text
          x={x}
          y={y}
          dy={20}
          fontSize={11}
          fontWeight={600}
          fontFamily="Inter, sans-serif"
          fill="var(--chakra-colors-textColor, #124e97)"
          textAnchor="end"
          transform={`rotate(-45,${x},${y})`}
        >
          {payload.value}
        </text>
      );
    }
    return (
      <text
        x={x}
        y={y}
        dy={16}
        fontSize={14}
        fontWeight={600}
        fontFamily="Inter, sans-serif"
        fill="var(--chakra-colors-textColor, #124e97)"
        textAnchor="middle"
      >
        {payload.value}
      </text>
    );
  };

  // Custom Tooltip for showing projected, actual, and difference
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload || !payload.length) return null;
    // Find projected and actual values for each scope
    const year = label;
    const scope1Projected = payload.find(
      (p: any) => p.dataKey === "scope1Projected"
    )?.value;
    const scope2Projected = payload.find(
      (p: any) => p.dataKey === "scope2Projected"
    )?.value;
    const scope3Projected = payload.find(
      (p: any) => p.dataKey === "scope3Projected"
    )?.value;
    const scope1Actual = payload.find(
      (p: any) => p.dataKey === "Scope1"
    )?.value;
    const scope2Actual = payload.find(
      (p: any) => p.dataKey === "Scope2"
    )?.value;
    const scope3Actual = payload.find(
      (p: any) => p.dataKey === "Scope3"
    )?.value;
    const showProjected =
      scope1Projected !== undefined ||
      scope2Projected !== undefined ||
      scope3Projected !== undefined;
    return (
      <div
        style={{
          background: "white",
          border: "none",
          borderRadius: 8,
          boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
          fontSize: 13,
          padding: "0.7rem 1.1rem",
          minWidth: 180,
        }}
      >
        <div style={{ fontWeight: 700, color: "#2d3748", marginBottom: 4 }}>
          {year}
        </div>
        {/* Scope 1 */}
        {scope1Projected !== undefined && (
          <div style={{ marginBottom: 4 }}>
            <span style={{ color: "#1976d2", fontWeight: 600 }}>
              Scope 1 Projected:{" "}
              {scope1Projected?.toLocaleString(undefined, {
                maximumFractionDigits: 2,
              })}
            </span>
            <br />
            <span style={{ color: "#1976d2", opacity: 0.7 }}>
              Actual:{" "}
              {scope1Actual?.toLocaleString(undefined, {
                maximumFractionDigits: 2,
              }) ?? "-"}
            </span>
            {scope1Actual !== undefined && (
              <span
                style={{
                  marginLeft: 8,
                  color:
                    scope1Projected - scope1Actual >= 0 ? "#38A169" : "#E53E3E",
                  fontWeight: 600,
                }}
              >
                ({scope1Projected - scope1Actual >= 0 ? "+" : ""}
                {(scope1Projected - scope1Actual).toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
                )
              </span>
            )}
          </div>
        )}
        {/* Scope 2 */}
        {scope2Projected !== undefined && (
          <div style={{ marginBottom: 4 }}>
            <span style={{ color: "#b3d464", fontWeight: 600 }}>
              Scope 2 Projected:{" "}
              {scope2Projected?.toLocaleString(undefined, {
                maximumFractionDigits: 2,
              })}
            </span>
            <br />
            <span style={{ color: "#b3d464", opacity: 0.7 }}>
              Actual:{" "}
              {scope2Actual?.toLocaleString(undefined, {
                maximumFractionDigits: 2,
              }) ?? "-"}
            </span>
            {scope2Actual !== undefined && (
              <span
                style={{
                  marginLeft: 8,
                  color:
                    scope2Projected - scope2Actual >= 0 ? "#38A169" : "#E53E3E",
                  fontWeight: 600,
                }}
              >
                ({scope2Projected - scope2Actual >= 0 ? "+" : ""}
                {(scope2Projected - scope2Actual).toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
                )
              </span>
            )}
          </div>
        )}
        {/* Scope 3 */}
        {scope3Projected !== undefined && (
          <div style={{ marginBottom: 4 }}>
            <span style={{ color: "#f6c343", fontWeight: 600 }}>
              Scope 3 Projected:{" "}
              {scope3Projected?.toLocaleString(undefined, {
                maximumFractionDigits: 2,
              })}
            </span>
            <br />
            <span style={{ color: "#f6c343", opacity: 0.7 }}>
              Actual:{" "}
              {scope3Actual?.toLocaleString(undefined, {
                maximumFractionDigits: 2,
              }) ?? "-"}
            </span>
            {scope3Actual !== undefined && (
              <span
                style={{
                  marginLeft: 8,
                  color:
                    scope3Projected - scope3Actual >= 0 ? "#38A169" : "#E53E3E",
                  fontWeight: 600,
                }}
              >
                ({scope3Projected - scope3Actual >= 0 ? "+" : ""}
                {(scope3Projected - scope3Actual).toLocaleString(undefined, {
                  maximumFractionDigits: 2,
                })}
                )
              </span>
            )}
          </div>
        )}
        {/* Fallback: show all other values if not projected */}
        {!showProjected &&
          payload.map((p: any, idx: number) => (
            <div key={idx} style={{ color: p.color, fontWeight: 600 }}>
              {p.name}:{" "}
              {p.value?.toLocaleString(undefined, { maximumFractionDigits: 2 })}
            </div>
          ))}
      </div>
    );
  };

  // Ref for chart download
  const chartRef = useRef<HTMLDivElement>(null);

  if (isLoading || isLoadingBaseYears) {
    return <ShimmerLoader variant="general" />;
  }

  return (
    <div className="carbon-neutrality-dashboard-minimal">
      {/* Filters Section */}
      <HStack spacing={4} justify="flex-end" mb={6}>
        <Box>
          <Select
            value={selectedTargetType}
            onChange={(e) => setSelectedTargetType(e.target.value)}
            size="md"
            bg="white"
            borderColor="gray.200"
            borderRadius="md"
            _hover={{ borderColor: "gray.300" }}
            _focus={{
              borderColor: "blue.400",
              boxShadow: "0 0 0 1px var(--chakra-colors-blue-500)",
            }}
            transition="all 0.2s ease"
            fontSize="sm"
            fontWeight="medium"
            color="textColor"
            _placeholder={{ color: "gray.500" }}
          >
            <option value="short_term">Short Term (0-5 Years)</option>
            <option value="medium_term">Medium Term (5-10 Years)</option>
            <option value="long_term">Long Term (10 Years to 30+ Yrs)</option>
          </Select>
        </Box>
        <Box>
          <MultiSelectScopeDropdown
            selectedScopes={selectedScopes}
            onSelectScopes={handleScopeChange}
          />
        </Box>
        <Box>
          <CustomYearDropdown
            selectedYear={selectedYear}
            onSelectYear={handleYearChange}
            years={(baseYears as any)?.data}
            placeholder="Select base year"
          />
        </Box>
      </HStack>

      {/* Stats Row */}
      <div className="stats-grid-minimal">
        {/* Total Emissions */}
        <div className="stat-card-minimal">
          <Icon
            as={Cloud}
            className="stat-icon-minimal"
            style={{ color: "#E53E3E" }}
          />
          <div>
            <div className="stat-value-minimal">
              {cnpData?.total_emission?.toFixed(1) || "0.0"} TCO₂e
            </div>
            <div className="stat-title-minimal">Total Emissions</div>
          </div>
        </div>

        {/* Carbon Offset */}
        <div className="stat-card-minimal">
          <Icon
            as={Leaf}
            className="stat-icon-minimal"
            style={{ color: "#38A169" }}
          />
          <div>
            <div className="stat-value-minimal">
              {cnpData?.carbon_offset?.toFixed(1) || "0.0"} TCO₂e
            </div>
            <div className="stat-title-minimal">Carbon Offset</div>
          </div>
        </div>

        {/* Residual Emissions */}
        <div className="stat-card-minimal">
          <Icon
            as={TrendingDown}
            className="stat-icon-minimal"
            style={{ color: "#DD6B20" }}
          />
          <div>
            <div className="stat-value-minimal">
              {cnpData?.residual_emission?.toFixed(1) || "0.0"} TCO₂e
            </div>
            <div className="stat-title-minimal">Residual Emissions</div>
          </div>
        </div>
      </div>

      {/* Chart Section */}
      <div
        ref={chartRef}
        className="chart-card-minimal"
        style={{
          marginBottom: "2rem",
          background: "#fff",
          borderRadius: "0.75rem",
          padding: "1.25rem 1.5rem",
          border: "1px solid #f3f4f6",
          boxShadow: "none",
          display: "flex",
          flexDirection: "column",
          alignItems: "stretch",
          position: "relative",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            marginBottom: "1rem",
          }}
        >
          <div
            className="chart-title-minimal"
            style={{
              fontSize: "0.9rem",
              fontWeight: 600,
              color: "#2d3748",
              letterSpacing: "0.02em",
            }}
          >
            Emissions Trend & Projected Path
          </div>
          <ChartDownloadButton
            targetRef={chartRef}
            filename="emissions-trend.png"
            title="Emissions Trend & Projected Path"
            forceHtml2Canvas={true}
          />
        </div>
        <ResponsiveContainer width="100%" height={320}>
          <LineChart
            data={chartData}
            margin={{
              left: 20,
              right: 20,
              top: 60,
              bottom: isLongTerm ? 60 : 20,
            }}
          >
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="#e2e8f0"
              opacity={0.5}
            />
            <XAxis
              dataKey="year"
              tick={renderYearTick}
              type="category"
              allowDuplicatedCategory={false}
              interval={xAxisInterval}
              ticks={yearRange}
              axisLine={{ stroke: "#e2e8f0" }}
              tickLine={false}
              fontSize={12}
              stroke="#A0AEC0"
            />
            <YAxis
              fontSize={12}
              stroke="#A0AEC0"
              tickLine={false}
              axisLine={{ stroke: "#e2e8f0" }}
              tick={{ fill: "#4A5568", fontWeight: 500 }}
            />
            <Tooltip
              content={CustomTooltip}
              cursor={{ fill: "rgba(0,0,0,0.03)" }}
            />
            <Legend
              verticalAlign="top"
              layout="horizontal"
              wrapperStyle={{ fontSize: 12 }}
            />
            {/* Solid lines for each scope - only render if scope is selected or no scopes selected */}
            {(selectedScopes.length === 0 ||
              selectedScopes.includes("CNP_SCOPE_1")) && (
              <Line
                type="monotone"
                dataKey="Scope1"
                name="Scope 1 (Net)"
                stroke="#1976d2"
                strokeWidth={2.5}
                dot={{ r: 4, stroke: "#1976d2", fill: "#fff", strokeWidth: 2 }}
                activeDot={{
                  r: 6,
                  stroke: "#1976d2",
                  fill: "#fff",
                  strokeWidth: 3,
                }}
                connectNulls
                isAnimationActive
              />
            )}
            {(selectedScopes.length === 0 ||
              selectedScopes.includes("CNP_SCOPE_2")) && (
              <Line
                type="monotone"
                dataKey="Scope2"
                name="Scope 2 (Net)"
                stroke="#b3d464"
                strokeWidth={2.5}
                dot={{ r: 4, stroke: "#b3d464", fill: "#fff", strokeWidth: 2 }}
                activeDot={{
                  r: 6,
                  stroke: "#b3d464",
                  fill: "#fff",
                  strokeWidth: 3,
                }}
                connectNulls
                isAnimationActive
              />
            )}
            {(selectedScopes.length === 0 ||
              selectedScopes.includes("CNP_SCOPE_3")) && (
              <Line
                type="monotone"
                dataKey="Scope3"
                name="Scope 3 (Net)"
                stroke="#f6c343"
                strokeWidth={2.5}
                dot={{ r: 4, stroke: "#f6c343", fill: "#fff", strokeWidth: 2 }}
                activeDot={{
                  r: 6,
                  stroke: "#f6c343",
                  fill: "#fff",
                  strokeWidth: 3,
                }}
                connectNulls
                isAnimationActive
              />
            )}
            {/* Projected dotted lines for each scope - only render if scope is selected or no scopes selected */}
            {(selectedScopes.length === 0 ||
              selectedScopes.includes("CNP_SCOPE_1")) && (
              <Line
                type="linear"
                dataKey="scope1Projected"
                name="Scope 1 Projected"
                stroke="#1976d2"
                strokeDasharray="4 4"
                strokeWidth={2.5}
                dot={{ r: 5, stroke: "#1976d2", fill: "#fff", strokeWidth: 2 }}
                legendType="plainline"
                isAnimationActive
                connectNulls
              />
            )}
            {(selectedScopes.length === 0 ||
              selectedScopes.includes("CNP_SCOPE_2")) && (
              <Line
                type="linear"
                dataKey="scope2Projected"
                name="Scope 2 Projected"
                stroke="#b3d464"
                strokeDasharray="4 4"
                strokeWidth={2.5}
                dot={{ r: 5, stroke: "#b3d464", fill: "#fff", strokeWidth: 2 }}
                legendType="plainline"
                isAnimationActive
                connectNulls
              />
            )}
            {(selectedScopes.length === 0 ||
              selectedScopes.includes("CNP_SCOPE_3")) && (
              <Line
                type="linear"
                dataKey="scope3Projected"
                name="Scope 3 Projected"
                stroke="#f6c343"
                strokeDasharray="4 4"
                strokeWidth={2.5}
                dot={{ r: 5, stroke: "#f6c343", fill: "#fff", strokeWidth: 2 }}
                legendType="plainline"
                isAnimationActive
                connectNulls
              />
            )}
          </LineChart>
        </ResponsiveContainer>
      </div>

      <style jsx>{`
        .carbon-neutrality-dashboard-minimal {
          padding: 2.5rem 1rem;
          background: #fafbfc;
          min-height: 100vh;
          font-family: "Inter", sans-serif;
        }
        .stats-grid-minimal {
          display: flex;
          gap: 1.5rem;
          margin-bottom: 2rem;
          flex-wrap: wrap;
        }
        .stat-card-minimal {
          flex: 1 1 200px;
          display: flex;
          align-items: center;
          gap: 1rem;
          background: #fff;
          border-radius: 0.75rem;
          padding: 1.25rem 1.5rem;
          box-shadow: none;
          border: 1px solid #f3f4f6;
          min-width: 200px;
          transition: all 0.2s ease-in-out;
        }
        .stat-card-minimal:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .stat-icon-minimal {
          width: 2.2rem;
          height: 2.2rem;
          opacity: 0.7;
        }
        .stat-value-minimal {
          font-size: 1.6rem;
          font-weight: 600;
          color: #2b6cb0;
          margin-bottom: 0.1rem;
        }
        .stat-title-minimal {
          font-size: 0.95rem;
          color: #8d99ae;
          font-weight: 400;
          letter-spacing: 0.01em;
        }
        .chart-card-minimal {
          background: #fff;
          border-radius: 0.75rem;
          padding: 1.25rem 1.5rem;
          border: 1px solid #f3f4f6;
          box-shadow: none;
          display: flex;
          flex-direction: column;
          align-items: stretch;
          transition: all 0.2s ease-in-out;
          position: relative;
        }
        .chart-card-minimal:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .chart-title-minimal {
          font-size: 0.9rem;
          font-weight: 600;
          color: #2d3748;
          margin-bottom: 1rem;
          letter-spacing: 0.02em;
        }
      `}</style>
    </div>
  );
};

export default CarbonNeutralityAnalytics;
