import { Roles } from "@/types/index.types";
import React, { useState, useEffect } from "react";
import { Box, Flex, Text, Button } from "@chakra-ui/react";
import { FileText, Leaf, ClipboardCheck, UserPlus } from "lucide-react";
import { useRouter } from "next/router";
import { getParsedToken } from "@/utils/withAuth";

const GeneralQuickActions = ({
  onAssessmentOpen,
  onCNPPlanOpen,
  onSelfAssessmentOpen,
}: {
  onAssessmentOpen: () => void;
  onCNPPlanOpen: () => void;
  onSelfAssessmentOpen: () => void;
}) => {
  const router = useRouter();

  const [isMounted, setIsMounted] = useState<boolean>();
  const [userRole, setUserRole] = useState<Roles>();
  // Load user role on mount
  useEffect(() => {
    setIsMounted(true);
    const token = getParsedToken();
    if (token?.role) {
      setUserRole(token.role as Roles);
    }
  }, []);

  return (
    <Box
      bg="white"
      borderRadius="2xl"
      boxShadow="sm"
      border="1px solid"
      borderColor="gray.200"
      p={6}
      mb={2}
    >
      <Flex direction="column" gap={4}>
        <Text fontSize="lg" fontWeight="bold" color="gray.700">
          Quick Actions
        </Text>
        <Flex
          direction={{ base: "column", sm: "row" }}
          gap={{ base: 3, sm: 3, md: 4 }}
          justify="flex-start"
          align={{ base: "stretch", sm: "flex-start" }}
          flexWrap={{ base: "nowrap", sm: "wrap" }}
          w="100%"
        >
          <Button
            leftIcon={<FileText size={18} />}
            colorScheme="blue"
            borderRadius="full"
            fontWeight="bold"
            px={6}
            py={4}
            onClick={() => {
              if (router.pathname !== "/dashboard/assessment") {
                localStorage.setItem("dashboard_quick_action", "assessment");
                router.push("/dashboard/assessment");
              } else {
                onAssessmentOpen();
              }
            }}
            _hover={{ bg: "blue.600", color: "white" }}
            transition="all 0.2s"
            width={{ base: "100%", sm: "auto" }}
          >
            Create ESG Assessment
          </Button>
          <Button
            leftIcon={<Leaf size={18} />}
            colorScheme="teal"
            borderRadius="full"
            fontWeight="bold"
            px={6}
            py={4}
            onClick={() => {
              if (router.pathname !== "/dashboard/carbon-neutrality-plan") {
                localStorage.setItem("dashboard_quick_action", "cnp");
                router.push("/dashboard/carbon-neutrality-plan");
              } else {
                onCNPPlanOpen();
              }
            }}
            _hover={{ bg: "teal.600", color: "white" }}
            transition="all 0.2s"
            width={{ base: "100%", sm: "auto" }}
          >
            Create Carbon Neutrality Plan
          </Button>
          <Button
            leftIcon={<ClipboardCheck size={18} />}
            colorScheme="purple"
            borderRadius="full"
            fontWeight="bold"
            px={6}
            py={4}
            onClick={() => {
              if (router.pathname !== "/dashboard/self-assessment") {
                localStorage.setItem(
                  "dashboard_quick_action",
                  "self-assessment"
                );
                router.push("/dashboard/self-assessment");
              } else {
                onSelfAssessmentOpen();
              }
            }}
            _hover={{ bg: "purple.600", color: "white" }}
            transition="all 0.2s"
            width={{ base: "100%", sm: "auto" }}
          >
            Create Self Assessment
          </Button>
          {isMounted && userRole != Roles.SUB_USER && (
            <Button
              leftIcon={<UserPlus size={18} />}
              colorScheme="cyan"
              textColor={"white"}
              borderRadius="full"
              fontWeight="bold"
              px={6}
              py={4}
              onClick={() => {
                if (router.pathname !== "/dashboard/sub-users") {
                  localStorage.setItem("dashboard_quick_action", "sub-user");
                  router.push("/dashboard/sub-users");
                } else {
                  // We'll handle dialog open on the sub-users page
                }
              }}
              _hover={{ bg: "cyan.600", color: "white" }}
              transition="all 0.2s"
              width={{ base: "100%", sm: "auto" }}
            >
              Create Sub User
            </Button>
          )}
        </Flex>
      </Flex>
    </Box>
  );
};

export default GeneralQuickActions;
