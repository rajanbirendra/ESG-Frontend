import React, { useState, useRef, useLayoutEffect, useEffect } from "react";
import {
  Box,
  Heading,
  Text,
  VStack,
  Icon,
  Flex,
  SimpleGrid,
} from "@chakra-ui/react";
import { BarChart3, Leaf, Users, ShieldCheck } from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  Legend,
  ResponsiveContainer,
  Tooltip,
} from "recharts";
import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";
import { getParsedToken } from "@/utils/withAuth";
import { Roles } from "@/types/index.types";

const PIE_COLORS = {
  YES: "#38A169", // green.500
  NO: "#E53E3E", // red.500
};

const chartMeta = [
  { key: "ENVIRONMENT", label: "Environment", icon: Leaf, color: "green.500" },
  { key: "SOCIAL", label: "Social", icon: Users, color: "blue.500" },
  {
    key: "GOVERNANCE",
    label: "Governance",
    icon: ShieldCheck,
    color: "purple.500",
  },
];

// Helper to get the mid angle and position for a slice's tooltip above the pie section
function getTooltipPlacement(data, idx, pieCx, pieCy, pieR, offset = 24) {
  if (!data || data.length === 0) return { left: pieCx, top: pieCy };
  const total = data.reduce((sum, d) => sum + d.value, 0);
  let startAngle = -90;
  for (let i = 0; i < idx; i++) {
    startAngle += (data[i].value / total) * 360;
  }
  const midAngle = startAngle + ((data[idx].value / total) * 360) / 2;
  const rad = (midAngle * Math.PI) / 180;
  // Tooltip position just outside the pie border at the mid-angle
  const left = pieCx + (pieR + offset) * Math.cos(rad);
  const top = pieCy + (pieR + offset) * Math.sin(rad);
  return { left, top };
}

const SelfAssessmentAnalytics: React.FC = () => {
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);
  const [selectedYear, setSelectedYear] = useState<string>(
    new Date().getFullYear().toString()
  );
  const [activeIndex] = useState(0); // Always show tooltip for first slice
  const [userRole, setUserRole] = useState<Roles | null>(null);

  // Load user role and set branch for SUB_USER on mount
  useEffect(() => {
    const token = getParsedToken();
    if (token?.role) {
      setUserRole(token.role as Roles);
      // For SUB_USER, set the branch from token
      if (token.role === Roles.SUB_USER && token.company?.branch_id) {
        setSelectedBranch(token.company.branch_id);
      }
    }
  }, []);

  const { data } = useUserAnalyticsAPI().getSelfAssessmentChartMetrics(
    selectedYear ? Number(selectedYear) : undefined,
    selectedBranch || undefined
  );

  // Prepare chart data for each section
  const getPieData = (section: string) => {
    if (!data || !data[section]) return null;
    // Always return YES first, NO second for consistent color mapping
    return [
      { name: "YES", value: data[section].YES },
      { name: "NO", value: data[section].NO },
    ];
  };

  // Ref and state for dynamic card size
  const containerRef = useRef<HTMLDivElement>(null);
  const [cardSize, setCardSize] = useState({ width: 600, height: 244 });

  useLayoutEffect(() => {
    if (containerRef.current) {
      const rect = containerRef.current.getBoundingClientRect();
      setCardSize({ width: rect.width, height: rect.height });
    }
  }, [data]);

  return (
    <Box
      bg="white"
      borderRadius="2xl"
      boxShadow="sm"
      border="1px solid"
      borderColor="gray.200"
      p={{ base: 6, md: 10 }}
      w="full"
      minH="300px"
      display="flex"
      flexDirection="column"
      alignItems="center"
      justifyContent="flex-start"
      gap={10}
    >
      <Flex w="full" mb={10} gap={6} align="center" justify="flex-end">
        {userRole === Roles.USER && (
          <Box minW="180px">
            <BranchDropdown
              value={selectedBranch}
              onChange={setSelectedBranch}
              label=""
            />
          </Box>
        )}
        <Box minW="160px">
          <YearDropdown
            selectedYear={selectedYear}
            onSelectYear={setSelectedYear}
            maxCurrentYear={true}
          />
        </Box>
      </Flex>
      <SimpleGrid columns={{ base: 1, md: 3 }} spacing={10} w="full">
        {chartMeta.map(({ key, label, icon, color }) => {
          const pieData = getPieData(key);
          return (
            <Box
              key={key}
              bg={`${color.split(".")[0]}.50`}
              borderRadius="xl"
              boxShadow="sm"
              border="1px solid"
              borderColor={`${color.split(".")[0]}.200`}
              p={{ base: 5, md: 8 }}
              display="flex"
              flexDirection="column"
              alignItems="center"
              justifyContent="center"
              maxH="375px"
              mb={2}
              transition="all 0.2s"
              _hover={{
                transform: "translateY(-4px)",
                boxShadow: "lg",
                borderColor: color,
              }}
            >
              <Flex align="center" gap={3} mb={6}>
                <Icon as={icon} boxSize={8} color={color} />
                <Heading size="md" color="gray.700" fontWeight="bold">
                  {label}
                </Heading>
              </Flex>
              {pieData ? (
                <Box w="100%" pb={8} position="relative" ref={containerRef}>
                  <ResponsiveContainer width="100%" height={180}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        dataKey="value"
                        nameKey="name"
                        cx={"50%"}
                        cy={90}
                        innerRadius={50}
                        outerRadius={80}
                        label={false}
                        labelLine={false}
                        activeIndex={activeIndex}
                        startAngle={90}
                        endAngle={-270}
                      >
                        {pieData.map((entry, idx) => {
                          if (!entry || entry.value <= 0) return null;
                          // Card and pie geometry (responsive)
                          const cardW = cardSize.width;
                          const cardH = cardSize.height;
                          const pieCx = 0.5 * cardW;
                          const pieCy = 90;
                          const pieR = 80;
                          const { left, top } = getTooltipPlacement(
                            pieData,
                            idx,
                            pieCx,
                            pieCy,
                            pieR,
                            24
                          );
                          return (
                            <Cell
                              key={`cell-${idx}`}
                              fill={PIE_COLORS[entry.name as "YES" | "NO"]}
                            />
                          );
                        })}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  {/* Custom legend at bottom right */}
                  <Flex justify="flex-end" mt={4} gap={4}>
                    {pieData.map((entry) => (
                      <Flex align="center" key={entry.name} gap={1}>
                        <Box
                          w="8px"
                          h="8px"
                          borderRadius="full"
                          bg={PIE_COLORS[entry.name as "YES" | "NO"]}
                        />
                        <Text
                          fontSize="xs"
                          color="gray.600"
                          fontWeight="medium"
                        >
                          {entry.name}
                        </Text>
                      </Flex>
                    ))}
                  </Flex>
                  {/* Dynamically place tooltips for each pie section with value > 0 */}
                  {pieData &&
                    pieData.map((entry, idx) => {
                      if (!entry || entry.value <= 0) return null;
                      // Pie geometry (responsive)
                      const cardW = cardSize.width;
                      const pieCx = 0.5 * cardW;
                      const pieCy = 90;
                      const pieR = 80;
                      const { left, top } = getTooltipPlacement(
                        pieData,
                        idx,
                        pieCx,
                        pieCy,
                        pieR,
                        24
                      );
                      const total = pieData.reduce(
                        (sum, d) => sum + d.value,
                        0
                      );
                      return (
                        <Box
                          key={entry.name}
                          position="absolute"
                          left={`${left}px`}
                          top={`${top}px`}
                          transform="translate(-50%, -100%)"
                          bg="white"
                          borderRadius="md"
                          boxShadow="md"
                          px={2}
                          py={1}
                          border="1px solid"
                          borderColor="gray.200"
                          minW="72px"
                          textAlign="center"
                          display="flex"
                          gap="2"
                          flexDirection="row"
                          alignItems="center"
                          style={{ zIndex: 2 }}
                        >
                          <Text
                            // fontSize="xs"
                            color="gray.500"
                            fontWeight="medium"
                          >
                            {entry.name}
                          </Text>
                          <Text
                            fontSize="md"
                            color="gray.700"
                            fontWeight="bold"
                          >
                            {total > 0
                              ? ((entry.value / total) * 100).toFixed(0)
                              : 0}
                            %
                          </Text>
                          {/* Arrow always points down */}
                          <Box
                            position="absolute"
                            left="50%"
                            top="100%"
                            transform="translate(-50%, 0)"
                            w="0"
                            h="0"
                            borderLeft="10px solid transparent"
                            borderRight="10px solid transparent"
                            borderTop="6px solid white"
                            filter="drop-shadow(0 1px 2px rgba(0,0,0,0.08))"
                          />
                        </Box>
                      );
                    })}
                </Box>
              ) : (
                <Text color="gray.400" mt={8}>
                  No data available
                </Text>
              )}
            </Box>
          );
        })}
      </SimpleGrid>
    </Box>
  );
};

export default SelfAssessmentAnalytics;
