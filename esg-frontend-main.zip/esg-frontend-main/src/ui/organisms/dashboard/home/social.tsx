import React, { useState, useEffect } from "react";
import {
  Box,
  Flex,
  Text,
  Badge,
  VStack,
  Spacer,
  Select,
  Stat,
  StatLabel,
  StatNumber,
  Icon,
  Skeleton,
  Button,
} from "@chakra-ui/react";
import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
  LabelList,
  Cell,
} from "recharts";
import DateRangePicker from "@/ui/molecules/DateRangeFilter";
import {
  Users,
  Briefcase,
  GraduationCap,
  HeartHandshake,
  FileCheck,
  FileX,
  DollarSign,
  CircleHelp,
  CalendarRange,
  Clock,
  Download,
} from "lucide-react";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import { format } from "date-fns";
import ChartDownloadButton from "@/ui/components/ChartDownloadButton";
import { getParsedToken } from "@/utils/withAuth";
import { Roles } from "@/types/index.types";

interface SocialCardMetrics {
  [key: string]: number | undefined; // Allow for other possible keys
}

// Map API keys to display properties (label, icon, color, suffix)
const socialCardDisplayMap: Record<
  string,
  {
    label: string;
    icon: typeof Icon | any;
    color: string;
    suffix: string;
  }
> = {
  total_employees: {
    label: "Total Employees",
    icon: Users,
    color: "blue.600",
    suffix: "",
  },
  employees_engaged_in_csr: {
    label: "Employees Engaged in CSR",
    icon: HeartHandshake,
    color: "blue.500",
    suffix: "",
  },
  training_hours_per_employee: {
    label: "Training Hours Per Employee",
    icon: GraduationCap,
    color: "blue.400",
    suffix: " hrs",
  },
  total_business_travel_cost: {
    label: "Total Business Travel Cost",
    icon: DollarSign,
    color: "blue.300",
    suffix: "",
  },
  number_of_business_travels: {
    label: "Number of Business Travels",
    icon: Briefcase,
    color: "blue.200",
    suffix: "",
  },
};

export default function Social() {
  const [activePicker, setActivePicker] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<Roles | null>(null);
  const currentYear = new Date().getFullYear();
  const today = new Date();
  const startOfYear = new Date(today.getFullYear(), 0, 1); // January 1st of current year

  // Load user role and set branches for SUB_USER on mount
  useEffect(() => {
    const token = getParsedToken();
    if (token?.role) {
      setUserRole(token.role as Roles);
      // For SUB_USER, set all branches from token
      if (token.role === Roles.SUB_USER && token.company?.branch_id) {
        setSelectedWorkdayBranch(token.company.branch_id);
        setSelectedTurnoverBranch(token.company.branch_id);
        setSelectedBranch(token.company.branch_id);
        setSelectedPermanentContractualBranch(token.company.branch_id);
      }
    }
  }, []);

  const [selectedWorkdayStartDate, setSelectedWorkdayStartDate] = useState<
    string | undefined
  >(format(startOfYear, "yyyy/MM/dd"));
  const [selectedWorkdayEndDate, setSelectedWorkdayEndDate] = useState<
    string | undefined
  >(format(today, "yyyy/MM/dd"));
  const [selectedTurnoverStartDate, setSelectedTurnoverStartDate] = useState<
    string | undefined
  >(format(startOfYear, "yyyy/MM/dd"));
  const [selectedTurnoverEndDate, setSelectedTurnoverEndDate] = useState<
    string | undefined
  >(format(today, "yyyy/MM/dd"));
  const [selectedWorkdayBranch, setSelectedWorkdayBranch] = useState<
    string | null
  >(null);
  const [selectedTurnoverBranch, setSelectedTurnoverBranch] = useState<
    string | null
  >(null);
  const [
    selectedPermanentContractualYear,
    setSelectedPermanentContractualYear,
  ] = useState(currentYear.toString());
  const [
    selectedPermanentContractualStartDate,
    setSelectedPermanentContractualStartDate,
  ] = useState<string | undefined>(format(startOfYear, "yyyy/MM/dd"));
  const [
    selectedPermanentContractualEndDate,
    setSelectedPermanentContractualEndDate,
  ] = useState<string | undefined>(format(today, "yyyy/MM/dd"));
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);
  const [
    selectedPermanentContractualBranch,
    setSelectedPermanentContractualBranch,
  ] = useState<string | null>(null);
  const [selectedHealthInsuredStartDate, setSelectedHealthInsuredStartDate] =
    useState<string | undefined>(format(startOfYear, "yyyy/MM/dd"));
  const [selectedHealthInsuredEndDate, setSelectedHealthInsuredEndDate] =
    useState<string | undefined>(format(today, "yyyy/MM/dd"));

  console.log("worklost", selectedWorkdayStartDate, selectedWorkdayEndDate);
  const { getSocialEmployeeTurnoverRate } = useUserAnalyticsAPI();

  const getSocialCards = useUserAnalyticsAPI().getSocialCards();
  const getSocialPermanentContractualEmployee =
    useUserAnalyticsAPI().getSocialPermanentContractualEmployee(
      selectedPermanentContractualBranch,
      selectedPermanentContractualStartDate,
      selectedPermanentContractualEndDate
    );
  const socialCardsData = getSocialCards?.data as SocialCardMetrics | undefined;
  const [workDayLostData, setWorkDayLostData] = useState<any[]>([]);
  const [employeeTurnoverRateData, setEmployeeTurnoverRateData] = useState<
    any[]
  >([]);
  const [healthInsuredData, setHealthInsuredData] = useState<any[]>([]);
  const [permanentContractualData, setPermanentContractualData] = useState<
    any[]
  >([]);

  const getSocialWorkDayLost = useUserAnalyticsAPI().getSocialWorkDayLost(
    selectedWorkdayBranch,
    selectedWorkdayStartDate,
    selectedWorkdayEndDate
  );
  const employeeTurnoverRateQuery = getSocialEmployeeTurnoverRate(
    selectedTurnoverBranch,
    selectedTurnoverStartDate,
    selectedTurnoverEndDate
  );

  const getSocialHealthInsuredEmployee =
    useUserAnalyticsAPI().getSocialHealthInsuredEmployee(
      selectedBranch,
      selectedHealthInsuredStartDate,
      selectedHealthInsuredEndDate
    );
  const healthInsuredQuery = getSocialHealthInsuredEmployee;

  const handleBranchChange = (branchId: string | null) => {
    setSelectedBranch(branchId || null);
  };

  const handleWorkdayBranchChange = (branchId: string | null) => {
    setSelectedWorkdayBranch(branchId);
  };

  const handleTurnoverBranchChange = (branchId: string | null) => {
    setSelectedTurnoverBranch(branchId);
  };

  useEffect(() => {
    if (getSocialWorkDayLost.data) {
      const data = getSocialWorkDayLost.data as Record<
        string,
        { male: number; female: number }
      >;
      const formattedData = Object.entries(data).map(([month, value]) => ({
        month,
        male: value.male,
        female: value.female,
      }));
      setWorkDayLostData(formattedData);
    }

    if (employeeTurnoverRateQuery.data) {
      const data = employeeTurnoverRateQuery.data as Record<
        string,
        { male: number; female: number }
      >;
      const formattedData = Object.entries(data).map(([month, value]) => ({
        month,
        male: value.male,
        female: value.female,
      }));
      setEmployeeTurnoverRateData(formattedData);
    }

    if (healthInsuredQuery.data) {
      const data = healthInsuredQuery.data as Record<
        string,
        { male: number; female: number }
      >;
      const formattedData = Object.entries(data).map(([month, value]) => ({
        month,
        male: value.male,
        female: value.female,
      }));
      setHealthInsuredData(formattedData);
    }

    if (getSocialPermanentContractualEmployee.data) {
      const data = getSocialPermanentContractualEmployee.data as Record<
        string,
        { permanent: number; contractual: number }
      >;
      const formattedData = Object.entries(data).map(([month, value]) => ({
        month,
        permanent: value.permanent,
        contractual: value.contractual,
      }));
      setPermanentContractualData(formattedData);
    }
  }, [
    getSocialWorkDayLost.data,
    employeeTurnoverRateQuery.data,
    healthInsuredQuery.data,
    getSocialPermanentContractualEmployee.data,
  ]);

  const isLoading = getSocialCards.isLoading;

  // Refs for each chart (for the chart+header container)
  const workdayChartRef = React.useRef<HTMLDivElement>(null);
  const turnoverChartRef = React.useRef<HTMLDivElement>(null);
  const healthChartRef = React.useRef<HTMLDivElement>(null);
  const permanentChartRef = React.useRef<HTMLDivElement>(null);

  // Helper to format date range
  const formatDateRange = (start?: string, end?: string) => {
    if (!start && !end) return "";
    if (start && end) return `${start} to ${end}`;
    return start || end || "";
  };

  if (isLoading) {
    return <ShimmerLoader variant="social" />;
  }

  return (
    <div className="social-dashboard-minimal">
      {/* Social Stat Cards */}
      <div className="stats-grid-minimal">
        {Object.entries(socialCardsData || {}).map(([key, value], index) => {
          const displayProps = socialCardDisplayMap[key] || {
            label: key
              .replace(/_/g, " ")
              .replace(/\b\w/g, (char) => char.toUpperCase()),
            icon: Clock,
            color: "gray.500",
            suffix: "",
          };

          return (
            <div key={index} className="stat-card-minimal">
              <Icon
                as={displayProps.icon}
                className="stat-icon-minimal"
                style={{ color: displayProps.color }}
              />
              <div>
                <div className="stat-value-minimal">
                  {value || 0}
                  {displayProps.suffix}
                </div>
                <div className="stat-title-minimal">{displayProps.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Charts Grid */}
      <div className="charts-grid-minimal">
        {/* Workday Lost Chart */}
        <div
          className={`chart-card-minimal ${
            activePicker === "workday" ? "picker-active" : ""
          }`}
        >
          <Flex align="center" justify="space-between" mb={1}>
            <div className="chart-title-minimal">Workdays Lost by Gender</div>
            <ChartDownloadButton
              targetRef={workdayChartRef}
              filename="workdays-lost-by-gender.png"
              title="Workdays Lost by Gender"
              branch={selectedWorkdayBranch || "All"}
              date={formatDateRange(
                selectedWorkdayStartDate,
                selectedWorkdayEndDate
              )}
            />
          </Flex>
          <Flex gap={3} justify="flex-end" mb={3}>
            {userRole === Roles.USER && (
              <Box w="180px">
                <BranchDropdown
                  value={selectedWorkdayBranch}
                  onChange={handleWorkdayBranchChange}
                  label=""
                />
              </Box>
            )}
            <DateRangePicker
              onOpen={() => setActivePicker("workday")}
              onClose={() => setActivePicker(null)}
              onApply={(startDateStr, endDateStr) => {
                setSelectedWorkdayStartDate(startDateStr);
                setSelectedWorkdayEndDate(endDateStr);
              }}
              onCancel={() => {
                setSelectedWorkdayStartDate(undefined);
                setSelectedWorkdayEndDate(undefined);
              }}
            />
          </Flex>
          <Box h="260px" ref={workdayChartRef}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={workDayLostData}
                margin={{ left: 20, right: 20, top: 20, bottom: 5 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#e2e8f0"
                  opacity={0.5}
                />
                <XAxis
                  dataKey="month"
                  fontSize={12}
                  stroke="#A0AEC0"
                  tick={{ fill: "#4A5568", fontWeight: 500 }}
                />
                <YAxis fontSize={12} stroke="#A0AEC0" hide />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                    fontSize: 13,
                  }}
                  cursor={{ fill: "rgba(0,0,0,0.03)" }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar
                  dataKey="male"
                  name="Male"
                  fill="#3182CE"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="male"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
                <Bar
                  dataKey="female"
                  name="Female"
                  fill="#63B3ED"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="female"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Box>
        </div>

        {/* Employee Turnover Rate Chart */}
        <div
          className={`chart-card-minimal ${
            activePicker === "turnover" ? "picker-active" : ""
          }`}
        >
          <Flex align="center" justify="space-between" mb={1}>
            <div className="chart-title-minimal">
              Employee Turnover Rate by Gender
            </div>
            <ChartDownloadButton
              targetRef={turnoverChartRef}
              filename="employee-turnover-rate-by-gender.png"
              title="Employee Turnover Rate by Gender"
              branch={selectedTurnoverBranch || "All"}
              date={formatDateRange(
                selectedTurnoverStartDate,
                selectedTurnoverEndDate
              )}
            />
          </Flex>
          <Flex gap={3} justify="flex-end" mb={3}>
            {userRole === Roles.USER && (
              <Box w="180px">
                <BranchDropdown
                  value={selectedTurnoverBranch}
                  onChange={handleTurnoverBranchChange}
                  label=""
                />
              </Box>
            )}
            <DateRangePicker
              onOpen={() => setActivePicker("turnover")}
              onClose={() => setActivePicker(null)}
              onApply={(startDateStr, endDateStr) => {
                setSelectedTurnoverStartDate(startDateStr);
                setSelectedTurnoverEndDate(endDateStr);
              }}
              onCancel={() => {
                setSelectedTurnoverStartDate(undefined);
                setSelectedTurnoverEndDate(undefined);
              }}
            />
          </Flex>
          <Box h="260px" ref={turnoverChartRef}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={employeeTurnoverRateData}
                margin={{ left: 20, right: 20, top: 20, bottom: 5 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#e2e8f0"
                  opacity={0.5}
                />
                <XAxis
                  dataKey="month"
                  fontSize={12}
                  stroke="#A0AEC0"
                  tick={{ fill: "#4A5568", fontWeight: 500 }}
                />
                <YAxis fontSize={12} stroke="#A0AEC0" hide />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                    fontSize: 13,
                  }}
                  cursor={{ fill: "rgba(0,0,0,0.03)" }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar
                  dataKey="male"
                  name="Male"
                  fill="#3182CE"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="male"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
                <Bar
                  dataKey="female"
                  name="Female"
                  fill="#63B3ED"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="female"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Box>
        </div>

        {/* Health Insured Employees Chart */}
        <div
          className={`chart-card-minimal ${
            activePicker === "health" ? "picker-active" : ""
          }`}
        >
          <Flex align="center" justify="space-between" mb={1}>
            <div className="chart-title-minimal">
              Health Insured Employees by Gender
            </div>
            <ChartDownloadButton
              targetRef={healthChartRef}
              filename="health-insured-employees-by-gender.png"
              title="Health Insured Employees by Gender"
              branch={selectedBranch || "All"}
              date={formatDateRange(
                selectedHealthInsuredStartDate,
                selectedHealthInsuredEndDate
              )}
            />
          </Flex>
          <Flex gap={3} justify="flex-end" mb={3}>
            {userRole === Roles.USER && (
              <Box w="180px">
                <BranchDropdown
                  value={selectedBranch}
                  onChange={handleBranchChange}
                  label=""
                />
              </Box>
            )}
            <DateRangePicker
              onOpen={() => setActivePicker("health")}
              onClose={() => setActivePicker(null)}
              onApply={(startDateStr, endDateStr) => {
                setSelectedHealthInsuredStartDate(startDateStr);
                setSelectedHealthInsuredEndDate(endDateStr);
              }}
              onCancel={() => {
                setSelectedHealthInsuredStartDate(undefined);
                setSelectedHealthInsuredEndDate(undefined);
              }}
            />
          </Flex>
          <Box h="260px" ref={healthChartRef}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={healthInsuredData}
                margin={{ left: 20, right: 20, top: 20, bottom: 5 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#e2e8f0"
                  opacity={0.5}
                />
                <XAxis
                  dataKey="month"
                  fontSize={12}
                  stroke="#A0AEC0"
                  tick={{ fill: "#4A5568", fontWeight: 500 }}
                />
                <YAxis fontSize={12} stroke="#A0AEC0" hide />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                    fontSize: 13,
                  }}
                  cursor={{ fill: "rgba(0,0,0,0.03)" }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar
                  dataKey="male"
                  name="Male"
                  fill="#3182CE"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="male"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
                <Bar
                  dataKey="female"
                  name="Female"
                  fill="#63B3ED"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="female"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Box>
        </div>

        {/* Permanent vs Contractual Employees Chart */}
        <div
          className={`chart-card-minimal ${
            activePicker === "permanent" ? "picker-active" : ""
          }`}
        >
          <Flex align="center" justify="space-between" mb={1}>
            <div className="chart-title-minimal">
              Permanent vs Contractual Employees
            </div>
            <ChartDownloadButton
              targetRef={permanentChartRef}
              filename="permanent-vs-contractual-employees.png"
              title="Permanent vs Contractual Employees"
              branch={selectedPermanentContractualBranch || "All"}
              date={formatDateRange(
                selectedPermanentContractualStartDate,
                selectedPermanentContractualEndDate
              )}
            />
          </Flex>
          <Flex gap={3} justify="flex-end" mb={3}>
            {userRole === Roles.USER && (
              <Box w="180px">
                <BranchDropdown
                  value={selectedPermanentContractualBranch}
                  onChange={setSelectedPermanentContractualBranch}
                  label=""
                />
              </Box>
            )}
            <DateRangePicker
              onOpen={() => setActivePicker("permanent")}
              onClose={() => setActivePicker(null)}
              onApply={(startDateStr, endDateStr) => {
                setSelectedPermanentContractualStartDate(startDateStr);
                setSelectedPermanentContractualEndDate(endDateStr);
              }}
              onCancel={() => {
                setSelectedPermanentContractualStartDate(undefined);
                setSelectedPermanentContractualEndDate(undefined);
              }}
            />
          </Flex>
          <Box h="260px" ref={permanentChartRef}>
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={permanentContractualData}
                margin={{ left: 20, right: 20, top: 20, bottom: 5 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  stroke="#e2e8f0"
                  opacity={0.5}
                />
                <XAxis
                  dataKey="month"
                  fontSize={12}
                  stroke="#A0AEC0"
                  tick={{ fill: "#4A5568", fontWeight: 500 }}
                />
                <YAxis fontSize={12} stroke="#A0AEC0" hide />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "none",
                    borderRadius: "8px",
                    boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                    fontSize: 13,
                  }}
                  cursor={{ fill: "rgba(0,0,0,0.03)" }}
                />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar
                  dataKey="permanent"
                  name="Permanent"
                  fill="#3182CE"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="permanent"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
                <Bar
                  dataKey="contractual"
                  name="Contractual"
                  fill="#63B3ED"
                  radius={[4, 4, 0, 0]}
                  maxBarSize={40}
                >
                  <LabelList
                    dataKey="contractual"
                    position="top"
                    content={(props: any) => {
                      const { x, y, width, value } = props;
                      if (
                        x === undefined ||
                        y === undefined ||
                        width === undefined ||
                        value === undefined ||
                        Number(value) === 0
                      ) {
                        return null;
                      }
                      return (
                        <text
                          x={Number(x) + Number(width) / 2}
                          y={Number(y) - 5}
                          textAnchor="middle"
                          fontSize={12}
                          fontWeight={600}
                          fill="#2B6CB0"
                        >
                          {value}
                        </text>
                      );
                    }}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </Box>
        </div>
      </div>

      <style jsx>{`
        .social-dashboard-minimal {
          padding: 2.5rem 1rem;
          background: #fafbfc;
          min-height: 100vh;
          font-family: "Inter", sans-serif;
        }
        .stats-grid-minimal {
          display: flex;
          gap: 1.5rem;
          margin-bottom: 2rem;
          flex-wrap: wrap;
        }
        .stat-card-minimal {
          flex: 1 1 180px;
          display: flex;
          align-items: center;
          gap: 1rem;
          background: #fff;
          border-radius: 0.75rem;
          padding: 1.25rem 1.5rem;
          box-shadow: none;
          border: 1px solid #f3f4f6;
          min-width: 180px;
          transition: all 0.2s ease-in-out;
        }
        .stat-card-minimal:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .stat-icon-minimal {
          width: 2.2rem;
          height: 2.2rem;
          opacity: 0.7;
        }
        .stat-value-minimal {
          font-size: 1.6rem;
          font-weight: 600;
          color: #2b6cb0;
          margin-bottom: 0.1rem;
        }
        .stat-title-minimal {
          font-size: 0.95rem;
          color: #8d99ae;
          font-weight: 400;
          letter-spacing: 0.01em;
        }
        .charts-grid-minimal {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
          gap: 1.5rem;
          margin-bottom: 2rem;
        }
        .chart-card-minimal {
          background: #fff;
          border-radius: 0.75rem;
          padding: 1.25rem 1.5rem;
          border: 1px solid #f3f4f6;
          box-shadow: none;
          display: flex;
          flex-direction: column;
          align-items: stretch;
          transition: all 0.2s ease-in-out;
          position: relative;
        }
        .chart-card-minimal:hover,
        .chart-card-minimal.picker-active {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
          z-index: 20;
        }
        .chart-title-minimal {
          font-size: 0.9rem;
          font-weight: 600;
          color: #2d3748;
          margin-bottom: 1rem;
          letter-spacing: 0.02em;
        }
      `}</style>
    </div>
  );
}
