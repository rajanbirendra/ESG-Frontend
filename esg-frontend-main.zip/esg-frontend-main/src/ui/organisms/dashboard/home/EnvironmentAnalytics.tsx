import React, { useState, useEffect, useRef } from "react";
import {
  Icon,
  Box,
  Text,
  Flex,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverBody,
  PopoverArrow,
  HStack,
  Center,
} from "@chakra-ui/react";
import {
  Zap,
  Cloud,
  Leaf,
  PieChart,
  Trash2,
  Activity,
  LucideArchiveX,
  LucideExternalLink,
} from "lucide-react";
// import Filters from "@/ui/components/Filters";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LabelList,
  Cell,
  PieChart as RechartsPieChart,
  Pie,
  Legend,
  TooltipProps,
} from "recharts";
import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import Link from "next/link";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import DateRangeFilter from "@/ui/molecules/DateRangeFilter";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import { format } from "date-fns";
import ChartDownloadButton from "@/ui/components/ChartDownloadButton";
import { getParsedToken } from "@/utils/withAuth";
import { Roles } from "@/types/index.types";

interface EnergyMixData {
  name: string;
  value: number;
  raw: number;
  fill: string;
}

interface BranchData {
  name: string;
  value: number;
  fill: string;
}

interface WasteTypeData {
  name: string;
  value: number;
  fill: string;
}

interface ScopeEmissionData {
  scope_1: number;
  scope_2: number;
  scope_3: number;
  total_emission: number;
}

interface Filters {
  branch?: string;
  facility?: string;
}

interface GHGChartDataItem {
  name: string;
  value: number;
  fill: string;
  actualValue: number;
}

type GHGChartDataType = GHGChartDataItem[];

// Custom tooltip for the Energy Mix pie
const CustomEnergyMixTooltip = ({
  active,
  payload,
  energyMixData,
}: {
  active?: boolean;
  payload?: any[];
  energyMixData: EnergyMixData[];
}) => {
  if (!active || !payload?.length) return null;
  const hovered = payload[0].payload;
  const other = energyMixData.find((d) => d.name !== hovered.name) || {
    name: "Other",
    value: 0,
    raw: 0,
    fill: "#718096",
  };
  const totalRaw = energyMixData.reduce((sum, d) => sum + d.raw, 0);
  const hoveredPct = (hovered.raw / totalRaw) * 100;
  const otherPct = (other.raw / totalRaw) * 100;

  return (
    <div
      style={{
        backgroundColor: "white",
        padding: "0.75rem",
        borderRadius: "0.75rem",
        boxShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
        border: "1px solid",
        borderColor: "#E2E8F0",
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "0.75rem",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "0.5rem",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
            }}
          >
            <div
              style={{
                width: "10px",
                height: "10px",
                backgroundColor: hovered.fill,
                borderRadius: "2px",
              }}
            />
            <span
              style={{
                fontWeight: 500,
                color: "#4A5568",
                fontSize: "0.875rem",
              }}
            >
              {hoveredPct.toFixed(1)}%
            </span>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: "0.5rem",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
            }}
          >
            <div
              style={{
                width: "10px",
                height: "10px",
                backgroundColor: other.fill,
                borderRadius: "2px",
              }}
            />
            <span
              style={{
                fontWeight: 500,
                color: "#4A5568",
                fontSize: "0.875rem",
              }}
            >
              {otherPct.toFixed(1)}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    console.log("active", active);
    console.log("payload", payload);
    return (
      <Box
        bg="white"
        p={3}
        borderRadius="md"
        boxShadow="lg"
        border="1px solid"
        borderColor="gray.200"
      >
        <Text fontWeight="medium" mb={2}>
          {label}
        </Text>
        {payload.map((entry: any, index: number) => (
          <Flex key={index} align="center" gap={2}>
            <Box w={3} h={3} borderRadius="sm" bg={entry.color} />
            <Text fontSize="sm" color="gray.600">
              {entry.name}: {entry.value}%
            </Text>
          </Flex>
        ))}
      </Box>
    );
  }
  return null;
};

const CustomEmissionTooltip = ({
  active,
  payload,
  emissionData,
}: {
  active?: boolean;
  payload?: any[];
  emissionData: GHGChartDataType;
}) => {
  if (!active || !payload?.length) return null;
  const totalValue = emissionData.reduce((sum, d) => sum + d.actualValue, 0);

  return (
    <div
      style={{
        backgroundColor: "white",
        padding: "0.75rem",
        borderRadius: "0.75rem",
        boxShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
        border: "1px solid",
        borderColor: "#E2E8F0",
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "0.75rem",
        }}
      >
        {emissionData.map((scope) => {
          const percentage = (scope.actualValue / totalValue) * 100;
          return (
            <div
              key={scope.name}
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: "0.5rem",
              }}
            >
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.5rem",
                }}
              >
                <div
                  style={{
                    width: "10px",
                    height: "10px",
                    backgroundColor: scope.fill,
                    borderRadius: "2px",
                  }}
                />
                <span
                  style={{
                    fontWeight: 500,
                    color: "#4A5568",
                    fontSize: "0.875rem",
                  }}
                >
                  {percentage.toFixed(1)}%
                </span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

const Environment: React.FC = () => {
  // State hooks
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<Roles | null>(null);
  const [dateRange, setDateRange] = useState<{
    startDate: string | undefined;
    endDate: string | undefined;
  }>(() => {
    const today = new Date();
    const startOfYear = new Date(today.getFullYear(), 0, 1);
    return {
      startDate: format(startOfYear, "yyyy/MM/dd"),
      endDate: format(today, "yyyy/MM/dd"),
    };
  });
  const [energyByBranch, setEnergyByBranch] = useState<BranchData[]>([]);
  const [energyMixData, setEnergyMixData] = useState<EnergyMixData[]>([]);
  const [wasteByBranch, setWasteByBranch] = useState<BranchData[]>([]);
  const [wasteTypeData, setWasteTypeData] = useState<WasteTypeData[]>([]);
  const [scope1Breakdown, setScope1Breakdown] = useState({
    stationary: 0,
    mobile: 0,
    process: 0,
    refrigerant: 0,
  });

  // API hooks
  const { getBranchWiseWasteGenerated } = useUserAnalyticsAPI();
  const getScopeWiseEnergyData = useUserAnalyticsAPI().getScopeWiseEnergyData();
  const getScopeEmissionData = useUserAnalyticsAPI().getScopeEmissionData();
  const getTotalWasteGenerated = useUserAnalyticsAPI().getTotalWasteGenerated();
  const getEnergyMixData = useUserAnalyticsAPI().getEnergyMixData();
  const getBranchWiseEnergyMixData =
    useUserAnalyticsAPI().getBranchWiseEnergyMixData(
      dateRange.startDate,
      dateRange.endDate
    );
  const getWasteTypeMetrics =
    useUserAnalyticsAPI().getWasteTypeMetrics(selectedBranch);

  // Loading state
  const isLoading =
    getScopeWiseEnergyData.isLoading ||
    getScopeEmissionData.isLoading ||
    getTotalWasteGenerated.isLoading ||
    getEnergyMixData.isLoading ||
    getBranchWiseEnergyMixData.isLoading ||
    getBranchWiseWasteGenerated.isLoading ||
    getWasteTypeMetrics.isLoading;

  // Memoized data
  const ghgChartData = React.useMemo<GHGChartDataType>(() => {
    const data = getScopeEmissionData.data as ScopeEmissionData | undefined;
    if (!data) return [];

    const total = data.scope_1 + data.scope_2 + data.scope_3;
    const minThreshold = total * 0.05;

    const adjustedScope1 = Math.max(data.scope_1, minThreshold);
    const adjustedScope2 = data.scope_2;
    const adjustedScope3 = data.scope_3;

    return [
      {
        name: `Scope 1`,
        value: adjustedScope1,
        fill: "#3182CE",
        actualValue: data.scope_1,
      },
      {
        name: `Scope 2`,
        value: adjustedScope2,
        fill: "#F6AD55",
        actualValue: data.scope_2,
      },
      {
        name: `Scope 3`,
        value: adjustedScope3,
        fill: "#E53E3E",
        actualValue: data.scope_3,
      },
    ];
  }, [getScopeEmissionData.data]);

  // Calculate total energy
  const totalEnergy = React.useMemo(() => {
    const data = getBranchWiseEnergyMixData.data;
    if (!data) return 0;
    return Object.values(data).reduce(
      (sum, branch: any) => sum + (branch.total_consumption || 0),
      0
    );
  }, [getBranchWiseEnergyMixData.data]);

  // Ref for GHG Emissions chart card
  const ghgChartRef = useRef<HTMLDivElement>(null);

  // Refs for all chart cards
  const energyByBranchRef = useRef<HTMLDivElement>(null);
  const wasteByBranchRef = useRef<HTMLDivElement>(null);
  const energyMixRef = useRef<HTMLDivElement>(null);
  const wasteTypeRef = useRef<HTMLDivElement>(null);

  // Effects
  useEffect(() => {
    if (selectedBranch) {
      setSelectedBranch(selectedBranch);
    }
  }, [selectedBranch]);

  useEffect(() => {
    if (getEnergyMixData.data) {
      const data = getEnergyMixData.data as {
        renewable_total_consumption: number;
        non_renewable_total_consumption: number;
      };

      setEnergyMixData([
        {
          name: "Renewable",
          value: data.renewable_total_consumption ?? 0,
          raw: data.renewable_total_consumption ?? 0,
          fill: "#38A169",
        },
        {
          name: "Non-renewable",
          value: data.non_renewable_total_consumption ?? 0,
          raw: data.non_renewable_total_consumption ?? 0,
          fill: "#3182CE",
        },
      ]);
    }

    if (getBranchWiseEnergyMixData.data) {
      const branchData = Object.entries(getBranchWiseEnergyMixData.data).map(
        ([branchName, data]: [string, any], index) => ({
          name: branchName,
          value: data.total_consumption,
          fill: ["#38A169", "#48BB78", "#68D391", "#9AE6B4"][index % 4],
        })
      );
      setEnergyByBranch(branchData);
    }

    if (getBranchWiseWasteGenerated.data) {
      const wasteData = Object.entries(getBranchWiseWasteGenerated.data).map(
        ([branchName, data]: [string, any], index) => ({
          name: branchName,
          value: data.total_waste_generated,
          fill: ["#38A169", "#48BB78", "#68D391", "#9AE6B4"][index % 4],
        })
      );
      setWasteByBranch(wasteData);
    }

    if (getWasteTypeMetrics.data) {
      const wasteTypeMetricsData = Object.entries(
        getWasteTypeMetrics.data as { [key: string]: number }
      ).map(([type, value]) => ({
        name: type,
        value: Number(value),
        fill:
          {
            Metal: "#38A169",
            "Non-metal": "#48BB78",
            Plastic: "#68D391",
            Wood: "#9AE6B4",
            Paper: "#C6F6D5",
            Glass: "#F0FFF4",
            Other: "#718096",
          }[type] || "#718096",
      })) as WasteTypeData[];
      setWasteTypeData(wasteTypeMetricsData);
    }
  }, [
    getEnergyMixData.data,
    getBranchWiseEnergyMixData.data,
    getBranchWiseWasteGenerated.data,
    getWasteTypeMetrics.data,
    selectedBranch,
  ]);

  // Load user role and set branch for SUB_USER on mount
  useEffect(() => {
    const token = getParsedToken();
    if (token?.role) {
      setUserRole(token.role as Roles);
      // For SUB_USER, set the branch from token
      if (token.role === Roles.SUB_USER && token.company?.branch_id) {
        setSelectedBranch(token.company.branch_id);
      }
    }
  }, []);

  // Loading state check
  if (isLoading) {
    return <ShimmerLoader variant="environment" />;
  }

  // Custom tooltip for the Scope pie
  const CustomScopeTooltip = ({
    active,
    payload,
  }: {
    active?: boolean;
    payload?: any[];
  }) => {
    if (!active || !payload?.length) return null;
    const slice = payload[0].payload;
    const scopeData =
      getScopeWiseEnergyData?.data?.[`SCOPE_${slice.name.split(" ")[1]}`];

    return (
      <div
        style={{
          backgroundColor: "white",
          padding: "0.75rem",
          borderRadius: "0.75rem",
          boxShadow: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
          border: "1px solid",
          borderColor: "#E2E8F0",
        }}
      >
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            marginBottom: "0.75rem",
          }}
        >
          <span
            style={{ fontWeight: 500, color: "#4A5568", fontSize: "0.875rem" }}
          >
            {slice.name}
          </span>
          {slice.name === "Scope 1" && scopeData && (
            <>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Stationary Fuel: {scopeData["Stationary Fuel Consumption"]} KWH
              </span>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Mobile Fuel: {scopeData["Mobile Fuel Consumption"]} KWH
              </span>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Process Emission: {scopeData["Process Emission"]} KWH
              </span>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Fugitive Emission: {scopeData["Fugitive Emission"]} KWH
              </span>
            </>
          )}
          {slice.name === "Scope 2" && scopeData && (
            <>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Renewable: {scopeData["renewable_total_consumption"]} KWH
              </span>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Non-renewable: {scopeData["non_renewable_total_consumption"]}{" "}
                KWH
              </span>
            </>
          )}
          {slice.name === "Scope 3" && scopeData && (
            <>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Upstream: {scopeData["upstream_consumption"]} KWH
              </span>
              <span style={{ fontSize: "0.875rem", color: "#4A5568" }}>
                Downstream: {scopeData["downstream_consumption"]} KWH
              </span>
            </>
          )}
        </div>
        <div
          style={{
            display: "flex",
            justifyContent: "flex-end",
            marginTop: "0.75rem",
          }}
        >
          <span
            style={{ fontWeight: 500, color: "#4A5568", fontSize: "0.875rem" }}
          >
            Total: {scopeData?.total_consumption} KWH
          </span>
        </div>
      </div>
    );
  };

  const handleBranchChange = (branchId: string | null) => {
    setSelectedBranch(branchId);
    // Refetch waste data for the selected branch
    getBranchWiseWasteGenerated.refetch();
    getWasteTypeMetrics.refetch();
  };

  const handleDateRangeChange = (
    startDate: string | undefined,
    endDate: string | undefined
  ) => {
    setDateRange({ startDate, endDate });
  };

  return (
    <div className="environment-dashboard-minimal">
      {/* Filters Section */}
      <div className="filters-section-minimal">
        <HStack spacing={4}>
          {userRole === Roles.USER && (
            <BranchDropdown
              value={selectedBranch}
              onChange={handleBranchChange}
            />
          )}
          <DateRangeFilter
            onApply={handleDateRangeChange}
            onCancel={() => {
              setDateRange({
                startDate: undefined,
                endDate: undefined,
              });
            }}
          />
        </HStack>
      </div>

      {/* Main Content Row */}
      <div className="main-content-row">
        {/* Stats Column */}
        <div className="stats-column">
          <div className="stat-card-minimal">
            <Icon as={Zap} className="stat-icon-minimal energy-icon" />
            <div>
              <div className="stat-value-minimal">{totalEnergy} KWH</div>
              <div className="stat-title-minimal">Total Energy</div>
            </div>
          </div>
          <div className="stat-card-minimal">
            <Icon as={Cloud} className="stat-icon-minimal emission-icon" />
            <div>
              <div className="stat-value-minimal">
                {getScopeEmissionData?.data
                  ? `${Number(
                      (getScopeEmissionData.data as ScopeEmissionData)
                        .total_emission
                    ).toFixed(2)} TCO₂e`
                  : "0 TCO₂e"}
              </div>
              <div className="stat-title-minimal">Total Emission</div>
            </div>
          </div>
          <div className="stat-card-minimal">
            <Icon
              as={LucideArchiveX}
              className="stat-icon-minimal waste-icon"
            />
            <div>
              <div className="stat-value-minimal">
                {getTotalWasteGenerated?.data
                  ? `${getTotalWasteGenerated.data as number} Tons`
                  : "0 Tons"}
              </div>
              <div className="stat-title-minimal">Total Waste</div>
            </div>
          </div>
        </div>

        {/* Charts Column */}
        <div className="charts-column">
          <div className="compact-cards-row">
            <div ref={energyByBranchRef} className="compact-card">
              <div
                className="compact-card-header"
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <span className="compact-card-title">
                  Top Energy Consuming Sites (Kwh)
                </span>
                <ChartDownloadButton
                  targetRef={energyByBranchRef}
                  filename="energy-by-branch.png"
                  title="Top Energy Consuming Sites (Kwh)"
                  forceHtml2Canvas={true}
                />
              </div>
              <div className="compact-card-chart">
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart
                    data={energyByBranch}
                    margin={{ left: 5, right: 5, top: 24, bottom: 0 }}
                  >
                    <XAxis
                      dataKey="name"
                      fontSize={10}
                      stroke="#A0AEC0"
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      type="number"
                      fontSize={10}
                      stroke="#A0AEC0"
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `${value}`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "white",
                        border: "none",
                        borderRadius: "0.5rem",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                        fontSize: 10,
                      }}
                      cursor={{ fill: "rgba(0,0,0,0.03)" }}
                      formatter={(value) => `${value} KWH`}
                    />
                    <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={20}>
                      {energyByBranch?.map((c, i) => (
                        <Cell key={i} fill={c.fill} />
                      ))}
                      <LabelList
                        dataKey="value"
                        position="top"
                        content={({ x, y, width, value, index }) => {
                          return (
                            <text
                              // @ts-ignore
                              x={x + width / 2}
                              // @ts-ignore
                              y={y - 8}
                              textAnchor="middle"
                              fontSize={10}
                              fontWeight={400}
                              fill="#2F855A"
                              style={{ pointerEvents: "none" }}
                            >
                              {value}
                            </text>
                          );
                        }}
                      />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            <div ref={wasteByBranchRef} className="compact-card">
              <div
                className="compact-card-header"
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <span className="compact-card-title">
                  Branch Wise Waste Generation (Tons)
                </span>
                <ChartDownloadButton
                  targetRef={wasteByBranchRef}
                  filename="waste-by-branch.png"
                  title="Branch Wise Waste Generation (Tons)"
                  forceHtml2Canvas={true}
                />
              </div>
              <div className="compact-card-chart">
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart
                    data={wasteByBranch}
                    margin={{ left: 5, right: 5, top: 24, bottom: 0 }}
                  >
                    <XAxis
                      dataKey="name"
                      fontSize={10}
                      stroke="#A0AEC0"
                      tickLine={false}
                      axisLine={false}
                    />
                    <YAxis
                      type="number"
                      fontSize={10}
                      stroke="#A0AEC0"
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(value) => `${value}`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "white",
                        border: "none",
                        borderRadius: "0.5rem",
                        boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                        fontSize: 10,
                      }}
                      cursor={{ fill: "rgba(0,0,0,0.03)" }}
                      formatter={(value: number) => [`${value} Kgs`, ""]}
                    />
                    <Bar dataKey="value" radius={[6, 6, 0, 0]} maxBarSize={20}>
                      {wasteByBranch?.map((c, i) => (
                        <Cell key={i} fill={c.fill} />
                      ))}
                      <LabelList
                        dataKey="value"
                        position="top"
                        fontSize={10}
                        fill="#4A5568"
                      />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Compact Cards for Energy Mix and GHG Emissions */}
          <div className="compact-cards-row">
            <div ref={energyMixRef} className="compact-card chart-card">
              <div
                className="compact-card-header"
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <span className="compact-card-title">Energy Mix</span>
                <ChartDownloadButton
                  targetRef={energyMixRef}
                  filename="energy-mix.png"
                  title="Energy Mix"
                  forceHtml2Canvas={true}
                />
              </div>
              <Link
                href="/dashboard/energy-dashboard"
                className="compact-card-chart-link"
              >
                <div className="compact-card-chart pie-chart">
                  <Box
                    w="100%"
                    display="flex"
                    flexDirection="column"
                    alignItems="center"
                    p={0}
                    m={0}
                  >
                    <ResponsiveContainer width={150} height={150}>
                      <RechartsPieChart>
                        <Pie
                          data={energyMixData}
                          dataKey="value"
                          nameKey="name"
                          cx="50%"
                          cy="50%"
                          innerRadius={36}
                          outerRadius={54}
                          labelLine={false}
                        >
                          {energyMixData?.map((slice, i) => (
                            <Cell key={i} fill={slice.fill} />
                          ))}
                        </Pie>
                        <Tooltip
                          content={({ active }) => {
                            if (active) {
                              const total =
                                energyMixData.reduce(
                                  (sum, d) =>
                                    sum +
                                    (typeof d.value === "number" ? d.value : 0),
                                  0
                                ) || 1;
                              return (
                                <Box
                                  bg="white"
                                  p={2}
                                  borderRadius="md"
                                  boxShadow="md"
                                  border="1px solid #E2E8F0"
                                >
                                  <HStack spacing={3}>
                                    {energyMixData.map((d, i) => (
                                      <HStack key={i} spacing={1}>
                                        <Box
                                          w="18px"
                                          h="12px"
                                          borderRadius="sm"
                                          bg={d.fill}
                                        />
                                        <Text fontSize="sm" color="gray.600">
                                          {((d.value / total) * 100).toFixed(1)}
                                          %
                                        </Text>
                                      </HStack>
                                    ))}
                                  </HStack>
                                </Box>
                              );
                            }
                            return null;
                          }}
                        />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                    {/* Custom Legend Row */}
                    <HStack mt={2} spacing={3} justify="center">
                      {energyMixData.map((d, i) => (
                        <HStack key={i} spacing={1}>
                          <Box
                            w={2.5}
                            h={2.5}
                            borderRadius="full"
                            bg={d.fill}
                          />
                          <Text
                            fontSize="xs"
                            color="gray.700"
                            fontWeight="medium"
                          >
                            {d.name}
                          </Text>
                        </HStack>
                      ))}
                    </HStack>
                  </Box>
                </div>
              </Link>
              <div className="view-detailed-container">
                <Link
                  href="/dashboard/energy-dashboard"
                  className="view-detailed-link"
                >
                  <small>View detailed</small>
                  <Icon
                    as={LucideExternalLink}
                    className="view-detailed-icon"
                  />
                </Link>
              </div>
            </div>
            {(getScopeEmissionData as any)?.data && (
              <div ref={ghgChartRef} className="compact-card chart-card">
                <div
                  className="compact-card-header"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <span className="compact-card-title">GHG Emissions</span>
                  <ChartDownloadButton
                    targetRef={ghgChartRef}
                    filename="ghg-emissions.png"
                    title="GHG Emissions"
                    forceHtml2Canvas={true}
                  />
                </div>
                <Link
                  href="/dashboard/emission-dashboard"
                  className="compact-card-chart-link"
                >
                  <div className="compact-card-chart pie-chart">
                    <Box
                      w="100%"
                      display="flex"
                      flexDirection="column"
                      alignItems="center"
                      p={0}
                      m={0}
                    >
                      <ResponsiveContainer width={150} height={150}>
                        <RechartsPieChart>
                          <Pie
                            data={ghgChartData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            innerRadius={36}
                            outerRadius={54}
                            labelLine={false}
                          >
                            {ghgChartData.map((slice, i) => (
                              <Cell key={i} fill={slice.fill} />
                            ))}
                          </Pie>
                          <Tooltip
                            content={({ active }) => {
                              if (active) {
                                const total =
                                  ghgChartData.reduce(
                                    (sum, d) =>
                                      sum +
                                      (typeof d.value === "number"
                                        ? d.value
                                        : 0),
                                    0
                                  ) || 1;
                                return (
                                  <Box
                                    bg="white"
                                    p={2}
                                    borderRadius="md"
                                    boxShadow="md"
                                    border="1px solid #E2E8F0"
                                  >
                                    <HStack spacing={3}>
                                      {ghgChartData.map((d, i) => (
                                        <HStack key={i} spacing={1}>
                                          <Box
                                            w="18px"
                                            h="12px"
                                            borderRadius="sm"
                                            bg={d.fill}
                                          />
                                          <Text fontSize="sm" color="gray.600">
                                            {((d.value / total) * 100).toFixed(
                                              1
                                            )}
                                            %
                                          </Text>
                                        </HStack>
                                      ))}
                                    </HStack>
                                  </Box>
                                );
                              }
                              return null;
                            }}
                          />
                        </RechartsPieChart>
                      </ResponsiveContainer>
                      {/* Custom Legend Row */}
                      <HStack mt={2} spacing={3} justify="center">
                        {ghgChartData.map((d, i) => (
                          <HStack key={i} spacing={1}>
                            <Box
                              w={2.5}
                              h={2.5}
                              borderRadius="full"
                              bg={d.fill}
                            />
                            <Text
                              fontSize="xs"
                              color="gray.700"
                              fontWeight="medium"
                            >
                              {d.name}
                            </Text>
                          </HStack>
                        ))}
                      </HStack>
                    </Box>
                  </div>
                </Link>
                <div className="view-detailed-container">
                  <Link
                    href="/dashboard/emission-dashboard"
                    className="view-detailed-link"
                  >
                    <small>View detailed</small>
                    <Icon
                      as={LucideExternalLink}
                      className="view-detailed-icon"
                    />
                  </Link>
                </div>
              </div>
            )}
            {/* Waste Type Chart Card (if present) */}
            {wasteTypeData && wasteTypeData.length > 0 && (
              <div ref={wasteTypeRef} className="compact-card chart-card">
                <div
                  className="compact-card-header"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                  }}
                >
                  <span className="compact-card-title">
                    Waste Type Breakdown
                  </span>
                  <ChartDownloadButton
                    targetRef={wasteTypeRef}
                    filename="waste-type.png"
                    title="Waste Type Breakdown"
                    forceHtml2Canvas={true}
                  />
                </div>
                {/* Place your waste type chart here, if not already present */}
              </div>
            )}
          </div>
        </div>
      </div>

      <style jsx>{`
        .environment-dashboard-minimal {
          padding: 1rem 0.5rem;
          background: #fafbfc;
          min-height: 100vh;
          font-family: "Inter", sans-serif;
        }
        .filters-section-minimal {
          margin-bottom: 1rem;
          background: none;
          border: none;
          box-shadow: none;
          padding: 0;
          display: flex;
          justify-content: flex-end;
        }
        .main-content-row {
          display: flex;
          gap: 1rem;
          margin-bottom: 1rem;
        }
        .stats-column {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
          width: 25%;
        }
        .stat-card-minimal {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 0.75rem;
          background: #fff;
          border-radius: 0.75rem;
          padding: 0.75rem;
          box-shadow: none;
          border: 1px solid #f3f4f6;
          height: 80px;
          transition: all 0.2s ease-in-out;
        }
        .stat-card-minimal:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .stat-icon-minimal {
          width: 1.8rem;
          height: 1.8rem;
          opacity: 0.7;
        }
        .energy-icon {
          color: #38a169;
        }
        .emission-icon {
          color: #48bb78;
        }
        .waste-icon {
          color: #68d391;
        }
        .stat-value-minimal {
          font-size: 1.2rem;
          font-weight: 600;
          color: #2f855a;
          margin-bottom: 0.1rem;
        }
        .stat-title-minimal {
          font-size: 0.85rem;
          color: #8d99ae;
          font-weight: 400;
          letter-spacing: 0.01em;
        }
        .charts-column {
          flex: 1;
        }
        .compact-cards-row {
          display: flex;
          gap: 0.75rem;
          margin-bottom: 1rem;
          flex-wrap: wrap;
        }
        .compact-card {
          background: #fff;
          border-radius: 0.75rem;
          border: 1px solid #f3f4f6;
          box-shadow: none;
          flex: 1 1 calc(50% - 0.375rem);
          min-width: 280px;
          display: flex;
          flex-direction: column;
          padding: 0.75rem;
          position: relative;
          min-height: 150px;
          transition: all 0.2s ease-in-out;
        }
        .compact-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .compact-card.chart-card {
          flex: 1 1 calc(50% - 0.375rem);
          min-width: 280px;
          min-height: 350px;
        }
        .compact-card-header {
          width: 100%;
          text-align: center;
          margin-bottom: 0.25rem;
          display: flex;
          justify-content: center;
          align-items: center;
          padding: 0.5rem;
        }
        .compact-card-title {
          font-weight: 600;
          color: #2d3748;
          letter-spacing: 0.02em;
          font-size: 0.9rem;
        }
        .compact-card-chart {
          display: flex;
          flex-direction: column;
          align-items: center;
          position: relative;
          flex: 1;
          width: 100%;
          padding-bottom: 2rem;
        }
        .compact-card-chart.pie-chart {
          flex-direction: row;
          justify-content: space-between;
          padding: 0.75rem;
          height: 100%;
        }
        .compact-card-chart.pie-chart :global(.recharts-wrapper) {
          width: 180px !important;
          height: 180px !important;
        }
        .compact-card-legend.pie-legend {
          flex: 1;
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
          padding: 0.75rem;
          max-width: 160px;
          justify-content: center;
        }
        .compact-legend-item {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.25rem 0;
        }
        .compact-legend-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          flex-shrink: 0;
        }
        .compact-legend-label {
          font-size: 0.75rem;
          color: #4a5568;
          line-height: 1.3;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
        .view-detailed-container {
          width: 100%;
          display: flex;
          justify-content: center;
          padding-top: 0.4rem;
          border-top: 1px solid #f1f5f9;
          position: absolute;
          bottom: 0;
          left: 0;
          background: #fff;
          padding-bottom: 0.4rem;
        }
        .view-detailed-link {
          display: inline-flex;
          align-items: center;
          gap: 0.35rem;
          font-size: 0.7rem;
          color: #64748b;
          text-decoration: none;
          transition: all 0.2s ease;
          padding: 0.25rem 0.6rem;
          border-radius: 0.25rem;
          background: #f8fafc;
          border: 1px solid #e2e8f0;
          font-weight: 500;
          letter-spacing: 0.01em;
        }
        .view-detailed-link:hover {
          color: #334155;
          background: #f1f5f9;
          border-color: #cbd5e1;
          transform: translateY(-1px);
          box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }
        .view-detailed-icon {
          width: 0.65rem;
          height: 0.65rem;
          opacity: 0.7;
          transition: transform 0.2s ease;
        }
        .view-detailed-link:hover .view-detailed-icon {
          transform: translateX(1px);
        }
        .compact-card-chart-link {
          display: flex;
          flex-direction: column;
          align-items: center;
          position: relative;
          flex: 1;
          width: 100%;
          cursor: pointer;
          text-decoration: none;
          color: inherit;
        }
        .compact-card-chart-link:hover {
          background-color: #f7fafc;
          border-radius: 0.5rem;
        }
        @media (max-width: 900px) {
          .main-content-row {
            flex-direction: column;
          }
          .stats-column {
            width: 100%;
            flex-direction: row;
          }
          .stat-card-minimal {
            flex: 1 1 200px;
          }
          .compact-card {
            flex: 1 1 100%;
          }
          .compact-card.chart-card {
            flex: 1 1 100%;
          }
        }
        @media (max-width: 500px) {
          .stats-column {
            flex-direction: column;
          }
          .stat-card-minimal {
            flex: 1 1 100%;
          }
        }
      `}</style>
    </div>
  );
};

export default Environment;
