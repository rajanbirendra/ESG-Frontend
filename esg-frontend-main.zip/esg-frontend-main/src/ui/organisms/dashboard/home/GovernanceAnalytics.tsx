import React, { useState, useEffect } from "react";
import {
  Box,
  Flex,
  Text,
  Icon,
  Spacer,
  Badge,
  VStack,
  HStack,
} from "@chakra-ui/react";
import {
  Users,
  Calendar,
  Percent,
  UserCheck,
  PieChart,
  FileCheck,
  FileX,
} from "lucide-react";
// import Filters from "@/ui/components/Filters";
import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LabelList,
  Cell,
} from "recharts";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import DateRangeFilter from "@/ui/molecules/DateRangeFilter";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import { format } from "date-fns";
import { getParsedToken } from "@/utils/withAuth";
import { Roles } from "@/types/index.types";

interface PolicyMetrics {
  "Area where policy exists": string[];
  "Area where policy doesnot exists": string[];
}

export default function Governance() {
  const [filters, setFilters] = useState({
    granularity: "monthly",
    fromDate: "",
    toDate: "",
    facilities: [],
  });
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<Roles | null>(null);

  // Load user role and set branch for SUB_USER on mount
  useEffect(() => {
    const token = getParsedToken();
    if (token?.role) {
      setUserRole(token.role as Roles);
      // For SUB_USER, set the branch from token
      if (token.role === Roles.SUB_USER && token.company?.branch_id) {
        setSelectedBranch(token.company.branch_id);
      }
    }
  }, []);

  const today = new Date();
  const startOfYear = new Date(today.getFullYear(), 0, 1);

  const [dateRange, setDateRange] = useState<{
    from: string | undefined;
    to: string | undefined;
  }>({
    from: format(startOfYear, "yyyy/MM/dd"),
    to: format(today, "yyyy/MM/dd"),
  });

  const getGovernanceChart = useUserAnalyticsAPI().getGovernanceChart(
    selectedBranch,
    dateRange.from,
    dateRange.to
  );

  const getGovernanceCardMetrics =
    useUserAnalyticsAPI().getGovernanceCardMetrics();
  const getGovernancePolicyMetrics =
    useUserAnalyticsAPI().getGovernancePolicyMetrics();

  const isLoading =
    getGovernanceCardMetrics.isLoading ||
    getGovernancePolicyMetrics?.isLoading ||
    getGovernanceChart.isLoading;

  const policyData = getGovernancePolicyMetrics?.data as
    | PolicyMetrics
    | undefined;

  const existingPolicies = policyData?.["Area where policy exists"] || [];
  const missingPolicies =
    policyData?.["Area where policy doesnot exists"] || [];

  const governanceChartRaw = getGovernanceChart?.data as
    | Record<string, number>
    | undefined;
  const governanceChartData = governanceChartRaw
    ? Object.entries(governanceChartRaw)
        .filter(([_, value]) => value > 0)
        .map(([name, value], i) => ({
          name,
          value,
          fill: ["#805AD5", "#9F7AEA", "#B794F4", "#D6BCFA", "#E9D8FD"][i % 5],
        }))
    : [];

  const handleBranchChange = (branchId: string | null) => {
    setSelectedBranch(branchId);
  };

  const handleDateRangeApply = (
    from: string | undefined,
    to: string | undefined
  ) => {
    setDateRange({ from, to });
  };

  const handleDateRangeCancel = () => {
    setDateRange({
      from: format(startOfYear, "yyyy/MM/dd"),
      to: format(today, "yyyy/MM/dd"),
    });
  };

  if (isLoading) {
    return <ShimmerLoader variant="governance" />;
  }

  return (
    <div className="governance-dashboard-minimal">
      {/* Main Content Row */}
      <div className="main-content-row">
        {/* Stats Column */}
        <div className="stats-column">
          <div className="stat-card-minimal">
            <Icon
              as={Users}
              className="stat-icon-minimal"
              style={{ color: "#805AD5" }}
            />
            <div>
              <div className="stat-value-minimal">
                {getGovernanceCardMetrics?.data?.[
                  "Number of Independent Members in Audit Committee"
                ] || 0}
              </div>
              <div className="stat-title-minimal">
                Independent Members in Audit Committee
              </div>
            </div>
          </div>

          <div className="stat-card-minimal">
            <Icon
              as={Calendar}
              className="stat-icon-minimal"
              style={{ color: "#9F7AEA" }}
            />
            <div>
              <div className="stat-value-minimal">
                {getGovernanceCardMetrics?.data?.[
                  "Number of Board Meetings in the fiscal year"
                ] || 0}
              </div>
              <div className="stat-title-minimal">
                Board Meetings (Fiscal Year)
              </div>
            </div>
          </div>

          <div className="stat-card-minimal">
            <Icon
              as={Percent}
              className="stat-icon-minimal"
              style={{ color: "#B794F4" }}
            />
            <div>
              <div className="stat-value-minimal">
                {getGovernanceCardMetrics?.data?.[
                  "% of Non-Audit fees to Total Audit fees"
                ] || 0}
                %
              </div>
              <div className="stat-title-minimal">
                Non-Audit to Total Audit Fees
              </div>
            </div>
          </div>

          <div className="stat-card-minimal">
            <Icon
              as={UserCheck}
              className="stat-icon-minimal"
              style={{ color: "#D6BCFA" }}
            />
            <div>
              <div className="stat-value-minimal">
                {getGovernanceCardMetrics?.data?.[
                  "Number of Promoter Board Members"
                ] || 0}
              </div>
              <div className="stat-title-minimal">Promoter Board Members</div>
            </div>
          </div>

          <div className="stat-card-minimal">
            <Icon
              as={PieChart}
              className="stat-icon-minimal"
              style={{ color: "#E9D8FD" }}
            />
            <div>
              <div className="stat-value-minimal">
                {getGovernanceCardMetrics?.data?.[
                  "Percentage of KMP's share ownership"
                ] || 0}
                %
              </div>
              <div className="stat-title-minimal">KMP's Share Ownership</div>
            </div>
          </div>
        </div>

        {/* Charts Column */}
        <div className="charts-column">
          <div className="compact-card">
            <div className="compact-card-header">
              <span className="compact-card-title">
                Board & Committee Composition
              </span>
              <Flex gap={4}>
                {userRole === Roles.USER && (
                  <Box w="180px">
                    <BranchDropdown
                      value={selectedBranch}
                      onChange={handleBranchChange}
                      label=""
                    />
                  </Box>
                )}
                <DateRangeFilter
                  onApply={handleDateRangeApply}
                  onCancel={handleDateRangeCancel}
                />
              </Flex>
            </div>
            <div className="compact-card-chart">
              <ResponsiveContainer width="100%" height={280}>
                <BarChart
                  data={governanceChartData}
                  margin={{ left: 20, right: 20, top: 5, bottom: 5 }}
                  barGap={0}
                  barCategoryGap="20%"
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    stroke="#e2e8f0"
                    opacity={0.5}
                  />
                  <XAxis
                    dataKey="name"
                    stroke="#A0AEC0"
                    tickLine={false}
                    axisLine={false}
                    interval={0}
                    tick={(props) => {
                      const { x, y, payload } = props;
                      let labelLines: string[] = [];
                      switch (payload.value) {
                        case "Number of non-executive Board Member":
                          labelLines = ["Non-Executive", "Members"];
                          break;
                        case "Number of Women in Board":
                          labelLines = ["Women in", "Board"];
                          break;
                        case "Number of independent Board Members":
                          labelLines = ["Independent", "Members"];
                          break;
                        case "Number of independent members in nomination committee":
                          labelLines = ["Nomination", "Committee"];
                          break;
                        case "Number of KMPs":
                          labelLines = ["KMPs"];
                          break;
                        default:
                          labelLines = payload.value.match(/.{1,15}/g) || [
                            payload.value,
                          ];
                          break;
                      }
                      return (
                        <g transform={`translate(${x},${y})`}>
                          <text
                            y={6}
                            textAnchor="middle"
                            fontSize={9}
                            fill="#4A5568"
                            fontWeight={500}
                          >
                            {labelLines.map((line, index) => (
                              <tspan x={0} dy={index > 0 ? "1.1em" : 0}>
                                {line}
                              </tspan>
                            ))}
                          </text>
                        </g>
                      );
                    }}
                  />
                  <YAxis
                    type="number"
                    fontSize={12}
                    stroke="#A0AEC0"
                    tickLine={false}
                    axisLine={false}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "white",
                      border: "none",
                      borderRadius: "8px",
                      boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                      fontSize: 13,
                    }}
                    cursor={{ fill: "rgba(0,0,0,0.03)" }}
                  />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]} maxBarSize={40}>
                    {governanceChartData.map((entry, index) => (
                      <Cell key={index} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="policy-grid-minimal">
            <div className="policy-card-minimal">
              <div className="policy-header-minimal">
                <div className="policy-title-minimal">
                  Areas where policy exists
                </div>
              </div>
              <div className="policy-list-minimal">
                {existingPolicies.length > 0 ? (
                  existingPolicies.map((policy, index) => (
                    <div key={index} className="policy-item-minimal">
                      <div
                        className="policy-indicator-minimal"
                        style={{ backgroundColor: "green" }}
                      />
                      <div className="policy-text-minimal">{policy}</div>
                    </div>
                  ))
                ) : (
                  <div className="policy-empty-minimal">
                    No existing policies found
                  </div>
                )}
              </div>
            </div>

            <div className="policy-card-minimal">
              <div className="policy-header-minimal">
                <div className="policy-title-minimal">
                  Areas where policy does not exist
                </div>
              </div>
              <div className="policy-list-minimal">
                {missingPolicies.length > 0 ? (
                  missingPolicies.map((policy, index) => (
                    <div key={index} className="policy-item-minimal">
                      <div
                        className="policy-indicator-minimal"
                        style={{ backgroundColor: "red" }}
                      />
                      <div className="policy-text-minimal">{policy}</div>
                    </div>
                  ))
                ) : (
                  <div className="policy-empty-minimal">
                    No missing policies
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx>{`
        .governance-dashboard-minimal {
          padding: 1rem 0.5rem;
          background: #fafbfc;
          min-height: 100vh;
          font-family: "Inter", sans-serif;
        }
        .filters-section-minimal {
          margin-bottom: 1rem;
          background: none;
          border: none;
          box-shadow: none;
          padding: 0;
        }
        .main-content-row {
          display: flex;
          gap: 1rem;
          margin-bottom: 1rem;
        }
        .stats-column {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
          width: 25%;
        }
        .stat-card-minimal {
          flex: 1;
          display: flex;
          align-items: center;
          gap: 0.75rem;
          background: #fff;
          border-radius: 0.75rem;
          padding: 0.75rem;
          box-shadow: none;
          border: 1px solid #f3f4f6;
          height: 80px;
          transition: all 0.2s ease-in-out;
        }
        .stat-card-minimal:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .stat-icon-minimal {
          width: 1.8rem;
          height: 1.8rem;
          opacity: 0.7;
        }
        .stat-value-minimal {
          font-size: 1.2rem;
          font-weight: 600;
          color: #6b46c1;
          margin-bottom: 0.1rem;
        }
        .stat-title-minimal {
          font-size: 0.85rem;
          color: #8d99ae;
          font-weight: 400;
          letter-spacing: 0.01em;
        }
        .charts-column {
          flex: 1;
        }
        .compact-card {
          background: #fff;
          border-radius: 0.75rem;
          border: 1px solid #f3f4f6;
          box-shadow: none;
          padding: 0.75rem;
          margin-bottom: 1rem;
          transition: all 0.2s ease-in-out;
        }
        .compact-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .compact-card-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 1rem;
        }
        .compact-card-title {
          font-size: 0.9rem;
          font-weight: 500;
          color: #2d3748;
          letter-spacing: 0.01em;
        }
        .compact-card-chart {
          height: 280px;
        }
        .policy-grid-minimal {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 1rem;
        }
        .policy-card-minimal {
          background: #fff;
          border-radius: 0.75rem;
          border: 1px solid #f3f4f6;
          height: 300px;
          display: flex;
          flex-direction: column;
          transition: all 0.2s ease-in-out;
        }
        .policy-card-minimal:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
            0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }
        .policy-header-minimal {
          padding: 0.75rem;
          border-bottom: 1px solid #f3f4f6;
          background: #fff;
          z-index: 1;
        }
        .policy-title-minimal {
          font-size: 0.9rem;
          font-weight: 500;
          color: #2d3748;
        }
        .policy-list-minimal {
          flex: 1;
          overflow-y: auto;
          padding: 0.75rem;
          scrollbar-width: thin;
          scrollbar-color: transparent transparent;
        }
        .policy-list-minimal:hover {
          scrollbar-color: #cbd5e0 #f1f1f1;
        }
        .policy-list-minimal::-webkit-scrollbar {
          width: 8px;
        }
        .policy-list-minimal::-webkit-scrollbar-track {
          background-color: transparent;
        }
        .policy-list-minimal:hover::-webkit-scrollbar-track {
          background-color: #f1f1f1;
        }
        .policy-list-minimal::-webkit-scrollbar-thumb {
          background-color: transparent;
          border-radius: 4px;
        }
        .policy-list-minimal:hover::-webkit-scrollbar-thumb {
          background-color: #cbd5e0;
        }
        .policy-item-minimal {
          display: flex;
          align-items: center;
          padding: 0.5rem;
          border-radius: 0.5rem;
          transition: background-color 0.2s;
        }
        .policy-item-minimal:hover {
          background-color: #f9fafb;
        }
        .policy-indicator-minimal {
          width: 4px;
          height: 16px;
          border-radius: 0.25rem;
          margin-right: 0.75rem;
        }
        .policy-text-minimal {
          font-size: 0.875rem;
          color: #1a202c;
          font-weight: 500;
        }
        .policy-empty-minimal {
          font-size: 0.875rem;
          color: #718096;
          text-align: center;
          padding: 1rem 0;
        }
        @media (max-width: 900px) {
          .main-content-row {
            flex-direction: column;
          }
          .stats-column {
            width: 100%;
            flex-direction: row;
            flex-wrap: wrap;
          }
          .stat-card-minimal {
            flex: 1 1 200px;
          }
          .policy-grid-minimal {
            grid-template-columns: 1fr;
          }
        }
        @media (max-width: 500px) {
          .stats-column {
            flex-direction: column;
          }
          .stat-card-minimal {
            flex: 1 1 100%;
          }
        }
      `}</style>
    </div>
  );
}
