import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import React from "react";
import {
  Box,
  Flex,
  SimpleGrid,
  Stat,
  StatLabel,
  StatNumber,
  Icon,
  Spacer,
  Text,
  VStack,
  Badge,
  Progress,
  Button,
} from "@chakra-ui/react";
import {
  Building2,
  ClipboardCheck,
  Users,
  CheckCircle2,
  Plus,
  FileText,
  UserPlus,
} from "lucide-react";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import CreateNewAssessmentModel from "../assessment/CreateNewAssessmentModel";
import CreatePlan from "../carbon-neutrality-plan/CreatePlan";
import CreateNewSelfAssessment from "../self-assessment/CreateNewSelfAssessment";
import { useDisclosure } from "@chakra-ui/react";
import { useRouter } from "next/router";
import GeneralQuickActions from "./GeneralQuickActions";

interface GeneralAnalytics {
  total_branches: number;
  total_assessments: number;
  total_sub_users: number;
  total_completed_assessments: number;
}

interface RecentAssessment {
  assessment: {
    id: string;
    title: string;
    assessment_status: string;
    branch: {
      branch_name: string;
      state: string;
      country: string;
    };
  };
  completion_percentage: number;
}

const General = () => {
  const getGeneralAnalytics = useUserAnalyticsAPI().getGeneralAnalytics();
  const getRecentlyCreatedAssessments =
    useUserAnalyticsAPI().getRecentlyCreatedAssessments();
  const data = getGeneralAnalytics.data as GeneralAnalytics | undefined;
  const recentAssessments = getRecentlyCreatedAssessments.data as
    | RecentAssessment[]
    | undefined;
  const isLoading = getGeneralAnalytics.isLoading;

  const router = useRouter();

  const {
    isOpen: isAssessmentOpen,
    onOpen: onAssessmentOpen,
    onClose: onAssessmentClose,
  } = useDisclosure();
  const {
    isOpen: isCNPPlanOpen,
    onOpen: onCNPPlanOpen,
    onClose: onCNPPlanClose,
  } = useDisclosure();
  const {
    isOpen: isSelfAssessmentOpen,
    onOpen: onSelfAssessmentOpen,
    onClose: onSelfAssessmentClose,
  } = useDisclosure();

  // Open dialog after navigation using localStorage
  React.useEffect(() => {
    if (typeof window === "undefined") return;
    const quickAction = localStorage.getItem("dashboard_quick_action");
    if (quickAction) {
      if (
        quickAction === "assessment" &&
        router.pathname === "/dashboard/assessment"
      ) {
        onAssessmentOpen();
        localStorage.removeItem("dashboard_quick_action");
      }
      if (
        quickAction === "cnp" &&
        router.pathname === "/dashboard/carbon-neutrality-plan"
      ) {
        onCNPPlanOpen();
        localStorage.removeItem("dashboard_quick_action");
      }
      if (
        quickAction === "self-assessment" &&
        router.pathname === "/dashboard/self-assessment"
      ) {
        onSelfAssessmentOpen();
        localStorage.removeItem("dashboard_quick_action");
      }
    }
  }, [router.pathname]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "IN_PROGRESS":
        return "blue";
      case "APPROVED":
        return "green";
      case "REJECTED":
        return "red";
      default:
        return "gray";
    }
  };

  if (isLoading) {
    return <ShimmerLoader variant="general" />;
  }

  return (
    <VStack spacing={6} align="stretch">
      <GeneralQuickActions
        onAssessmentOpen={onAssessmentOpen}
        onCNPPlanOpen={onCNPPlanOpen}
        onSelfAssessmentOpen={onSelfAssessmentOpen}
      />
      <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
        {/* Total Branches */}
        <Stat
          bg="white"
          boxShadow="sm"
          borderRadius="2xl"
          p={6}
          border="1px solid"
          borderColor="gray.200"
          transition="all 0.2s"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
        >
          <Flex align="center" mb={4}>
            <StatLabel
              fontSize="sm"
              fontWeight="medium"
              color="gray.600"
              textTransform="uppercase"
              letterSpacing="wider"
            >
              Total Branches
            </StatLabel>
            <Spacer />
            <Icon as={Building2} boxSize={5} color="blue.500" />
          </Flex>
          <StatNumber fontSize="3xl" fontWeight="bold" color="gray.700">
            {data?.total_branches ?? 0}
          </StatNumber>
        </Stat>

        {/* Total Assessments */}
        <Stat
          bg="white"
          boxShadow="sm"
          borderRadius="2xl"
          p={6}
          border="1px solid"
          borderColor="gray.200"
          transition="all 0.2s"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
        >
          <Flex align="center" mb={4}>
            <StatLabel
              fontSize="sm"
              fontWeight="medium"
              color="gray.600"
              textTransform="uppercase"
              letterSpacing="wider"
            >
              Total Assessments
            </StatLabel>
            <Spacer />
            <Icon as={ClipboardCheck} boxSize={5} color="green.500" />
          </Flex>
          <StatNumber fontSize="3xl" fontWeight="bold" color="gray.700">
            {data?.total_assessments ?? 0}
          </StatNumber>
        </Stat>

        {/* Total Sub Users */}
        <Stat
          bg="white"
          boxShadow="sm"
          borderRadius="2xl"
          p={6}
          border="1px solid"
          borderColor="gray.200"
          transition="all 0.2s"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
        >
          <Flex align="center" mb={4}>
            <StatLabel
              fontSize="sm"
              fontWeight="medium"
              color="gray.600"
              textTransform="uppercase"
              letterSpacing="wider"
            >
              Total Sub Users
            </StatLabel>
            <Spacer />
            <Icon as={Users} boxSize={5} color="purple.500" />
          </Flex>
          <StatNumber fontSize="3xl" fontWeight="bold" color="gray.700">
            {data?.total_sub_users ?? 0}
          </StatNumber>
        </Stat>

        {/* Completed Assessments */}
        <Stat
          bg="white"
          boxShadow="sm"
          borderRadius="2xl"
          p={6}
          border="1px solid"
          borderColor="gray.200"
          transition="all 0.2s"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
        >
          <Flex align="center" mb={4}>
            <StatLabel
              fontSize="sm"
              fontWeight="medium"
              color="gray.600"
              textTransform="uppercase"
              letterSpacing="wider"
            >
              Completed Assessments
            </StatLabel>
            <Spacer />
            <Icon as={CheckCircle2} boxSize={5} color="teal.500" />
          </Flex>
          <StatNumber fontSize="3xl" fontWeight="bold" color="gray.700">
            {data?.total_completed_assessments ?? 0}
          </StatNumber>
        </Stat>
      </SimpleGrid>

      {/* Recent Assessments List */}
      <Box
        bg="white"
        boxShadow="sm"
        borderRadius="2xl"
        p={6}
        border="1px solid"
        borderColor="gray.200"
      >
        <Text fontSize="lg" fontWeight="medium" mb={4}>
          Recent Assessments
        </Text>
        <VStack spacing={4} align="stretch">
          {recentAssessments?.map((item) => (
            <Box
              key={item.assessment.id}
              p={4}
              border="1px solid"
              borderColor="gray.100"
              borderRadius="lg"
              _hover={{ bg: "gray.50" }}
            >
              <Flex justify="space-between" align="center" mb={2}>
                <Text fontWeight="medium">{item.assessment.title}</Text>
                <Badge
                  colorScheme={getStatusColor(
                    item.assessment.assessment_status
                  )}
                >
                  {item.assessment.assessment_status.replace("_", " ")}
                </Badge>
              </Flex>
              <Text fontSize="sm" color="gray.600" mb={2}>
                {item.assessment.branch.branch_name} •{" "}
                {item.assessment.branch.state}, {item.assessment.branch.country}
              </Text>
              <Flex align="center" gap={2}>
                <Progress
                  value={item.completion_percentage}
                  size="sm"
                  width="100%"
                  colorScheme={
                    item.completion_percentage === 100 ? "green" : "blue"
                  }
                  borderRadius="full"
                />
                <Text fontSize="sm" color="gray.600" minW="60px">
                  {item.completion_percentage.toFixed(1)}%
                </Text>
              </Flex>
            </Box>
          ))}
        </VStack>
      </Box>
    </VStack>
  );
};

export default General;
