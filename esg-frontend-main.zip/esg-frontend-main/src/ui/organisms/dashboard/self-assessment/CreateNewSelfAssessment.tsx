import { useAssessmentsAPI } from "@/query/use-assessments";
import { AssessmentType, Roles } from "@/types/index.types";
import React, { useRef, useState } from "react";
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  Button,
  FormLabel,
  Input,
  Textarea,
  VStack,
  FormControl,
  FormErrorMessage,
  AlertDialogOverlay,
  AlertDialogCloseButton,
  Flex,
  Text,
} from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { getParsedToken } from "@/utils/withAuth";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import CustomYearDropdown from "@/ui/molecules/dropdown/CustomYearDropdown";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";

interface CreateNewSelfAssessmentProps {
  isOpen: boolean;
  onClose: () => void;
}

const CreateNewSelfAssessment: React.FC<CreateNewSelfAssessmentProps> = ({
  isOpen,
  onClose,
}) => {
  const { createAssessment } = useAssessmentsAPI();
  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
    setValue,
    trigger,
  } = useForm({
    defaultValues: {
      title: "",
      description: "",
      branch: "",
      year: "",
    },
  });

  const { mutate, isPending: isCreating } = createAssessment;
  const closeRef = React.useRef(null);

  const token = getParsedToken();
  const [userRole, setUserRole] = useState(token?.role || null);
  const selectedBranch = watch("branch");
  const selectedYear = watch("year");
  const [yearState, setYearState] = useState(
    new Date().getFullYear().toString()
  );

  console.log("token", token);
  // Update form value when selectedYear changes
  React.useEffect(() => {
    setValue("year", yearState);
  }, [yearState, setValue]);

  const handleAddAssessment = (data: any) => {
    mutate(
      // @ts-ignore
      {
        body: {
          title: data.title,
          description: data.description,
          assessment_type: AssessmentType.SELF_ASSESSMENT,
          branch_id:
            token?.role === Roles.SUB_USER
              ? token?.company?.branch_id
              : data.branch,
          assessment_year: data.year,
        },
      },
      {
        onSuccess: () => {
          onClose();
          reset();
        },
      }
    );
  };

  return (
    <AlertDialog
      isOpen={isOpen}
      onClose={onClose}
      leastDestructiveRef={closeRef}
      isCentered
    >
      <AlertDialogOverlay>
        <AlertDialogContent>
          <AlertDialogHeader fontSize="lg" fontWeight="bold">
            Create Self Assessment
          </AlertDialogHeader>
          <AlertDialogCloseButton />
          <AlertDialogBody>
            <form onSubmit={handleSubmit(handleAddAssessment)}>
              <VStack spacing={4}>
                <FormControl isInvalid={!!errors.title}>
                  <FormLabel>
                    Title{" "}
                    <Text as="span" color="red.500">
                      *
                    </Text>
                  </FormLabel>
                  <Input
                    placeholder="Enter assessment title"
                    {...register("title", {
                      required: "Title is required",
                    })}
                  />
                  <FormErrorMessage>
                    {errors.title && (errors.title as any).message}
                  </FormErrorMessage>
                </FormControl>

                <FormControl isInvalid={!!errors.description}>
                  <FormLabel>Description</FormLabel>
                  <Textarea
                    placeholder="Enter assessment description"
                    {...register("description", {})}
                  />
                  <FormErrorMessage>
                    {errors.description && (errors.description as any).message}
                  </FormErrorMessage>
                </FormControl>

                <Flex justify={"start"} gap={4}>
                  {userRole === Roles.USER && (
                    <FormControl isInvalid={!!errors.branch}>
                      <FormLabel>
                        Branch{" "}
                        <Text as="span" color="red.500">
                          *
                        </Text>
                      </FormLabel>
                      <BranchDropdown
                        value={selectedBranch}
                        // @ts-ignore
                        onChange={(branch) => {
                          setValue("branch", branch || "");
                          // Trigger validation after setting the value
                          setTimeout(() => {
                            trigger("branch");
                          }, 0);
                        }}
                        error={errors.branch?.message}
                      />
                      <input
                        type="hidden"
                        {...register("branch", {
                          required: "Branch is required",
                        })}
                      />
                      <FormErrorMessage>
                        {errors.branch && (errors.branch as any).message}
                      </FormErrorMessage>
                    </FormControl>
                  )}
                  <FormControl isInvalid={!!errors.year}>
                    <FormLabel>
                      Year{" "}
                      <Text as="span" color="red.500">
                        *
                      </Text>
                    </FormLabel>
                    <YearDropdown
                      selectedYear={yearState}
                      onSelectYear={setYearState}
                      maxCurrentYear={true}
                    />
                    <input
                      type="hidden"
                      {...register("year", {
                        required: "Year is required",
                      })}
                    />
                    <FormErrorMessage>
                      {errors.year && (errors.year as any).message}
                    </FormErrorMessage>
                  </FormControl>
                </Flex>
              </VStack>
            </form>
          </AlertDialogBody>
          <AlertDialogFooter>
            <Button ref={closeRef} onClick={onClose}>
              Cancel
            </Button>
            <Button
              colorScheme="primary"
              onClick={handleSubmit(handleAddAssessment)}
              isLoading={isCreating}
              ml={3}
            >
              Create
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialogOverlay>
    </AlertDialog>
  );
};

export default CreateNewSelfAssessment;
