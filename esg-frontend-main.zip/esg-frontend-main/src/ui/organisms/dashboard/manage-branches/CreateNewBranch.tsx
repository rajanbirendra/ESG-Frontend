import {
  Button,
  Modal,
  ModalOverlay,
  ModalCloseButton,
  ModalContent,
  ModalHeader,
  FormControl,
  FormLabel,
  Input,
  ModalBody,
  ModalFooter,
  VStack,
  Box,
} from "@chakra-ui/react";
import { useState } from "react";
import { useCompanyAPI } from "@/query/use-company";
import CountryStateDropdown from "@/ui/molecules/dropdown/CountryStateDropdown";

interface CreateNewBranchProps {
  isOpen: boolean;
  onClose: () => void;
}

const CreateNewBranch = ({ isOpen, onClose }: CreateNewBranchProps) => {
  const [branchName, setBranchName] = useState("");
  const [selectedCountry, setSelectedCountry] = useState("");
  const [selectedState, setSelectedState] = useState("");
  const { createCompanyBranch } = useCompanyAPI();

  const handleSubmit = () => {
    if (branchName && selectedCountry && selectedState) {
      createCompanyBranch.mutate(
        // @ts-ignore
        {
          body: {
            branch_name: branchName,
            country: selectedCountry,
            state: selectedState,
          },
        },
        {
          onSuccess: () => {
            onClose();
            setBranchName("");
            setSelectedCountry("");
            setSelectedState("");
          },
        }
      );
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader fontSize="lg" fontWeight="bold">
          Add New Branch
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <VStack spacing={4} width="100%">
            <FormControl>
              <FormLabel>Branch Name</FormLabel>
              <Input
                type="text"
                placeholder="Enter branch name"
                value={branchName}
                onChange={(e) => setBranchName(e.target.value)}
              />
            </FormControl>
            <Box width="100%">
              <CountryStateDropdown
                selectedCountry={selectedCountry}
                selectedState={selectedState}
                onCountryChange={setSelectedCountry}
                onStateChange={setSelectedState}
              />
            </Box>
          </VStack>
        </ModalBody>
        <ModalFooter>
          <Button variant="ghost" mr={3} onClick={onClose}>
            Cancel
          </Button>
          <Button
            colorScheme="blue"
            onClick={handleSubmit}
            isLoading={createCompanyBranch.isPending}
            isDisabled={!branchName || !selectedCountry || !selectedState}
          >
            Add Branch
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default CreateNewBranch;
