import {
  Card,
  CardBody,
  SimpleGrid,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Box,
  Text,
  Flex,
  Icon,
} from "@chakra-ui/react";
import { BarChart3, FileText, CheckCircle2, AlertCircle } from "lucide-react";

const SubUserDashboard = () => {
  // Mock data - replace with actual data from your API
  const stats = {
    totalAssessments: 10,
    completedAssessments: 7,
    pendingAssessments: 3,
    lastAssessmentDate: "2024-03-20",
  };

  return (
    <Box p={4}>
      <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6} mb={8}>
        {/* Total Assessments Card */}
        <Card
          bg="white"
          boxShadow="sm"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
          transition="all 0.2s"
        >
          <CardBody>
            <Flex align="center" justify="space-between">
              <Stat>
                <StatLabel color="gray.600" fontSize="sm">
                  Total Assessments
                </StatLabel>
                <StatNumber fontSize="2xl" fontWeight="bold" color="blue.600">
                  {stats.totalAssessments}
                </StatNumber>
                <StatHelpText mb={0}>
                  <StatArrow type="increase" />
                  23.36%
                </StatHelpText>
              </Stat>
              <Icon as={BarChart3} boxSize={8} color="blue.500" />
            </Flex>
          </CardBody>
        </Card>

        {/* Completed Assessments Card */}
        <Card
          bg="white"
          boxShadow="sm"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
          transition="all 0.2s"
        >
          <CardBody>
            <Flex align="center" justify="space-between">
              <Stat>
                <StatLabel color="gray.600" fontSize="sm">
                  Completed
                </StatLabel>
                <StatNumber fontSize="2xl" fontWeight="bold" color="green.600">
                  {stats.completedAssessments}
                </StatNumber>
                <StatHelpText mb={0}>
                  <StatArrow type="increase" />
                  15.05%
                </StatHelpText>
              </Stat>
              <Icon as={CheckCircle2} boxSize={8} color="green.500" />
            </Flex>
          </CardBody>
        </Card>

        {/* Pending Assessments Card */}
        <Card
          bg="white"
          boxShadow="sm"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
          transition="all 0.2s"
        >
          <CardBody>
            <Flex align="center" justify="space-between">
              <Stat>
                <StatLabel color="gray.600" fontSize="sm">
                  Pending
                </StatLabel>
                <StatNumber fontSize="2xl" fontWeight="bold" color="orange.600">
                  {stats.pendingAssessments}
                </StatNumber>
                <StatHelpText mb={0}>
                  <StatArrow type="decrease" />
                  9.05%
                </StatHelpText>
              </Stat>
              <Icon as={AlertCircle} boxSize={8} color="orange.500" />
            </Flex>
          </CardBody>
        </Card>

        {/* Last Assessment Card */}
        <Card
          bg="white"
          boxShadow="sm"
          _hover={{ transform: "translateY(-2px)", boxShadow: "md" }}
          transition="all 0.2s"
        >
          <CardBody>
            <Flex align="center" justify="space-between">
              <Stat>
                <StatLabel color="gray.600" fontSize="sm">
                  Last Assessment
                </StatLabel>
                <StatNumber fontSize="2xl" fontWeight="bold" color="purple.600">
                  {new Date(stats.lastAssessmentDate).toLocaleDateString()}
                </StatNumber>
                <StatHelpText mb={0}>
                  <Text fontSize="sm" color="gray.500">
                    Last updated
                  </Text>
                </StatHelpText>
              </Stat>
              <Icon as={FileText} boxSize={8} color="purple.500" />
            </Flex>
          </CardBody>
        </Card>
      </SimpleGrid>

      {/* Add more sections as needed */}
    </Box>
  );
};

export default SubUserDashboard;
