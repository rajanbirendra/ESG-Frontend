// src/pages/dashboard/index.js   ← rename from dashboards.js so it maps to /dashboard
import {
  Box,
  Flex,
  Text,
  useColorModeValue,
  Icon,
  VStack,
  HStack,
  useDisclosure,
} from "@chakra-ui/react";
import Environment from "./home/EnvironmentAnalytics";
import Social from "./home/social";
import Governance from "./home/GovernanceAnalytics";
import { useState, useEffect } from "react";
import {
  Leaf,
  Users,
  Shield,
  ChevronRight,
  LucideBarChart3,
  LucideClipboardPenLine,
  LucidePersonStanding,
} from "lucide-react";
import General from "./home/general";
import { useRouter } from "next/router";
import CarbonNeutralityAnalytics from "./home/CarbonNeutralityAnalytics";
import SelfAssessmentAnalytics from "./home/SelfAssessmentAnalytics";
import { getParsedToken } from "@/utils/withAuth";
import { Roles } from "@/types/index.types";

const UserDashboardPage = () => {
  const router = useRouter();
  const { tab } = router.query;
  const [activeTab, setActiveTab] = useState("general");
  const [isMounted, setIsMounted] = useState<boolean>();
  const [userRole, setUserRole] = useState<Roles>();
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const activeTextColor = useColorModeValue("blue.600", "blue.400");
  const hoverBg = useColorModeValue("gray.50", "gray.700");
  const activeBg = useColorModeValue("blue.50", "blue.900");

  const navItems = [
    {
      id: "general",
      label: "General",
      icon: LucideBarChart3,
      component: General,
    },
    {
      id: "environment",
      label: "Environment",
      icon: Leaf,
      component: Environment,
    },
    {
      id: "social",
      label: "Social",
      icon: Users,
      component: Social,
    },
    {
      id: "governance",
      label: "Governance",
      icon: Shield,
      component: Governance,
    },
    {
      id: "carbon-neutrality-plan",
      label: "Carbon Neutrality",
      icon: LucideClipboardPenLine,
      component: CarbonNeutralityAnalytics, // Placeholder for future component
    },
    {
      id: "self-assessment",
      label: "Self Assessment",
      icon: LucidePersonStanding,
      component: SelfAssessmentAnalytics, // Placeholder for future component
    },
  ];

  // Update URL when tab changes
  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    router.push(
      {
        pathname: router.pathname,
        query: { ...router.query, tab: tabId },
      },
      undefined,
      { shallow: true }
    );
  };

  // Initialize tab from URL on mount
  useEffect(() => {
    if (
      tab &&
      typeof tab === "string" &&
      navItems.some((item) => item.id === tab)
    ) {
      setActiveTab(tab);
    }
  }, [tab]);

  // Load user role on mount
  useEffect(() => {
    setIsMounted(true);
    const token = getParsedToken();
    if (token?.role) {
      setUserRole(token.role as Roles);
    }
  }, []);

  const ActiveComponent = navItems.find(
    (item) => item.id === activeTab
  )?.component;

  return (
    <Box p={4}>
      <Flex
        bg={bgColor}
        borderWidth="1px"
        borderColor={borderColor}
        borderRadius="xl"
        marginTop={"-25px"}
        boxShadow="sm"
        overflow="hidden"
        direction="column"
      >
        {/* Navigation Bar */}
        <Flex
          borderBottom="1px"
          borderColor={borderColor}
          p={4}
          gap={2}
          align="center"
        >
          {navItems.map((item) => (
            <Flex
              key={item.id}
              align="center"
              px={4}
              py={2}
              borderRadius="lg"
              cursor="pointer"
              onClick={() => handleTabChange(item.id)}
              bg={activeTab === item.id ? activeBg : "transparent"}
              color={activeTab === item.id ? activeTextColor : textColor}
              _hover={{
                bg: activeTab === item.id ? activeBg : hoverBg,
                transform: "translateY(-1px)",
              }}
              transition="all 0.2s"
              position="relative"
            >
              <Icon as={item.icon} boxSize={5} mr={2} />
              <Text
                fontWeight={activeTab === item.id ? "semibold" : "medium"}
                fontSize="md"
              >
                {item.label}
              </Text>
              {activeTab === item.id && (
                <Box
                  position="absolute"
                  bottom="-1px"
                  left="0"
                  right="0"
                  height="2px"
                  bg={activeTextColor}
                  borderRadius="full"
                />
              )}
            </Flex>
          ))}
        </Flex>

        {/* Content Area */}
        <Box p={6}>{ActiveComponent && <ActiveComponent />}</Box>
      </Flex>
    </Box>
  );
};

export default UserDashboardPage;
