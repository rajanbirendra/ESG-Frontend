import { useCNPAPI } from "@/query/use-cnp";
import React, { useState, useMemo } from "react";
import {
  Box,
  VStack,
  HStack,
  Text,
  Badge,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Icon,
  useColorModeValue,
  Flex,
  Center,
  Button,
  useDisclosure,
  Link,
} from "@chakra-ui/react";
import { CalendarDays, Clock, Edit, Trash2, Filter } from "lucide-react";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import DeletePlanDialog from "./DeletePlanDialog";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";

const PlanList = () => {
  const { getAll } = useCNPAPI();
  const { data, isLoading, error, refetch } = getAll();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [planToDelete, setPlanToDelete] = useState<any>(null);
  const [selectedYear, setSelectedYear] = useState<string>(
    (new Date().getFullYear() - 1).toString()
  );

  // Theme colors
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const textColor = useColorModeValue("gray.700", "gray.200");
  const subtitleColor = useColorModeValue("gray.500", "gray.400");
  const cardBg = useColorModeValue("white", "gray.800");
  const cardBorder = useColorModeValue("gray.200", "gray.700");

  const handleDeleteClick = (plan: any) => {
    setPlanToDelete(plan);
    onOpen();
  };

  const handleDeleteSuccess = () => {
    setPlanToDelete(null);
    refetch();
  };

  const handleCancelDelete = () => {
    onClose();
    setPlanToDelete(null);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Filter plans based on selected year
  const filteredPlans = useMemo(() => {
    const plans = (data as any)?.data || [];
    if (!selectedYear) return plans;
    return plans.filter((plan: any) => plan.year?.toString() === selectedYear);
  }, [data, selectedYear]);

  if (isLoading) {
    return <ShimmerLoader variant="carbon-neutrality-plan" count={3} />;
  }

  if (error) {
    return (
      <Center py={10}>
        <VStack spacing={4}>
          <Text color="red.500" fontSize="lg">
            Failed to load plans
          </Text>
          <Button onClick={() => refetch()} colorScheme="blue" size="sm">
            Try Again
          </Button>
        </VStack>
      </Center>
    );
  }

  const plans = (data as any)?.data || [];

  if (plans.length === 0) {
    return (
      <Center py={10}>
        <VStack spacing={4}>
          <Box
            p={8}
            bg={cardBg}
            borderRadius="xl"
            border="1px solid"
            borderColor={cardBorder}
            textAlign="center"
          >
            <Icon as={CalendarDays} boxSize={12} color={subtitleColor} mb={4} />
            <Heading size="md" color={textColor} mb={2}>
              No Carbon Neutrality Plans
            </Heading>
            <Text color={subtitleColor}>
              Create your first carbon neutrality plan to get started
            </Text>
          </Box>
        </VStack>
      </Center>
    );
  }

  return (
    <>
      <VStack spacing={6} align="stretch" w="full">
        {/* Filter Section */}
        <Box
          p={4}
          bg={cardBg}
          border="1px solid"
          borderColor={cardBorder}
          borderRadius="lg"
        >
          <Flex justify="space-between" align="center">
            <HStack spacing={4} align="center">
              <Icon as={Filter} color="blue.500" boxSize={5} />
              <Text fontSize="sm" fontWeight="medium" color={textColor}>
                Filter by Year:
              </Text>
            </HStack>
            <HStack spacing={3} align="center">
              <YearDropdown
                selectedYear={selectedYear}
                onSelectYear={setSelectedYear}
                maxCurrentYear={true}
              />
              {selectedYear && (
                <Button
                  size="sm"
                  variant="ghost"
                  colorScheme="blue"
                  onClick={() => setSelectedYear("")}
                >
                  Clear Filter
                </Button>
              )}
            </HStack>
          </Flex>
        </Box>

        {/* Results Count */}
        {selectedYear && (
          <Text fontSize="sm" color={subtitleColor}>
            Showing {filteredPlans.length} plan
            {filteredPlans.length !== 1 ? "s" : ""} for {selectedYear}
          </Text>
        )}

        <VStack spacing={4} align="stretch">
          {filteredPlans.length === 0 ? (
            <Center py={10}>
              <VStack spacing={4}>
                <Box
                  p={8}
                  bg={cardBg}
                  borderRadius="xl"
                  border="1px solid"
                  borderColor={cardBorder}
                  textAlign="center"
                >
                  <Icon
                    as={CalendarDays}
                    boxSize={12}
                    color={subtitleColor}
                    mb={4}
                  />
                  <Heading size="md" color={textColor} mb={2}>
                    No Plans Found
                  </Heading>
                  <Text color={subtitleColor}>
                    No carbon neutrality plans found for {selectedYear}
                  </Text>
                </Box>
              </VStack>
            </Center>
          ) : (
            filteredPlans.map((plan) => (
              <Card
                key={plan.id}
                bg={cardBg}
                border="1px solid"
                borderColor={cardBorder}
                borderRadius="xl"
                boxShadow="sm"
                _hover={{
                  boxShadow: "md",
                  transform: "translateY(-1px)",
                }}
                transition="all 0.2s"
              >
                <CardHeader pb={3}>
                  <Flex justify="space-between" align="center">
                    <HStack spacing={3}>
                      <Icon as={CalendarDays} color="blue.500" boxSize={5} />
                      <VStack
                        align="start"
                        spacing={0}
                        as={Link}
                        href={`/dashboard/carbon-neutrality-plan/details/${plan.id}`}
                      >
                        <Heading size="md" color={textColor}>
                          Carbon Neutrality Plan {plan.year}
                        </Heading>
                        <Text fontSize="sm" color={subtitleColor}>
                          Plan ID: {plan.id.slice(0, 8)}...
                        </Text>
                      </VStack>
                    </HStack>
                  </Flex>
                </CardHeader>

                <CardBody pt={0}>
                  <VStack spacing={4} align="stretch">
                    <HStack justify="space-between" wrap="wrap" gap={4}>
                      <HStack spacing={2}>
                        <Icon as={Clock} color={subtitleColor} boxSize={4} />
                        <Text fontSize="sm" color={subtitleColor}>
                          Created: {formatDate(plan.created_at)}
                        </Text>
                      </HStack>
                    </HStack>

                    <Flex justify="flex-end" gap={2} pt={2}>
                      <Button
                        size="sm"
                        variant="outline"
                        leftIcon={<Trash2 size={16} />}
                        colorScheme="red"
                        borderRadius="lg"
                        onClick={() => handleDeleteClick(plan)}
                      >
                        Delete
                      </Button>
                    </Flex>
                  </VStack>
                </CardBody>
              </Card>
            ))
          )}
        </VStack>
      </VStack>

      {/* Delete Confirmation Modal */}
      <DeletePlanDialog
        isOpen={isOpen}
        onClose={handleCancelDelete}
        onSuccess={handleDeleteSuccess}
        plan={planToDelete}
      />
    </>
  );
};

export default PlanList;
