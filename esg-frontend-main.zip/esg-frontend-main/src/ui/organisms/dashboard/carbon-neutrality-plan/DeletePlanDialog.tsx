import React from "react";
import {
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Button,
  HStack,
  VStack,
  Text,
  Icon,
  useToast,
} from "@chakra-ui/react";
import { AlertTriangle } from "lucide-react";
import { useCNPAPI } from "@/query/use-cnp";

interface DeletePlanDialogProps {
  plan: any;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

const DeletePlanDialog: React.FC<DeletePlanDialogProps> = ({
  plan,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { delete: deleteMutation } = useCNPAPI();
  const toast = useToast();

  const handleConfirmDelete = () => {
    if (!plan) return;

    deleteMutation.mutate(
      {
        path: { cnp_id: plan.id },
        headers: { authorization: `Bearer ${localStorage.getItem("token")}` },
      },
      {
        onSuccess: () => {
          onClose();
          onSuccess();
        },
      }
    );
  };

  const handleCancelDelete = () => {
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={handleCancelDelete} isCentered>
      <ModalOverlay backdropFilter="blur(4px)" />
      <ModalContent borderRadius="xl" boxShadow="2xl">
        <ModalHeader
          textAlign="center"
          fontSize="xl"
          fontWeight="bold"
          borderBottom="1px solid"
          borderColor="gray.200"
          pb={4}
        >
          <HStack justify="center" spacing={3}>
            <Icon as={AlertTriangle} color="red.500" boxSize={6} />
            <Text>Confirm Deletion</Text>
          </HStack>
        </ModalHeader>

        <ModalBody py={8}>
          <VStack spacing={4} align="stretch">
            <Text fontSize="md" color="gray.700" textAlign="center">
              Are you sure you want to delete the Carbon Neutrality Plan for{" "}
              <Text as="span" fontWeight="bold" color="red.500">
                {plan?.year}
              </Text>
              ?
            </Text>
            <Text fontSize="sm" color="gray.500" textAlign="center">
              This action cannot be undone. All data associated with this plan
              will be permanently removed.
            </Text>
          </VStack>
        </ModalBody>

        <ModalFooter
          gap={3}
          borderTop="1px solid"
          borderColor="gray.200"
          pt={4}
        >
          <Button
            variant="outline"
            onClick={handleCancelDelete}
            borderRadius="lg"
            px={6}
          >
            Cancel
          </Button>
          <Button
            colorScheme="red"
            onClick={handleConfirmDelete}
            borderRadius="lg"
            px={6}
            isLoading={deleteMutation.isPending}
            loadingText="Deleting..."
          >
            Delete Plan
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default DeletePlanDialog;
