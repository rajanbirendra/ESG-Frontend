import React, { useState } from "react";
import {
  Box,
  Button,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  VStack,
  Text,
  useToast,
} from "@chakra-ui/react";
import { Plus } from "lucide-react";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";
import { useCNPAPI } from "@/query/use-cnp";
import { useAssessmentsAPI } from "@/query/use-assessments";
import CustomYearDropdown from "@/ui/molecules/dropdown/CustomYearDropdown";

const CreatePlan = ({
  isOpen,
  onClose,
}: {
  isOpen: boolean;
  onClose: () => void;
}) => {
  const [selectedYear, setSelectedYear] = useState<string>("");
  const toast = useToast();
  const createMutation = useCNPAPI().create;
  const { data: assessmentDoneYears, isLoading } =
    useAssessmentsAPI().getAssessmentDoneYears();

  const handleStart = () => {
    if (!selectedYear) {
      toast({
        title: "Please select a year",
        status: "warning",
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    // Handle the start action here
    console.log("Selected year:", selectedYear);

    createMutation.mutate(
      //   @ts-ignore
      {
        body: {
          year: selectedYear,
        },
      },
      {
        onSuccess: () => {
          onClose();
          setSelectedYear("");
        },
      }
    );
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered>
      <ModalOverlay backdropFilter="blur(4px)" />
      <ModalContent borderRadius="xl" boxShadow="2xl">
        <ModalHeader
          textAlign="center"
          fontSize="xl"
          fontWeight="bold"
          borderBottom="1px solid"
          borderColor="gray.200"
          pb={4}
        >
          Create New Carbon Neutrality Plan
        </ModalHeader>

        <ModalBody py={8}>
          <VStack spacing={6} align="stretch">
            <Text fontSize="md" fontWeight="medium" color="gray.700">
              Select the Base Year
            </Text>

            <Box>
              <CustomYearDropdown
                selectedYear={selectedYear}
                onSelectYear={setSelectedYear}
                years={assessmentDoneYears as string[]}
              />
              <Text fontSize="sm" color="blue.600" mt={2} fontWeight="medium">
                Note: Years will only appear for completed assessments
              </Text>
            </Box>
          </VStack>
        </ModalBody>

        <ModalFooter
          gap={3}
          borderTop="1px solid"
          borderColor="gray.200"
          pt={4}
        >
          <Button variant="outline" onClick={onClose} borderRadius="lg" px={6}>
            Cancel
          </Button>
          <Button
            colorScheme="primary"
            onClick={handleStart}
            borderRadius="lg"
            px={6}
            isDisabled={!selectedYear}
            _disabled={{
              opacity: 0.6,
              cursor: "not-allowed",
            }}
          >
            Start Plan
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default CreatePlan;
