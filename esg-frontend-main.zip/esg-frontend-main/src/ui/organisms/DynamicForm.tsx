import { syncValueSyncPostMutation } from "@/api/@tanstack/react-query.gen";
import {
  useToast,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  AlertDialog,
  AlertDialogOverlay,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogBody,
  AlertDialogFooter,
  Flex,
} from "@chakra-ui/react";
import { useMutation } from "@tanstack/react-query";
import React, {
  useEffect,
  useState,
  useRef,
  useMemo,
  useCallback,
} from "react";
import { Box, Text, Button } from "@chakra-ui/react";
import ProgressBox from "../molecules/ProgressBox";
import {
  handleRenderingMultipleFields,
  renderFields,
} from "./dashboard/assessment/dynamic-form/handleRenderingField";
import { ArrowUp } from "lucide-react";

interface QuestionData {
  id: string;
  question_title: string;
  answer_field: {
    for_user: Array<{
      label: string;
      input_type: string;
      options?: string[];
      conditional?: {
        [key: string]: Array<{
          label: string;
          input_type: string;
          allowedExtensions?: string[];
          multiple?: Array<any>;
        }>;
      };
      allowedExtensions?: string[];
      multiple?: Array<any>;
    }>;
  };
  sub_category?: string;
  category?: string;
  type?: string;
  answer?: any;
}

interface DynamicFormProps {
  data: {
    questions: QuestionData[];
    completion_percentage: number;
    answered_questions: number;
    total_questions: number;
  };
  assessmentId?: string;
  cnpId?: string;
  assessmentFor?: string;
  showProgressBar?: boolean;
}

const AssessmentDynamicForm = ({
  data,
  assessmentId,
  cnpId,
  assessmentFor = "",
  showProgressBar = true,
}: DynamicFormProps) => {
  const noTabsPages = [
    "SELF_ASSESSMENT_SOCIAL",
    "SELF_ASSESSMENT_GOVERNANCE",
    "SELF_ASSESSMENT_ENVIRONMENT",
  ];
  const { mutate } = useMutation({
    ...syncValueSyncPostMutation(),
  });
  const [formData, setFormData] = useState<{ [key: string]: any }>({});
  const [progressBarState, setProgressBarState] = useState<{
    completion_percentage: number;
    answered_questions: number;
    total_questions: number;
  }>({
    completion_percentage: 0,
    answered_questions: 0,
    total_questions: 0,
  });

  // Add state for delete confirmation dialog
  const [deleteDialogState, setDeleteDialogState] = useState<{
    isOpen: boolean;
    questionId: string;
    indexToDelete: number;
  }>({
    isOpen: false,
    questionId: "",
    indexToDelete: -1,
  });

  // Add ref for dialog
  const cancelRef = React.useRef(null);

  const subCategories = useMemo(() => {
    console.log("data (AssessmentDynamicForm)", data);

    // Get unique categories while preserving order
    const uniqueCategories =
      data?.questions?.reduce((acc: string[], q) => {
        const category =
          assessmentFor === "ASSESSMENT_SOCIAL" ||
          assessmentFor === "ASSESSMENT_GOVERNANCE" ||
          assessmentFor === "CARBON_NEUTRALITY_PLAN"
            ? q.category
            : q.sub_category || q.category;
        if (category && !acc.includes(category)) {
          acc.push(category);
        }
        return acc;
      }, []) || [];

    return uniqueCategories;
  }, [data, assessmentFor]);

  //  State for selected tab
  const [selectedSubCategory, setSelectedSubCategory] = useState<string | null>(
    null
  );
  // Add state for selected tab index
  const [selectedTabIndex, setSelectedTabIndex] = useState(0);
  // Create refs for each tab panel
  const tabContentRefs = useRef<(HTMLDivElement | null)[]>([]);
  console.log("data (AssessmentDynamicForm)", data);

  // Auto-select first tab on load
  useEffect(() => {
    if (subCategories.length > 0 && !selectedSubCategory) {
      setSelectedSubCategory(subCategories[0]);
    }
  }, [subCategories, selectedSubCategory]);

  const filteredQuestions = useMemo(
    () =>
      data?.questions?.filter((q) => {
        if (
          assessmentFor === "ASSESSMENT_SOCIAL" ||
          assessmentFor === "ASSESSMENT_GOVERNANCE"
        ) {
          return q.category === selectedSubCategory;
        } else {
          return (q.sub_category || q.category) === selectedSubCategory;
        }
      }),
    [data, selectedSubCategory, assessmentFor]
  );

  const [lastQuestionNumber, setLastQuestionNumber] = useState(0);

  useEffect(() => {
    if (selectedSubCategory) {
      const currentTabIndex = subCategories.indexOf(selectedSubCategory);
      if (currentTabIndex > 0) {
        // Get the count of questions in previous tabs
        let previousCount = 0;
        for (let i = 0; i < currentTabIndex; i++) {
          const prevTabQuestions = data?.questions?.filter((q: any) => {
            if (
              assessmentFor === "ASSESSMENT_SOCIAL" ||
              assessmentFor === "ASSESSMENT_GOVERNANCE" ||
              assessmentFor === "CARBON_NEUTRALITY_PLAN"
            ) {
              return q.category === subCategories[i];
            }
            return (q.sub_category || q.category) === subCategories[i];
          });
          previousCount += prevTabQuestions?.length || 0;
        }
        setLastQuestionNumber(previousCount);
      } else {
        setLastQuestionNumber(0);
      }
    }
  }, [selectedSubCategory, subCategories, data, assessmentFor]);

  useEffect(() => {
    if (data && data.questions && data.questions.length > 0) {
      const initialFormData = data.questions.reduce((acc, question) => {
        acc[question.id] = {};
        question.answer_field.for_user.forEach((field) => {
          if (field.multiple) {
            // Handle multiple fields with existing answers
            if (question.answer?.values?.value?.[0]) {
              acc[question.id] = {
                value: [question.answer.values.value[0]],
              };
            } else {
              // Initialize empty state for multiple fields
              acc[question.id] = {
                value: [{ "0": {} }], // doing this renders the field.
              };
            }
          } else {
            if (field.input_type === "radio") {
              acc[question.id]["value"] = question.answer?.values?.value;
              if (field?.conditional) {
                Object.entries(question.answer?.values ?? {}).map(
                  ([key, value]) => {
                    acc[question.id][key] = value;
                  }
                );
              }
            } else {
              acc[question.id][field.label] =
                question.answer?.values[field.label];
              if (field?.conditional) {
                Object.entries(question.answer?.values ?? {}).map(
                  ([key, value]) => {
                    if (key === "value") {
                      acc[question.id]["value"] = question.answer?.values
                        ?.value?.[0]
                        ? [question.answer.values.value[0]]
                        : [
                            {
                              "0": {},
                            },
                          ];
                    } else acc[question.id][key] = value;
                  }
                );
              }
            }
          }
        });
        return acc;
      }, {} as { [key: string]: any });

      console.log("initialFormData", initialFormData);
      setFormData(initialFormData);

      // set progress bar state
      setProgressBarState({
        completion_percentage: data.completion_percentage!,
        answered_questions: data.answered_questions!,
        total_questions: data.total_questions!,
      });
    }
  }, [data]);

  // Memoize handleSync
  const handleSync = useCallback(
    (data: { questionId: string; values: any }) => {
      if (data.values.file) {
        console.log("data.values.questionIndex", data.values.questionIndex);
        const formData = new FormData();
        formData.append("file", data.values.file as Blob);
        formData.append("question_id", data.questionId);
        if (data.values.questionIndex !== null && data.values.questionIndex !== undefined)
          formData.append("question_index", data.values.questionIndex);
        if (assessmentId) formData.append("assessment_id", assessmentId);
        if (cnpId) formData.append("cnf_id", cnpId);

        fetch(`${process.env.NEXT_PUBLIC_API_URL}/sync`, {
          method: "POST",
          body: formData,
        })
          .then((res) => res.json())
          .then((data) => {
            console.log("Full API response:", data);
            // show toast
            const toast = useToast();
            toast({
              title: "File uploaded successfully",
              description: "File uploaded successfully",
              status: "success",
              duration: 3000,
              isClosable: true,
            });
          })
          .catch((err) => console.error("File upload error:", err));
      } else {
        let body = {
          question_id: data.questionId,
          values: data.values,
        };
        if (assessmentId) {
          // @ts-ignore
          body.assessment_id = assessmentId;
        }
        if (cnpId) {
          // @ts-ignore
          body.cnp_id = cnpId;
        }
        mutate(
          {
            // @ts-ignore
            body,
          },
          {
            onSuccess: (res: any) => {
              setProgressBarState((prev) => ({
                ...prev,
                total_questions: res.total_questions,
                answered_questions: res.answered_questions,
                completion_percentage: res.completion_percentage,
              }));
            },
          }
        );
      }
    },
    [mutate, assessmentId]
  );

  const confirmDelete = useCallback(() => {
    const newFormData = { ...formData };
    if (!newFormData[deleteDialogState.questionId]?.value?.[0]) return;

    const currentValues = {
      ...newFormData[deleteDialogState.questionId].value[0],
    };
    delete currentValues[deleteDialogState.indexToDelete];

    // Reindex the remaining values
    const reindexedValues = Object.entries(currentValues).reduce(
      (acc, [_, value], idx) => {
        acc[idx] = value;
        return acc;
      },
      {}
    );

    // Update form state with reindexed values
    newFormData[deleteDialogState.questionId] = {
      ...newFormData[deleteDialogState.questionId],
      value: [reindexedValues],
    };

    // If there are no remaining values, initialize with an empty object
    if (Object.keys(reindexedValues).length === 0) {
      newFormData[deleteDialogState.questionId] = {
        value: [{ "0": {} }],
      };
    }

    setFormData(newFormData);

    handleSync({
      questionId: deleteDialogState.questionId,
      values: {
        ...newFormData[deleteDialogState.questionId],
        value: [reindexedValues],
      },
    });

    // Close the dialog
    setDeleteDialogState({
      isOpen: false,
      questionId: "",
      indexToDelete: -1,
    });
  }, [deleteDialogState, formData, handleSync]);

  const [showScrollToTop, setShowScrollToTop] = useState(false);
  const mainContentRef = useRef<HTMLDivElement>(null);

  // Set up scroll listener
  useEffect(() => {
    let currentRef: HTMLDivElement | null = null;
    if (subCategories.length > 1 && !noTabsPages.includes(assessmentFor)) {
      // Tabbed UI: use the ref for the current tab
      currentRef = tabContentRefs.current[selectedTabIndex];
    } else {
      // Non-tabbed UI
      currentRef = mainContentRef.current;
    }
    if (!currentRef) return;
    const handleScroll = () => {
      setShowScrollToTop(currentRef!.scrollTop > 300);
    };
    currentRef.addEventListener("scroll", handleScroll);
    return () => {
      currentRef && currentRef.removeEventListener("scroll", handleScroll);
    };
  }, [selectedTabIndex, subCategories.length, assessmentFor, noTabsPages]);

  const scrollToTop = () => {
    let currentRef: HTMLDivElement | null = null;
    if (subCategories.length > 1 && !noTabsPages.includes(assessmentFor)) {
      currentRef = tabContentRefs.current[selectedTabIndex];
    } else {
      currentRef = mainContentRef.current;
    }
    if (currentRef) {
      currentRef.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    }
  };

  const scrollButtonStyle = {
    position: "fixed",
    bottom: "24px",
    right: "32px",
    zIndex: 1000,
    colorScheme: "blue",
    borderRadius: "full",
    width: "48px",
    height: "48px",
    boxShadow: "lg",
    _hover: {
      transform: "translateY(-2px)",
      boxShadow: "xl",
    },
    transition: "all 0.2s",
  };

  // Memoize renderContent
  const renderContent = useCallback(
    (question: any, displayIndex: number) => {
      return (
        <>
          <Box
            key={`questions_${question.id}`}
            display="flex"
            flexDirection="column"
            marginBottom={{ base: "16px", md: "20px" }}
            boxShadow="0 0 10px 0 rgba(0, 0, 0, 0.1)"
            padding={{ base: "16px", md: "20px" }}
            width="100%"
            borderRadius="md"
            bg="white"
            position="relative"
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                flexDirection: "row",
              }}
            >
              <Text
                fontSize={{ base: "md", md: "lg" }}
                fontWeight="bold"
                mb={{ base: 1, md: 2 }}
              >
                {`${displayIndex + 1}. ${question.question_title}`}
              </Text>
            </div>

            <div key={"answer_field_" + question.id + "_" + displayIndex + "_"}>
              {question.answer_field.for_user.length === 2 &&
              (question.type == "SOCIAL" || question.type == "GOVERNANCE") &&
              !question.answer_field.for_user[0].multiple ? (
                // Responsive layout: stack on mobile, side by side on desktop
                <Flex
                  direction={{ base: "column", md: "row" }}
                  sx={{
                    "& > *": {
                      width: { base: "100%", md: "50%" },
                    },
                  }}
                  gap={{ base: 4, md: 5 }}
                >
                  {question.answer_field.for_user.map((field, fieldIndex) => {
                    return renderFields(
                      formData,
                      setFormData,
                      handleSync,
                      setDeleteDialogState,
                      question,
                      displayIndex,
                      field,
                      fieldIndex
                    );
                  })}
                </Flex>
              ) : (
                question.answer_field["for_user"].map((field, i) => {
                  if (field.multiple && field.multiple.length > 0) {
                    return handleRenderingMultipleFields(
                      formData,
                      setFormData,
                      handleSync,
                      setDeleteDialogState,
                      question,
                      displayIndex,
                      field.multiple,
                      i
                    );
                  } else {
                    return renderFields(
                      formData,
                      setFormData,
                      handleSync,
                      setDeleteDialogState,
                      question,
                      displayIndex,
                      field
                    );
                  }
                })
              )}
            </div>
          </Box>
        </>
      );
    },
    [formData, handleSync, setDeleteDialogState]
  );

  const handleTabChange = useCallback(
    (index: number) => {
      setSelectedSubCategory(subCategories[index]);
      setSelectedTabIndex(index); // update tab index
    },
    [subCategories]
  );

  // Memoize the progress box
  const progressBox = useMemo(
    () =>
      showProgressBar && (
        <ProgressBox
          completion_percentage={progressBarState.completion_percentage}
          answered_questions={progressBarState.answered_questions}
          total_questions={progressBarState.total_questions}
          style={{ position: "fixed", bottom: 0, right: 0, zIndex: 10000000 }}
        />
      ),
    [progressBarState, showProgressBar]
  );

  console.log("assessmentFor", assessmentFor);
  return (
    <>
      {!noTabsPages.includes(assessmentFor) &&
        subCategories.length > 1 &&
        subCategories.length <= 3 && (
          <Box
            position="sticky"
            top={0}
            bg="white"
            justifyContent={"center"}
            display={"flex"}
            flexDirection={"column"}
            py={{ base: 2, md: 4 }}
            zIndex={2}
            borderBottom="1px"
            borderColor="gray.200"
          >
            <Tabs
              variant="soft-rounded"
              colorScheme="blue"
              onChange={handleTabChange}
              index={subCategories.indexOf(selectedSubCategory || "")}
              display="flex"
              flexDirection={"column"}
              alignItems={"center"}
              gap={{ base: 4, md: 10 }}
              defaultIndex={0}
              width="100%"
            >
              <TabList
                flexDirection="row"
                borderColor="gray.200"
                alignItems={"center"}
                justifyContent="center"
                gap={{ base: 1, sm: 2, md: 3, lg: 5 }}
                maxW={{ base: "100%", sm: "400px", lg: "600px" }}
                width="auto"
                display={"flex"}
                mx="auto"
                flexWrap="wrap"
                overflowX={{ base: "auto", md: "visible" }}
                pb={{ base: 1, md: 0 }}
              >
                {subCategories?.map((subCat: string) => (
                  <Tab
                    key={subCat}
                    fontWeight="medium"
                    fontSize={{ base: "xs", sm: "sm" }}
                    whiteSpace="nowrap"
                    px={{ base: 2, sm: 3 }}
                    py={{ base: 1, sm: 1.5 }}
                    minW={{ base: "auto", sm: "100px", md: "120px" }}
                    flexShrink={0}
                    color="gray.700"
                    _selected={{
                      bg: "blue.500",
                      color: "white",
                      boxShadow: "sm",
                      _hover: {
                        bg: "blue.600",
                        color: "white",
                      },
                    }}
                    _hover={{
                      bg: "blue.50",
                      color: "blue.700",
                    }}
                  >
                    {subCat
                      .replaceAll("_", " ")
                      .split(" ")
                      .map((word, index) =>
                        index === 0
                          ? word.charAt(0).toUpperCase() +
                            word.slice(1).toLowerCase()
                          : word.toLowerCase()
                      )
                      .join(" ")}
                  </Tab>
                ))}
              </TabList>
              <Box
                flex="1"
                display={"flex"}
                flexDirection={"column"}
                width={"100%"}
                height={{
                  base: "calc(100vh - 150px)",
                  md: "calc(100vh - 200px)",
                }}
                overflowY="auto"
                css={{
                  "&::-webkit-scrollbar": {
                    width: "4px",
                  },
                  "&::-webkit-scrollbar-track": {
                    width: "6px",
                  },
                  "&::-webkit-scrollbar-thumb": {
                    background: "gray.200",
                    borderRadius: "24px",
                  },
                }}
              >
                <TabPanels height="100%">
                  {subCategories?.map((subCat: string, idx: number) => (
                    <TabPanel key={subCat} p={0} height="100%">
                      <Box
                        ref={(el) => {
                          tabContentRefs.current[idx] = el;
                        }}
                        flex="1"
                        p={{ base: 3, md: 6 }}
                        overflowY="auto"
                        height="100%"
                      >
                        {data.questions
                          ?.filter((question) =>
                            assessmentFor === "ASSESSMENT_SOCIAL" ||
                            assessmentFor === "ASSESSMENT_GOVERNANCE"
                              ? question.category === subCat
                              : (question.sub_category || question.category) ===
                                subCat
                          )
                          .map((question, index) => {
                            // Calculate display index for horizontal tabs
                            const displayIndex = lastQuestionNumber + index;
                            return renderContent(question, displayIndex);
                          })}
                        <Box height="100px" /> {/* Spacer for last item */}
                      </Box>
                    </TabPanel>
                  ))}
                </TabPanels>
              </Box>
            </Tabs>
          </Box>
        )}
      {assessmentFor &&
      !noTabsPages.includes(assessmentFor) &&
      subCategories.length > 3 ? (
        <Box
          position="sticky"
          top={0}
          bg="white"
          zIndex={2}
          borderBottom="1px"
          borderColor="gray.200"
          py={{ base: 2, md: 4 }}
          height={{ base: "100vh", lg: "100vh" }}
          overflow="hidden"
        >
          <Tabs
            variant="soft-rounded"
            colorScheme="blue"
            onChange={handleTabChange}
            index={subCategories.indexOf(selectedSubCategory || "")}
            orientation="vertical"
            display="flex"
            gap={{ base: 2, lg: 4 }}
            defaultIndex={0}
            height="100%"
            flexDirection={{ base: "column", lg: "row" }}
          >
            <TabList
              flexDirection={{ base: "row", lg: "column" }}
              alignItems="center"
              borderRight={{ base: "none", lg: "1px" }}
              borderBottom={{ base: "1px", lg: "none" }}
              borderColor="gray.200"
              pr={{ base: 0, lg: 4 }}
              pb={{ base: 2, lg: 0 }}
              minW={{ base: "100%", lg: "200px" }}
              height={{ base: "auto", lg: "100%" }}
              overflowY={{ base: "visible", lg: "auto" }}
              justifyContent={{ base: "center", lg: "flex-start" }}
              flexWrap={{ base: "wrap", lg: "nowrap" }}
              gap={{ base: 1, lg: 2 }}
            >
              {subCategories?.map((subCat: string) => (
                <Tab
                  key={subCat}
                  fontWeight="medium"
                  fontSize={{ base: "xs", sm: "sm" }}
                  whiteSpace="nowrap"
                  px={{ base: 2, sm: 3 }}
                  py={{ base: 1, sm: 1.5 }}
                  width={{ base: "auto", lg: "100%" }}
                  justifyContent={{ base: "center", lg: "flex-start" }}
                  color="gray.700"
                  _selected={{
                    bg: "blue.500",
                    color: "white",
                    boxShadow: "sm",
                    _hover: {
                      bg: "blue.600",
                      color: "white",
                    },
                  }}
                  _hover={{
                    bg: "blue.50",
                    color: "blue.700",
                  }}
                >
                  {subCat
                    .replaceAll("_", " ")
                    .split(" ")
                    .map((word, index) =>
                      index === 0
                        ? word.charAt(0).toUpperCase() +
                          word.slice(1).toLowerCase()
                        : word.toLowerCase()
                    )
                    .join(" ")}
                </Tab>
              ))}
            </TabList>
            <Box
              flex="1"
              height={{ base: "calc(100vh - 120px)", lg: "100%" }}
              overflow="hidden"
            >
              <TabPanels height="100%">
                {subCategories?.map((subCat: string, idx: number) => (
                  <TabPanel key={subCat} p={0} height="100%">
                    <Box
                      ref={(el) => {
                        tabContentRefs.current[idx] = el;
                      }}
                      flex="1"
                      p={{ base: 3, md: 6 }}
                      overflowY="auto"
                      height="100%"
                    >
                      {data.questions
                        ?.filter((question) =>
                          assessmentFor === "ASSESSMENT_SOCIAL"
                            ? question.category === subCat
                            : (question.sub_category || question.category) ===
                              subCat
                        )
                        .map((question) => {
                          // Calculate global index for each question
                          const globalIndex = data.questions.findIndex(
                            (q) => q.id === question.id
                          );
                          return renderContent(question, globalIndex);
                        })}
                      <Box height="100px" /> {/* Spacer for last item */}
                    </Box>
                  </TabPanel>
                ))}
              </TabPanels>
            </Box>
          </Tabs>
        </Box>
      ) : (
        (subCategories.length <= 1 ||
          (assessmentFor && noTabsPages.includes(assessmentFor))) && (
          <Box
            ref={mainContentRef}
            flex="1"
            p={{ base: 3, md: 6 }}
            overflowY="auto"
            height={{ base: "calc(100vh - 80px)", md: "calc(100vh - 100px)" }}
            maxH="calc(100vh - 200px)"
            sx={{
              "&::-webkit-scrollbar": {
                width: "8px",
              },
              "&::-webkit-scrollbar-track": {
                background: "#f1f1f1",
                borderRadius: "4px",
              },
              "&::-webkit-scrollbar-thumb": {
                background: "#c1c1c1",
                borderRadius: "4px",
                "&:hover": {
                  background: "#a8a8a8",
                },
              },
            }}
          >
            {data.questions?.map((question, index) => {
              return renderContent(question, index);
            })}
            <Box height="100px" /> {/* Spacer for last item */}
          </Box>
        )
      )}

      {/* Move to Top Button and ProgressBox (stacked at bottom right) */}
      <Box
        position="fixed"
        bottom={{ base: "16px", md: "24px" }}
        right={{ base: "16px", md: "32px" }}
        zIndex={10000001}
        display="flex"
        flexDirection="column"
        alignItems="flex-end"
        gap={3}
      >
        {showScrollToTop && (
          <Button
            onClick={scrollToTop}
            colorScheme="blue"
            borderRadius="full"
            width={{ base: "auto", md: "auto" }}
            height={{ base: "40px", md: "48px" }}
            boxShadow="lg"
            px={6}
            py={2}
            display="flex"
            alignItems="center"
            gap={2}
            _hover={{
              transform: "translateY(-2px)",
              boxShadow: "xl",
            }}
            transition="all 0.2s"
            aria-label="Scroll to top"
            mb={10}
          >
            <ArrowUp size={22} />
            <span style={{ fontWeight: 600, fontSize: 16 }}>Move to Top</span>
          </Button>
        )}
        {progressBox}
      </Box>

      {/* AlertDialog at root level */}
      <AlertDialog
        isOpen={deleteDialogState.isOpen}
        leastDestructiveRef={cancelRef}
        onClose={() =>
          setDeleteDialogState({
            isOpen: false,
            questionId: "",
            indexToDelete: -1,
          })
        }
        isCentered
      >
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              Delete Field
            </AlertDialogHeader>

            <AlertDialogBody>
              Are you sure you want to delete this field? This action cannot be
              undone.
            </AlertDialogBody>

            <AlertDialogFooter>
              <Button
                ref={cancelRef}
                onClick={() =>
                  setDeleteDialogState({
                    isOpen: false,
                    questionId: "",
                    indexToDelete: -1,
                  })
                }
              >
                Cancel
              </Button>
              <Button colorScheme="red" onClick={confirmDelete} ml={3}>
                Delete
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </>
  );
};

export default React.memo(AssessmentDynamicForm);
