import {
  Button,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  FormErrorMessage,
  Input,
  VStack,
  useDisclosure,
  useToast,
  Box,
  Avatar,
  IconButton,
  Center,
  Grid,
} from "@chakra-ui/react";
import { Edit, Upload } from "lucide-react";
import { useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { useUserAPI } from "@/query/use-user";
import { useMediaAPI } from "@/query/use-media";
import { useQueryClient } from "@tanstack/react-query";
import { meAuthMeGetOptions } from "@/api/@tanstack/react-query.gen";

interface ProfileFormData {
  first_name: string;
  last_name: string;
  email: string;
  phone_number?: string;
  company_role?: string;
  profile_picture?: string;
}

const EditProfile = ({ values }: { values: ProfileFormData }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const {
    register,
    handleSubmit,
    formState: { errors, isDirty },
    reset,
    setValue,
    watch,
  } = useForm<ProfileFormData>({
    defaultValues: values,
  });

  const profilePicture = watch("profile_picture");

  // Update form values when props change
  useEffect(() => {
    if (values) {
      Object.entries(values).forEach(([key, value]) => {
        setValue(key as keyof ProfileFormData, value);
      });
    }
  }, [values, setValue]);

  const { mutate: updateProfile, isPending: isUpdating } =
    useUserAPI().updateProfile;

  const onSubmit = (data: ProfileFormData) => {
    delete data.profile_picture; // as it will be directly set after onChange on Media
    updateProfile(
      // @ts-ignore
      {
        body: data,
      },
      {
        onSuccess: () => {
          onClose();
          reset(values);
        },
      }
    );
  };

  const { mutate: uploadMedia, isPending: isUploading } = useMediaAPI().upload;

  const queryClient = useQueryClient();
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      toast({
        title: "Invalid File",
        description: "Please upload an image file",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please upload an image smaller than 5MB",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    uploadMedia(
      // @ts-ignore
      {
        body: {
          file: file,
          media_type: "PROFILE_PICTURE",
        },
      },
      {
        onSuccess: (response: any) => {
          if (response?.data?.file_key) {
            setValue("profile_picture", response.data.url);
            toast({
              title: "Image Uploaded",
              description: "Profile picture has been updated successfully",
              status: "success",
              duration: 3000,
              isClosable: true,
            });

            // @ts-ignore
            queryClient.invalidateQueries(meAuthMeGetOptions({}));
          }
        },
        onError: (error) => {
          toast({
            title: "Upload Failed",
            description: "Failed to upload image. Please try again.",
            status: "error",
            duration: 3000,
            isClosable: true,
          });
          console.error("Error uploading image:", error);
        },
      }
    );
  };

  return (
    <div>
      <Button
        onClick={onOpen}
        leftIcon={<Edit size={18} />}
        variant="ghost"
        colorScheme="primary"
        borderRadius="lg"
        size="sm"
        fontWeight="medium"
        alignSelf="flex-end"
        _hover={{ bg: "primary.50" }}
        marginTop={"-50px"}
        marginBottom={"0px"}
        _focus={{
          boxShadow: "0 0 0 2px var(--chakra-colors-primary-200)",
        }}
        aria-label="Edit Profile"
      >
        Edit Profile
      </Button>

      <Modal isOpen={isOpen} onClose={onClose} size="lg">
        <ModalOverlay backdropFilter="blur(4px)" />
        <ModalContent>
          <ModalHeader borderBottom="1px" borderColor="gray.200" pb={4}>
            Edit Profile
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody py={6}>
            <form id="edit-profile-form" onSubmit={handleSubmit(onSubmit)}>
              <VStack spacing={6} align="stretch">
                <Center>
                  <Box position="relative">
                    <Avatar
                      size="2xl"
                      name={`${values.first_name} ${values.last_name}`}
                      src={profilePicture}
                    />
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept="image/*"
                      style={{ display: "none" }}
                    />
                    <IconButton
                      aria-label="Upload profile picture"
                      icon={<Upload size={16} />}
                      size="sm"
                      colorScheme="primary"
                      position="absolute"
                      bottom="0"
                      right="0"
                      borderRadius="full"
                      onClick={() => fileInputRef.current?.click()}
                      isLoading={isUploading}
                    />
                  </Box>
                </Center>

                <Grid templateColumns="repeat(2, 1fr)" gap={4}>
                  <FormControl isInvalid={!!errors.first_name}>
                    <FormLabel fontWeight="medium">First Name</FormLabel>
                    <Input
                      {...register("first_name", {
                        required: "First name is required",
                      })}
                      placeholder="Enter first name"
                    />
                    <FormErrorMessage>
                      {errors.first_name?.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.last_name}>
                    <FormLabel fontWeight="medium">Last Name</FormLabel>
                    <Input
                      {...register("last_name", {
                        required: "Last name is required",
                      })}
                      placeholder="Enter last name"
                    />
                    <FormErrorMessage>
                      {errors.last_name?.message}
                    </FormErrorMessage>
                  </FormControl>
                </Grid>

                <FormControl isInvalid={!!errors.email}>
                  <FormLabel fontWeight="medium">Email</FormLabel>
                  <Input
                    type="email"
                    {...register("email", {
                      required: "Email is required",
                      pattern: {
                        value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                        message: "Invalid email address",
                      },
                    })}
                    placeholder="Enter email address"
                  />
                  <FormErrorMessage>{errors.email?.message}</FormErrorMessage>
                </FormControl>

                <FormControl isInvalid={!!errors.phone_number}>
                  <FormLabel fontWeight="medium">Phone Number</FormLabel>
                  <Input
                    {...register("phone_number", {
                      pattern: {
                        value: /^[0-9+\-\s()]*$/,
                        message: "Invalid phone number",
                      },
                    })}
                    placeholder="Enter phone number"
                  />
                  <FormErrorMessage>
                    {errors.phone_number?.message}
                  </FormErrorMessage>
                </FormControl>

                <FormControl isInvalid={!!errors.company_role}>
                  <FormLabel fontWeight="medium">Company Role</FormLabel>
                  <Input
                    {...register("company_role")}
                    placeholder="Enter your role in the company"
                  />
                  <FormErrorMessage>
                    {errors.company_role?.message}
                  </FormErrorMessage>
                </FormControl>
              </VStack>
            </form>
          </ModalBody>
          <ModalFooter borderTop="1px" borderColor="gray.200" pt={4}>
            <Button variant="ghost" mr={3} onClick={onClose}>
              Cancel
            </Button>
            <Button
              colorScheme="primary"
              type="submit"
              form="edit-profile-form"
              isLoading={isUpdating}
              loadingText="Saving..."
              isDisabled={!isDirty}
            >
              Save Changes
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </div>
  );
};

export default EditProfile;
