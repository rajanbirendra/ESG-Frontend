import { useState, useRef, useMemo, useCallback } from "react";
import {
  Popover,
  PopoverTrigger,
  Button,
  PopoverContent,
  PopoverArrow,
  PopoverCloseButton,
  PopoverBody,
  VStack,
  Text,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  FormControl,
  FormLabel,
  Box,
  Input,
  InputGroup,
  InputLeftElement,
} from "@chakra-ui/react";
import CountryStateDropdown from "@/ui/molecules/dropdown/CountryStateDropdown";
import CountryDropdown from "@/ui/molecules/dropdown/CountryDropdown";
import { Download, ChevronDown, Search } from "lucide-react";
import { useToast } from "@chakra-ui/react";
import { useMiscAPI } from "@/query/use-misc";

const SearchableSelect = ({
  label,
  value,
  options,
  onChange,
  isLoading,
  isDisabled,
}: {
  label: string;
  value: string;
  options: string[];
  onChange: (value: string) => void;
  isLoading?: boolean;
  isDisabled?: boolean;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  const filteredOptions = useMemo(() => {
    if (!options) return [];
    return options.filter((option) =>
      option.toString().toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [options, searchTerm]);

  const handleSelect = useCallback(
    (selectedValue: string) => {
      onChange(selectedValue);
      setIsOpen(false);
      setSearchTerm("");
    },
    [onChange]
  );

  return (
    <FormControl isRequired>
      <FormLabel fontWeight="medium" fontSize="sm">
        {label}
      </FormLabel>
      <Box position="relative">
        <Button
          ref={buttonRef}
          w="100%"
          h="40px"
          variant="filled"
          bg="white"
          borderWidth="1px"
          borderColor="gray.200"
          _hover={{ borderColor: "blue.500" }}
          _focus={{
            borderColor: "blue.500",
            boxShadow: "0 0 0 1px blue.500",
          }}
          fontWeight="normal"
          onClick={() => setIsOpen(!isOpen)}
          justifyContent="space-between"
          px={4}
          isDisabled={isDisabled || isLoading}
        >
          <Text isTruncated>{value || "Select an option"}</Text>
          <ChevronDown size={20} />
        </Button>
        {isOpen && (
          <Box
            position="absolute"
            top="100%"
            left={0}
            right={0}
            zIndex={1000}
            mt={1}
            bg="white"
            borderRadius="md"
            boxShadow="lg"
            borderWidth="1px"
            borderColor="gray.200"
            maxH="300px"
            overflow="hidden"
          >
            <VStack align="stretch" spacing={0}>
              <Box p={2} borderBottomWidth="1px">
                <InputGroup>
                  <InputLeftElement pointerEvents="none">
                    <Search size={16} />
                  </InputLeftElement>
                  <Input
                    ref={inputRef}
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    size="sm"
                    autoFocus
                  />
                </InputGroup>
              </Box>
              <VStack align="stretch" maxH="250px" overflowY="auto">
                {isLoading ? (
                  <Text p={4} textAlign="center" color="gray.500">
                    Loading...
                  </Text>
                ) : filteredOptions?.length === 0 ? (
                  <Text p={4} textAlign="center" color="gray.500">
                    No options found
                  </Text>
                ) : (
                  filteredOptions?.map((option, index) => (
                    <Button
                      key={`${option}_${index}`}
                      variant="ghost"
                      justifyContent="flex-start"
                      px={4}
                      py={2}
                      h="auto"
                      whiteSpace="normal"
                      textAlign="left"
                      onClick={() => handleSelect(option)}
                      bg={value === option ? "blue.50" : "transparent"}
                      _hover={{ bg: "blue.50" }}
                    >
                      {option}
                    </Button>
                  ))
                )}
              </VStack>
            </VStack>
          </Box>
        )}
      </Box>
    </FormControl>
  );
};

const DownloadTemplate = () => {
  const [downloadCountry, setDownloadCountry] = useState<string | null>("");
  const [downloadState, setDownloadState] = useState<string | null>("");
  const toast = useToast();
  const [selectedType, setSelectedType] = useState<string>("");
  const [selectedTypeId, setSelectedTypeId] = useState<string>("");
  const [downloadCountry2, setDownloadCountry2] = useState<string | null>("");

  const { getTypeList, getAllTypes } = useMiscAPI();

  const { data: allTypes, isLoading: isLoadingAllTypes } = getAllTypes;
  const { data: typeList, isLoading: isLoadingTypeList } =
    getTypeList(selectedType);

  const clearTemplate2Fields = () => {
    setSelectedType("");
    setSelectedTypeId("");
    setDownloadCountry2("");
  };

  const handleDownloadTemplate = (templateNumber: number) => {
    const queryParams = new URLSearchParams();

    if (templateNumber === 1) {
      if (downloadCountry) queryParams.append("country", downloadCountry);
      if (downloadState) queryParams.append("state", downloadState);
    } else if (templateNumber === 2) {
      if (downloadCountry2) queryParams.append("country", downloadCountry2);
      if (selectedTypeId) queryParams.append("category_name", selectedTypeId);
      if (selectedType) queryParams.append("category", selectedType);
    }

    const link = document.createElement("a");
    link.href = `${
      process.env.NEXT_PUBLIC_API_URL ?? "https://backend.paudyals.com/api"
    }/ef/download-template/${templateNumber}?${queryParams.toString()}`;
    link.download = `emission_factors_template_${templateNumber}.xlsx`;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    if (templateNumber === 1) {
      setDownloadCountry("");
      setDownloadState("");
    } else {
      clearTemplate2Fields();
    }

    toast({
      title: "Download Started",
      description: "Template download has started",
      status: "info",
      duration: 3000,
      isClosable: true,
    });
  };

  const handleDownloadCountryChange = (newCountry: string) => {
    setDownloadCountry(newCountry);
    setDownloadState("");
  };

  const handleDownloadCountryChange2 = (newCountry: string) => {
    setDownloadCountry2(newCountry);
  };

  return (
    <Popover
      placement="bottom-end"
      onClose={() => {
        setDownloadCountry("");
        setDownloadState("");
        clearTemplate2Fields();
      }}
    >
      <PopoverTrigger>
        <Button
          size="sm"
          variant="outline"
          leftIcon={<Download className="h-4 w-4" />}
        >
          Download Template
        </Button>
      </PopoverTrigger>
      <PopoverContent width="500px">
        <PopoverArrow />
        <PopoverCloseButton />
        <PopoverBody p={4}>
          <Tabs isFitted variant="enclosed">
            <TabList mb="1em">
              <Tab>Template 1</Tab>
              <Tab>Template 2</Tab>
            </TabList>
            <TabPanels>
              <TabPanel>
                <VStack spacing={4} align="stretch">
                  <Text fontWeight="medium" fontSize="sm" color={"gray.600"}>
                    Select Country and State for downloading customized
                    Template.
                  </Text>
                  <CountryStateDropdown
                    selectedCountry={downloadCountry || ""}
                    selectedState={downloadState || ""}
                    onCountryChange={handleDownloadCountryChange}
                    onStateChange={setDownloadState}
                  />
                  <Button
                    size="sm"
                    colorScheme="blue"
                    leftIcon={<Download size={16} />}
                    onClick={() => handleDownloadTemplate(1)}
                    disabled={!downloadCountry}
                  >
                    Download
                  </Button>
                </VStack>
              </TabPanel>
              <TabPanel>
                <VStack spacing={4} align="stretch">
                  <SearchableSelect
                    label="Select Type"
                    value={selectedType}
                    options={(allTypes as any)?.data || []}
                    onChange={(value) => {
                      setSelectedType(value);
                      setSelectedTypeId("");
                    }}
                    isLoading={isLoadingAllTypes}
                  />

                  <SearchableSelect
                    label="Select Type List"
                    value={selectedTypeId}
                    options={(typeList as any)?.data || []}
                    onChange={setSelectedTypeId}
                    isLoading={isLoadingTypeList}
                    isDisabled={!selectedType}
                  />

                  <CountryDropdown
                    selectedCountry={downloadCountry2 || ""}
                    onCountryChange={handleDownloadCountryChange2}
                  />

                  <Button
                    size="sm"
                    colorScheme="blue"
                    leftIcon={<Download size={16} />}
                    onClick={() => handleDownloadTemplate(2)}
                    disabled={!selectedTypeId}
                  >
                    Download Template 2
                  </Button>
                </VStack>
              </TabPanel>
            </TabPanels>
          </Tabs>
        </PopoverBody>
      </PopoverContent>
    </Popover>
  );
};

export default DownloadTemplate;
