import { useEFAPI } from "@/query/use-ef";
import {
  Button,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  Input,
  Modal,
  ModalBody,
  ModalCloseButton,
  ModalContent,
  ModalFooter,
  ModalHeader,
  ModalOverlay,
  useToast,
} from "@chakra-ui/react";
import { useEffect, useState } from "react";
import CountryStateDropdown from "@/ui/molecules/dropdown/CountryStateDropdown";

interface EditEFModalProps {
  selectedItem: any;
  isEditOpen: boolean;
  onEditClose: () => void;
}

const EditEFModal = ({
  selectedItem,
  isEditOpen,
  onEditClose,
}: EditEFModalProps) => {
  const [editForm, setEditForm] = useState({
    country: "",
    state: "",
    category_name: "",
    name: "",
    ef_value: "",
  });

  console.log("selectedItem", selectedItem);
  const toast = useToast();

  const { mutate: updateEmissionFactor, isPending: isUpdating } =
    useEFAPI().updateEmissionFactor;

  // Check if any field has been changed
  const hasChanges = () => {
    if (!selectedItem) return false;
    return (
      editForm.country !== selectedItem.country ||
      editForm.state !== selectedItem.state ||
      editForm.category_name !== selectedItem.category_name ||
      editForm.name !== selectedItem.name ||
      editForm.ef_value !== selectedItem.emission_factor
    );
  };

  // Update form when selectedItem changes
  useEffect(() => {
    if (selectedItem) {
      setEditForm({
        country: selectedItem?.country || "",
        state: selectedItem?.state || "",
        category_name: selectedItem?.category || "",
        name: selectedItem?.name || "",
        ef_value: selectedItem?.emission_factor || "",
      });
    }
  }, [selectedItem]);

  const handleUpdate = () => {
    if (!selectedItem) return;

    updateEmissionFactor(
      // @ts-ignore
      {
        path: {
          id: selectedItem.id,
        },
        // @ts-ignore
        body: editForm,
      },
      {
        onSuccess: () => {
          onEditClose();
        },
      }
    );
  };

  console.log("editForm", editForm);
  console.log("category name", editForm.category_name);
  return (
    <Modal isOpen={isEditOpen} onClose={onEditClose} size="xl">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Edit Emission Factor</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <Grid templateColumns="repeat(2, 1fr)" gap={4}>
            <GridItem colSpan={2}>
              <CountryStateDropdown
                selectedCountry={editForm.country}
                selectedState={editForm.state}
                onCountryChange={(country) =>
                  setEditForm({ ...editForm, country, state: "" })
                }
                onStateChange={(state) => setEditForm({ ...editForm, state })}
              />
            </GridItem>
            <GridItem>
              <FormControl>
                <FormLabel>Category</FormLabel>
                <Input
                  value={editForm.category_name}
                  onChange={(e) =>
                    setEditForm({ ...editForm, category_name: e.target.value })
                  }
                />
              </FormControl>
            </GridItem>
            <GridItem>
              <FormControl>
                <FormLabel>Name</FormLabel>
                <Input
                  value={editForm.name}
                  onChange={(e) =>
                    setEditForm({ ...editForm, name: e.target.value })
                  }
                />
              </FormControl>
            </GridItem>
            <GridItem colSpan={2}>
              <FormControl>
                <FormLabel>Emission Factor</FormLabel>
                <Input
                  type="number"
                  value={editForm.ef_value}
                  onKeyDown={(e) => {
                    if (e.key === "-" || e.key === "e" || e.key == "+") {
                      e.preventDefault();
                    }
                  }}
                  onChange={(e) =>
                    setEditForm({
                      ...editForm,
                      ef_value: e.target.value,
                    })
                  }
                />
              </FormControl>
            </GridItem>
          </Grid>
        </ModalBody>
        <ModalFooter>
          <Button variant="ghost" mr={3} onClick={onEditClose}>
            Cancel
          </Button>
          <Button
            colorScheme="blue"
            onClick={handleUpdate}
            isLoading={isUpdating}
            isDisabled={!hasChanges()}
          >
            Update
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default EditEFModal;
