import React from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  Button,
  Select,
  Text,
} from "@chakra-ui/react";
import { Lock } from "lucide-react";
import { useAdminAPI } from "@/query/use-admin";

const EditUser = ({ isOpen, onClose, user }) => {
  const [plan, setPlan] = React.useState(user?.plan_type || "FREE");
  const updateUserPlanMutation = useAdminAPI().updateUserPlan;
  const handleUpdate = () => {
    // TODO: Call API to update user plan

    updateUserPlanMutation.mutate(
      // @ts-ignore
      {
        body: {
          user_id: user.id,
          plan_type: plan,
        },
      }
    );
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>
          <Lock style={{ marginRight: 8 }} /> Update User Plan
        </ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <Text mb={2} fontWeight="medium">
            User: {user?.first_name} {user?.last_name}
          </Text>
          <Select value={plan} onChange={(e) => setPlan(e.target.value)}>
            <option value="FREE">FREE</option>
            <option value="SUBSCRIBED">SUBSCRIBED</option>
          </Select>
        </ModalBody>
        <ModalFooter>
          <Button onClick={onClose} mr={3} variant="ghost">
            Cancel
          </Button>
          <Button colorScheme="blue" onClick={handleUpdate}>
            Update
          </Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default EditUser;
