import React, { useState } from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  Text,
  Box,
  VStack,
  HStack,
  Badge,
  Divider,
  Input,
  FormControl,
  FormLabel,
  FormHelperText,
  useToast,
  Flex,
  IconButton,
  Tooltip,
  Image,
  Icon,
} from "@chakra-ui/react";
import {
  Upload,
  X,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  Search,
  Trash2,
} from "lucide-react";
import { useMediaAPI } from "@/query/use-media";
import { useUpdateReport } from "@/query/use-report";

interface ReportCreator {
  id: string;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
}

interface ReportStatus {
  status: string;
  date: string;
  remarks?: string;
}

interface ReportItem {
  id: string;
  type: string;
  starting_year_month: string;
  ending_year_month: string;
  legal_company_name: string;
  cin_number: string;
  report_person_name: string;
  status: ReportStatus[];
  file: string | null;
  created_by: string;
  company_id: string;
  created_at: string;
  updated_at: string;
  creator?: ReportCreator;
}

interface ViewActionDialogProps {
  isOpen: boolean;
  onClose: () => void;
  report: ReportItem | null;
  onFileUpload?: (file: File) => void;
}

const ViewActionDialog: React.FC<ViewActionDialogProps> = ({
  isOpen,
  onClose,
  report,
  onFileUpload,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const [uploadedFileData, setUploadedFileData] = useState<{
    file_key: string;
    url: string;
    media_type: string;
  } | null>(null);
  const [isUpdatingReport, setIsUpdatingReport] = useState(false);
  const [isReplacingFile, setIsReplacingFile] = useState(false);
  const toast = useToast();
  const { mutate: uploadMedia, isPending: isUploadingMedia } =
    useMediaAPI().upload;
  const { mutate: updateReport, isPending: isUpdatingReportMutation } =
    useUpdateReport();

  // Helper to format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Helper to format period display
  const formatPeriod = (startPeriod: string, endPeriod: string) => {
    const startYear = startPeriod.split("-")[0];
    const startMonth = startPeriod.split("-")[1];
    const endYear = endPeriod.split("-")[0];
    const endMonth = endPeriod.split("-")[1];

    const monthNames = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December",
    ];

    const startMonthName = monthNames[parseInt(startMonth) - 1];
    const endMonthName = monthNames[parseInt(endMonth) - 1];

    if (startYear === endYear) {
      return `${startMonthName} - ${endMonthName} ${startYear}`;
    } else {
      return `${startMonthName} ${startYear} - ${endMonthName} ${endYear}`;
    }
  };

  // Helper to get status icon and color
  const getStatusInfo = (status: string) => {
    switch (status) {
      case "APPROVED":
        return {
          icon: CheckCircle,
          color: "success.500",
          bg: "success.50",
          textColor: "success.700",
        };
      case "REJECTED":
        return {
          icon: XCircle,
          color: "error.500",
          bg: "error.50",
          textColor: "error.700",
        };
      case "REQUESTED":
        return {
          icon: Clock,
          color: "warning.500",
          bg: "warning.50",
          textColor: "warning.700",
        };
      default:
        return {
          icon: Clock,
          color: "gray.500",
          bg: "gray.50",
          textColor: "gray.700",
        };
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type (PDF, DOC, DOCX, XLS, XLSX)
      const allowedTypes = [
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/vnd.ms-excel",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      ];

      if (!allowedTypes.includes(file.type)) {
        toast({
          title: "Invalid file type",
          description: "Please upload a PDF, Word, or Excel file.",
          status: "error",
          duration: 3000,
          isClosable: true,
        });
        return;
      }

      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please upload a file smaller than 10MB.",
          status: "error",
          duration: 3000,
          isClosable: true,
        });
        return;
      }

      setSelectedFile(file);

      // Create preview for image files
      if (file.type.startsWith("image/")) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setFilePreview(e.target?.result as string);
        };
        reader.readAsDataURL(file);
      } else {
        setFilePreview(null);
      }

      // Upload file immediately
      setIsUploading(true);
      uploadMedia(
        {
          body: {
            file: file,
            media_type: "REPORT_FILE",
          },
        },
        {
          onSuccess: (data: any) => {
            toast({
              title: "File uploaded successfully",
              description: "The report file has been uploaded.",
              status: "success",
              duration: 3000,
              isClosable: true,
            });
            setIsUploading(false);
            // Store the uploaded file data for updating the report
            setUploadedFileData({
              file_key: data?.data?.file_key,
              url: data?.data?.url,
              media_type: data?.data?.media_type,
            });
            console.log("Uploaded file key:", data?.data?.file_key);
          },
          onError: (err: any) => {
            toast({
              title: "Upload failed",
              description:
                err?.message ||
                "There was an error uploading the file. Please try again.",
              status: "error",
              duration: 3000,
              isClosable: true,
            });
            setIsUploading(false);
            setSelectedFile(null);
            setFilePreview(null);
          },
        }
      );
    }
  };

  const clearSelectedFile = () => {
    setSelectedFile(null);
    setFilePreview(null);
    setUploadedFileData(null);
    setIsReplacingFile(false);
  };

  const handleReplaceFile = () => {
    setIsReplacingFile(true);
  };

  const handleUpdateReport = () => {
    if (!uploadedFileData || !report) {
      toast({
        title: "No file uploaded",
        description: "Please upload a file first before updating the report.",
        status: "warning",
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    setIsUpdatingReport(true);
    updateReport(
      {
        path: {
          report_id: report.id,
        },
        body: {
          file: uploadedFileData.file_key,
        },
        headers: {
          authorization: "",
        },
      },
      {
        onSuccess: () => {
          toast({
            title: "Report updated successfully",
            description: "The report has been updated with the uploaded file.",
            status: "success",
            duration: 3000,
            isClosable: true,
          });
          setIsUpdatingReport(false);
          onClose();
        },
        onError: (err: any) => {
          toast({
            title: "Update failed",
            description:
              err?.message ||
              "There was an error updating the report. Please try again.",
            status: "error",
            duration: 3000,
            isClosable: true,
          });
          setIsUpdatingReport(false);
        },
      }
    );
  };

  if (!report) return null;

  const latestStatus = report.status?.[report.status.length - 1] || {};
  const statusInfo = getStatusInfo(latestStatus.status);
  const StatusIcon = statusInfo.icon;

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl" isCentered>
      <ModalOverlay />
      <ModalContent borderRadius="xl" maxW="600px">
        <ModalHeader
          bg="primary.50"
          borderTopRadius="xl"
          borderBottom="1px solid"
          borderColor="gray.200"
        >
          <Flex justify="space-between" align="center">
            <Text color="primary.700" fontWeight="bold">
              Report Details
            </Text>
            <ModalCloseButton position="static" />
          </Flex>
        </ModalHeader>

        <ModalBody py={6}>
          <VStack spacing={6} align="stretch">
            {/* Report Basic Info */}
            <Box>
              <Text fontSize="lg" fontWeight="semibold" color="gray.700" mb={4}>
                Report Information
              </Text>
              <VStack spacing={3} align="stretch">
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Framework:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {report.type}
                  </Text>
                </HStack>
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Period:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {formatPeriod(
                      report.starting_year_month,
                      report.ending_year_month
                    )}
                  </Text>
                </HStack>
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Company Name:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {report.legal_company_name || "N/A"}
                  </Text>
                </HStack>
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    CIN Number:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {report.cin_number || "N/A"}
                  </Text>
                </HStack>
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Report Person:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {report.report_person_name || "N/A"}
                  </Text>
                </HStack>
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Status:
                  </Text>
                  <HStack spacing={2}>
                    <StatusIcon size={16} color={statusInfo.color} />
                    <Badge
                      px={3}
                      py={1}
                      borderRadius="md"
                      bg={statusInfo.bg}
                      color={statusInfo.textColor}
                      fontWeight="semibold"
                      fontSize="sm"
                    >
                      {latestStatus.status || "PENDING"}
                    </Badge>
                  </HStack>
                </HStack>
                {latestStatus.remarks && (
                  <HStack justify="space-between" align="flex-start">
                    <Text color="gray.600" fontWeight="medium">
                      Remarks:
                    </Text>
                    <Text color="gray.800" maxW="300px" textAlign="right">
                      {latestStatus.remarks}
                    </Text>
                  </HStack>
                )}
              </VStack>
            </Box>

            <Divider />

            {/* Requester Info */}
            <Box>
              <Text fontSize="lg" fontWeight="semibold" color="gray.700" mb={4}>
                Requester Information
              </Text>
              <VStack spacing={3} align="stretch">
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Name:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {report.creator
                      ? `${report.creator.first_name} ${report.creator.last_name}`
                      : "N/A"}
                  </Text>
                </HStack>
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Email:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {report.creator?.email || "N/A"}
                  </Text>
                </HStack>
                <HStack justify="space-between">
                  <Text color="gray.600" fontWeight="medium">
                    Requested At:
                  </Text>
                  <Text color="gray.800" fontWeight="semibold">
                    {formatDate(report.created_at)}
                  </Text>
                </HStack>
              </VStack>
            </Box>

            <Divider />

            {/* File Upload Section */}
            <Box>
              <Text fontSize="lg" fontWeight="semibold" color="gray.700" mb={4}>
                Upload Report File
              </Text>

              {report.file && !isReplacingFile ? (
                <Box
                  p={4}
                  bg="success.50"
                  borderRadius="lg"
                  border="1px solid"
                  borderColor="success.200"
                >
                  <HStack justify="space-between">
                    <HStack spacing={3}>
                      <FileText size={20} color="#38A169" />
                      <Text color="success.700" fontWeight="medium">
                        Report file already uploaded
                      </Text>
                    </HStack>
                      <Tooltip label="Replace file">
                        <IconButton
                          aria-label="Replace file"
                          icon={<Upload size={16} />}
                          size="sm"
                          variant="ghost"
                          colorScheme="blue"
                          onClick={handleReplaceFile}
                        />
                      </Tooltip>
                  </HStack>
                </Box>
              ) : (
                <VStack spacing={4} align="stretch">
                  {selectedFile ? (
                    <Box
                      p={4}
                      bg="primary.50"
                      borderRadius="lg"
                      border="1px solid"
                      borderColor="primary.200"
                    >
                      <HStack justify="space-between">
                        <HStack spacing={3}>
                          <FileText size={20} color="#1976d2" />
                          <VStack spacing={1} align="flex-start">
                            <Text color="primary.700" fontWeight="medium">
                              {selectedFile.name}
                            </Text>
                            <Text color="primary.600" fontSize="sm">
                              {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                            </Text>
                            {isUploading && (
                              <Text color="primary.600" fontSize="sm">
                                Uploading...
                              </Text>
                            )}
                          </VStack>
                        </HStack>
                        {!isUploading && (
                          <Tooltip label="Remove file">
                            <IconButton
                              aria-label="Remove file"
                              icon={<X size={16} />}
                              size="sm"
                              variant="ghost"
                              colorScheme="primary"
                              onClick={clearSelectedFile}
                            />
                          </Tooltip>
                        )}
                      </HStack>
                      {isUploading && (
                        <Box
                          mt={3}
                          p={3}
                          bg="primary.25"
                          borderRadius="md"
                          border="1px solid"
                          borderColor="primary.200"
                        >
                          <HStack spacing={2}>
                            <Box
                              animation="spin 1s linear infinite"
                              color="primary.500"
                            >
                              <Icon as={CheckCircle} boxSize={4} />
                            </Box>
                            <Text
                              color="primary.700"
                              fontSize="sm"
                              fontWeight="medium"
                            >
                              Uploading file...
                            </Text>
                          </HStack>
                        </Box>
                      )}
                    </Box>
                  ) : (
                    <FormControl>
                      <Box
                        border="2px dashed"
                        borderColor="gray.300"
                        borderRadius="lg"
                        p={6}
                        textAlign="center"
                        bg="white"
                        _hover={{ borderColor: "primary.300", bg: "gray.50" }}
                        transition="all 0.2s"
                        position="relative"
                      >
                        <Input
                          type="file"
                          accept=".pdf,.doc,.docx,.xls,.xlsx"
                          onChange={handleFileSelect}
                          position="absolute"
                          top="0"
                          left="0"
                          width="100%"
                          height="100%"
                          opacity="0"
                          cursor="pointer"
                          zIndex={2}
                        />
                        <VStack spacing={3}>
                          <Icon as={FileText} boxSize={8} color="gray.400" />
                          <Text color="gray.600" fontWeight="medium">
                            Click to upload report file
                          </Text>
                          <Text color="gray.500" fontSize="sm">
                            Supported formats: PDF, Word (.doc, .docx), Excel
                            (.xls, .xlsx)
                          </Text>
                          <Text color="gray.400" fontSize="xs">
                            Max size: 10MB
                          </Text>
                        </VStack>
                      </Box>
                    </FormControl>
                  )}
                </VStack>
              )}
            </Box>
          </VStack>
        </ModalBody>

        <ModalFooter
          bg="gray.50"
          borderBottomRadius="xl"
          borderTop="1px solid"
          borderColor="gray.200"
        >
          <HStack spacing={3}>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            {uploadedFileData && (
              <Button
                colorScheme="primary"
                onClick={handleUpdateReport}
                isLoading={isUpdatingReport || isUpdatingReportMutation}
                loadingText="Updating Report"
              >
                Replace File
              </Button>
            )}
          </HStack>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default ViewActionDialog;
