"use client";
import React, { useState, useEffect } from "react";
import {
  Box,
  Flex,
  Image,
  Text,
  Button,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  useDisclosure,
  useToast,
  VStack,
  Tooltip,
  Heading,
  Icon,
  IconButton,
  Drawer,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  DrawerBody,
  Skeleton,
  HStack,
  useColorModeValue,
  Divider,
  Badge,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  MenuDivider,
} from "@chakra-ui/react";
import { ChevronDownIcon, ChevronLeftIcon } from "@chakra-ui/icons";
import {
  LogOut,
  ArrowLeft,
  Menu as MenuIcon,
  X,
  CircleArrowLeftIcon,
  Lock,
  ChevronDown,
  ChevronRight,
  Bell,
  LucideUser,
  LucideUser2,
  LucideGitBranch,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import { userMenuList } from "../molecules/userMenuList";
import { Roles } from "@/types/index.types";
import {
  useNotificationsList,
  useUnreadCount,
  useMarkAllAsRead,
} from "@/query/use-notification";
import Loader from "../molecules/Loader";
import Notification from "../organisms/dashboard/Notification";
import { getParsedToken } from "@/utils/withAuth";

/** Utility to get initials from first + last name. */
function getInitials(firstName, lastName) {
  const f = firstName?.charAt(0).toUpperCase() || "";
  const l = lastName?.charAt(0).toUpperCase() || "";
  return f + l;
}

export default function Layout({
  children,
  isLoading = false,
  headerTitle = "",
  subHeaderTitle = <></>,
  backButtonURL = null,
  activePage = null,
}: {
  children: React.ReactNode;
  isLoading?: boolean;
  headerTitle?: string;
  subHeaderTitle?: React.ReactNode | null;
  backButtonURL?: string | null;
  activePage?: string | null;
}) {
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const toast = useToast();
  const [isMounted, setIsMounted] = useState(false);
  const [userRole, setUserRole] = useState<Roles | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const {
    isOpen: isMobileDrawerOpen,
    onOpen: onMobileDrawerOpen,
    onClose: onMobileDrawerClose,
  } = useDisclosure();

  // Handle localStorage after mount
  useEffect(() => {
    setIsMounted(true);
    const savedState = localStorage.getItem("sidebarOpen");
    if (savedState) {
      setIsSidebarOpen(JSON.parse(savedState));
    }
  }, []);

  // Update localStorage when sidebar state changes
  useEffect(() => {
    if (isMounted) {
      localStorage.setItem("sidebarOpen", JSON.stringify(isSidebarOpen));
    }
  }, [isSidebarOpen, isMounted]);

  // Check for token and redirect if not present
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      router.push("/");
    }
  }, [router]);

  // Modals
  const {
    isOpen: isSignOutOpen,
    onOpen: onSignOutOpen,
    onClose: onSignOutClose,
  } = useDisclosure();

  const {
    isOpen: isSubscriptionOpen,
    onOpen: onSubscriptionOpen,
    onClose: onSubscriptionClose,
  } = useDisclosure();

  const {
    isOpen: isNotificationsOpen,
    onOpen: onNotificationsOpen,
    onClose: onNotificationsClose,
  } = useDisclosure();

  const [user, setUser] = useState<any>(null);

  // Get user data from parsed token instead of API call
  useEffect(() => {
    const parsedToken = getParsedToken();
    if (parsedToken) {
      console.log("parsedToken", parsedToken);
      setUser(parsedToken);
    }
  }, []);

  const userDropdownMenu = [
    {
      title: "Profile",
      icon: <LucideUser className="h-4 w-4" />,
      route: "/dashboard/profile",
      role: [Roles.USER, Roles.SUB_USER],
      planType: "all",
    },
    {
      title: "Sub Users",
      icon: <LucideUser2 className="h-4 w-4" />,
      route: "/dashboard/sub-users",
      role: [Roles.USER],
      planType: "SUBSCRIBED",
    },
    {
      title: "Manage Branches",
      icon: <LucideGitBranch className="h-4 w-4" />,
      route: "/dashboard/manage-branches",
      role: [Roles.USER],
      planType: "SUBSCRIBED",
    },
    {
      title: "Change Password",
      icon: <Lock className="h-4 w-4" />,
      route: "/dashboard/change-password",
      role: [Roles.USER, Roles.SUB_USER],
      planType: "all",
    },
  ];



  // Fetch notifications for USER role only
  const { data: notificationsData, isLoading: isLoadingNotifications } =
    useNotificationsList({
      headers: { authorization: "" },
      query: {
        page: 1,
        limit: 10,
      },
    });

  // Fetch unread count for USER role only
  const { data: unreadCountData } = useUnreadCount({
    headers: { authorization: "" },
  });

  const notifications = notificationsData as any;
  const unreadCount = unreadCountData as any;

  // Mark all as read mutation
  const { mutate: markAllAsRead, isPending: isMarkingAllAsRead } =
    useMarkAllAsRead();

  const handleSignOut = () => {
    localStorage.removeItem("token");
    router.push("/");
  };

  const handleLockedItemClick = (e: React.MouseEvent, itemTitle: string) => {
    e.preventDefault();
    onSubscriptionOpen();
  };

  const handleMarkAllAsRead = () => {
    markAllAsRead(
      {
        headers: { authorization: "" },
      },
      {
        onSuccess: () => {
          // Refetch notifications and unread count to update the UI
          // The query client will automatically refetch the data
        },
        onError: (err: any) => {
          console.error("Failed to mark all notifications as read:", err);
        },
      }
    );
  };

  // Language switcher
  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng);
    toast({
      title: t("Language switched to {{lng}}", { lng }),
      status: "info",
      duration: 2000,
      isClosable: true,
    });
  };

  // Load user role on mount
  useEffect(() => {
    setIsMounted(true);

    const token = localStorage.getItem("token");
    if (token) {
      try {
        const parsedToken = JSON.parse(atob(token.split(".")[1]));
        if (parsedToken?.role) {
          setUserRole(parsedToken.role as Roles);
        }
      } catch (error) {
        console.error("Error parsing token:", error);
      }
    }
  }, []);

  const handleSidebarToggle = () => {
    if (window.innerWidth < 768) {
      setIsMobileMenuOpen(!isMobileMenuOpen);
      onMobileDrawerOpen();
    } else {
      setIsTransitioning(true);
      setIsSidebarOpen(!isSidebarOpen);
      setTimeout(() => {
        setIsTransitioning(false);
      }, 300);
    }
  };

  // Check if current route matches any settings route to keep submenu open
  const currentPath = router.asPath;

  const SidebarContent = () => {
    return (
      <>
        <Flex align="center" mb={8} justify="space-between">
          {isMounted && isSidebarOpen ? (
            <Flex align="center" justify="space-between" w="100%">
              <Flex align="center">
                <Image
                  src="/logo.webp"
                  boxSize="40px"
                  mr={3}
                  transition="all 0.3s ease"
                  _hover={{
                    transform: "scale(1.1)",
                  }}
                />
                <Heading
                  size="md"
                  fontWeight="bold"
                  bgGradient="linear(to-r, blue.500, blue.600)"
                  bgClip="text"
                >
                  Cleaffo
                </Heading>
              </Flex>
            </Flex>
          ) : (
            <Flex justify="center" w="100%">
              <Image
                src="/logo.webp"
                boxSize="40px"
                transition="all 0.3s ease"
                _hover={{
                  transform: "scale(1.1)",
                }}
              />
            </Flex>
          )}
        </Flex>

        {/* Toggle Button - Fixed Position */}
        <Box
          position="absolute"
          right="-20px"
          bottom="100px"
          zIndex="1001"
          display={{ base: "none", md: "flex" }}
          alignItems="center"
          justifyContent="center"
        >
          <IconButton
            aria-label="Toggle sidebar"
            icon={isSidebarOpen ? <CircleArrowLeftIcon /> : <MenuIcon />}
            variant="solid"
            size="sm"
            onClick={handleSidebarToggle}
            bg="white"
            color="gray.600"
            _hover={{
              bg: "blue.50",
              color: "blue.500",
              transform: "scale(1.1)",
            }}
            boxShadow="lg"
            borderRadius="full"
            w="32px"
            h="32px"
            minW="32px"
            p={0}
            border="1px"
            borderColor="gray.100"
            transition="all 0.2s ease"
          />
        </Box>

        {/* Content Container with Overflow */}
        <Box
          flex="1"
          overflowY="auto"
          overflowX="hidden"
          pr={2}
          css={{
            "&::-webkit-scrollbar": {
              width: "4px",
            },
            "&::-webkit-scrollbar-track": {
              width: "6px",
            },
            "&::-webkit-scrollbar-thumb": {
              background: "var(--chakra-colors-gray-200)",
              borderRadius: "24px",
            },
          }}
        >
          {isMounted &&
            userMenuList.map(({ title, icon, route, role, planType }) => {
              const active = route === activePage;
              const hasRole = !role || (userRole && role.includes(userRole));
              const isLocked =
                planType === "SUBSCRIBED" && user?.plan_type === "FREE";
              const canAccess =
                planType === "all" || user?.plan_type === "SUBSCRIBED";

              return hasRole ? (
                <Box key={route}>
                  {canAccess ? (
                    <Link href={route}>
                      <Flex
                        align="center"
                        mb={3}
                        p={3}
                        borderRadius="lg"
                        bg={active ? "blue.50" : "transparent"}
                        _hover={{
                          bg: active ? "blue.50" : "gray.50",
                          transform: "translateX(4px)",
                        }}
                        cursor={active ? "default" : "pointer"}
                        justify={
                          isMounted && isSidebarOpen ? "flex-start" : "center"
                        }
                        transition="all 0.2s ease"
                        position="relative"
                        _before={
                          active
                            ? {
                                content: '""',
                                position: "absolute",
                                left: 0,
                                top: 0,
                                bottom: 0,
                                width: "4px",
                                bg: "blue.500",
                                borderRadius: "0 4px 4px 0",
                                transition: "all 0.2s ease",
                              }
                            : {}
                        }
                      >
                        <Box
                          color={active ? "blue.500" : "gray.600"}
                          transition="all 0.2s ease"
                        >
                          {icon}
                        </Box>
                        {isMounted && isSidebarOpen && (
                          <Text
                            fontWeight="medium"
                            ml={3}
                            color={active ? "blue.500" : "gray.600"}
                            fontSize="sm"
                            transition="all 0.2s ease"
                          >
                            {title}
                          </Text>
                        )}
                      </Flex>
                    </Link>
                  ) : (
                    <Flex
                      align="center"
                      mb={3}
                      p={3}
                      borderRadius="lg"
                      bg="gray.50"
                      _hover={{
                        bg: "gray.100",
                        cursor: "pointer",
                        transform: "translateX(4px)",
                      }}
                      onClick={(e) =>
                        handleLockedItemClick(
                          e,
                          typeof title === "string" ? title : "Menu Item"
                        )
                      }
                      justify={
                        isMounted && isSidebarOpen ? "flex-start" : "center"
                      }
                      transition="all 0.2s ease"
                      position="relative"
                      opacity={0.6}
                    >
                      <Box color="gray.400" transition="all 0.2s ease">
                        {icon}
                      </Box>
                      {isMounted && isSidebarOpen && (
                        <Flex
                          align="center"
                          justify="space-between"
                          flex="1"
                          ml={3}
                        >
                          <Text
                            fontWeight="medium"
                            color="gray.400"
                            fontSize="sm"
                            transition="all 0.2s ease"
                          >
                            {title}
                          </Text>
                          <Icon as={Lock} boxSize={4} color="gray.400" />
                        </Flex>
                      )}
                    </Flex>
                  )}
                </Box>
              ) : null;
            })}
        </Box>
      </>
    );
  };

  // Show loading state when no user is available
  if (!user) {
    return (
      <Flex 
        minH="100vh" 
        bg="gray.50" 
        align="center" 
        justify="center"
        direction="column"
      >
        <Text mt={4} color="gray.600" fontSize="md">
          Loading...
        </Text>
      </Flex>
    );
  }

  return (
    <Flex minH="100vh" bg="gray.50" position="relative">
      {/* Desktop Sidebar */}
      <Box
        as="nav"
        bg="white"
        w={{
          base: "0",
          md: isMounted && isSidebarOpen ? "280px" : "80px",
        }}
        p={isMounted && isSidebarOpen ? 6 : 3}
        boxShadow="lg"
        display={{ base: "none", md: "flex" }}
        flexDirection="column"
        h="100vh"
        position="fixed"
        top="0"
        left="0"
        zIndex="1000"
        borderRight="1px"
        borderColor="gray.100"
        overflow="visible"
        _hover={{
          boxShadow: "xl",
        }}
      >
        <SidebarContent />
      </Box>

      {/* Mobile Menu Button */}
      <IconButton
        aria-label="Open menu"
        icon={<MenuIcon />}
        display={{ base: "flex", md: "none" }}
        position="fixed"
        top="4"
        left="4"
        zIndex="1002"
        onClick={onMobileDrawerOpen}
        bg="white"
        color="gray.600"
        _hover={{
          bg: "blue.50",
          color: "blue.500",
        }}
        boxShadow="lg"
        borderRadius="full"
        w="40px"
        h="40px"
      />

      {/* Mobile Drawer */}
      <Drawer
        isOpen={isMobileDrawerOpen}
        placement="left"
        onClose={onMobileDrawerClose}
        size="full"
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerBody p={0}>
            <Box
              as="nav"
              bg="white"
              w="full"
              h="100vh"
              display="flex"
              flexDirection="column"
              p={6}
            >
              <SidebarContent />
            </Box>
          </DrawerBody>
        </DrawerContent>
      </Drawer>

      {/* MAIN CONTENT */}
      <Flex
        flex="1"
        direction="column"
        ml={{ base: 0, md: isMounted && isSidebarOpen ? "280px" : "80px" }}
        transition={isTransitioning ? "margin-left 0.3s ease" : "none"}
        willChange="margin-left"
      >
        {/* HEADER */}
        <Box
          as="header"
          boxShadow="sm"
          p={6}
          borderBottom="1px"
          borderColor="gray.100"
          position="sticky"
          top={0}
          zIndex={100}
          backdropFilter="blur(8px)"
          bg="white"
          width="100%"
        >
          <Flex justify="space-between" align="center">
            <Flex align="center">
              {backButtonURL && (
                <Button
                  leftIcon={<ChevronLeftIcon boxSize={5} />}
                  variant="ghost"
                  size="sm"
                  mr={4}
                  onClick={() => router.push(backButtonURL)}
                  colorScheme="gray"
                  _hover={{
                    bg: "gray.100",
                    transform: "translateX(-2px)",
                  }}
                  _active={{
                    bg: "gray.200",
                  }}
                  transition="all 0.2s"
                  aria-label="Go back"
                  fontWeight="medium"
                  borderRadius="md"
                  px={3}
                  py={5}
                >
                  Back
                </Button>
              )}

              <VStack
                align="start"
                style={{
                  borderLeft: backButtonURL ? "1px solid #ccc" : "none",
                  paddingLeft: backButtonURL ? "15px" : "0",
                }}
                spacing={1}
                ml={backButtonURL ? 0 : 2}
              >
                <Heading
                  size="md"
                  color="gray.700"
                  fontWeight="600"
                  dangerouslySetInnerHTML={{ __html: headerTitle }}
                />
                <Text color="gray.500" fontSize="md">
                  {subHeaderTitle}
                </Text>
              </VStack>
            </Flex>

            {/* Profile Section */}
            <Flex align="center" gap={3}>
              {/* Notification Icon - Only for USER role */}
              {userRole === "USER" && (
                <Box
                  bg="white"
                  p={2}
                  borderRadius="lg"
                  border="1px"
                  borderColor="gray.200"
                  boxShadow="sm"
                  _hover={{
                    boxShadow: "md",
                    borderColor: "gray.300",
                  }}
                  transition="all 0.2s ease"
                  position="relative"
                >
                  <IconButton
                    aria-label="Notifications"
                    icon={<Bell size={20} />}
                    variant="ghost"
                    size="sm"
                    onClick={onNotificationsOpen}
                    color="gray.600"
                    _hover={{ bg: "blue.50", color: "blue.500" }}
                    h="32px"
                    w="32px"
                    position="relative"
                  />
                  {unreadCount?.unread_count > 0 && (
                    <Badge
                      position="absolute"
                      top="-2px"
                      right="-2px"
                      colorScheme="red"
                      borderRadius="full"
                      fontSize="xs"
                      minW="18px"
                      h="18px"
                      display="flex"
                      alignItems="center"
                      justifyContent="center"
                    >
                      {unreadCount.unread_count > 99
                        ? "99+"
                        : unreadCount.unread_count}
                    </Badge>
                  )}
                </Box>
              )}

              {/* Language selector */}
              {/* <Box
                bg="white"
                p={3}
                borderRadius="lg"
                border="1px"
                borderColor="gray.200"
                boxShadow="sm"
                _hover={{
                  boxShadow: "md",
                  borderColor: "gray.300",
                }}
                transition="all 0.2s ease"
              >
                <Flex align="center" gap={2} cursor="pointer">
                  <Button
                    variant="ghost"
                    size="sm"
                    leftIcon={
                      <Text fontSize="sm">
                        {i18n.language === "hi" ? "🇮🇳" : "🇺🇸"}
                      </Text>
                    }
                    onClick={() =>
                      changeLanguage(i18n.language === "hi" ? "en" : "hi")
                    }
                    _hover={{ bg: "gray.50" }}
                    h="32px"
                    px={2}
                    fontSize="xs"
                  >
                    {i18n.language === "hi" ? "हिंदी" : "EN"}
                  </Button>
                </Flex>
              </Box> */}

              <Menu>
                <MenuButton
                  as={Box}
                  cursor="pointer"
                  bg="white"
                  p={2}
                  borderRadius="lg"
                  border="1px"
                  borderColor="gray.200"
                  boxShadow="sm"
                  _hover={{
                    boxShadow: "md",
                    borderColor: "gray.300",
                  }}
                  transition="all 0.2s ease"
                >
                  <Flex align="center" gap={3}>
                    {user?.profile_picture ? (
                      <Image
                        src={user.profile_picture}
                        alt="Profile"
                        boxSize="32px"
                        borderRadius="full"
                        objectFit="cover"
                        border="2px"
                        borderColor="gray.100"
                      />
                    ) : (
                      <Box
                        boxSize="32px"
                        bg="primary.500"
                        borderRadius="full"
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                        border="2px"
                        borderColor="gray.100"
                      >
                        <Text fontWeight="bold" color="white" fontSize="xs">
                          {getInitials(user?.first_name, user?.last_name)}
                        </Text>
                      </Box>
                    )}

                    <VStack spacing={0} align="start" maxW="150px">
                      <Text
                        fontWeight="medium"
                        color="gray.700"
                        noOfLines={1}
                        fontSize="sm"
                      >
                        {user?.first_name} {user?.last_name}
                      </Text>
                      <Tooltip
                        label={user?.company?.company_name}
                        placement="bottom-start"
                      >
                        <Text
                          fontSize="xs"
                          color="gray.500"
                          isTruncated
                          noOfLines={1}
                        >
                          {user?.company?.company_name}
                        </Text>
                      </Tooltip>
                    </VStack>
                    <ChevronDownIcon w={5} h={5} color="gray.400" />
                  </Flex>
                </MenuButton>
                <MenuList
                  bg={useColorModeValue("white", "gray.800")}
                  borderRadius="lg"
                  boxShadow="xl"
                  border="1px"
                  borderColor={useColorModeValue("gray.200", "gray.700")}
                  p={2}
                  zIndex={1001}
                  minW="240px"
                >
                  {userDropdownMenu.map(
                    ({ title, icon, route, role, planType }) => {
                      const active = route === activePage;
                      const hasRole =
                        !role || (userRole && role.includes(userRole));
                      const isLocked =
                        planType === "SUBSCRIBED" && user?.plan_type === "FREE";
                      const canAccess =
                        planType === "all" || user?.plan_type === "SUBSCRIBED";

                      if (!hasRole) {
                        return null;
                      }

                      return (
                        <MenuItem
                          key={route}
                          icon={icon}
                          onClick={
                            canAccess
                              ? () => router.push(route)
                              : (e) =>
                                  handleLockedItemClick(
                                    e,
                                    typeof title === "string"
                                      ? title
                                      : "Menu Item"
                                  )
                          }
                          bg={
                            active
                              ? useColorModeValue("blue.50", "blue.900")
                              : "transparent"
                          }
                          borderRadius="md"
                          fontSize="sm"
                          _hover={{
                            bg: active
                              ? useColorModeValue("blue.50", "blue.900")
                              : useColorModeValue("gray.50", "gray.700"),
                          }}
                          opacity={isLocked ? 0.7 : 1}
                          cursor={isLocked ? "not-allowed" : "pointer"}
                          color={
                            isLocked
                              ? "gray.400"
                              : active
                              ? "blue.500"
                              : "gray.600"
                          }
                          fontWeight="medium"
                        >
                          <Flex justify="space-between" align="center" w="100%">
                            <Text>{title}</Text>
                            {isLocked && (
                              <Icon as={Lock} boxSize={4} color="gray.400" />
                            )}
                          </Flex>
                        </MenuItem>
                      );
                    }
                  )}
                  <MenuDivider />
                  <MenuItem
                    icon={<LogOut className="h-4 w-4" />}
                    onClick={onSignOutOpen}
                    color="red.500"
                    borderRadius="md"
                    fontSize="sm"
                    fontWeight="medium"
                    _hover={{ bg: "red.50" }}
                  >
                    Sign Out
                  </MenuItem>
                </MenuList>
              </Menu>
            </Flex>
          </Flex>
        </Box>

        {/* Main Content */}
        <Box flex="1" p={6} overflowY="auto" height="calc(100vh - 80px)">
          {isLoading && <Loader />}
          {!isLoading && children}
        </Box>
      </Flex>

      {/* SIGN OUT MODAL */}
      <Modal isOpen={isSignOutOpen} onClose={onSignOutClose} isCentered>
        <ModalOverlay backdropFilter="blur(4px)" />
        <ModalContent>
          <ModalHeader>{t("Confirm Sign Out")}</ModalHeader>
          <ModalCloseButton />
          <ModalBody>{t("Are you sure you want to log out?")}</ModalBody>
          <ModalFooter>
            <Button mr={3} onClick={onSignOutClose}>
              {t("No")}
            </Button>
            <Button colorScheme="red" onClick={handleSignOut}>
              {t("Yes")}
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

      {/* SUBSCRIPTION MODAL */}
      <Modal
        isOpen={isSubscriptionOpen}
        onClose={onSubscriptionClose}
        isCentered
      >
        <ModalOverlay backdropFilter="blur(4px)" />
        <ModalContent>
          <ModalHeader>
            <Flex align="center" gap={3}>
              <Icon as={Lock} boxSize={6} color="orange.500" />
              <Text>{t("Premium Feature")}</Text>
            </Flex>
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <VStack spacing={4} align="start">
              <Text fontSize="lg" fontWeight="medium" color="gray.700">
                {t("This feature requires a subscription")}
              </Text>
              <Text color="gray.600">
                {t(
                  "To access this premium feature, please contact us for subscription details."
                )}
              </Text>
              <Box
                bg="blue.50"
                p={4}
                borderRadius="md"
                border="1px"
                borderColor="blue.200"
              >
                <Text fontSize="sm" color="blue.700" fontWeight="medium">
                  {t("Contact us at:")}
                </Text>
                <Text fontSize="sm" color="blue.600">
                  support@cleaffo.com
                </Text>
              </Box>
            </VStack>
          </ModalBody>
          <ModalFooter>
            <Button colorScheme="blue" onClick={onSubscriptionClose}>
              {t("Got it")}
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

      {/* NOTIFICATIONS MODAL */}
      <Notification
        isOpen={isNotificationsOpen}
        onClose={onNotificationsClose}
        notifications={notifications}
        unreadCount={unreadCount}
        isLoadingNotifications={isLoadingNotifications}
        isMarkingAllAsRead={isMarkingAllAsRead}
        onMarkAllAsRead={handleMarkAllAsRead}
        onDeleteNotification={(notificationId: string) => {
          // The notification will be automatically removed from the list
          // when the API call succeeds due to React Query cache invalidation
          console.log("Notification deleted:", notificationId);
        }}
      />
    </Flex>
  );
}
