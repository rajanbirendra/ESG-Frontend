"use client";

import React, { useState, useEffect, useRef } from "react";
import {
  Box,
  Flex,
  Image,
  Text,
  Input,
  Button,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  useDisclosure,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  IconButton,
  useColorModeValue,
  Heading,
  Icon,
  VStack,
  Drawer,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  DrawerBody,
  useBreakpointValue,
  Tooltip,
} from "@chakra-ui/react";
import Link from "next/link";
import { useRouter } from "next/router";
import {
  ChevronLeftIcon,
  Menu as MenuIcon,
  CircleArrowLeftIcon,
} from "lucide-react";
import { adminMenuList } from "../molecules/adminMenuList";
import { ChevronUpIcon, ChevronDownIcon } from "@chakra-ui/icons";
import { FiSettings, FiUser, FiLogOut } from "react-icons/fi";
import { useTranslation } from "react-i18next";
import Loader from "../molecules/Loader";

/**
 * Utility to get initials from first + last name.
 */
function getInitials(firstName, lastName) {
  const f = firstName?.charAt(0).toUpperCase() || "";
  const l = lastName?.charAt(0).toUpperCase() || "";
  return f + l;
}

export default function Layout({
  children,
  headerTitle = "",
  subHeaderTitle = "",
  backButtonURL = null,
  activePage = null,
  isLoading = false,
}: {
  children: React.ReactNode;
  headerTitle?: string;
  subHeaderTitle?: string;
  backButtonURL?: string | null;
  activePage?: string | null;
  isLoading?: boolean;
}) {
  const router = useRouter();
  const { i18n } = useTranslation();
  const isMobile = useBreakpointValue({ base: true, md: false });
  const {
    isOpen: isMobileDrawerOpen,
    onOpen: onMobileDrawerOpen,
    onClose: onMobileDrawerClose,
  } = useDisclosure();

  // Disclosures for modals
  const {
    isOpen: isSignOutOpen,
    onOpen: onSignOutOpen,
    onClose: onSignOutClose,
  } = useDisclosure();
  const {
    isOpen: isProfileOpen,
    onOpen: onProfileOpen,
    onClose: onProfileClose,
  } = useDisclosure();

  // // Store user details from localStorage (placeholders for now)
  const [firstName, setFirstName] = useState("");
  // const [lastName, setLastName] = useState("");
  const [profilePictureUrl, setProfilePictureUrl] = useState<string | null>(
    null
  );

  // // File upload state for profile picture (placeholders)
  const [selectedFile, setSelectedFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const fileInputRef = useRef(null);

  // useEffect(() => {
  //   const storedFirstName = localStorage.getItem("first_name") ?? "";
  //   const storedLastName = localStorage.getItem("last_name") ?? "";
  //   const storedPictureUrl = localStorage.getItem("profilePictureUrl") ?? null;

  //   if (storedFirstName) setFirstName(storedFirstName);
  //   if (storedLastName) setLastName(storedLastName);
  //   if (storedPictureUrl) setProfilePictureUrl(storedPictureUrl);
  // }, []);

  // useEffect(() => {
  //   if (!selectedFile) {
  //     setPreview(null);
  //     return;
  //   }
  //   const objectUrl = URL.createObjectURL(selectedFile);
  //   setPreview(objectUrl);
  //   return () => URL.revokeObjectURL(objectUrl);
  // }, [selectedFile]);

  // // Helper to check if a route is active
  const isActive = (path) => router.pathname === path;

  // // Helper to check if any child route is active
  const isChildActive = (children) => {
    return children?.some((child) => isActive(child.route));
  };

  // // Sign out logic placeholder
  const handleSignOut = () => {
    // Placeholder: clear local storage and perform sign out logic
    localStorage.removeItem("token");
    router.push("/");
  };

  const handleChooseFile = () => {
    if (fileInputRef.current) {
      // @ts-ignore
      fileInputRef.current?.click();
    }
  };

  const handleFileChange = (e: any) => {
    if (!e.target.files || e.target.files.length === 0) {
      setSelectedFile(null);
      return;
    }
    setSelectedFile(e.target.files[0]);
  };

  // // Profile picture submission placeholder
  const handleProfileSubmit = () => {
    // Placeholder: API integration to update profile picture goes here.
    onProfileClose();
  };

  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  // Theme colors
  const sidebarBg = useColorModeValue("white", "gray.800");
  const mainBg = useColorModeValue("gray.50", "gray.900");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const headingColor = useColorModeValue("gray.700", "white");
  const activeBg = useColorModeValue("blue.50", "blue.900");
  const activeColor = useColorModeValue("blue.600", "blue.400");
  const hoverBg = useColorModeValue("gray.100", "gray.700");
  const searchBg = useColorModeValue("gray.50", "gray.700");
  const headerBg = useColorModeValue("white", "gray.800");
  const headerBorderColor = useColorModeValue("gray.200", "gray.700");
  const searchBorderColor = useColorModeValue("gray.200", "gray.600");

  console.log("adminMenuList", adminMenuList);

  // Set initial active menu based on current route
  useEffect(() => {
    adminMenuList.forEach((item) => {
      if (item.children && isChildActive(item.children)) {
        setActiveMenu(item.route);
      }
    });
  }, [router.pathname]);

  const [isMounted, setIsMounted] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Handle localStorage after mount
  useEffect(() => {
    setIsMounted(true);
    const savedState = localStorage.getItem("sidebarOpen");
    if (savedState) {
      setIsSidebarOpen(JSON.parse(savedState));
    }
  }, []);

  // Update localStorage when sidebar state changes
  useEffect(() => {
    if (isMounted) {
      localStorage.setItem("sidebarOpen", JSON.stringify(isSidebarOpen));
    }
  }, [isSidebarOpen, isMounted]);

  const handleSidebarToggle = () => {
    if (window.innerWidth < 768) {
      onMobileDrawerOpen();
    } else {
      setIsTransitioning(true);
      setIsSidebarOpen(!isSidebarOpen);
      setTimeout(() => {
        setIsTransitioning(false);
      }, 300);
    }
  };

  const SidebarContent = () => (
    <>
      <Flex align="center" mb={8} justify="space-between">
        {isMounted && isSidebarOpen ? (
          <Flex align="center" justify="space-between" w="100%">
            <Flex align="center">
              <Image
                src="/logo.webp"
                boxSize="40px"
                mr={3}
                transition="all 0.3s ease"
                _hover={{
                  transform: "scale(1.1)",
                }}
              />
              <Heading
                size="md"
                fontWeight="bold"
                bgGradient="linear(to-r, blue.500, blue.600)"
                bgClip="text"
              >
                Cleaffo
              </Heading>
            </Flex>
          </Flex>
        ) : (
          <Flex justify="center" w="100%">
            <Image
              src="/logo.webp"
              boxSize="40px"
              transition="all 0.3s ease"
              _hover={{
                transform: "scale(1.1)",
              }}
            />
          </Flex>
        )}
      </Flex>

      {/* Toggle Button - Fixed Position */}
      <Box
        position="absolute"
        right="-20px"
        bottom="100px"
        zIndex="1001"
        display={{ base: "none", md: "flex" }}
        alignItems="center"
        justifyContent="center"
      >
        <IconButton
          aria-label="Toggle sidebar"
          icon={isSidebarOpen ? <CircleArrowLeftIcon /> : <MenuIcon />}
          variant="solid"
          size="sm"
          onClick={handleSidebarToggle}
          bg="white"
          color="gray.600"
          _hover={{
            bg: "blue.50",
            color: "blue.500",
            transform: "scale(1.1)",
          }}
          boxShadow="lg"
          borderRadius="full"
          w="32px"
          h="32px"
          minW="32px"
          p={0}
          border="1px"
          borderColor="gray.100"
          transition="all 0.2s ease"
        />
      </Box>

      {/* Content Container with Overflow */}
      <Box
        flex="1"
        overflowY="auto"
        overflowX="hidden"
        pr={2}
        css={{
          "&::-webkit-scrollbar": {
            width: "4px",
          },
          "&::-webkit-scrollbar-track": {
            width: "6px",
          },
          "&::-webkit-scrollbar-thumb": {
            background: "var(--chakra-colors-gray-200)",
            borderRadius: "24px",
          },
        }}
      >
        {adminMenuList.map((item) => (
          <Box key={item.route} mb={3}>
            {item.children && item.children.length > 0 ? (
              <Box>
                {/* Parent Menu Item */}
                <Box
                  onClick={() =>
                    setActiveMenu(activeMenu === item.route ? null : item.route)
                  }
                  cursor="pointer"
                  bg={
                    isActive(item.route) || isChildActive(item.children)
                      ? activeBg
                      : "transparent"
                  }
                  p={3}
                  borderRadius="lg"
                  _hover={{
                    bg: hoverBg,
                    transform: "translateX(4px)",
                  }}
                  transition="all 0.2s ease"
                  position="relative"
                  _before={{
                    content: '""',
                    position: "absolute",
                    left: 0,
                    top: 0,
                    bottom: 0,
                    width: "4px",
                    bg:
                      isActive(item.route) || isChildActive(item.children)
                        ? activeColor
                        : "transparent",
                    borderRadius: "0 4px 4px 0",
                    transition: "all 0.2s ease",
                  }}
                >
                  <Flex align="center" justify="space-between">
                    <Flex align="center" gap={3}>
                      <Box
                        color={
                          isActive(item.route) || isChildActive(item.children)
                            ? activeColor
                            : textColor
                        }
                        transition="all 0.2s ease"
                      >
                        {item.icon}
                      </Box>
                      {isMounted && isSidebarOpen && (
                        <Text
                          fontWeight="medium"
                          color={
                            isActive(item.route) || isChildActive(item.children)
                              ? activeColor
                              : textColor
                          }
                          fontSize="sm"
                          transition="all 0.2s ease"
                        >
                          {item.title}
                        </Text>
                      )}
                    </Flex>
                    {isMounted && isSidebarOpen && (
                      <Box color={textColor} transition="all 0.2s ease">
                        {activeMenu === item.route ? (
                          <ChevronUpIcon />
                        ) : (
                          <ChevronDownIcon />
                        )}
                      </Box>
                    )}
                  </Flex>
                </Box>

                {/* Submenu Items */}
                {activeMenu === item.route && isMounted && isSidebarOpen && (
                  <Box pl={4} mt={2}>
                    {item.children.map((child) => (
                      <Box
                        key={child.route}
                        mb={2}
                        bg={isActive(child.route) ? activeBg : "transparent"}
                        p={3}
                        borderRadius="lg"
                        _hover={{
                          bg: hoverBg,
                          transform: "translateX(4px)",
                        }}
                        transition="all 0.2s ease"
                        position="relative"
                        _before={{
                          content: '""',
                          position: "absolute",
                          left: 0,
                          top: 0,
                          bottom: 0,
                          width: "4px",
                          bg: isActive(child.route)
                            ? activeColor
                            : "transparent",
                          borderRadius: "0 4px 4px 0",
                          transition: "all 0.2s ease",
                        }}
                      >
                        <Link href={child.route}>
                          <Flex align="center" gap={3}>
                            <Box
                              color={
                                isActive(child.route) ? activeColor : textColor
                              }
                              transition="all 0.2s ease"
                            >
                              {child.icon}
                            </Box>
                            <Text
                              fontWeight="medium"
                              color={
                                isActive(child.route) ? activeColor : textColor
                              }
                              fontSize="sm"
                              transition="all 0.2s ease"
                            >
                              {child.title}
                            </Text>
                          </Flex>
                        </Link>
                      </Box>
                    ))}
                  </Box>
                )}
              </Box>
            ) : (
              // Single Menu Item
              <Box
                bg={isActive(item.route) ? activeBg : "transparent"}
                p={3}
                borderRadius="lg"
                _hover={{
                  bg: hoverBg,
                  transform: "translateX(4px)",
                }}
                transition="all 0.2s ease"
                position="relative"
                _before={{
                  content: '""',
                  position: "absolute",
                  left: 0,
                  top: 0,
                  bottom: 0,
                  width: "4px",
                  bg: isActive(item.route) ? activeColor : "transparent",
                  borderRadius: "0 4px 4px 0",
                  transition: "all 0.2s ease",
                }}
              >
                <Link href={item.route}>
                  <Flex align="center" gap={3}>
                    <Box
                      color={isActive(item.route) ? activeColor : textColor}
                      transition="all 0.2s ease"
                    >
                      {item.icon}
                    </Box>
                    {isMounted && isSidebarOpen && (
                      <Text
                        fontWeight="medium"
                        color={isActive(item.route) ? activeColor : textColor}
                        fontSize="sm"
                        transition="all 0.2s ease"
                      >
                        {item.title}
                      </Text>
                    )}
                  </Flex>
                </Link>
              </Box>
            )}
          </Box>
        ))}

        <Flex
          align="center"
          mt="auto"
          p={3}
          borderRadius="lg"
          onClick={onSignOutOpen}
          _hover={{
            bg: "red.50",
            cursor: "pointer",
            transform: "translateX(4px)",
            _before: {
              bg: "red.500",
            },
          }}
          justify={isMounted && isSidebarOpen ? "flex-start" : "center"}
          transition="all 0.2s ease"
          position="relative"
          _before={{
            content: '""',
            position: "absolute",
            left: 0,
            top: 0,
            bottom: 0,
            width: "4px",
            bg: "transparent",
            borderRadius: "0 4px 4px 0",
            transition: "all 0.2s ease",
          }}
        >
          <Icon as={FiLogOut} boxSize={5} color="red.500" />
          {isMounted && isSidebarOpen && (
            <Text
              fontWeight="medium"
              color="red.500"
              fontSize="sm"
              ml={3}
              transition="all 0.2s ease"
            >
              Sign Out
            </Text>
          )}
        </Flex>
      </Box>
    </>
  );

  return (
    <Flex minH="100vh" bg="gray.50" position="relative">
      {/* Desktop Sidebar */}
      <Box
        as="nav"
        bg="white"
        w={{
          base: "0",
          md: isMounted && isSidebarOpen ? "280px" : "80px",
        }}
        p={isMounted && isSidebarOpen ? 6 : 3}
        boxShadow="lg"
        display={{ base: "none", md: "flex" }}
        flexDirection="column"
        h="100vh"
        position="fixed"
        top="0"
        left="0"
        zIndex="1000"
        borderRight="1px"
        borderColor="gray.100"
        overflow="visible"
        _hover={{
          boxShadow: "xl",
        }}
      >
        <SidebarContent />
      </Box>

      {/* Mobile Menu Button */}
      <IconButton
        aria-label="Open menu"
        icon={<MenuIcon />}
        display={{ base: "flex", md: "none" }}
        position="fixed"
        top="4"
        left="4"
        zIndex="1002"
        onClick={onMobileDrawerOpen}
        bg="white"
        color="gray.600"
        _hover={{
          bg: "blue.50",
          color: "blue.500",
        }}
        boxShadow="lg"
        borderRadius="full"
        w="40px"
        h="40px"
      />

      {/* Mobile Drawer */}
      <Drawer
        isOpen={isMobileDrawerOpen}
        placement="left"
        onClose={onMobileDrawerClose}
        size="full"
      >
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerBody p={0}>
            <Box
              as="nav"
              bg="white"
              w="full"
              h="100vh"
              display="flex"
              flexDirection="column"
              p={6}
            >
              <SidebarContent />
            </Box>
          </DrawerBody>
        </DrawerContent>
      </Drawer>

      {/* MAIN CONTENT AREA */}
      <Flex
        flex="1"
        direction="column"
        ml={{ base: 0, md: isMounted && isSidebarOpen ? "280px" : "80px" }}
        transition={isTransitioning ? "margin-left 0.3s ease" : "none"}
        willChange="margin-left"
      >
        {/* TOP NAVIGATION BAR */}
        <Box
          as="header"
          bg={headerBg}
          boxShadow="sm"
          borderBottom="1px"
          borderColor={headerBorderColor}
          position="sticky"
          top="0"
          zIndex="1000"
        >
          <Flex
            align="center"
            justify="space-between"
            p={4}
            maxW="1600px"
            mx="auto"
            w="full"
          >
            {/* Left Section: Back Button + Title */}
            <Flex align="center" minW="200px">
              {backButtonURL && (
                <IconButton
                  aria-label="Back"
                  icon={<ChevronLeftIcon />}
                  variant="ghost"
                  size="sm"
                  mr={3}
                  onClick={() => router.push(backButtonURL)}
                  _hover={{ bg: hoverBg }}
                />
              )}

              <VStack align="start" spacing={2}>
                <Heading size="md" color={headingColor} fontWeight="600">
                  {headerTitle}
                </Heading>
                <Text
                  color={useColorModeValue("gray.500", "gray.500")}
                  fontSize="md"
                >
                  {subHeaderTitle}
                </Text>
              </VStack>
            </Flex>

            {/* Right Section: Language + Profile */}
            {/* <Flex align="center" gap={3} minW="300px" justify="flex-end"> */}
            {/* Language Selector */}
            {/* <Box
                bg="white"
                p={2}
                borderRadius="lg"
                border="1px"
                borderColor="gray.200"
                boxShadow="sm"
                _hover={{
                  boxShadow: "md",
                  borderColor: "gray.300",
                }}
                transition="all 0.2s ease"
              >
                <Menu>
                  <MenuButton
                    as={Button}
                    variant="ghost"
                    size="sm"
                    leftIcon={
                      <Text fontSize="sm">
                        {i18n.language === "hi" ? "🇮🇳" : "🇺🇸"}
                      </Text>
                    }
                    rightIcon={<ChevronDownIcon />}
                    _hover={{ bg: hoverBg }}
                    color={textColor}
                    h="32px"
                    px={2}
                    fontSize="xs"
                  >
                    {i18n.language === "hi" ? "हिंदी" : "EN"}
                  </MenuButton>
                  <MenuList>
                    <MenuItem onClick={() => i18n.changeLanguage("en")}>
                      🇺🇸 English (US)
                    </MenuItem>
                    <MenuItem onClick={() => i18n.changeLanguage("hi")}>
                      🇮🇳 हिंदी
                    </MenuItem>
                  </MenuList>
                </Menu>
              </Box> */}
            {/* </Flex> */}
          </Flex>
        </Box>

        {/* Main Content */}
        <Box flex="1" p={6} maxW="1600px" mx="auto" w="full">
          {isLoading && <Loader />}
          {children}
        </Box>
      </Flex>

      {/* SIGN OUT MODAL */}
      <Modal isOpen={isSignOutOpen} onClose={onSignOutClose} isCentered>
        <ModalOverlay backdropFilter="blur(4px)" />
        <ModalContent>
          <ModalHeader>Confirm Sign Out</ModalHeader>
          <ModalCloseButton />
          <ModalBody>Are you sure you want to log out?</ModalBody>
          <ModalFooter>
            <Button mr={3} onClick={onSignOutClose}>
              No
            </Button>
            <Button colorScheme="red" onClick={handleSignOut}>
              Yes
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>

      {/* UPLOAD/CHANGE PROFILE PICTURE MODAL */}
      <Modal
        isOpen={isProfileOpen}
        onClose={onProfileClose}
        isCentered
        size="lg"
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader textAlign="center">
            {profilePictureUrl
              ? "Change your Profile Picture"
              : "Upload your Profile Picture"}
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Input
              type="file"
              accept="image/*"
              ref={fileInputRef}
              display="none"
              onChange={handleFileChange}
            />
            <Flex justify="center" mb={6}>
              <Button
                bg="white"
                color="black"
                border="1px solid"
                borderColor="gray.400"
                onClick={handleChooseFile}
              >
                + Choose from your device
              </Button>
            </Flex>
            {preview && (
              <Flex align="center" direction="column" mb={4}>
                <Image
                  src={preview}
                  alt="Preview"
                  borderRadius="full"
                  boxSize="100px"
                  objectFit="cover"
                />
              </Flex>
            )}
          </ModalBody>
          <ModalFooter>
            <Button variant="ghost" mr={3} onClick={onProfileClose}>
              Cancel
            </Button>
            <Button
              colorScheme="green"
              onClick={handleProfileSubmit}
              disabled={!selectedFile}
            >
              Submit
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </Flex>
  );
}
