import { FileText } from "lucide-react";

import { CheckCircle2 } from "lucide-react";

import { Clock } from "lucide-react";

import { Send } from "lucide-react";

export const getStatusDisplay = (status: string) => {
  switch (status) {
    case "FORWARD_FOR_REVIEW":
      return "Forwarded for Review";
    case "APPROVED":
      return "Approved";
    case "IN_PROGRESS":
      return "In Progress";
    case "COMPLETED":
      return "Completed";
    default:
      return status.replace(/_/g, " ");
  }
};

export const getStatusIcon = (status: string) => {
  switch (status) {
    case "FORWARD_FOR_REVIEW":
    case "APPROVED":
      return <Send size={18} />;
    case "IN_PROGRESS":
      return <Clock size={18} />;
    case "COMPLETED":
      return <CheckCircle2 size={20} />;
    default:
      return <FileText size={20} />;
  }
};

export const getStatusColor = (status: string) => {
  switch (status) {
    case "FORWARD_FOR_REVIEW":
    case "APPROVED":
      return "green.500";
    case "IN_PROGRESS":
      return "orange.500";
    case "COMPLETED":
      return "purple.500";
    default:
      return "blue.500";
  }
};
