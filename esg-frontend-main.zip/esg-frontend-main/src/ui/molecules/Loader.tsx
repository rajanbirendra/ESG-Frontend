import { Flex } from "@chakra-ui/react";
import { keyframes } from "@emotion/react";
import { Loader2 } from "lucide-react";

const spin = keyframes`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`;

const Loader = () => {
  return (
    <Flex
      justifyContent="center"
      alignItems="center"
      height="100%"
      width="100%"
      minHeight="200px"
    >
      <Flex animation={`${spin} 1s linear infinite`} color="gray.700">
        <Loader2 size={40} />
      </Flex>
    </Flex>
  );
};

export default Loader;
