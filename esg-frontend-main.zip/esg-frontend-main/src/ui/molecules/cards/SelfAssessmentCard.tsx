import React from "react";
import AssessmentCard from "@/ui/molecules/cards/AssessmentCard";

interface SelfAssessmentCardProps {
  assessment: any;
  onClick: () => void;
}

const SelfAssessmentCard: React.FC<SelfAssessmentCardProps> = ({
  assessment,
  onClick,
}) => {
  return (
    <AssessmentCard
      assessment={assessment}
      onClick={onClick}
      showStatus={false}
      showActions={true}
      showBranch={false}
      showRequester={true}
      showYear={true}
      showMonth={false}
      showCreationDate={true}
      buttonText={
        assessment?.completion_percentage === 100
          ? "View Assessment"
          : "Continue Assessment"
      }
    />
  );
};

export default SelfAssessmentCard;
