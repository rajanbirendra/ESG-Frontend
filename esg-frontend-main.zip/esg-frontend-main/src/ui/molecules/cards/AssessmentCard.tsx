import { Roles } from "@/types/index.types";
import {
  Box,
  Heading,
  Text,
  Button,
  Flex,
  VStack,
  Divider,
  Badge,
  HStack,
  IconButton,
  Link,
} from "@chakra-ui/react";
import {
  ArrowRight,
  LucideGitBranch,
  LucideUser,
  LucideGalleryVerticalEnd,
  Info,
  LucideCalendar,
  CalendarDays,
  Clock,
} from "lucide-react";
import { MiniProgressBox } from "@/ui/molecules/ProgressBox";
import { getStatusDisplay } from "@/ui/molecules/assessmentStatus";
import { getStatusColor } from "@/ui/molecules/assessmentStatus";
import React, { useState, useEffect } from "react";

// Shared interface for assessment data
interface AssessmentData {
  id?: string;
  title?: string;
  description?: string;
  created_at?: string;
  assessment_year?: number;
  assessment_month?: number;
  assessment_status?: string;
  requester?: {
    first_name?: string;
    last_name?: string;
  };
  branch?: {
    branch_name?: string;
  };
}

interface AssessmentCardProps {
  assessment: any;
  userRole?: string;
  setSelectedAssessment?: (assessment: any) => void;
  selectedAssessment?: any;
  setSelectedAssessmentId?: (id: string) => void;
  onHistoryOpen?: any;
  onForwardOpen?: any;
  isForwardOpen?: boolean;
  onClick?: () => void;
  showStatus?: boolean;
  showActions?: boolean;
  showBranch?: boolean;
  showRequester?: boolean;
  showYear?: boolean;
  showMonth?: boolean;
  showCreationDate?: boolean;
  buttonText?: string;
  href?: string;
}

// Shared utility function for date formatting
const formatDate = (dateString: string) => {
  try {
    const date = new Date(dateString);
    const month = date.toLocaleDateString("en-US", { month: "short" });
    const day = date.getDate();
    const year = date.getFullYear();
    return `${month} ${day}, ${year}`;
  } catch (error) {
    return dateString;
  }
};

const AssessmentCard: React.FC<AssessmentCardProps> = ({
  assessment,
  userRole = "",
  setSelectedAssessment,
  selectedAssessment,
  setSelectedAssessmentId,
  onHistoryOpen,
  onForwardOpen,
  isForwardOpen,
  onClick,
  showStatus = true,
  showActions = true,
  showBranch = true,
  showRequester = true,
  showYear = true,
  showMonth = true,
  showCreationDate = true,
  buttonText,
}) => {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Defensive programming to handle potential undefined values
  const assessmentData: AssessmentData =
    assessment?.assessment || assessment || {};
  const title = assessmentData.title || "Untitled Assessment";
  const description = assessmentData.description || "";
  const created_at = assessmentData.created_at || "";
  const requester = assessmentData.requester || null;
  const assessment_year = assessmentData.assessment_year || null;
  const assessment_month = assessmentData.assessment_month || null;
  const assessment_status = assessmentData.assessment_status || "";
  const branch = assessmentData.branch || null;
  const completion_percentage = assessment?.completion_percentage || 0;
  const answered_questions = assessment?.answered_questions || 0;
  const total_questions = assessment?.total_questions || 0;

  const formattedDate = formatDate(created_at);

  const handleClick = (e: React.MouseEvent) => {
    if (onClick) {
      e.preventDefault();
      onClick();
    }
  };

  return (
    <Box
      key={assessment?.id || Math.random()}
      _hover={{ textDecoration: "none" }}
      onClick={onClick ? handleClick : undefined}
      cursor={onClick ? "pointer" : "initial"}
    >
      <Box
        bg="white"
        borderRadius="xl"
        boxShadow="lg"
        overflow="hidden"
        transition="all 0.3s ease"
        _hover={{
          transform: "translateY(-4px)",
          boxShadow: "xl",
        }}
      >
        <Box p={6} borderBottom="1px" borderColor="gray.100">
          <Flex justify="space-between" align="center" mb={4}>
            <VStack align="start" spacing={1}>
              <Heading size="md" color="gray.700" noOfLines={1}>
                {title}
              </Heading>
              <Text color="gray.500" fontSize="sm" noOfLines={2}>
                {description}
              </Text>
            </VStack>
            {showStatus && assessment_status && (
              <HStack spacing={2}>
                {onHistoryOpen && (
                  <IconButton
                    aria-label="View History"
                    icon={<Info size={16} />}
                    size="sm"
                    variant="ghost"
                    visibility={"visible"}
                    colorScheme="blue"
                    style={{
                      position: "absolute",
                      right: "0",
                      top: "0",
                    }}
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      setSelectedAssessment?.(assessmentData);
                      onHistoryOpen();
                    }}
                  />
                )}
                <Badge
                  colorScheme={getStatusColor(assessment_status)}
                  px={3}
                  py={1}
                  borderRadius="full"
                  fontSize="xs"
                  fontWeight="medium"
                >
                  {getStatusDisplay(assessment_status)}
                </Badge>
              </HStack>
            )}
          </Flex>

          <Flex gap={4} align="center" flexWrap="wrap">
            {showBranch && userRole === Roles.USER && branch && (
              <Flex align="center" gap={2}>
                <LucideGitBranch
                  size={16}
                  color="var(--chakra-colors-gray-500)"
                />
                <Text color="gray.500" fontSize="sm">
                  {branch.branch_name}
                </Text>
              </Flex>
            )}
            {showRequester && requester && (
              <Flex align="center" gap={2}>
                <LucideUser size={16} color="var(--chakra-colors-gray-500)" />
                <Text color="gray.500" fontSize="sm" noOfLines={1}>
                  {requester.first_name || ""} {requester.last_name || ""}
                </Text>
              </Flex>
            )}
            {showYear && assessment_year && (
              <Flex align="center" gap={2}>
                <CalendarDays size={16} color="var(--chakra-colors-gray-500)" />
                <Text color="gray.500" fontSize="sm" noOfLines={1}>
                  {assessment_year}
                  {showMonth && assessment_month && `/${assessment_month}`}
                </Text>
              </Flex>
            )}
            {showCreationDate && mounted && formattedDate && (
              <Flex align="center" gap={2}>
                <Clock size={16} color="var(--chakra-colors-gray-500)" />
                <Text color="gray.500" fontSize="sm" noOfLines={1}>
                  {formattedDate}
                </Text>
              </Flex>
            )}
          </Flex>
        </Box>

        <Box p={6}>
          <MiniProgressBox
            completion_percentage={completion_percentage}
            answered_questions={answered_questions}
            total_questions={total_questions}
          />
          {showActions && (
            <>
              <Divider my={4} />
              <HStack spacing={4} align="stretch">
                <Button
                  rightIcon={<ArrowRight size={20} />}
                  as={Link}
                  href={
                    "/dashboard/assessment/start/" + assessment.assessment.id
                  }
                  colorScheme="primary"
                  variant="outline"
                  size="xs"
                  padding={"5"}
                  width={
                    assessment.completion_percentage >= 98 &&
                    assessment.assessment?.assessment_status != "COMPLETED" &&
                    showActions
                      ? "50%"
                      : "full"
                  }
                  _hover={{
                    bg: "primary.50",
                    textDecoration: "none",
                    transform: "translateX(4px)",
                  }}
                  transition="all 0.2s"
                >
                  {(assessment.completion_percentage > 0
                    ? "Continue "
                    : "View") + " Assessment"}
                </Button>
                {assessment.completion_percentage >= 98 &&
                  assessment.assessment?.assessment_status != "COMPLETED" &&
                  showActions && (
                    <Button
                      size="xs"
                      rightIcon={<LucideGalleryVerticalEnd size={20} />}
                      backgroundColor={"green.50"}
                      color="green"
                      variant={"outline"}
                      width="50%"
                      padding={"5"}
                      textAlign="center"
                      _hover={{
                        bg: "green.100",
                        transform: "translateX(4px)",
                      }}
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setSelectedAssessmentId?.(assessment.assessment?.id);
                        onForwardOpen?.();
                      }}
                    >
                      {userRole === Roles.USER && "Approve"}
                      {userRole === Roles.SUB_USER && "Forward for Review"}
                    </Button>
                  )}
              </HStack>
            </>
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default AssessmentCard;
