import {
  Box,
  SimpleGrid,
  Flex,
  HStack,
  VStack,
  Skeleton,
  Card,
  CardBody,
  Avatar,
  Spacer,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
} from "@chakra-ui/react";

interface ShimmerLoaderProps {
  count?: number;
  variant?:
    | "card"
    | "branch"
    | "sub-user"
    | "social"
    | "governance"
    | "environment"
    | "general"
    | "carbon-neutrality-plan"
    | "reports";
}

const ShimmerLoader = ({ count = 3, variant = "card" }: ShimmerLoaderProps) => {
  const BranchSkeleton = () => (
    <Card
      bg="white"
      border="1px solid"
      borderColor="gray.200"
      transition="all 0.2s"
    >
      <CardBody>
        <Flex justify="space-between" align="center">
          <HStack spacing={4}>
            <Skeleton height="24px" width="24px" />
            <VStack align="start" spacing={1}>
              <Skeleton height="20px" width="200px" />
              <HStack spacing={2}>
                <Skeleton height="16px" width="16px" />
                <Skeleton height="16px" width="150px" />
              </HStack>
            </VStack>
          </HStack>
          <Skeleton height="20px" width="100px" />
        </Flex>
      </CardBody>
    </Card>
  );

  const SubUserSkeleton = () => (
    <Card
      bg="white"
      border="1px solid"
      borderColor="gray.200"
      transition="all 0.2s"
    >
      <CardBody>
        <Flex justify="space-between" align="start">
          <HStack spacing={4}>
            <Skeleton height="40px" width="40px" borderRadius="full" />
            <VStack align="start" spacing={1}>
              <Skeleton height="20px" width="150px" />
              <Skeleton height="16px" width="200px" />
              <HStack spacing={2}>
                <Skeleton height="16px" width="60px" />
                <Skeleton height="16px" width="60px" />
              </HStack>
            </VStack>
          </HStack>
          <Skeleton height="24px" width="24px" />
        </Flex>
        <VStack align="start" spacing={1} mt={4}>
          <Skeleton height="16px" width="120px" />
          <Skeleton height="16px" width="180px" />
          <Skeleton height="16px" width="140px" />
        </VStack>
      </CardBody>
    </Card>
  );

  const CardSkeleton = () => (
    <Box
      bg="white"
      borderRadius="xl"
      boxShadow="lg"
      overflow="hidden"
      position="relative"
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        background:
          "linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent)",
        animation: "shimmer 1.5s infinite",
      }}
    >
      <Box p={6} borderBottom="1px" borderColor="gray.100">
        <Box height="24px" bg="gray.100" borderRadius="md" mb={2} width="70%" />
        <Box height="16px" bg="gray.100" borderRadius="md" width="90%" />
      </Box>
      <Box p={6}>
        <Box
          height="20px"
          bg="gray.100"
          borderRadius="md"
          mb={4}
          width="100%"
        />
        <Box height="40px" bg="gray.100" borderRadius="md" width="100%" />
      </Box>
    </Box>
  );

  const SocialStatSkeleton = () => (
    <div className="stat-card-minimal">
      <Skeleton height="2.2rem" width="2.2rem" borderRadius="md" />
      <div>
        <Skeleton height="1.6rem" width="80px" mb={1} />
        <Skeleton height="0.95rem" width="120px" />
      </div>
    </div>
  );

  const SocialChartSkeleton = () => (
    <div className="chart-card-minimal">
      <Skeleton height="1.1rem" width="250px" mb={3} />
      <Flex gap={4} justify="flex-end" mb={3}>
        <Skeleton height="48px" width="180px" />
        <Skeleton height="48px" width="180px" />
      </Flex>
      <Box h="250px">
        <Skeleton height="100%" />
      </Box>
    </div>
  );

  const EnvironmentStatSkeleton = () => (
    <div className="stat-card-minimal">
      <Skeleton height="1.8rem" width="1.8rem" borderRadius="md" />
      <div>
        <Skeleton height="1.2rem" width="80px" mb={1} />
        <Skeleton height="0.85rem" width="120px" />
      </div>
    </div>
  );

  const EnvironmentChartSkeleton = () => (
    <div className="compact-card">
      <div className="compact-card-header">
        <Skeleton height="0.9rem" width="180px" />
      </div>
      <div className="compact-card-chart">
        <Skeleton height="200px" />
      </div>
    </div>
  );

  const EnvironmentCompactCardSkeleton = () => (
    <div className="compact-card chart-card">
      <div className="compact-card-header">
        <Skeleton height="0.9rem" width="120px" />
      </div>
      <div className="compact-card-chart pie-chart">
        <Skeleton height="140px" width="140px" borderRadius="full" />
        <div className="compact-card-legend pie-legend">
          {[1, 2].map((_, index) => (
            <div key={index} className="compact-legend-item">
              <Skeleton height="8px" width="8px" borderRadius="sm" />
              <Skeleton height="12px" width="80px" />
            </div>
          ))}
        </div>
      </div>
      <div className="view-detailed-container">
        <Skeleton height="24px" width="100px" />
      </div>
    </div>
  );

  const GovernanceStatSkeleton = () => (
    <div className="stat-card-minimal">
      <Skeleton height="1.8rem" width="1.8rem" borderRadius="md" />
      <div>
        <Skeleton height="1.2rem" width="80px" mb={1} />
        <Skeleton height="0.85rem" width="120px" />
      </div>
    </div>
  );

  const GovernanceChartSkeleton = () => (
    <div className="compact-card">
      <div className="compact-card-header">
        <Skeleton height="0.9rem" width="200px" />
        <Flex gap={4}>
          <Skeleton height="40px" width="180px" />
          <Skeleton height="40px" width="180px" />
        </Flex>
      </div>
      <div className="compact-card-chart">
        <Skeleton height="280px" />
      </div>
    </div>
  );

  const GovernancePolicySkeleton = () => (
    <div className="policy-card-minimal">
      <div className="policy-header-minimal">
        <Skeleton height="0.9rem" width="200px" />
      </div>
      <div className="policy-list-minimal">
        {[1, 2, 3, 4, 5].map((_, index) => (
          <div key={index} className="policy-item-minimal">
            <Skeleton height="16px" width="4px" mr={3} />
            <Skeleton height="20px" width="100%" />
          </div>
        ))}
      </div>
    </div>
  );

  const GeneralStatSkeleton = () => (
    <Box
      bg="white"
      boxShadow="sm"
      borderRadius="2xl"
      p={6}
      border="1px solid"
      borderColor="gray.200"
    >
      <Flex align="center" mb={4}>
        <Skeleton height="20px" width="120px" />
        <Spacer />
        <Skeleton height="20px" width="20px" />
      </Flex>
      <Skeleton height="36px" width="80px" />
    </Box>
  );

  const GeneralAssessmentSkeleton = () => (
    <Box p={4} border="1px solid" borderColor="gray.100" borderRadius="lg">
      <Flex justify="space-between" align="center" mb={2}>
        <Skeleton height="20px" width="200px" />
        <Skeleton height="20px" width="80px" />
      </Flex>
      <Skeleton height="16px" width="250px" mb={2} />
      <Flex align="center" gap={2}>
        <Skeleton height="8px" width="100%" />
        <Skeleton height="16px" width="60px" />
      </Flex>
    </Box>
  );

  const CarbonNeutralityPlanSkeleton = () => (
    <Card
      bg="white"
      border="1px solid"
      borderColor="gray.200"
      borderRadius="xl"
      boxShadow="sm"
      transition="all 0.2s"
    >
      <CardBody>
        <Flex justify="space-between" align="center" mb={4}>
          <HStack spacing={3}>
            <Skeleton height="20px" width="20px" />
            <VStack align="start" spacing={1}>
              <Skeleton height="24px" width="250px" />
              <Skeleton height="16px" width="120px" />
            </VStack>
          </HStack>
          <Skeleton height="24px" width="60px" borderRadius="full" />
        </Flex>

        <VStack spacing={4} align="stretch">
          <HStack justify="space-between" wrap="wrap" gap={4}>
            <HStack spacing={2}>
              <Skeleton height="16px" width="16px" />
              <Skeleton height="16px" width="180px" />
            </HStack>
          </HStack>

          <Flex justify="flex-end" gap={2} pt={2}>
            <Skeleton height="32px" width="60px" borderRadius="lg" />
            <Skeleton height="32px" width="70px" borderRadius="lg" />
          </Flex>
        </VStack>
      </CardBody>
    </Card>
  );

  if (variant === "branch") {
    return (
      <VStack spacing={4} align="stretch">
        {Array.from({ length: count }).map((_, index) => (
          <BranchSkeleton key={index} />
        ))}
      </VStack>
    );
  }

  if (variant === "sub-user") {
    return (
      <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
        {Array.from({ length: count }).map((_, index) => (
          <SubUserSkeleton key={index} />
        ))}
      </SimpleGrid>
    );
  }

  if (variant === "social") {
    return (
      <div className="social-dashboard-minimal">
        <div className="stats-grid-minimal">
          {Array.from({ length: 5 }).map((_, index) => (
            <SocialStatSkeleton key={index} />
          ))}
        </div>
        <div className="charts-grid-minimal">
          {Array.from({ length: 4 }).map((_, index) => (
            <SocialChartSkeleton key={index} />
          ))}
        </div>

        <style jsx>{`
          .social-dashboard-minimal {
            padding: 2.5rem 1rem;
            background: #fafbfc;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
          }
          .stats-grid-minimal {
            display: flex;
            gap: 1.5rem;
            margin-bottom: 2rem;
            flex-wrap: wrap;
          }
          .stat-card-minimal {
            flex: 1 1 180px;
            display: flex;
            align-items: center;
            gap: 1rem;
            background: #fff;
            border-radius: 0.75rem;
            padding: 1.25rem 1.5rem;
            box-shadow: none;
            border: 1px solid #f3f4f6;
            min-width: 180px;
          }
          .charts-grid-minimal {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
          }
          .chart-card-minimal {
            background: #fff;
            border-radius: 0.75rem;
            padding: 1.25rem 1.5rem;
            border: 1px solid #f3f4f6;
            box-shadow: none;
            display: flex;
            flex-direction: column;
            align-items: stretch;
          }
        `}</style>
      </div>
    );
  }

  if (variant === "governance") {
    return (
      <div className="governance-dashboard-minimal">
        {/* Main Content Row */}
        <div className="main-content-row">
          {/* Stats Column */}
          <div className="stats-column">
            {Array.from({ length: 5 }).map((_, index) => (
              <GovernanceStatSkeleton key={index} />
            ))}
          </div>

          {/* Charts Column */}
          <div className="charts-column">
            <GovernanceChartSkeleton />

            <div className="policy-grid-minimal">
              <GovernancePolicySkeleton />
              <GovernancePolicySkeleton />
            </div>
          </div>
        </div>

        <style jsx>{`
          .governance-dashboard-minimal {
            padding: 1rem 0.5rem;
            background: #fafbfc;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
          }
          .main-content-row {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
          }
          .stats-column {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            width: 25%;
          }
          .stat-card-minimal {
            flex: 1;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: #fff;
            border-radius: 0.75rem;
            padding: 0.75rem;
            box-shadow: none;
            border: 1px solid #f3f4f6;
            height: 80px;
          }
          .charts-column {
            flex: 1;
          }
          .compact-card {
            background: #fff;
            border-radius: 0.75rem;
            border: 1px solid #f3f4f6;
            box-shadow: none;
            padding: 0.75rem;
            margin-bottom: 1rem;
          }
          .compact-card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
          }
          .compact-card-chart {
            height: 280px;
          }
          .policy-grid-minimal {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1rem;
          }
          .policy-card-minimal {
            background: #fff;
            border-radius: 0.75rem;
            border: 1px solid #f3f4f6;
            height: 300px;
            display: flex;
            flex-direction: column;
          }
          .policy-header-minimal {
            padding: 0.75rem;
            border-bottom: 1px solid #f3f4f6;
            background: #fff;
            z-index: 1;
          }
          .policy-list-minimal {
            flex: 1;
            overflow-y: auto;
            padding: 0.75rem;
            scrollbar-width: thin;
            scrollbar-color: transparent transparent;
          }
          .policy-list-minimal::-webkit-scrollbar {
            width: 4px;
          }
          .policy-list-minimal::-webkit-scrollbar-track {
            background: transparent;
          }
          .policy-list-minimal::-webkit-scrollbar-thumb {
            background-color: transparent;
            border-radius: 20px;
          }
          .policy-list-minimal:hover::-webkit-scrollbar-thumb {
            background-color: #cbd5e0;
          }
          .policy-item-minimal {
            display: flex;
            align-items: center;
            padding: 0.5rem;
            border-radius: 0.5rem;
            transition: background-color 0.2s;
          }
          .policy-item-minimal:hover {
            background-color: #f9fafb;
          }
          @media (max-width: 900px) {
            .main-content-row {
              flex-direction: column;
            }
            .stats-column {
              width: 100%;
              flex-direction: row;
              flex-wrap: wrap;
            }
            .stat-card-minimal {
              flex: 1 1 200px;
            }
            .policy-grid-minimal {
              grid-template-columns: 1fr;
            }
          }
          @media (max-width: 500px) {
            .stats-column {
              flex-direction: column;
            }
            .stat-card-minimal {
              flex: 1 1 100%;
            }
          }
        `}</style>
      </div>
    );
  }

  if (variant === "environment") {
    return (
      <div className="environment-dashboard-minimal">
        {/* Filters Section */}
        <div className="filters-section-minimal">
          <Skeleton height="48px" width="100%" />
        </div>

        {/* Main Content Row */}
        <div className="main-content-row">
          {/* Stats Column */}
          <div className="stats-column">
            {Array.from({ length: 3 }).map((_, index) => (
              <EnvironmentStatSkeleton key={index} />
            ))}
          </div>

          {/* Charts Column */}
          <div className="charts-column">
            <div className="compact-cards-row">
              <EnvironmentChartSkeleton />
              <EnvironmentChartSkeleton />
            </div>

            <div className="compact-cards-row">
              <EnvironmentCompactCardSkeleton />
              <EnvironmentCompactCardSkeleton />
            </div>
          </div>
        </div>

        <style jsx>{`
          .environment-dashboard-minimal {
            padding: 1rem 0.5rem;
            background: #fafbfc;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
          }
          .filters-section-minimal {
            margin-bottom: 1rem;
            background: none;
            border: none;
            box-shadow: none;
            padding: 0;
          }
          .main-content-row {
            display: flex;
            gap: 1rem;
            margin-bottom: 1rem;
          }
          .stats-column {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
            width: 25%;
          }
          .stat-card-minimal {
            flex: 1;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: #fff;
            border-radius: 0.75rem;
            padding: 0.75rem;
            box-shadow: none;
            border: 1px solid #f3f4f6;
            height: 80px;
          }
          .charts-column {
            flex: 1;
          }
          .compact-cards-row {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
          }
          .compact-card {
            background: #fff;
            border-radius: 0.75rem;
            border: 1px solid #f3f4f6;
            box-shadow: none;
            flex: 1 1 calc(50% - 0.375rem);
            min-width: 280px;
            display: flex;
            flex-direction: column;
            padding: 0.75rem;
            position: relative;
            min-height: 220px;
          }
          .compact-card.chart-card {
            flex: 1 1 calc(50% - 0.375rem);
            min-width: 280px;
            min-height: 200px;
          }
          .compact-card-header {
            width: 100%;
            text-align: center;
            margin-bottom: 0.25rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 0.5rem;
          }
          .compact-card-chart {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            flex: 1;
            width: 100%;
            padding-bottom: 2rem;
          }
          .compact-card-chart.pie-chart {
            flex-direction: row;
            justify-content: space-between;
            padding: 0.5rem;
            height: 100%;
          }
          .compact-card-legend.pie-legend {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 0.35rem;
            padding: 0.5rem;
            max-width: 140px;
            justify-content: center;
          }
          .compact-legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.25rem 0;
          }
          .view-detailed-container {
            width: 100%;
            display: flex;
            justify-content: center;
            padding-top: 0.4rem;
            border-top: 1px solid #f1f5f9;
            position: absolute;
            bottom: 0;
            left: 0;
            background: #fff;
            padding-bottom: 0.4rem;
          }
          @media (max-width: 900px) {
            .main-content-row {
              flex-direction: column;
            }
            .stats-column {
              width: 100%;
              flex-direction: row;
            }
            .stat-card-minimal {
              flex: 1 1 200px;
            }
            .compact-card {
              flex: 1 1 100%;
            }
            .compact-card.chart-card {
              flex: 1 1 100%;
            }
          }
          @media (max-width: 500px) {
            .stats-column {
              flex-direction: column;
            }
            .stat-card-minimal {
              flex: 1 1 100%;
            }
          }
        `}</style>
      </div>
    );
  }

  if (variant === "general") {
    return (
      <VStack spacing={6} align="stretch">
        <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
          <GeneralStatSkeleton />
          <GeneralStatSkeleton />
          <GeneralStatSkeleton />
          <GeneralStatSkeleton />
        </SimpleGrid>

        <Box
          bg="white"
          boxShadow="sm"
          borderRadius="2xl"
          p={6}
          border="1px solid"
          borderColor="gray.200"
        >
          <Skeleton height="24px" width="180px" mb={4} />
          <VStack spacing={4} align="stretch">
            <GeneralAssessmentSkeleton />
            <CarbonNeutralityPlanSkeleton />
          </VStack>
        </Box>
      </VStack>
    );
  }

  if (variant === "carbon-neutrality-plan") {
    return (
      <VStack spacing={6} align="stretch" w="full">
        <VStack spacing={4} align="stretch">
          {Array.from({ length: count }).map((_, index) => (
            <CarbonNeutralityPlanSkeleton key={index} />
          ))}
        </VStack>
      </VStack>
    );
  }

  if (variant === "reports") {
    return (
      <Box
        bg="white"
        borderRadius="2xl"
        boxShadow="lg"
        overflowX="auto"
        px={{ base: 2, md: 6 }}
        py={6}
        maxW="100%"
        border="1px solid"
        borderColor="gray.100"
      >
        <Table
          variant="striped"
          colorScheme="gray"
          size="md"
          sx={{
            "th, td": { whiteSpace: "nowrap" },
            th: {
              position: "sticky",
              top: 0,
              zIndex: 1,
              bg: "primary.50",
            },
          }}
        >
          <Thead>
            <Tr>
              <Th fontSize="sm" color="gray.600" fontWeight="bold">
                Framework
              </Th>
              <Th fontSize="sm" color="gray.600" fontWeight="bold">
                Period
              </Th>
              <Th fontSize="sm" color="gray.600" fontWeight="bold">
                Status
              </Th>
              <Th fontSize="sm" color="gray.600" fontWeight="bold">
                Remarks
              </Th>
              <Th fontSize="sm" color="gray.600" fontWeight="bold">
                Requested At
              </Th>
              <Th fontSize="sm" color="gray.600" fontWeight="bold">
                Requested By
              </Th>
              <Th
                fontSize="sm"
                color="gray.600"
                fontWeight="bold"
                textAlign="center"
              >
                Download
              </Th>
            </Tr>
          </Thead>
          <Tbody>
            {Array.from({ length: count }).map((_, idx) => (
              <Tr key={idx}>
                <Td>
                  <Skeleton height="20px" width="80px" />
                </Td>
                <Td>
                  <Skeleton height="20px" width="60px" />
                </Td>
                <Td>
                  <Skeleton height="24px" width="70px" borderRadius="md" />
                </Td>
                <Td>
                  <Skeleton height="20px" width="120px" />
                </Td>
                <Td>
                  <Skeleton height="20px" width="100px" />
                </Td>
                <Td>
                  <VStack align="start" spacing={1}>
                    <Skeleton height="16px" width="80px" />
                    <Skeleton height="12px" width="120px" />
                  </VStack>
                </Td>
                <Td textAlign="center">
                  <Skeleton height="32px" width="90px" borderRadius="md" />
                </Td>
              </Tr>
            ))}
          </Tbody>
        </Table>
      </Box>
    );
  }

  return (
    <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
      {Array.from({ length: count }).map((_, index) => (
        <CardSkeleton key={index} />
      ))}
    </SimpleGrid>
  );
};

export default ShimmerLoader;
