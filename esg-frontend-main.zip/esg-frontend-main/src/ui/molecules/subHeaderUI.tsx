import { HStack } from "@chakra-ui/react";
import { LucideFile, LucideGitBranch, LucideCalendar } from "lucide-react";
import { Text } from "@chakra-ui/react";

const SubHeaderUI = ({ assessment }: { assessment: any }) => {
  console.log("assessment", assessment);
  return (
    <HStack style={{ marginTop: "5px" }}>
      <div style={{ display: "flex", gap: "5px" }}>
        <LucideFile size={"20"} />
        <Text>{assessment.title}</Text>
      </div>
      {assessment?.branch && (
        <div style={{ display: "flex", gap: "5px" }}>
          <LucideGitBranch size={"20"} />
          <Text>{assessment?.branch?.branch_name}</Text>
        </div>
      )}
      {assessment?.assessment_year && assessment?.assessment_month && (
        <div style={{ display: "flex", marginLeft: "10px", gap: "5px" }}>
          <LucideCalendar size={"20"} />
          <Text>
            {assessment?.assessment_year}/{assessment?.assessment_month}
          </Text>
        </div>
      )}
    </HStack>
  );
};

export default SubHeaderUI;
