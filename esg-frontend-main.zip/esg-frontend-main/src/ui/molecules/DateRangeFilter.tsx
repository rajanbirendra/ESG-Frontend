import {
  Popover,
  PopoverTrigger,
  PopoverContent,
  Box,
  Button,
  VStack,
  PopoverArrow,
  PopoverCloseButton,
  Select,
  HStack,
  Text,
  Flex,
  Icon,
} from "@chakra-ui/react";
import { format, addDays, addMonths } from "date-fns";
import { useState } from "react";
import { ChevronDownIcon } from "@chakra-ui/icons";
import { Calendar, ChevronLeft, ChevronRight } from "lucide-react";

interface DateRangeFilterProps {
  onApply: (startDate: string | undefined, endDate: string | undefined) => void;
  onCancel: () => void;
  onOpen?: () => void;
  onClose?: () => void;
}

export default function DateRangePicker({
  onApply,
  onCancel,
  onOpen,
  onClose,
}: DateRangeFilterProps) {
  const [selectedRange, setSelectedRange] = useState<{
    from: string | undefined;
    to: string | undefined;
  }>(() => {
    const today = new Date();
    const startOfYear = new Date(today.getFullYear(), 0, 1);
    return {
      from: format(startOfYear, "yyyy/MM/dd"),
      to: format(today, "yyyy/MM/dd"),
    };
  });
  const [open, setOpen] = useState(false);

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 10 }, (_, i) => currentYear - 5 + i);
  const months = [
    { value: 0, label: "January" },
    { value: 1, label: "February" },
    { value: 2, label: "March" },
    { value: 3, label: "April" },
    { value: 4, label: "May" },
    { value: 5, label: "June" },
    { value: 6, label: "July" },
    { value: 7, label: "August" },
    { value: 8, label: "September" },
    { value: 9, label: "October" },
    { value: 10, label: "November" },
    { value: 11, label: "December" },
  ];

  const predefinedRanges = [
    {
      label: "This Month",
      getRange: () => {
        const start = new Date();
        start.setDate(1);
        const end = new Date();
        return {
          from: format(start, "yyyy/MM/dd"),
          to: format(end, "yyyy/MM/dd"),
        };
      },
    },
    {
      label: "Last 3 Months",
      getRange: () => {
        const end = new Date();
        const start = new Date();
        start.setMonth(start.getMonth() - 2);
        start.setDate(1);
        return {
          from: format(start, "yyyy/MM/dd"),
          to: format(end, "yyyy/MM/dd"),
        };
      },
    },
    {
      label: "Last 6 Months",
      getRange: () => {
        const end = new Date();
        const start = new Date();
        start.setMonth(start.getMonth() - 5);
        start.setDate(1);
        return {
          from: format(start, "yyyy/MM/dd"),
          to: format(end, "yyyy/MM/dd"),
        };
      },
    },
    {
      label: "This Year",
      getRange: () => {
        const today = new Date();
        const startOfYear = new Date(today.getFullYear(), 0, 1);
        return {
          from: format(startOfYear, "yyyy/MM/dd"),
          to: format(today, "yyyy/MM/dd"),
        };
      },
    },
    {
      label: "Last 3 Years",
      getRange: () => {
        const end = new Date();
        const start = new Date();
        start.setFullYear(start.getFullYear() - 2);
        start.setMonth(0);
        start.setDate(1);
        return {
          from: format(start, "yyyy/MM/dd"),
          to: format(end, "yyyy/MM/dd"),
        };
      },
    },
  ];

  const displayRange = selectedRange?.from
    ? `${format(new Date(selectedRange.from), "MMM yyyy")} - ${
        selectedRange.to
          ? format(new Date(selectedRange.to), "MMM yyyy")
          : format(new Date(selectedRange.from), "MMM yyyy")
      }`
    : "Select Date Range";

  const handleToggle = () => {
    const willOpen = !open;
    setOpen(willOpen);
    if (willOpen && onOpen) {
      onOpen();
    } else if (!willOpen && onClose) {
      onClose();
    }
  };

  const handleClose = () => {
    setOpen(false);
    if (onClose) {
      onClose();
    }
  };

  const handleApply = () => {
    onApply(selectedRange?.from, selectedRange?.to);
    handleClose();
  };

  const handleCancel = () => {
    onCancel();
    handleClose();
  };

  const applyPredefinedRange = (range: { from: string; to: string }) => {
    setSelectedRange(range);
  };

  const handleYearMonthChange = (
    type: "from" | "to",
    year: number,
    month: number
  ) => {
    const date = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);

    setSelectedRange((prev) => ({
      ...prev,
      [type]:
        type === "from"
          ? format(date, "yyyy/MM/dd")
          : format(lastDay, "yyyy/MM/dd"),
    }));
  };

  return (
    <Popover
      isOpen={open}
      onClose={handleClose}
      placement="bottom-end"
      closeOnBlur={false}
    >
      <PopoverTrigger>
        <Button
          onClick={handleToggle}
          rightIcon={<ChevronDownIcon />}
          leftIcon={<Icon as={Calendar} boxSize={4} />}
          variant="outline"
          size="sm"
          bg="white"
          borderColor="gray.200"
          _hover={{ borderColor: "gray.300", bg: "gray.50" }}
          _active={{ bg: "gray.100" }}
          fontWeight="medium"
          color="gray.700"
          px={4}
          h="36px"
          borderRadius="md"
          boxShadow="sm"
        >
          {displayRange}
        </Button>
      </PopoverTrigger>
      <PopoverContent
        p={0}
        w="600px"
        shadow="lg"
        borderRadius="lg"
        border="1px solid"
        borderColor="gray.200"
        _focus={{ outline: "none" }}
        zIndex={40000000000}
      >
        <PopoverArrow />
        <PopoverCloseButton
          size="sm"
          color="gray.500"
          _hover={{ color: "gray.700" }}
        />
        <Box p={4}>
          <Flex gap={6}>
            <VStack
              align="start"
              spacing={2}
              borderRight="1px solid"
              borderColor="gray.200"
              pr={4}
              minW="180px"
            >
              <Text
                fontSize="sm"
                fontWeight="medium"
                color="gray.600"
                mb={1}
                px={2}
              >
                Quick Select
              </Text>
              {predefinedRanges.map((range) => (
                <Button
                  key={range.label}
                  size="sm"
                  variant="ghost"
                  onClick={() => applyPredefinedRange(range.getRange())}
                  w="full"
                  justifyContent="flex-start"
                  px={2}
                  h="32px"
                  fontSize="sm"
                  color="gray.700"
                  _hover={{ bg: "gray.50" }}
                  _active={{ bg: "gray.100" }}
                >
                  {range.label}
                </Button>
              ))}
            </VStack>

            <Box flex="1">
              <Flex direction="column" gap={4}>
                <Box>
                  <Text
                    fontSize="sm"
                    fontWeight="medium"
                    color="gray.600"
                    mb={2}
                  >
                    From
                  </Text>
                  <HStack spacing={2}>
                    <Select
                      value={
                        selectedRange.from
                          ? new Date(selectedRange.from).getFullYear()
                          : currentYear
                      }
                      onChange={(e) =>
                        handleYearMonthChange(
                          "from",
                          Number(e.target.value),
                          selectedRange.from
                            ? new Date(selectedRange.from).getMonth()
                            : 0
                        )
                      }
                      size="sm"
                      variant="filled"
                      bg="gray.50"
                      borderColor="gray.200"
                      _hover={{ borderColor: "gray.300" }}
                      _focus={{ borderColor: "blue.400", bg: "white" }}
                    >
                      {years.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </Select>
                    <Select
                      value={
                        selectedRange.from
                          ? new Date(selectedRange.from).getMonth()
                          : 0
                      }
                      onChange={(e) =>
                        handleYearMonthChange(
                          "from",
                          selectedRange.from
                            ? new Date(selectedRange.from).getFullYear()
                            : currentYear,
                          Number(e.target.value)
                        )
                      }
                      size="sm"
                      variant="filled"
                      bg="gray.50"
                      borderColor="gray.200"
                      _hover={{ borderColor: "gray.300" }}
                      _focus={{ borderColor: "blue.400", bg: "white" }}
                    >
                      {months.map((month) => (
                        <option key={month.value} value={month.value}>
                          {month.label}
                        </option>
                      ))}
                    </Select>
                  </HStack>
                </Box>

                <Box>
                  <Text
                    fontSize="sm"
                    fontWeight="medium"
                    color="gray.600"
                    mb={2}
                  >
                    To
                  </Text>
                  <HStack spacing={2}>
                    <Select
                      value={
                        selectedRange.to
                          ? new Date(selectedRange.to).getFullYear()
                          : currentYear
                      }
                      onChange={(e) =>
                        handleYearMonthChange(
                          "to",
                          Number(e.target.value),
                          selectedRange.to
                            ? new Date(selectedRange.to).getMonth()
                            : 0
                        )
                      }
                      size="sm"
                      variant="filled"
                      bg="gray.50"
                      borderColor="gray.200"
                      _hover={{ borderColor: "gray.300" }}
                      _focus={{ borderColor: "blue.400", bg: "white" }}
                    >
                      {years.map((year) => (
                        <option key={year} value={year}>
                          {year}
                        </option>
                      ))}
                    </Select>
                    <Select
                      value={
                        selectedRange.to
                          ? new Date(selectedRange.to).getMonth()
                          : 0
                      }
                      onChange={(e) =>
                        handleYearMonthChange(
                          "to",
                          selectedRange.to
                            ? new Date(selectedRange.to).getFullYear()
                            : currentYear,
                          Number(e.target.value)
                        )
                      }
                      size="sm"
                      variant="filled"
                      bg="gray.50"
                      borderColor="gray.200"
                      _hover={{ borderColor: "gray.300" }}
                      _focus={{ borderColor: "blue.400", bg: "white" }}
                    >
                      {months.map((month) => (
                        <option key={month.value} value={month.value}>
                          {month.label}
                        </option>
                      ))}
                    </Select>
                  </HStack>
                </Box>
              </Flex>
            </Box>
          </Flex>
        </Box>
        <Flex
          justify="flex-end"
          p={3}
          borderTop="1px solid"
          borderColor="gray.200"
          bg="gray.50"
          borderBottomRadius="lg"
        >
          <HStack spacing={2}>
            <Button
              size="sm"
              variant="ghost"
              onClick={handleCancel}
              color="gray.600"
              _hover={{ bg: "gray.100" }}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              colorScheme="blue"
              onClick={handleApply}
              bg="blue.500"
              _hover={{ bg: "blue.600" }}
            >
              Apply
            </Button>
          </HStack>
        </Flex>
      </PopoverContent>
    </Popover>
  );
}
