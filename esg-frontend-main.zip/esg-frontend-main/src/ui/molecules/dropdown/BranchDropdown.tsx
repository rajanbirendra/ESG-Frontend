import {
  Box,
  Input,
  InputGroup,
  InputLeftElement,
  List,
  ListItem,
  Text,
  useOutsideClick,
  Flex,
  Icon,
  Spinner,
  Badge,
} from "@chakra-ui/react";
import { Search, Building, ChevronDown } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useCompanyAPI } from "@/query/use-company";

interface Branch {
  id: string;
  branch_name: string;
  country: string;
  state: string;
  company_id: string;
  created_at: string;
  updated_at: string;
}

interface BranchDropdownProps {
  value: string | null;
  onChange: (branchId: string | null) => void;
  error?: string | undefined;
  isDisabled?: boolean;
  label?: string;
}

export default function BranchDropdown({
  value,
  onChange,
  error,
  isDisabled = false,
  label = "Branch",
}: BranchDropdownProps) {
  const [branchSearch, setBranchSearch] = useState("");
  const [debouncedBranchSearch, setDebouncedBranchSearch] = useState("");
  const [selectedBranchName, setSelectedBranchName] =
    useState<string>("Select Branch");
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedBranchSearch(branchSearch);
    }, 300);
    return () => clearTimeout(handler);
  }, [branchSearch]);

  const { getAllCompanyBranches } = useCompanyAPI();
  const { data: branches, isLoading: isLoadingBranches } =
    getAllCompanyBranches(
      // @ts-ignore
      {}
    ) as {
      data: { data: Branch[] };
      isLoading: boolean;
    };

  const filteredBranches =
    (branches as any)?.filter((branch) =>
      branch.branch_name
        .toLowerCase()
        .includes(debouncedBranchSearch.toLowerCase())
    ) || [];

  // Update selected branch name when value (branch ID) changes
  useEffect(() => {
    if (!value) {
      setSelectedBranchName("Select Branch");
      return;
    }

    if (branches?.data) {
      const branch = branches.data.find((b) => b.id === value);
      if (branch) {
        setSelectedBranchName(branch.branch_name);
      }
    }
  }, [value, branches?.data]);

  useOutsideClick({
    ref: dropdownRef,
    handler: () => setIsOpen(false),
  });

  const handleBranchSelect = (branchId: string | null, branchName: string) => {
    onChange(branchId);
    setSelectedBranchName(branchName);
    setBranchSearch("");
    setIsOpen(false);
  };

  return (
    <Box position="relative" ref={dropdownRef} maxW="300px">
      <InputGroup>
        <InputLeftElement pointerEvents="none">
          <Icon as={Building} color="gray.500" boxSize={5} />
        </InputLeftElement>
        <Input
          value={selectedBranchName}
          onClick={() => setIsOpen(true)}
          readOnly
          placeholder="Select branch"
          cursor="pointer"
          bg="white"
          height="40px"
          isDisabled={isDisabled || isLoadingBranches}
          borderColor="gray.200"
          _hover={{ borderColor: "gray.300" }}
          _focus={{ borderColor: "blue.400", boxShadow: "none" }}
          pr="2.5rem"
          borderRadius="md"
          fontSize="sm"
          fontWeight="medium"
          color="gray.700"
        />
        <Box
          position="absolute"
          right="0.75rem"
          top="50%"
          transform="translateY(-50%)"
          pointerEvents="none"
          color="gray.500"
        >
          <Icon as={ChevronDown} boxSize={4} />
        </Box>
      </InputGroup>

      {isOpen && (
        <Box
          position="absolute"
          top="calc(100% + 0.5rem)"
          left={0}
          right={0}
          bg="white"
          borderRadius="lg"
          boxShadow="lg"
          zIndex={10}
          maxH="320px"
          overflowY="auto"
          border="1px solid"
          borderColor="gray.200"
        >
          <Box p={2} borderBottom="1px solid" borderColor="gray.100">
            <InputGroup size="sm">
              <InputLeftElement pointerEvents="none">
                <Icon as={Search} color="gray.500" boxSize={4} />
              </InputLeftElement>
              <Input
                placeholder="Search branches..."
                value={branchSearch}
                onChange={(e) => setBranchSearch(e.target.value)}
                size="sm"
                autoFocus
                bg="gray.50"
                borderColor="gray.200"
                _hover={{ borderColor: "gray.300" }}
                _focus={{
                  borderColor: "blue.400",
                  bg: "white",
                  boxShadow: "none",
                }}
                borderRadius="md"
                fontSize="sm"
              />
            </InputGroup>
          </Box>

          <List spacing={0}>
            <ListItem
              px={3}
              py={2}
              cursor="pointer"
              display="flex"
              alignItems="center"
              bg={!value ? "blue.50" : "transparent"}
              _hover={{ bg: !value ? "blue.100" : "gray.50" }}
              onClick={() => handleBranchSelect(null, "Select Branch")}
              borderBottom="1px solid"
              borderColor="gray.100"
            >
              <Text
                color={!value ? "blue.600" : "gray.700"}
                fontWeight={!value ? "medium" : "normal"}
                fontSize="sm"
              >
                Select Branch
              </Text>
            </ListItem>
            {isLoadingBranches ? (
              <ListItem px={3} py={4} display="flex" justifyContent="center">
                <Spinner size="sm" color="blue.500" />
              </ListItem>
            ) : filteredBranches.length === 0 ? (
              <ListItem px={3} py={4} textAlign="center">
                <Text fontSize="sm" color="gray.500">
                  No branches found
                </Text>
              </ListItem>
            ) : (
              filteredBranches.map((branch) => (
                <ListItem
                  key={branch.id}
                  px={3}
                  py={2}
                  cursor="pointer"
                  display="flex"
                  flexDirection="column"
                  bg={value === branch.id ? "blue.50" : "transparent"}
                  _hover={{ bg: value === branch.id ? "blue.100" : "gray.50" }}
                  onClick={() =>
                    handleBranchSelect(branch.id, branch.branch_name)
                  }
                  borderBottom="1px solid"
                  borderColor="gray.100"
                >
                  <Flex justify="space-between" align="center" w="full">
                    <Text
                      color={value === branch.id ? "blue.600" : "gray.700"}
                      fontWeight={value === branch.id ? "medium" : "normal"}
                      fontSize="sm"
                    >
                      {branch.branch_name}
                    </Text>
                    {value === branch.id && (
                      <Badge colorScheme="blue" variant="subtle" fontSize="xs">
                        Selected
                      </Badge>
                    )}
                  </Flex>
                  <Text fontSize="xs" color="gray.500" mt={0.5}>
                    {branch.country}, {branch.state}
                  </Text>
                </ListItem>
              ))
            )}
          </List>
        </Box>
      )}
    </Box>
  );
}
