import React, { useState, useRef, useEffect } from "react";
import {
  Box,
  Input,
  InputGroup,
  InputLeftElement,
  List,
  ListItem,
  Text,
  useOutsideClick,
  Checkbox,
  Flex,
  Button,
  useColorModeValue,
  Icon,
} from "@chakra-ui/react";
import { Search, CalendarDays, ChevronDown } from "lucide-react";

interface CustomYearDropdownProps {
  selectedYear: string;
  onSelectYear: (year: string) => void;
  years: string[]; // Array of years provided by user
  placeholder?: string;
}

interface MultiSelectCustomYearDropdownProps {
  selectedYears: string[];
  onSelectYears: (years: string[]) => void;
  years: string[]; // Array of years provided by user
  placeholder?: string;
}

const CustomYearDropdown: React.FC<CustomYearDropdownProps> = ({
  selectedYear,
  onSelectYear,
  years,
  placeholder = "Select year",
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  console.log("years", years);
  // Theme colors
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.600");
  const hoverBg = useColorModeValue("gray.50", "gray.700");
  const selectedBg = useColorModeValue("blue.50", "blue.900");
  const selectedColor = useColorModeValue("blue.600", "blue.200");
  const textColor = useColorModeValue("gray.700", "gray.200");
  const placeholderColor = useColorModeValue("gray.500", "gray.400");

  // Filter years based on search term
  const filteredYears = years?.filter((year) =>
    year.toString().includes(searchTerm)
  );

  useOutsideClick({
    ref: dropdownRef,
    handler: () => setIsOpen(false),
  });

  const handleYearSelect = (year: string) => {
    onSelectYear(year);
    setIsOpen(false);
    setSearchTerm("");
  };

  // Reset search when dropdown closes
  useEffect(() => {
    if (!isOpen) {
      setSearchTerm("");
    }
  }, [isOpen]);

  return (
    <Box position="relative" ref={dropdownRef} maxW="200px">
      <InputGroup>
        <InputLeftElement pointerEvents="none">
          <Icon as={CalendarDays} color={placeholderColor} boxSize={5} />
        </InputLeftElement>
        <Input
          value={selectedYear || ""}
          onClick={() => setIsOpen(true)}
          readOnly
          placeholder={placeholder}
          cursor="pointer"
          bg={bgColor}
          height="40px"
          borderRadius="md"
          border="1px solid"
          borderColor={borderColor}
          _hover={{ borderColor: "gray.300" }}
          _focus={{ borderColor: "blue.400", boxShadow: "none" }}
          pr="2.5rem"
          fontSize="sm"
          fontWeight="medium"
          color={textColor}
          _placeholder={{ color: placeholderColor }}
        />
        <Box
          position="absolute"
          right="0.75rem"
          top="50%"
          transform="translateY(-50%)"
          pointerEvents="none"
          color={placeholderColor}
        >
          <Icon as={ChevronDown} boxSize={4} />
        </Box>
      </InputGroup>

      {isOpen && (
        <Box
          position="absolute"
          top="calc(100% + 0.5rem)"
          left={0}
          right={0}
          bg={bgColor}
          borderRadius="lg"
          boxShadow="lg"
          zIndex={10}
          maxH="320px"
          overflowY="auto"
          border="1px solid"
          borderColor={borderColor}
        >
          <Box p={2} borderBottom="1px solid" borderColor="gray.100">
            <InputGroup size="sm">
              <InputLeftElement pointerEvents="none">
                <Icon as={Search} color={placeholderColor} boxSize={4} />
              </InputLeftElement>
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search year..."
                size="sm"
                autoFocus
                bg="gray.50"
                borderColor="gray.200"
                _hover={{ borderColor: "gray.300" }}
                _focus={{
                  borderColor: "blue.400",
                  bg: "white",
                  boxShadow: "none",
                }}
                borderRadius="md"
                fontSize="sm"
              />
            </InputGroup>
          </Box>

          <List spacing={0}>
            {/* Reset option */}
            <ListItem
              px={3}
              py={2}
              cursor="pointer"
              display="flex"
              bg={!selectedYear ? selectedBg : "transparent"}
              _hover={{
                bg: !selectedYear ? "blue.100" : "gray.50",
              }}
              onClick={() => handleYearSelect("")}
              borderBottom="1px solid"
              borderColor="gray.100"
            >
              <Text
                color={!selectedYear ? selectedColor : textColor}
                fontWeight={!selectedYear ? "medium" : "normal"}
                fontSize="sm"
                fontStyle="italic"
              >
                {placeholder}
              </Text>
            </ListItem>

            {filteredYears.length > 0 ? (
              filteredYears.map((year) => (
                <ListItem
                  key={year}
                  px={3}
                  py={2}
                  cursor="pointer"
                  display="flex"
                  bg={
                    selectedYear === year.toString()
                      ? selectedBg
                      : "transparent"
                  }
                  _hover={{
                    bg:
                      selectedYear === year.toString() ? "blue.100" : "gray.50",
                  }}
                  onClick={() => handleYearSelect(year)}
                  borderBottom="1px solid"
                  borderColor="gray.100"
                >
                  <Text
                    color={
                      selectedYear === year.toString()
                        ? selectedColor
                        : textColor
                    }
                    fontWeight={
                      selectedYear === year.toString() ? "medium" : "normal"
                    }
                    fontSize="sm"
                  >
                    {year}
                  </Text>
                </ListItem>
              ))
            ) : (
              <ListItem px={3} py={4} textAlign="center">
                <Text color="gray.500" fontSize="sm">
                  No years found
                </Text>
              </ListItem>
            )}
          </List>
        </Box>
      )}
    </Box>
  );
};

const MultiSelectCustomYearDropdown: React.FC<
  MultiSelectCustomYearDropdownProps
> = ({ selectedYears, onSelectYears, years, placeholder = "Select years" }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Theme colors
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.600");
  const hoverBg = useColorModeValue("gray.50", "gray.700");
  const textColor = useColorModeValue("gray.700", "gray.200");
  const placeholderColor = useColorModeValue("gray.500", "gray.400");

  // Filter years based on search term
  const filteredYears = years?.filter((year) =>
    year.toString().includes(searchTerm)
  );

  useOutsideClick({
    ref: dropdownRef,
    handler: () => setIsOpen(false),
  });

  const handleYearToggle = (year: string) => {
    const newSelectedYears = selectedYears.includes(year)
      ? selectedYears.filter((y) => y !== year)
      : [...selectedYears, year];
    onSelectYears(newSelectedYears);
  };

  const handleSelectAll = () => {
    onSelectYears([...years]);
  };

  const handleClearAll = () => {
    onSelectYears([]);
  };

  // Reset search when dropdown closes
  useEffect(() => {
    if (!isOpen) {
      setSearchTerm("");
    }
  }, [isOpen]);

  return (
    <Box position="relative" ref={dropdownRef} width="250px">
      <InputGroup>
        <InputLeftElement pointerEvents="none">
          <Icon as={CalendarDays} color={placeholderColor} boxSize={5} />
        </InputLeftElement>
        <Input
          value={
            selectedYears.length === 0
              ? placeholder
              : selectedYears.length === 1
              ? selectedYears[0]
              : `${selectedYears.length} years selected`
          }
          onClick={() => setIsOpen(true)}
          readOnly
          placeholder={placeholder}
          cursor="pointer"
          bg={bgColor}
          height="40px"
          borderRadius="md"
          border="1px solid"
          borderColor={borderColor}
          _hover={{ borderColor: "gray.300" }}
          _focus={{ borderColor: "blue.400", boxShadow: "none" }}
          pr="2.5rem"
          fontSize="sm"
          fontWeight="medium"
          color={textColor}
          _placeholder={{ color: placeholderColor }}
        />
        <Box
          position="absolute"
          right="0.75rem"
          top="50%"
          transform="translateY(-50%)"
          pointerEvents="none"
          color={placeholderColor}
        >
          <Icon as={ChevronDown} boxSize={4} />
        </Box>
      </InputGroup>

      {isOpen && (
        <Box
          position="absolute"
          top="calc(100% + 0.5rem)"
          left={0}
          right={0}
          bg={bgColor}
          borderRadius="lg"
          boxShadow="lg"
          zIndex={10}
          maxH="320px"
          overflowY="auto"
          border="1px solid"
          borderColor={borderColor}
        >
          <Flex p={2} gap={2} borderBottom="1px solid" borderColor="gray.100">
            <Button
              size="sm"
              onClick={handleSelectAll}
              variant="ghost"
              colorScheme="blue"
              fontSize="sm"
              fontWeight="medium"
              _hover={{ bg: hoverBg }}
            >
              Select All
            </Button>
            <Button
              size="sm"
              onClick={handleClearAll}
              variant="ghost"
              colorScheme="blue"
              fontSize="sm"
              fontWeight="medium"
              _hover={{ bg: hoverBg }}
            >
              Clear All
            </Button>
          </Flex>

          <Box p={2} borderBottom="1px solid" borderColor="gray.100">
            <InputGroup size="sm">
              <InputLeftElement pointerEvents="none">
                <Icon as={Search} color={placeholderColor} boxSize={4} />
              </InputLeftElement>
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search year..."
                size="sm"
                autoFocus
                bg="gray.50"
                borderColor="gray.200"
                _hover={{ borderColor: "gray.300" }}
                _focus={{
                  borderColor: "blue.400",
                  bg: "white",
                  boxShadow: "none",
                }}
                borderRadius="md"
                fontSize="sm"
              />
            </InputGroup>
          </Box>

          <List spacing={0}>
            {filteredYears.length > 0 ? (
              filteredYears.map((year) => (
                <ListItem
                  key={year}
                  px={3}
                  py={2}
                  cursor="pointer"
                  display="flex"
                  alignItems="center"
                  _hover={{ bg: hoverBg }}
                  onClick={(e) => {
                    e.preventDefault();
                    handleYearToggle(year);
                  }}
                  borderBottom="1px solid"
                  borderColor="gray.100"
                >
                  <Checkbox
                    isChecked={selectedYears.includes(year)}
                    onChange={() => handleYearToggle(year)}
                    colorScheme="blue"
                    mr={2}
                  >
                    <Text color={textColor} fontSize="sm" fontWeight="medium">
                      {year}
                    </Text>
                  </Checkbox>
                </ListItem>
              ))
            ) : (
              <ListItem px={3} py={4} textAlign="center">
                <Text color="gray.500" fontSize="sm">
                  No years found
                </Text>
              </ListItem>
            )}
          </List>
        </Box>
      )}
    </Box>
  );
};

// Default export for backward compatibility
export default CustomYearDropdown;

// Named exports for both components
export { MultiSelectCustomYearDropdown };
