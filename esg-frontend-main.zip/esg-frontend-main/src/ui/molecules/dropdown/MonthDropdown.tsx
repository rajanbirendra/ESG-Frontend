import React, { useState } from "react";
import {
  Box,
  Button,
  Flex,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Text,
  useColorModeValue,
  InputGroup,
  InputLeftElement,
  Input,
} from "@chakra-ui/react";
import { ChevronDown, Calendar } from "lucide-react";

interface MonthDropdownProps {
  selectedMonth: number;
  onSelectMonth: (month: number) => void;
  label?: string;
}

interface MonthOption {
  value: number;
  label: string;
}

const months: MonthOption[] = [
  { value: 1, label: "January" },
  { value: 2, label: "February" },
  { value: 3, label: "March" },
  { value: 4, label: "April" },
  { value: 5, label: "May" },
  { value: 6, label: "June" },
  { value: 7, label: "July" },
  { value: 8, label: "August" },
  { value: 9, label: "September" },
  { value: 10, label: "October" },
  { value: 11, label: "November" },
  { value: 12, label: "December" },
];

const MonthDropdown: React.FC<MonthDropdownProps> = ({
  selectedMonth,
  onSelectMonth,
  label = "Select Month",
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const hoverBg = useColorModeValue("gray.50", "gray.700");
  const selectedBg = useColorModeValue("blue.50", "blue.900");
  const selectedColor = useColorModeValue("blue.600", "blue.200");

  const selectedMonthLabel =
    months.find((m) => m.value === selectedMonth)?.label || label;

  return (
    <Menu isOpen={isOpen} onClose={() => setIsOpen(false)} closeOnSelect={true}>
      <MenuButton
        as={Button}
        rightIcon={<ChevronDown size={20} />}
        variant="outline"
        size="md"
        width="full"
        onClick={() => setIsOpen(!isOpen)}
        bg={bgColor}
        borderColor={borderColor}
        _hover={{ bg: hoverBg, borderColor: "blue.400" }}
        _active={{ bg: hoverBg }}
        height="40px"
        p={0}
        borderRadius="md"
      >
        <InputGroup>
          <InputLeftElement pointerEvents="none">
            <Calendar size={20} style={{ color: "gray.500" }} />
          </InputLeftElement>
          <Input
            value={selectedMonthLabel}
            readOnly
            placeholder={label}
            cursor="pointer"
            bg="transparent"
            height="40px"
            border="none"
            _hover={{ border: "none" }}
            _focus={{ border: "none", boxShadow: "none" }}
            pl={10}
            fontSize="sm"
          />
        </InputGroup>
      </MenuButton>
      <MenuList
        bg={bgColor}
        borderColor={borderColor}
        boxShadow="lg"
        minW="200px"
        maxH="300px"
        overflowY="auto"
        p={0}
        borderRadius="md"
      >
        {months.map((month) => (
          <MenuItem
            key={month.value}
            onClick={() => {
              onSelectMonth(month.value);
              setIsOpen(false);
            }}
            bg={selectedMonth === month.value ? selectedBg : bgColor}
            color={selectedMonth === month.value ? selectedColor : "inherit"}
            _hover={{ bg: hoverBg }}
            p={2}
            px={4}
            py={2}
            fontSize="sm"
          >
            {month.label}
          </MenuItem>
        ))}
      </MenuList>
    </Menu>
  );
};

export default MonthDropdown;
