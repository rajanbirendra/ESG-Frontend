import { useMiscAPI } from "@/query/use-misc";
import {
  Box,
  Button,
  Divider,
  FormControl,
  FormLabel,
  Input,
  InputGroup,
  InputLeftElement,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Text,
  Icon,
  Spinner,
  Flex,
} from "@chakra-ui/react";
import { ChevronDown, Search, Globe } from "lucide-react";
import { useState } from "react";

interface CountryDropdownProps {
  selectedCountry: string;
  onCountryChange: (country: string) => void;
  disabled?: boolean;
}

const CountryDropdown = ({
  selectedCountry,
  onCountryChange,
  disabled = false,
}: CountryDropdownProps) => {
  // Country dropdown state
  const [countrySearch, setCountrySearch] = useState("");
  const [isCountryOpen, setIsCountryOpen] = useState(false);

  // Fetch country list
  const { data: countryList, isLoading: isLoadingCountryList } =
    useMiscAPI().getCountryList;

  const filteredCountries = (countryList as { data: string[] })?.data?.filter(
    (country) => country.toLowerCase().includes(countrySearch.toLowerCase())
  );

  return (
    <FormControl>
      <FormLabel fontSize="sm" fontWeight="medium" color="gray.700" mb={1.5}>
        Country
      </FormLabel>
      <Menu
        isOpen={isCountryOpen}
        onClose={() => setIsCountryOpen(false)}
        closeOnSelect={false}
      >
        <MenuButton
          as={Button}
          rightIcon={<Icon as={ChevronDown} boxSize={4} />}
          leftIcon={<Icon as={Globe} boxSize={4} color="gray.500" />}
          width="full"
          textAlign="left"
          isDisabled={isLoadingCountryList || disabled}
          onClick={() => setIsCountryOpen(true)}
          fontWeight="medium"
          fontSize="sm"
          height="40px"
          bg="white"
          border="1px solid"
          borderColor="gray.200"
          _hover={{ borderColor: "gray.300", bg: "gray.50" }}
          _active={{ bg: "gray.100" }}
          _disabled={{
            opacity: 0.7,
            cursor: "not-allowed",
            bg: "gray.50",
          }}
        >
          {selectedCountry?.slice(0, 35) || "Select Country"}
        </MenuButton>
        <MenuList
          maxH="320px"
          overflowY="auto"
          p={0}
          border="1px solid"
          borderColor="gray.200"
          borderRadius="lg"
          boxShadow="lg"
        >
          <Box p={2} borderBottom="1px solid" borderColor="gray.100">
            <InputGroup size="sm">
              <InputLeftElement pointerEvents="none">
                <Icon as={Search} color="gray.500" boxSize={4} />
              </InputLeftElement>
              <Input
                placeholder="Search country..."
                value={countrySearch}
                onChange={(e) => setCountrySearch(e.target.value)}
                onClick={(e) => e.stopPropagation()}
                size="sm"
                bg="gray.50"
                borderColor="gray.200"
                _hover={{ borderColor: "gray.300" }}
                _focus={{
                  borderColor: "blue.400",
                  bg: "white",
                  boxShadow: "none",
                }}
                borderRadius="md"
                fontSize="sm"
              />
            </InputGroup>
          </Box>
          <Divider />
          {isLoadingCountryList ? (
            <Flex py={4} justify="center">
              <Spinner size="sm" color="blue.500" />
            </Flex>
          ) : filteredCountries?.length === 0 ? (
            <Text py={4} textAlign="center" fontSize="sm" color="gray.500">
              No results found
            </Text>
          ) : (
            filteredCountries?.map((country) => (
              <MenuItem
                key={country}
                onClick={() => {
                  onCountryChange(country);
                  setCountrySearch("");
                  setIsCountryOpen(false);
                }}
                fontSize="sm"
                py={2}
                px={3}
                _hover={{ bg: "gray.50" }}
                _focus={{ bg: "gray.50" }}
              >
                {country}
              </MenuItem>
            ))
          )}
        </MenuList>
      </Menu>
    </FormControl>
  );
};

export default CountryDropdown;
