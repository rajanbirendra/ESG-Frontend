import { useMiscAPI } from "@/query/use-misc";
import {
  Box,
  Button,
  Divider,
  FormControl,
  FormLabel,
  Grid,
  GridItem,
  Input,
  InputGroup,
  InputLeftElement,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Text,
  Icon,
  Spinner,
  Flex,
} from "@chakra-ui/react";
import { ChevronDown, Search, MapPin } from "lucide-react";
import { useState } from "react";
import CountryDropdown from "./CountryDropdown";

interface CountryStateDropdownProps {
  selectedCountry: string;
  selectedState?: string;
  onCountryChange: (country: string) => void;
  onStateChange: (state: string) => void;
  disabled?: boolean;
}

const CountryStateDropdown = ({
  selectedCountry,
  selectedState,
  onCountryChange,
  onStateChange,
  disabled = false,
}: CountryStateDropdownProps) => {
  // State dropdown states
  const [stateSearch, setStateSearch] = useState("");
  const [isStateOpen, setIsStateOpen] = useState(false);

  // Fetch state list
  const { data: stateList, isLoading: isLoadingStateList } =
    useMiscAPI().getStateListByCountryName(selectedCountry ?? "");

  const filteredStates = (stateList as { data: string[] })?.data?.filter(
    (state) => state.toLowerCase().includes(stateSearch.toLowerCase())
  );

  return (
    <Grid templateColumns="repeat(2, 1fr)" gap={4}>
      <GridItem>
        <CountryDropdown
          selectedCountry={selectedCountry}
          onCountryChange={onCountryChange}
          disabled={disabled}
        />
      </GridItem>
      <GridItem>
        <FormControl>
          <FormLabel
            fontSize="sm"
            fontWeight="medium"
            color="gray.700"
            mb={1.5}
          >
            State/Province 
          </FormLabel>
          <Menu
            isOpen={isStateOpen}
            onClose={() => setIsStateOpen(false)}
            closeOnSelect={false}
          >
            <MenuButton
              as={Button}
              rightIcon={<Icon as={ChevronDown} boxSize={4} />}
              leftIcon={<Icon as={MapPin} boxSize={4} color="gray.500" />}
              width="full"
              textAlign="left"
              isDisabled={isLoadingStateList || !selectedCountry || disabled}
              onClick={() => setIsStateOpen(true)}
              fontWeight="medium"
              fontSize="sm"
              height="40px"
              bg="white"
              border="1px solid"
              borderColor="gray.200"
              _hover={{ borderColor: "gray.300", bg: "gray.50" }}
              _active={{ bg: "gray.100" }}
              _disabled={{
                opacity: 0.7,
                cursor: "not-allowed",
                bg: "gray.50",
              }}
            >
              {selectedState?.slice(0, 35) || "Select State/Province (Optional)"}
            </MenuButton>
            <MenuList
              maxH="320px"
              overflowY="auto"
              p={0}
              border="1px solid"
              borderColor="gray.200"
              borderRadius="lg"
              boxShadow="lg"
            >
              <Box p={2} borderBottom="1px solid" borderColor="gray.100">
                <InputGroup size="sm">
                  <InputLeftElement pointerEvents="none">
                    <Icon as={Search} color="gray.500" boxSize={4} />
                  </InputLeftElement>
                  <Input
                    placeholder="Search state..."
                    value={stateSearch}
                    onChange={(e) => setStateSearch(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    size="sm"
                    bg="gray.50"
                    borderColor="gray.200"
                    _hover={{ borderColor: "gray.300" }}
                    _focus={{
                      borderColor: "blue.400",
                      bg: "white",
                      boxShadow: "none",
                    }}
                    borderRadius="md"
                    fontSize="sm"
                  />
                </InputGroup>
              </Box>
              <Divider />
              {isLoadingStateList ? (
                <Flex py={4} justify="center">
                  <Spinner size="sm" color="blue.500" />
                </Flex>
              ) : filteredStates?.length === 0 ? (
                <Text py={4} textAlign="center" fontSize="sm" color="gray.500">
                  No results found
                </Text>
              ) : (
                filteredStates?.map((state) => (
                  <MenuItem
                    key={state}
                    onClick={() => {
                      onStateChange(state);
                      setStateSearch("");
                      setIsStateOpen(false);
                    }}
                    fontSize="sm"
                    py={2}
                    px={3}
                    _hover={{ bg: "gray.50" }}
                    _focus={{ bg: "gray.50" }}
                  >
                    {state}
                  </MenuItem>
                ))
              )}
            </MenuList>
          </Menu>
        </FormControl>
      </GridItem>
    </Grid>
  );
};

export default CountryStateDropdown;
