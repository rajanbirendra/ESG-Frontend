import React, { useState } from "react";
import {
  Box,
  Button,
  Checkbox,
  Flex,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Text,
  useColorModeValue,
  InputGroup,
  InputLeftElement,
  Input,
} from "@chakra-ui/react";
import { ChevronDown, Calendar } from "lucide-react";

interface MonthDropdownProps {
  selectedMonths: number[];
  onSelectMonths: (months: number[]) => void;
  label?: string;
}

interface MonthOption {
  value: number;
  label: string;
}

const months: MonthOption[] = [
  { value: 1, label: "January" },
  { value: 2, label: "February" },
  { value: 3, label: "March" },
  { value: 4, label: "April" },
  { value: 5, label: "May" },
  { value: 6, label: "June" },
  { value: 7, label: "July" },
  { value: 8, label: "August" },
  { value: 9, label: "September" },
  { value: 10, label: "October" },
  { value: 11, label: "November" },
  { value: 12, label: "December" },
];

const MonthDropdown: React.FC<MonthDropdownProps> = ({
  selectedMonths,
  onSelectMonths,
  label = "Select Months",
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const hoverBg = useColorModeValue("gray.50", "gray.700");

  const handleMonthToggle = (monthValue: number) => {
    const newSelectedMonths = selectedMonths.includes(monthValue)
      ? selectedMonths.filter((m) => m !== monthValue)
      : [...selectedMonths, monthValue];
    onSelectMonths(newSelectedMonths);
  };

  const handleSelectAll = () => {
    onSelectMonths(months.map((month) => month.value));
  };

  const handleClearAll = () => {
    onSelectMonths([]);
  };

  const getSelectedMonthLabels = () => {
    return selectedMonths
      .map((monthNum) => months.find((m) => m.value === monthNum)?.label)
      .filter(Boolean);
  };

  return (
    <Menu
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      closeOnSelect={false}
    >
      <MenuButton
        as={Button}
        rightIcon={<ChevronDown size={20} />}
        variant="outline"
        size="md"
        width="250px"
        onClick={() => setIsOpen(!isOpen)}
        bg={bgColor}
        borderColor={borderColor}
        _hover={{ bg: hoverBg }}
        _active={{ bg: hoverBg }}
        height="48px"
        p={0}
      >
        <InputGroup>
          <InputLeftElement pointerEvents="none">
            <Calendar
              size={25}
              style={{ color: "gray.500", marginTop: "5px" }}
            />
          </InputLeftElement>
          <Input
            value={
              selectedMonths.length === 0
                ? label
                : selectedMonths.length === 1
                ? months.find((m) => m.value === selectedMonths[0])?.label
                : `${selectedMonths.length} months selected`
            }
            readOnly
            placeholder={label}
            cursor="pointer"
            bg="transparent"
            height="48px"
            border="none"
            _hover={{ border: "none" }}
            _focus={{ border: "none", boxShadow: "none" }}
            pl={10}
          />
        </InputGroup>
      </MenuButton>
      <MenuList
        bg={bgColor}
        borderColor={borderColor}
        boxShadow="lg"
        minW="200px"
        maxH="300px"
        overflowY="auto"
        p={0}
      >
        <Flex p={2} gap={2} borderBottom="1px solid" borderColor={borderColor}>
          <Button size="sm" onClick={handleSelectAll} variant="ghost">
            Select All
          </Button>
          <Button size="sm" onClick={handleClearAll} variant="ghost">
            Clear All
          </Button>
        </Flex>
        {months.map((month) => (
          <MenuItem
            key={month.value}
            onClick={(e) => {
              e.preventDefault();
              handleMonthToggle(month.value);
            }}
            bg={bgColor}
            _hover={{ bg: hoverBg }}
            p={2}
            closeOnSelect={false}
            px={4}
            py={2}
          >
            <Checkbox
              isChecked={selectedMonths.includes(month.value)}
              onChange={() => handleMonthToggle(month.value)}
              colorScheme="blue"
              mr={2}
            >
              {month.label}
            </Checkbox>
          </MenuItem>
        ))}
      </MenuList>
    </Menu>
  );
};

export default MonthDropdown;
