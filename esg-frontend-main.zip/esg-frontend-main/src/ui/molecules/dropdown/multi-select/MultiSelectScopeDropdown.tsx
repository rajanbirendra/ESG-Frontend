import React, { useState, useRef, useEffect } from "react";
import {
  Box,
  Input,
  InputGroup,
  InputLeftElement,
  List,
  ListItem,
  Text,
  useOutsideClick,
  Checkbox,
  Flex,
  Button,
  useColorModeValue,
  Icon,
} from "@chakra-ui/react";
import { Search, Layers, ChevronDown } from "lucide-react";

interface MultiSelectScopeDropdownProps {
  selectedScopes: string[];
  onSelectScopes: (scopes: string[]) => void;
}

const MultiSelectScopeDropdown: React.FC<MultiSelectScopeDropdownProps> = ({
  selectedScopes,
  onSelectScopes,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Theme colors
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.600");
  const hoverBg = useColorModeValue("gray.50", "gray.700");
  const textColor = useColorModeValue("gray.700", "gray.200");
  const placeholderColor = useColorModeValue("gray.500", "gray.400");

  // Available scopes
  const scopes = [
    { value: "CNP_SCOPE_1", label: "Scope 1" },
    { value: "CNP_SCOPE_2", label: "Scope 2" },
    { value: "CNP_SCOPE_3", label: "Scope 3" },
  ];

  // Filter scopes based on search term
  const filteredScopes = scopes.filter((scope) =>
    scope.label.toLowerCase().includes(searchTerm.toLowerCase())
  );

  useOutsideClick({
    ref: dropdownRef,
    handler: () => setIsOpen(false),
  });

  const handleScopeToggle = (scopeValue: string) => {
    const newSelectedScopes = selectedScopes.includes(scopeValue)
      ? selectedScopes.filter((s) => s !== scopeValue)
      : [...selectedScopes, scopeValue];
    onSelectScopes(newSelectedScopes);
  };

  const handleSelectAll = () => {
    onSelectScopes(scopes.map((scope) => scope.value));
  };

  const handleClearAll = () => {
    onSelectScopes([]);
  };

  // Reset search when dropdown closes
  useEffect(() => {
    if (!isOpen) {
      setSearchTerm("");
    }
  }, [isOpen]);

  return (
    <Box position="relative" ref={dropdownRef} width="250px">
      <InputGroup>
        <InputLeftElement pointerEvents="none">
          <Icon as={Layers} color={placeholderColor} boxSize={5} />
        </InputLeftElement>
        <Input
          value={
            selectedScopes.length === 0
              ? "Select scopes"
              : selectedScopes.length === 1
              ? scopes.find((s) => s.value === selectedScopes[0])?.label ||
                selectedScopes[0]
              : `${selectedScopes.length} scopes selected`
          }
          onClick={() => setIsOpen(true)}
          readOnly
          placeholder="Select scopes"
          cursor="pointer"
          bg={bgColor}
          height="40px"
          borderRadius="md"
          border="1px solid"
          borderColor={borderColor}
          _hover={{ borderColor: "gray.300" }}
          _focus={{ borderColor: "blue.400", boxShadow: "none" }}
          pr="2.5rem"
          fontSize="sm"
          fontWeight="medium"
          color={textColor}
          _placeholder={{ color: placeholderColor }}
        />
        <Box
          position="absolute"
          right="0.75rem"
          top="50%"
          transform="translateY(-50%)"
          pointerEvents="none"
          color={placeholderColor}
        >
          <Icon as={ChevronDown} boxSize={4} />
        </Box>
      </InputGroup>

      {isOpen && (
        <Box
          position="absolute"
          top="calc(100% + 0.5rem)"
          left={0}
          right={0}
          bg={bgColor}
          borderRadius="lg"
          boxShadow="lg"
          zIndex={10}
          maxH="320px"
          overflowY="auto"
          border="1px solid"
          borderColor={borderColor}
        >
          <Flex p={2} gap={2} borderBottom="1px solid" borderColor="gray.100">
            <Button
              size="sm"
              onClick={handleSelectAll}
              variant="ghost"
              colorScheme="blue"
              fontSize="sm"
              fontWeight="medium"
              _hover={{ bg: hoverBg }}
            >
              Select All
            </Button>
            <Button
              size="sm"
              onClick={handleClearAll}
              variant="ghost"
              colorScheme="blue"
              fontSize="sm"
              fontWeight="medium"
              _hover={{ bg: hoverBg }}
            >
              Clear All
            </Button>
          </Flex>

          <Box p={2} borderBottom="1px solid" borderColor="gray.100">
            <InputGroup size="sm">
              <InputLeftElement pointerEvents="none">
                <Icon as={Search} color={placeholderColor} boxSize={4} />
              </InputLeftElement>
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search scopes..."
                size="sm"
                autoFocus
                bg="gray.50"
                borderColor="gray.200"
                _hover={{ borderColor: "gray.300" }}
                _focus={{
                  borderColor: "blue.400",
                  bg: "white",
                  boxShadow: "none",
                }}
                borderRadius="md"
                fontSize="sm"
              />
            </InputGroup>
          </Box>

          <List spacing={0}>
            {filteredScopes.map((scope) => (
              <ListItem
                key={scope.value}
                px={3}
                py={2}
                cursor="pointer"
                display="flex"
                alignItems="center"
                _hover={{ bg: hoverBg }}
                onClick={(e) => {
                  e.preventDefault();
                  handleScopeToggle(scope.value);
                }}
                borderBottom="1px solid"
                borderColor="gray.100"
              >
                <Checkbox
                  isChecked={selectedScopes.includes(scope.value)}
                  onChange={() => handleScopeToggle(scope.value)}
                  colorScheme="blue"
                  mr={2}
                >
                  <Text color={textColor} fontSize="sm" fontWeight="medium">
                    {scope.label}
                  </Text>
                </Checkbox>
              </ListItem>
            ))}
          </List>
        </Box>
      )}
    </Box>
  );
};

export default MultiSelectScopeDropdown;
