import {
  Box,
  Flex,
  Progress,
  Text,
  useColorModeValue,
  Tooltip,
  Popover,
  PopoverTrigger,
  PopoverContent,
  IconButton,
  Collapse,
} from "@chakra-ui/react";
import {
  CheckCircle2,
  AlertCircle,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import React, { useState } from "react";

const getStatusColor = (percentage: number) => {
  if (percentage === 100) return "green.500";
  if (percentage >= 75) return "blue.500";
  if (percentage >= 50) return "yellow.500";
  if (percentage >= 25) return "orange.500";
  return "red.500";
};

const getStatusIcon = (percentage: number) => {
  if (percentage === 100)
    return <CheckCircle2 size={20} color="var(--chakra-colors-green-500)" />;
  return <AlertCircle size={20} color={getStatusColor(percentage)} />;
};

export const MiniProgressBox = ({
  completion_percentage,
  answered_questions,
  total_questions,
}: {
  completion_percentage: number;
  answered_questions: number;
  total_questions: number;
}) => {
  return (
    <Box>
      <Flex justify="space-between" align="center" mb={2}>
        <Text fontSize="sm" color="gray.500">
          Progress
        </Text>
        <Text
          fontSize="sm"
          fontWeight="semibold"
          color={getStatusColor(completion_percentage)}
        >
          {completion_percentage?.toFixed(0)}%
        </Text>
      </Flex>
      <Progress
        value={completion_percentage}
        size="sm"
        borderRadius="full"
        colorScheme={completion_percentage === 100 ? "green" : "blue"}
        bg={useColorModeValue("gray.100", "gray.700")}
        mb={2}
      />
      <Flex justify="space-between" align="center">
        <Text fontSize="xs" color="gray.500">
          Questions
        </Text>
        <Text fontSize="xs" fontWeight="medium" color="gray.700">
          {answered_questions}/{total_questions}
        </Text>
      </Flex>
    </Box>
  );
};

const FullProgressBox = ({
  completion_percentage,
  answered_questions,
  total_questions,
  style,
}: {
  completion_percentage: number;
  answered_questions: number;
  total_questions: number;
  style?: React.CSSProperties;
}) => {
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const progressBg = useColorModeValue("gray.100", "gray.700");

  return (
    <Box
      p={4}
      bg={bgColor}
      borderRadius="lg"
      // border="1px solid"
      // borderColor={borderColor}
      // boxShadow="sm"
      maxW="md"
      mx="auto"
      width="80%"
      style={style}
    >
      <Flex justify="space-between" align="center" mb={4}>
        <Flex align="center" gap={2}>
          {getStatusIcon(completion_percentage)}
          <Text fontSize="md" fontWeight="small" color="gray.700">
            Completed Questions:
          </Text>
        </Flex>
        <Tooltip
          label={
            completion_percentage === 100
              ? "Assessment Completed!"
              : "Assessment in Progress"
          }
          placement="top"
        >
          <Text
            fontSize="lg"
            fontWeight="bold"
            color={getStatusColor(completion_percentage)}
          >
            {completion_percentage?.toFixed(0)}%
          </Text>
        </Tooltip>
      </Flex>

      <Progress
        value={completion_percentage}
        size="md"
        borderRadius="full"
        colorScheme={completion_percentage === 100 ? "green" : "blue"}
        bg={progressBg}
        mb={4}
        sx={{
          "& > div": {
            transition: "all 0.3s ease-in-out",
          },
        }}
      />

      <Flex
        justify="space-between"
        align="center"
        bg={useColorModeValue("gray.50", "gray.700")}
        p={3}
        borderRadius="md"
      >
        <Text fontSize="sm" color="gray.500">
          Questions Completed
        </Text>
        <Text fontSize="sm" fontWeight="semibold" color="gray.700">
          {answered_questions} of {total_questions}
        </Text>
      </Flex>
    </Box>
  );
};

// Main ProgressBox: one-liner with expand/collapse functionality
const ProgressBox = ({
  completion_percentage,
  answered_questions,
  total_questions,
  style,
}: {
  completion_percentage: number;
  answered_questions: number;
  total_questions: number;
  style?: React.CSSProperties;
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");

  return (
    <Box
      width="25%"
      borderRadius="lg"
      bg={bgColor}
      border="1px solid"
      borderColor={borderColor}
      boxShadow="sm"
      overflow="hidden"
      style={style}
    >
      {/* One-liner view */}
      <Flex
        p={3}
        align="center"
        justify="space-between"
        cursor="pointer"
        onClick={() => setIsExpanded(!isExpanded)}
        _hover={{ bg: useColorModeValue("gray.50", "gray.700") }}
      >
        <Flex align="center" gap={2} flex={1}>
          {getStatusIcon(completion_percentage)}
          <Text fontSize="sm" fontWeight="medium" color="gray.700">
            Progress
          </Text>
          <Progress
            value={completion_percentage}
            size="sm"
            flex={1}
            mx={4}
            borderRadius="full"
            colorScheme={completion_percentage === 100 ? "green" : "blue"}
            bg={useColorModeValue("gray.100", "gray.700")}
          />
          <Text
            fontSize="sm"
            fontWeight="semibold"
            color={getStatusColor(completion_percentage)}
          >
            {completion_percentage?.toFixed(0)}%
          </Text>
        </Flex>
        <IconButton
          aria-label={isExpanded ? "Minimize" : "Maximize"}
          icon={
            isExpanded ? <ChevronDown size={20} /> : <ChevronUp size={20} />
          }
          variant="ghost"
          size="sm"
          onClick={(e) => {
            e.stopPropagation();
            setIsExpanded(!isExpanded);
          }}
        />
      </Flex>

      {/* Expanded view */}
      <Collapse in={isExpanded}>
        <Box p={4} borderTop="1px solid" borderColor={borderColor}>
          <FullProgressBox
            completion_percentage={completion_percentage}
            answered_questions={answered_questions}
            total_questions={total_questions}
          />
        </Box>
      </Collapse>
    </Box>
  );
};

export default ProgressBox;
