import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogCloseButton,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogOverlay,
  Button,
  useDisclosure,
} from "@chakra-ui/react";
import { useRouter } from "next/router";
import React from "react";

export function CustomDialog({
  title,
  description,
  clickRoute,
  onClose,
  onOpen,
  isOpen,
}: {
  title: string;
  description: string;
  clickRoute: string;
  onClose: () => void;
  onOpen: () => void;
  isOpen: boolean;
  navigatingRoute: string;
}) {
  const cancelRef = React.useRef();

  const router = useRouter();

  return (
    <>
      <AlertDialog
        motionPreset="slideInBottom"
        // @ts-ignore
        leastDestructiveRef={cancelRef}
        onClose={onClose}
        isOpen={isOpen}
        isCentered
      >
        <AlertDialogOverlay />

        <AlertDialogContent>
          <AlertDialogHeader>{title}</AlertDialogHeader>
          <AlertDialogCloseButton />
          <AlertDialogBody>{description}</AlertDialogBody>
          <AlertDialogFooter>
            <Button
              colorScheme="red"
              ml={3}
              onClick={() => router.push(clickRoute)}
            >
              I understand !
            </Button>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
