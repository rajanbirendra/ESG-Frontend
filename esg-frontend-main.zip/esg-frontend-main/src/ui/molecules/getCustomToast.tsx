import { useToast } from "@chakra-ui/react";

export function CustomToast({
  message,
  type = "success",
  position = "bottom-right",
}: {
  message: string;
  type?: "success" | "error" | "info" | "warning";
  position?:
    | "top"
    | "bottom"
    | "top-right"
    | "top-left"
    | "bottom-right"
    | "bottom-left";
}) {
  const toast = useToast();

  toast({
    title: type === "success" ? "Success" : "Error",
    description: message,
    status: type,
    duration: 5000,
    isClosable: true,
    position,
  });
}
