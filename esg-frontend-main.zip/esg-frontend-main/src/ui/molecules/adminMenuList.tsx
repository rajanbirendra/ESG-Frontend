import {
  LucideBook,
  LucideBookCheck,
  LucideChartBar,
  LucideFileBarChart2,
  LucideGitBranch,
  LucideHelpCircle,
  LucideLayoutDashboard,
  LucideUsers,
} from "lucide-react";

export const adminMenuList = [
  {
    title: "Dashboard",
    icon: <LucideLayoutDashboard className="h-4 w-4" />,
    route: "/admin-dashboard",
  },
  {
    title: "Assessment List",
    icon: <LucideBook className="h-4 w-4" />,
    route: "/admin-dashboard/assessment/list",
  },
  {
    title: "Emission Factors",
    icon: <LucideFileBarChart2 className="h-4 w-4" />,
    route: "/admin-dashboard/emission-factors",
  },
  {
    title: "Manage Reports",
    icon: <LucideChartBar className="h-4 w-4" />,
    route: "/admin-dashboard/manage-reports",
  },
  {
    title: "Questions List",
    icon: <LucideHelpCircle className="h-4 w-4" />,
    route: "/admin-dashboard/question-list",
    children: [
      {
        title: "Self Assessment",
        icon: <LucideBookCheck className="h-4 w-4" />,
        route: "/admin-dashboard/question-list/self-assessment",
      },
      {
        title: "ESG Assessment",
        icon: <LucideBook className="h-4 w-4" />,
        route: "/admin-dashboard/question-list/assessment",
      },
    ],
  },

  {
    title: "Users",
    icon: <LucideUsers className="h-4 w-4" />,
    route: "/admin-dashboard/users",
  },
];
