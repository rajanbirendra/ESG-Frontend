import {
  LucideChartBar,
  LucideClipboardPenLine,
  LucideFile,
  LucideHelpCircle,
  LucideLayoutDashboard,
  LucideLock,
  LucidePersonStanding,
  LucideUser,
  LucideUser2,
  LucideSettings,
  LucideDroplet,
} from "lucide-react";
import { Text } from "@chakra-ui/react";
import { Roles } from "@/types/index.types";

export const userMenuList = [
  {
    title: "Dashboard",
    icon: <LucideLayoutDashboard className="h-4 w-4" />,
    route: "/dashboard",
    role: [Roles.USER, Roles.SUB_USER],
    planType: "all",
  },
  {
    title: <>Self Assessment</>,
    icon: <LucidePersonStanding className="h-4 w-4" />,
    route: "/dashboard/self-assessment",
    role: [Roles.USER, Roles.SUB_USER],
    planType: "all",
  },
  {
    title: "ESG Assessment",
    icon: <LucideFile className="h-4 w-4" />,
    route: "/dashboard/assessment",
    role: [Roles.USER, Roles.SUB_USER],
    planType: "SUBSCRIBED",
  },
  // {
  //   title: "Water Assessment",
  //   icon: <LucideDroplet className="h-4 w-4" />,
  //   route: "/dashboard/water-assessment",
  //   role: [Roles.USER, Roles.SUB_USER],
  //   planType: "SUBSCRIBED",
  // },
  {
    title: "Carbon Neutrality Plan",
    icon: <LucideClipboardPenLine className="h-4 w-4" />,
    route: "/dashboard/carbon-neutrality-plan",
    role: [Roles.USER, Roles.SUB_USER],
    planType: "SUBSCRIBED",
  },
  {
    title: "Reports",
    icon: <LucideChartBar className="h-4 w-4" />,
    route: "/dashboard/reports",
    role: [Roles.USER],
    planType: "SUBSCRIBED",
  },
];
