import { z } from "zod";

export const signupSchema = z
  .object({
    firstName: z
      .string()
      .min(1, { message: "First name is required" })
      .max(50, { message: "Name must be less than 50 characters" }),

    lastName: z
      .string()
      .min(1, { message: "Last name is required" })
      .max(50, { message: "Name must be less than 50 characters" }),

    password: z
      .string()
      .min(8, { message: "Password must be at least 8 characters long" })
      .max(100, { message: "Password must be less than 100 characters" })
      .regex(/[a-z]/, {
        message: "Password must contain at least one lowercase letter",
      })
      .regex(/[A-Z]/, {
        message: "Password must contain at least one uppercase letter",
      })
      .regex(/[0-9]/, { message: "Password must contain at least one number" })
      .regex(/[@$!%*?&]/, {
        message: "Password must contain at least one special character",
      }),
    repassword: z.string(),

    companyEmail: z
      .string()
      .email({ message: "Invalid company email address" })
      .max(100, { message: "Company email must be less than 100 characters" }),
    phoneNumber: z
      .string()
      .regex(/^\+?[1-9]\d{1,14}$/, { message: "Invalid phone number" })
      .optional(),
    country: z
      .string()
      .min(1, { message: "Country is required" })
      .max(100, { message: "Country must be less than 100 characters" }),
    state: z
      .string()
      .min(1, { message: "State/Province is required" })
      .max(100, { message: "State/Province must be less than 100 characters" })
      .optional(),
    username: z
      .string()
      .min(3, { message: "Username must be at least 3 characters long" })
      .max(50, { message: "Username must be less than 50 characters" }),
    companyName: z
      .string()
      .min(1, { message: "Company name is required" })
      .max(100, { message: "Company name must be less than 100 characters" }),
    companyLogo: z.string().optional(),
    companySize: z
      .string()
      .optional()
      .refine((val) => val !== "Select company size", {
        message: "Company size is required",
      }),
    companyVertical: z
      .string()
      .min(1, { message: "Industry type is required" })
      .max(100, { message: "Industry type must be less than 100 characters" }),
    companySubVertical: z
      .string()
      .min(1, { message: "Sub-industry type is required" })
      .max(100, { message: "Sub-industry type must be less than 100 characters" }),
    companyRole: z.string().optional(),
    co2Accounted: z.boolean(),
    termsAccepted: z.boolean().refine((val) => val === true, {
      message: "You must accept the terms and conditions",
    }),
  })
  .refine((data) => data.password === data.repassword, {
    message: "Passwords do not match",
    path: ["repassword"],
  });
