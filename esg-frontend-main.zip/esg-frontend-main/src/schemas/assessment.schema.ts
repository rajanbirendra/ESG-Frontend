import { z } from "zod";

export const CreateAssessmentSchema = z.object({
  title: z.string().min(1, { message: "Title is required" }),
  description: z.string().optional(),
  year: z.number().min(2020, { message: "Year is required" }),
  month: z.number().min(1).max(12, { message: "Month is required" }),
  branch: z.string().optional(),
});
