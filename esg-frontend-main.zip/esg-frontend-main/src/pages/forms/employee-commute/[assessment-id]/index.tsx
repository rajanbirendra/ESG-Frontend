import React from "react";
import {
  Box,
  Container,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Button,
  Heading,
  Text,
  useToast,
  FormErrorMessage,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverBody,
  InputGroup,
  InputLeftElement,
  Spinner,
} from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/router";
import { Search, ChevronDown, Loader } from "lucide-react";
import { useMiscAPI } from "@/query/use-misc";

// Constants for select options
const primary_mode_of_transport = [
  "Car",
  "Bus",
  "Rail",
  "Bike",
  "Bicycle",
  "Walk",
];

// SearchableSelect Component
const SearchableSelect = React.memo(
  ({
    questionId,
    field,
    fieldIndex,
    value,
    onChange,
  }: {
    questionId: string;
    field: any;
    fieldIndex: number | null;
    value: string;
    onChange: (value: string) => void;
  }) => {
    const [isOpen, setIsOpen] = React.useState(false);
    const [searchTerm, setSearchTerm] = React.useState("");
    const inputRef = React.useRef<HTMLInputElement>(null);

    // Memoize filtered options
    const filteredOptions = React.useMemo(
      () =>
        field?.options?.filter((option: string) =>
          option.toLowerCase().includes(searchTerm.toLowerCase())
        ),
      [field?.options, searchTerm]
    );

    const handleSelect = React.useCallback(
      (selectedValue: string) => {
        onChange(selectedValue);
        setIsOpen(false);
        setSearchTerm("");
      },
      [onChange]
    );

    return (
      <FormControl
        key={`select_field_${questionId}_${fieldIndex}_${field.label}`}
        isRequired
        style={{ marginTop: "10px" }}
      >
        <FormLabel
          fontWeight="medium"
          fontSize={"sm"}
          style={{
            minHeight: "30px",
            maxHeight: "30px",
            textOverflow: "ellipsis",
          }}
        >
          {field?.label}
        </FormLabel>
        <Popover
          isOpen={isOpen}
          onClose={() => {
            setIsOpen(false);
            setSearchTerm("");
          }}
          placement="bottom-start"
        >
          <PopoverTrigger>
            <Button
              w="100%"
              h="40px"
              variant="filled"
              bg="white"
              borderWidth="1px"
              borderColor="gray.200"
              _hover={{ borderColor: "blue.500" }}
              _focus={{
                borderColor: "blue.500",
                boxShadow: "0 0 0 1px blue.500",
              }}
              fontWeight={"normal"}
              onClick={() => setIsOpen(true)}
              justifyContent="space-between"
              px={4}
            >
              <Text isTruncated>{value || "Select an option"}</Text>
              <ChevronDown size={20} />
            </Button>
          </PopoverTrigger>
          <PopoverContent
            minW="300px"
            maxH="300px"
            overflowY="auto"
            style={{ overflowY: "hidden" }}
          >
            <PopoverBody p={0}>
              <VStack align="stretch" spacing={0}>
                <Box p={2} borderBottomWidth="1px">
                  <InputGroup>
                    <InputLeftElement pointerEvents="none">
                      <Search size={16} />
                    </InputLeftElement>
                    <Input
                      ref={inputRef}
                      name={`search-${questionId}`}
                      placeholder="Search..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      size="sm"
                      autoFocus
                      isRequired={false}
                    />
                  </InputGroup>
                </Box>
                <VStack align="stretch" maxH="250px" overflowY="auto">
                  {filteredOptions?.map((option: string, index: number) => (
                    <Button
                      key={`${questionId}_${fieldIndex}_${field.label}_${option}_${index}`}
                      variant="ghost"
                      justifyContent="flex-start"
                      px={4}
                      py={2}
                      h="auto"
                      whiteSpace="normal"
                      textAlign="left"
                      onClick={() => handleSelect(option)}
                      bg={value === option ? "blue.50" : "transparent"}
                      _hover={{ bg: "blue.50" }}
                    >
                      {option}
                    </Button>
                  ))}
                </VStack>
              </VStack>
            </PopoverBody>
          </PopoverContent>
        </Popover>
      </FormControl>
    );
  }
);

const EmployeeCommuteForm = () => {
  const router = useRouter();
  const assessmentId = router.query["assessment-id"];
  console.log("router.query", router.query);

  const { data: stationaryFuelTypes, isLoading: isLoadingStationaryFuelTypes } =
    useMiscAPI().getStationaryFuelTypes;

  const {
    data: assessmentVerifyResponse,
    isLoading: isLoadingAssessment,
    error: assessmentVerifyError,
  } = useMiscAPI().verifyAssessmentById(assessmentId as string);

  const { mutate: addFormResponse } = useMiscAPI().addFormResponse;

  const toast = useToast();
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    setValue,
    watch,
    trigger,
    reset,
  } = useForm();

  const onSubmit = async (data: any) => {
    try {
      addFormResponse(
        // @ts-ignore
        {
          body: data,
          path: {
            assessment_id: assessmentId as string,
          },
        },
        {
          onSuccess: () => {
            reset();
          },
        }
      );
    } catch (error) {
      toast({
        title: "Error submitting form",
        description: "Please try again later",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
    }
  };

  // Watch the values for the select fields
  const transportMode = watch("primary_mode_of_transport");
  const fuelType = watch("fuel_type");

  // Handle select field changes
  const handleTransportModeChange = (value: string) => {
    setValue("primary_mode_of_transport", value);
    trigger("primary_mode_of_transport"); // Trigger validation
  };

  const handleFuelTypeChange = (value: string) => {
    setValue("fuel_type", value);
    trigger("fuel_type"); // Trigger validation
  };

  if (isLoadingStationaryFuelTypes || isLoadingAssessment) {
    return (
      <Container
        maxW="container.md"
        style={{
          height: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <VStack spacing={8} align="stretch">
          <Spinner />
          Checking assessment...
        </VStack>
      </Container>
    );
  }

  if (
    assessmentVerifyError ||
    (assessmentVerifyResponse as any)?.verified === false
  ) {
    return (
      <Container maxW="container.md" py={8}>
        <VStack spacing={8} align="stretch">
          <Heading size="lg" color="gray.700" mb={2}>
            Employee Commute Form
          </Heading>
          <Text color="gray.500">
            Unable to verify Assessment. Invalid Assessment.
          </Text>
        </VStack>
      </Container>
    );
  }

  console.log("errors", errors);
  return (
    <Container maxW="container.md" py={8}>
      <VStack spacing={8} align="stretch">
        <Box textAlign="center">
          <Heading size="lg" color="gray.700" mb={2}>
            Employee Commute Form
          </Heading>
          <Text color="gray.500">
            Please fill in your commute details accurately (~{" "}
            {(assessmentVerifyResponse as any).company_name})
          </Text>
        </Box>

        <Box
          as="form"
          onSubmit={handleSubmit(onSubmit)}
          bg="white"
          p={8}
          borderRadius="xl"
          boxShadow="lg"
        >
          <VStack spacing={6}>
            {/* Employee Name */}
            <FormControl isInvalid={!!errors.employeeName}>
              <FormLabel fontWeight="medium">Employee Name</FormLabel>
              <Input
                {...register("employee_name", {
                  required: "Employee name is required",
                })}
                placeholder="Enter your full name"
                size="lg"
                variant="filled"
                _hover={{ borderColor: "blue.500" }}
                _focus={{
                  borderColor: "blue.500",
                  boxShadow: "0 0 0 1px blue.500",
                }}
              />
              <FormErrorMessage>
                {errors.employee_name && (errors.employee_name as any).message}
              </FormErrorMessage>
            </FormControl>

            {/* Department */}
            <FormControl isInvalid={!!errors.department}>
              <FormLabel fontWeight="medium">Department</FormLabel>
              <Input
                {...register("department", {
                  required: "Department is required",
                })}
                placeholder="Enter your department"
                size="lg"
                variant="filled"
                _hover={{ borderColor: "blue.500" }}
                _focus={{
                  borderColor: "blue.500",
                  boxShadow: "0 0 0 1px blue.500",
                }}
              />
              <FormErrorMessage>
                {errors.department && (errors.department as any).message}
              </FormErrorMessage>
            </FormControl>

            {/* Commute Days per Week */}
            <FormControl isInvalid={!!errors.commute_days_per_week}>
              <FormLabel fontWeight="medium">Commute Days per Week</FormLabel>
              <Input
                type="number"
                min="1"
                step="1"
                {...register("commute_days_per_week", {
                  required: "Commute days is required",
                  min: { value: 1, message: "Must be at least 1 day" },
                  max: { value: 7, message: "Cannot exceed 7 days" },
                  valueAsNumber: true,
                })}
                placeholder="Enter number of commute days"
                size="lg"
                variant="filled"
                _hover={{ borderColor: "blue.500" }}
                _focus={{
                  borderColor: "blue.500",
                  boxShadow: "0 0 0 1px blue.500",
                }}
                onKeyDown={(e) => {
                  if (e.key === "-" || e.key === "e" || e.key == "+") {
                    e.preventDefault();
                  }
                }}
              />
              <FormErrorMessage>
                {errors.commute_days_per_week &&
                  (errors.commute_days_per_week as any).message}
              </FormErrorMessage>
            </FormControl>

            {/* Primary Mode of Transport */}
            <FormControl isInvalid={!!errors.primary_mode_of_transport}>
              <SearchableSelect
                questionId="primary_mode_of_transport"
                field={{
                  label: "Primary Mode of Transport",
                  options: primary_mode_of_transport,
                }}
                fieldIndex={null}
                value={transportMode}
                onChange={handleTransportModeChange}
              />
              <FormErrorMessage>
                {errors.primary_mode_of_transport &&
                  (errors.primary_mode_of_transport as any).message}
              </FormErrorMessage>
            </FormControl>

            {/* Fuel Type */}
            <FormControl isInvalid={!!errors.fuelType}>
              <SearchableSelect
                questionId="fuel_type"
                field={{
                  label: "Fuel Type (if applicable)",
                  options: (stationaryFuelTypes as any)?.data?.map(
                    (fuelType: any) => fuelType
                  ),
                }}
                fieldIndex={null}
                value={fuelType}
                onChange={handleFuelTypeChange}
              />
              <FormErrorMessage>
                {errors.fuel_type && (errors.fuel_type as any).message}
              </FormErrorMessage>
            </FormControl>

            {/* One Way Distance */}
            <FormControl isInvalid={!!errors.distance}>
              <FormLabel fontWeight="medium">One Way Distance (km)</FormLabel>
              <Input
                type="number"
                min="0.1"
                step="0.1"
                {...register("one_way_distance", {
                  required: "Distance is required",
                  min: { value: 0.1, message: "Must be greater than 0" },
                  valueAsNumber: true,
                })}
                placeholder="Enter one way distance"
                size="lg"
                variant="filled"
                _hover={{ borderColor: "blue.500" }}
                _focus={{
                  borderColor: "blue.500",
                  boxShadow: "0 0 0 1px blue.500",
                }}
                onKeyDown={(e) => {
                  if (e.key === "-" || e.key === "e" || e.key == "+") {
                    e.preventDefault();
                  }
                }}
              />
              <FormErrorMessage>
                {errors.distance && (errors.distance as any).message}
              </FormErrorMessage>
            </FormControl>

            {/* Carpool Passengers */}
            <FormControl isInvalid={!!errors.carpoolPassengers}>
              {/* <FormLabel fontWeight="medium">Do you carpool?</FormLabel> */}
              <SearchableSelect
                questionId="carpool_yes_no"
                field={{
                  label: "Do you carpool?",
                  options: ["Yes", "No"],
                }}
                fieldIndex={null}
                value={watch("carpool_yes_no")}
                onChange={(value) => {
                  setValue("carpool_yes_no", value);
                  if (value === "No") {
                    setValue("carpool_passengers", "0");
                  }
                  trigger("carpool_yes_no");
                }}
              />
              <FormErrorMessage>
                {errors.carpool_yes_no &&
                  (errors.carpool_yes_no as any).message}
              </FormErrorMessage>
            </FormControl>

            {watch("carpool_yes_no") === "Yes" && (
              <FormControl isInvalid={!!errors.carpoolPassengers}>
                <FormLabel fontWeight="medium">
                  Number of Carpool Passengers
                </FormLabel>
                <Input
                  type="number"
                  min="1"
                  step="1"
                  {...register("carpool_passengers", {
                    required:
                      watch("carpool_yes_no") === "Yes"
                        ? "Number of passengers is required"
                        : false,
                    min: { value: 1, message: "Must be at least 1 passenger" },
                    valueAsNumber: true,
                  })}
                  placeholder="Enter number of carpool passengers"
                  size="lg"
                  variant="filled"
                  _hover={{ borderColor: "blue.500" }}
                  _focus={{
                    borderColor: "blue.500",
                    boxShadow: "0 0 0 1px blue.500",
                  }}
                  onKeyDown={(e) => {
                    if (e.key === "-" || e.key === "e" || e.key == "+") {
                      e.preventDefault();
                    }
                  }}
                />
                <FormErrorMessage>
                  {errors.carpoolPassengers &&
                    (errors.carpoolPassengers as any).message}
                </FormErrorMessage>
              </FormControl>
            )}

            {/* Work from Home Days */}
            <FormControl isInvalid={!!errors.work_from_home_days}>
              <FormLabel fontWeight="medium">Work-from-Home Days</FormLabel>
              <Input
                type="number"
                min="0"
                step="1"
                {...register("work_from_home_days", {
                  required: "Work from home days is required",
                  min: { value: 0, message: "Must be 0 or greater" },
                  max: { value: 7, message: "Cannot exceed 7 days" },
                  valueAsNumber: true,
                })}
                placeholder="Enter number of WFH days"
                size="lg"
                variant="filled"
                _hover={{ borderColor: "blue.500" }}
                _focus={{
                  borderColor: "blue.500",
                  boxShadow: "0 0 0 1px blue.500",
                }}
                onKeyDown={(e) => {
                  if (e.key === "-" || e.key === "e" || e.key == "+") {
                    e.preventDefault();
                  }
                }}
              />
              <FormErrorMessage>
                {errors.work_from_home_days &&
                  (errors.work_from_home_days as any).message}
              </FormErrorMessage>
            </FormControl>

            {/* Submit Button */}
            <Button
              type="submit"
              colorScheme="blue"
              size="lg"
              width="full"
              isLoading={isSubmitting}
              loadingText="Submitting"
              mt={4}
            >
              Submit Form
            </Button>
          </VStack>
        </Box>
      </VStack>
    </Container>
  );
};

export default EmployeeCommuteForm;
