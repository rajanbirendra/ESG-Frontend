import { useMiscAPI } from "@/query/use-misc";
import {
  Box,
  Container,
  Heading,
  Text,
  VStack,
  HStack,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  IconButton,
  useToast,
  Spinner,
  Flex,
  useColorModeValue,
  Tooltip,
  AlertDialog,
  AlertDialogBody,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogContent,
  AlertDialogOverlay,
  Button,
} from "@chakra-ui/react";
import { useRouter } from "next/router";
import React, { useRef, useState } from "react";
import { Trash2 } from "lucide-react";

const ViewResponse = () => {
  const router = useRouter();
  const assessmentId = router.query["assessment-id"];
  const toast = useToast();
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [responseToDelete, setResponseToDelete] = useState<string | null>(null);
  const cancelRef = useRef<HTMLButtonElement>(null);

  const {
    data: formResponse,
    isLoading: isLoadingFormResponse,
    refetch,
  } = useMiscAPI().getFormResponse(assessmentId as string);

  const { mutate: deleteFormResponse } = useMiscAPI().deleteFormResponse;

  const borderColor = useColorModeValue("gray.200", "gray.700");
  const hoverBg = useColorModeValue("gray.50", "gray.700");
  const tableBg = useColorModeValue("gray.50", "gray.800");

  const handleDeleteClick = (id: string) => {
    setResponseToDelete(id);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!responseToDelete) return;

    try {
      deleteFormResponse(
        // @ts-ignore
        {
          path: {
            form_id: responseToDelete,
          },
        },
        {
          onSuccess: () => {
            refetch();
          },
        }
      );
    } catch (error) {
      toast({
        title: "Error deleting response",
        description: "Please try again later",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
    } finally {
      setIsDeleteDialogOpen(false);
      setResponseToDelete(null);
    }
  };

  if (isLoadingFormResponse) {
    return (
      <Container maxW="container.lg" py={8}>
        <Flex justify="center" align="center" minH="60vh">
          <Spinner
            thickness="4px"
            speed="0.65s"
            emptyColor="gray.200"
            color="blue.500"
            size="xl"
          />
        </Flex>
      </Container>
    );
  }

  if (!formResponse || (formResponse as any).length === 0) {
    return (
      <Container maxW="container.lg" py={8}>
        <VStack spacing={6} align="center">
          <Heading size="lg" color="gray.700">
            No Responses Yet
          </Heading>
          <Text color="gray.500">
            There are no form responses available at the moment.
          </Text>
        </VStack>
      </Container>
    );
  }

  return (
    <Container maxW="container.lg" py={8}>
      <VStack spacing={8} align="stretch">
        <Box textAlign="center">
          <Heading size="lg" color="gray.700" mb={2}>
            Employee Commute Responses
          </Heading>
          <Text color="gray.500">
            View and manage employee commute form submissions
          </Text>
        </Box>

        <Box
          borderWidth="1px"
          borderColor={borderColor}
          borderRadius="lg"
          w="100%"
          overflowX="auto"
          bg={tableBg}
          boxShadow="sm"
        >
          <Table variant="simple" width="100%">
            <Thead bg={useColorModeValue("gray.50", "gray.800")}>
              <Tr>
                <Th>Employee</Th>
                <Th>Department</Th>
                <Th>Transport Mode</Th>
                <Th>Distance (km)</Th>
                <Th>Commute Days</Th>
                <Th>WFH Days</Th>
                <Th>Submitted</Th>
                <Th>Actions</Th>
              </Tr>
            </Thead>
            <Tbody>
              {(formResponse as any) &&
                (formResponse as any).data?.map((response: any) => (
                  <Tr
                    key={response.id}
                    _hover={{ bg: hoverBg }}
                    transition="all 0.2s"
                  >
                    <Td fontWeight="medium">{response.employee_name}</Td>
                    <Td>{response.department}</Td>
                    <Td>
                      <Tooltip label={response.primary_mode_of_transport}>
                        <Text isTruncated maxW="200px">
                          {response.primary_mode_of_transport}
                        </Text>
                      </Tooltip>
                    </Td>
                    <Td isNumeric>{response.one_way_distance}</Td>
                    <Td isNumeric>{response.commute_days_per_week}</Td>
                    <Td isNumeric>{response.work_from_home_days}</Td>
                    <Td>
                      {new Date(response.created_at).toLocaleDateString()}
                    </Td>
                    <Td>
                      <Tooltip label="Delete Response">
                        <IconButton
                          aria-label="Delete response"
                          icon={<Trash2 size={18} />}
                          variant="ghost"
                          colorScheme="red"
                          size="sm"
                          onClick={() => handleDeleteClick(response.id)}
                        />
                      </Tooltip>
                    </Td>
                  </Tr>
                ))}
            </Tbody>
          </Table>
        </Box>
      </VStack>

      <AlertDialog
        isOpen={isDeleteDialogOpen}
        leastDestructiveRef={cancelRef}
        onClose={() => setIsDeleteDialogOpen(false)}
      >
        <AlertDialogOverlay>
          <AlertDialogContent>
            <AlertDialogHeader fontSize="lg" fontWeight="bold">
              Delete Response
            </AlertDialogHeader>

            <AlertDialogBody>
              Are you sure you want to delete this response? This action cannot
              be undone.
            </AlertDialogBody>

            <AlertDialogFooter>
              <Button
                ref={cancelRef}
                onClick={() => setIsDeleteDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button colorScheme="red" onClick={handleDeleteConfirm} ml={3}>
                Delete
              </Button>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialogOverlay>
      </AlertDialog>
    </Container>
  );
};

export default ViewResponse;
