import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Container,
  FormControl,
  FormLabel,
  Input,
  FormErrorMessage,
  Heading,
  Text,
  VStack,
  useToast,
  Icon,
  Flex,
  Image,
  InputGroup,
  InputRightElement,
  useColorModeValue,
  Spinner,
} from "@chakra-ui/react";
import { Eye, EyeOff, ArrowLeft, Lock } from "lucide-react";
import { useRouter } from "next/router";
import { useAuthAPI } from "../query/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

// Validation schema for reset password form
const resetPasswordSchema = z
  .object({
    password: z
      .string()
      .min(8, { message: "Password must be at least 8 characters long" })
      .max(100, { message: "Password must be less than 100 characters" })
      .regex(/[a-z]/, {
        message: "Password must contain at least one lowercase letter",
      })
      .regex(/[A-Z]/, {
        message: "Password must contain at least one uppercase letter",
      })
      .regex(/[0-9]/, { message: "Password must contain at least one number" })
      .regex(/[@$!%*?&]/, {
        message: "Password must contain at least one special character",
      }),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type ResetPasswordFormData = z.infer<typeof resetPasswordSchema>;

const ResetPassword: React.FC = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [token, setToken] = useState("");
  const [isValidating, setIsValidating] = useState(true);
  const [isTokenValid, setIsTokenValid] = useState(false);
  const toast = useToast();
  const router = useRouter();
  const { resetPassword } = useAuthAPI();

  // React Hook Form setup
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<ResetPasswordFormData>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    },
  });

  const cardBg = useColorModeValue("white", "gray.800");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const headingColor = useColorModeValue("gray.700", "white");
  const borderColor = useColorModeValue("gray.200", "gray.700");

  // Function to validate token
  const validateToken = async (token: string) => {
    try {
      // Decode the JWT token to check if it's valid
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const payload = JSON.parse(atob(base64));
      
      console.log('Token payload:', payload);
      console.log('Current time:', Math.floor(Date.now() / 1000));
      console.log('Token expiration:', payload.exp);
      
      // Check if token has expired
      const currentTime = Math.floor(Date.now() / 1000);
      if (payload.exp && payload.exp < currentTime) {
        throw new Error('Token has expired');
      }
      
      // Check if it's a password reset token
      if (payload.type !== 'password_reset') {
        throw new Error('Invalid token type');
      }
      
      setIsTokenValid(true);
      return true;
    } catch (error) {
      console.error('Token validation error:', error);
      setIsTokenValid(false);
      toast({
        title: "Invalid Reset Link",
        description: "The reset link is invalid or has expired. Please request a new one.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
      router.push("/forgot-password");
      return false;
    } finally {
      setIsValidating(false);
    }
  };

  useEffect(() => {
    // Wait for router to be ready and query parameters to be loaded
    if (!router.isReady) return;
    
    const urlToken = router.query.token as string;
    
    if (urlToken) {
      setToken(urlToken);
      validateToken(urlToken);
    } else {
      toast({
        title: "Invalid Reset Link",
        description: "The reset link is invalid or has expired.",
        status: "error",
        duration: 5000,
        isClosable: true,
      });
      router.push("/forgot-password");
    }
  }, [router.isReady, router.query.token, router, toast]);

  const onSubmit = (data: ResetPasswordFormData) => {
    resetPassword.mutate({
      body: {
        token,
        new_password: data.password,
      },
    });
  };

  // Show loading state while router is not ready or validating token
  if (!router.isReady || isValidating) {
    return (
      <Flex
        minH="100vh"
        align="center"
        justify="center"
        bgImage="url('/bgsignup.webp')"
        bgSize="cover"
        bgPosition="center"
        bgRepeat="no-repeat"
        bgAttachment="fixed"
        position="relative"
        _before={{
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          bg: "rgba(0, 0, 0, 0.4)",
          backdropFilter: "blur(4px)",
        }}
      >
        <Container maxW="container.sm" position="relative" zIndex={1}>
          <Box
            bg={cardBg}
            p={8}
            borderRadius="2xl"
            boxShadow="2xl"
            maxW="md"
            w="100%"
            mx="auto"
            textAlign="center"
          >
            <Spinner size="xl" color="blue.500" mb={4} />
            <Text fontSize="lg" color={textColor}>
              {!router.isReady ? "Loading..." : "Validating reset link..."}
            </Text>
          </Box>
        </Container>
      </Flex>
    );
  }

  // Show error state if token is invalid
  if (!isTokenValid) {
    return null; // Will redirect to forgot password page
  }

  return (
    <Flex
      minH="100vh"
      align="center"
      justify="center"
      bgImage="url('/bgsignup.webp')"
      bgSize="cover"
      bgPosition="center"
      bgRepeat="no-repeat"
      bgAttachment="fixed"
      position="relative"
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        bg: "rgba(0, 0, 0, 0.4)",
        backdropFilter: "blur(4px)",
      }}
    >
      <Container maxW="container.sm" position="relative" zIndex={1}>
        <Box
          bg={cardBg}
          p={8}
          borderRadius="2xl"
          boxShadow="2xl"
          maxW="md"
          w="100%"
          mx="auto"
          position="relative"
          _before={{
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            borderRadius: "2xl",
            border: "1px solid",
            borderColor: "gray.200",
            opacity: 0.1,
          }}
          display="flex"
          flexDirection="column"
          alignItems="center"
        >
          {/* Logo */}
          <Flex justify="center" mb={8}>
            <Image
              src="/logo.webp"
              alt="Company Logo"
              boxSize="70px"
              transition="all 0.3s ease"
              _hover={{
                transform: "scale(1.1)",
              }}
            />
          </Flex>

          {/* Heading */}
          <Heading
            size="lg"
            textAlign="center"
            mb={2}
            color={headingColor}
            fontWeight="bold"
          >
            Reset Your Password
          </Heading>
          <Text color={textColor} mb={8} textAlign="center">
            Enter your new password below.
          </Text>

          <form onSubmit={handleSubmit(onSubmit)} style={{ width: "100%" }}>
            <VStack spacing={4} align="stretch">
              <FormControl isInvalid={!!errors.password} isRequired>
                <FormLabel>New Password</FormLabel>
                <InputGroup>
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter new password"
                    bg="gray.50"
                    borderColor="gray.200"
                    _focus={{ borderColor: "primary.500", bg: "white" }}
                    {...register("password")}
                  />
                  <InputRightElement>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </Button>
                  </InputRightElement>
                </InputGroup>
                <FormErrorMessage>
                  {errors.password && errors.password.message}
                </FormErrorMessage>
              </FormControl>

              <FormControl isInvalid={!!errors.confirmPassword} isRequired>
                <FormLabel>Confirm New Password</FormLabel>
                <InputGroup>
                  <Input
                    type={showConfirmPassword ? "text" : "password"}
                    placeholder="Confirm new password"
                    bg="gray.50"
                    borderColor="gray.200"
                    _focus={{ borderColor: "primary.500", bg: "white" }}
                    {...register("confirmPassword")}
                  />
                  <InputRightElement>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    >
                      {showConfirmPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </Button>
                  </InputRightElement>
                </InputGroup>
                <FormErrorMessage>
                  {errors.confirmPassword && errors.confirmPassword.message}
                </FormErrorMessage>
              </FormControl>

              <Button
                type="submit"
                colorScheme="primary"
                isLoading={resetPassword.isPending || isSubmitting}
                isDisabled={resetPassword.isPending || isSubmitting}
                size="lg"
                width="100%"
                mt={2}
              >
                Reset Password
              </Button>
            </VStack>
          </form>

          {/* Back Button */}
          <Button
            variant="ghost"
            leftIcon={<ArrowLeft size={18} />}
            alignSelf="flex-start"
            mt={6}
            colorScheme="gray"
            onClick={() => router.push("/forgot-password")}
          >
            Back to Forgot Password
          </Button>
        </Box>
      </Container>
      {/* Footer */}
      <Box
        position="absolute"
        bottom={0}
        left={0}
        right={0}
        py={4}
        textAlign="center"
        zIndex={2}
      >
        <Flex
          direction={{ base: "column", md: "row" }}
          justify="center"
          align="center"
          gap={{ base: 2, md: 4 }}
        >
          <Text
            color="white"
            fontSize="sm"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
          >
            © {new Date().getFullYear()} Cleaffo. All rights reserved.
          </Text>
          <Text
            as="span"
            color="white"
            fontSize="sm"
            fontWeight="medium"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
            _hover={{
              color: "blue.200",
              textDecoration: "underline",
              textShadow: "0 1px 2px rgba(0,0,0,0.7)",
            }}
            textDecoration="none"
            transition="all 0.2s ease"
            cursor="pointer"
          >
            |
          </Text>
          <Text
            as="a"
            href="/privacy-policy"
            color="white"
            fontSize="sm"
            fontWeight="medium"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
            _hover={{
              color: "blue.200",
              textDecoration: "underline",
              textShadow: "0 1px 2px rgba(0,0,0,0.7)",
            }}
            textDecoration="none"
            transition="all 0.2s ease"
            cursor="pointer"
          >
            Privacy Policy
          </Text>
        </Flex>
      </Box>
    </Flex>
  );
};

export default ResetPassword; 