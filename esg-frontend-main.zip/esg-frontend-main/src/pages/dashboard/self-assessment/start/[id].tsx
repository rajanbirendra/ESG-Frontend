"use client";

import { useState, useEffect } from "react";
import {
  Box,
  Text,
  Button,
  Icon,
  Container,
  Heading,
  SimpleGrid,
  useColorModeValue,
  VStack,
  HStack,
} from "@chakra-ui/react";
import { useRouter } from "next/router";
import { FiUsers, FiShield } from "react-icons/fi";
import { FaLeaf } from "react-icons/fa";
import Layout from "@/ui/layouts/DashboardLayout";
import { CustomDialog } from "@/ui/molecules/CustomDialog";
import { useDisclosure } from "@chakra-ui/react";
import { MiniProgressBox } from "@/ui/molecules/ProgressBox";
import { useAssessmentsAPI } from "@/query/use-assessments";
import SubHeaderUI from "@/ui/molecules/subHeaderUI";

const FreeSelfAssessment = () => {
  const router = useRouter();
  const [assessmentId, setAssessmentId] = useState<string | null>(null);
  const [selectedAssessment, setSelectedAssessment] = useState<string | null>(
    null
  );
  const [navigatingRoute, setNavigatingRoute] = useState<string | null>(null);
  const [isClient, setIsClient] = useState(false);
  const { isOpen, onOpen, onClose } = useDisclosure();

  const { data: percentageInfo, isLoading } =
    useAssessmentsAPI().getPercentageOfAssessment({
      query: {
        assessment_id: router.query.id as string,
      },
    });

  // Theme colors
  const cardBg = useColorModeValue("white", "gray.800");
  const boxBg = useColorModeValue("gray.50", "gray.700");
  const headingColor = useColorModeValue("gray.700", "white");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const borderColor = useColorModeValue("gray.200", "gray.600");
  const envColor = useColorModeValue("green.500", "green.300");
  const socialColor = useColorModeValue("blue.500", "blue.300");
  const govColor = useColorModeValue("purple.500", "purple.300");

  // Handle router on client side
  useEffect(() => {
    if (router.isReady) {
      const id = router.query.id as string;
      if (!id) {
        router.push("/dashboard/self-assessment");
      } else {
        setAssessmentId(id);
      }
    }
  }, [router.isReady, router]);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const handleStart = (category: string) => {
    let route = "";
    switch (category) {
      case "Environment":
        route = `/dashboard/self-assessment/environment/${assessmentId}`;
        break;
      case "Social":
        route = `/dashboard/self-assessment/social/${assessmentId}`;
        break;
      case "Governance":
        route = `/dashboard/self-assessment/governance/${assessmentId}`;
        break;
    }
    if (route) {
      router.push(route);
    }
  };

  const AssessmentCard = ({
    title,
    description,
    icon,
    color,
    onClick,
  }: {
    title: string;
    description: string;
    icon: any;
    color: string;
    onClick: () => void;
  }) => (
    <Box
      bg={boxBg}
      p={6}
      borderRadius="lg"
      border="1px solid"
      borderColor={borderColor}
      transition="all 0.2s"
      _hover={{
        transform: "translateY(-4px)",
        boxShadow: "lg",
        borderColor: color,
      }}
    >
      <VStack align="start" spacing={4}>
        <HStack justify="space-between" w="full">
          <Heading size="md" color={headingColor} fontWeight="600">
            {title}
          </Heading>
          <Box
            p={2}
            bg={`${color}10`}
            borderRadius="full"
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            <Icon as={icon} boxSize={6} color={color} />
          </Box>
        </HStack>
        <Text fontSize="md" color={textColor} lineHeight="tall">
          {description}
        </Text>
        <Text style={{ width: "100%" }}>
          {(percentageInfo as any)?.data && (
            <MiniProgressBox
              completion_percentage={
                (percentageInfo as any).data[title.toString().toUpperCase()]
                  ?.completion_percentage
              }
              answered_questions={
                (percentageInfo as any).data[title.toString().toUpperCase()]
                  ?.answered_questions
              }
              total_questions={
                (percentageInfo as any).data[title.toString().toUpperCase()]
                  ?.total_questions
              }
            />
          )}
        </Text>
        <Button
          colorScheme={color.split(".")[0]}
          onClick={onClick}
          size="lg"
          width="full"
          fontWeight="medium"
          _hover={{
            transform: "translateY(-1px)",
            boxShadow: "md",
          }}
          transition="all 0.2s"
        >
          {(percentageInfo as any)?.data?.[title.toString().toUpperCase()]
            ?.answered_questions > 0
            ? "View"
            : "Start"}{" "}
          Assessment
        </Button>
      </VStack>
    </Box>
  );

  if (!assessmentId) {
    return null; // Wait for router to be ready
  }

  return (
    <Layout
      backButtonURL="/dashboard/self-assessment"
      activePage="/dashboard/self-assessment"
      headerTitle="ESG Self Assessment Categories"
      subHeaderTitle={
        isClient && (percentageInfo as any)?.assessment ? (
          <SubHeaderUI assessment={(percentageInfo as any)?.assessment} />
        ) : null
      }
    >
      <Container maxW="1200px" px={6}>
        <VStack spacing={8} align="stretch">
          <VStack align="start" spacing={2}>
            <Text color={textColor} fontSize="md">
              Select a category to begin your free assessment
            </Text>
          </VStack>

          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6}>
            <AssessmentCard
              title="Environment"
              description="Record and monitor your monthly environmental metrics (energy use, waste, emissions)."
              icon={FaLeaf}
              color={envColor}
              onClick={() => handleStart("Environment")}
            />

            <AssessmentCard
              title="Social"
              description="Capture your social impact data, from community programs to employee well‑being."
              icon={FiUsers}
              color={socialColor}
              onClick={() => handleStart("Social")}
            />

            <AssessmentCard
              title="Governance"
              description="Answer governance questions on policies, risk management, and board oversight. Use Help for information on each question."
              icon={FiShield}
              color={govColor}
              onClick={() => handleStart("Governance")}
            />
          </SimpleGrid>
        </VStack>
      </Container>
    </Layout>
  );
};

export default FreeSelfAssessment;
