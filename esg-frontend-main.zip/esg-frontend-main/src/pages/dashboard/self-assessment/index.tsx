import { useAssessmentsAPI } from "@/query/use-assessments";
import { AssessmentType } from "@/types/index.types";
import Layout from "@/ui/layouts/DashboardLayout";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import React, { useState, useEffect } from "react";
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  useDisclosure,
  Box,
  SimpleGrid,
  Heading,
  Text,
  Button,
  Flex,
  VStack,
  Icon,
  Container,
} from "@chakra-ui/react";
import { useRouter } from "next/router";
import { useCompanyAPI } from "@/query/use-company";
import { getParsedToken } from "@/utils/withAuth";
import { Roles } from "@/types/index.types";
import CreateNewSelfAssessment from "@/ui/organisms/dashboard/self-assessment/CreateNewSelfAssessment";
import {
  Plus,
  Calendar,
  ArrowRight,
  ClipboardCheck,
  Building2,
} from "lucide-react";
import { MiniProgressBox } from "@/ui/molecules/ProgressBox";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import SelfAssessmentCard from "@/ui/molecules/cards/SelfAssessmentCard";

const FreeAssessment = () => {
  const router = useRouter();
  const { getAssessments } = useAssessmentsAPI();
  const { getAllCompanyBranches } = useCompanyAPI();
  const token = getParsedToken();
  const userRole = token?.role;
  const [mounted, setMounted] = useState(false);

  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);
  const [selectedYear, setSelectedYear] = useState<string>("");

  // @ts-ignore
  const { isLoading, data } = getAssessments({
    query: {
      assessment_type: AssessmentType.SELF_ASSESSMENT,
      ...(selectedBranch && { branch: selectedBranch }),
      ...(selectedYear && { year: Number(selectedYear) }),
    },
  });

  const { isOpen, onOpen, onClose } = useDisclosure();

  useEffect(() => {
    setMounted(true);
    // Set the year after mounting to avoid hydration issues
    setSelectedYear(new Date().getFullYear().toString());
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const quickAction = localStorage.getItem("dashboard_quick_action");
    if (quickAction === "self-assessment") {
      onOpen();
      localStorage.removeItem("dashboard_quick_action");
    }
  }, []);

  const EmptyState = () => (
    <VStack spacing={8} py={16} px={4} textAlign="center">
      <Box
        p={6}
        bg="primary.50"
        borderRadius="full"
        display="inline-flex"
        alignItems="center"
        justifyContent="center"
      >
        <Icon as={ClipboardCheck} w={12} h={12} color="primary.500" />
      </Box>
      <VStack spacing={4}>
        <Heading size="lg" color="gray.700" fontWeight="600">
          No Self Assessments Yet
        </Heading>
        <Text color="gray.500" maxW="md" fontSize="md">
          Start your ESG journey with a self-assessment. Evaluate your current
          practices and identify areas for improvement.
        </Text>
      </VStack>
      <Button
        size="lg"
        colorScheme="primary"
        onClick={onOpen}
        leftIcon={<Plus size={20} />}
        fontWeight="medium"
        _hover={{ transform: "translateY(-1px)", boxShadow: "md" }}
        transition="all 0.2s"
      >
        Start Self Assessment
      </Button>
    </VStack>
  );

  // Don't render anything until mounted to prevent hydration issues
  if (!mounted) {
    return (
      <Layout
        activePage={"/dashboard/self-assessment"}
        headerTitle="Self Assessments"
        subHeaderTitle="Track and manage your ESG self-assessments and progress"
      >
        <Container maxW="1600px" px={6}>
          <ShimmerLoader count={6} />
        </Container>
      </Layout>
    );
  }

  // Defensive programming to handle potential undefined data
  const assessments = Array.isArray(data) ? data : [];
  const hasAssessments = assessments.length > 0;

  return (
    <Layout
      activePage={"/dashboard/self-assessment"}
      headerTitle="Self Assessments"
      subHeaderTitle="Track and manage your ESG self-assessments and progress"
    >
      <Container maxW="1600px" px={6}>
        <Flex justifyContent="flex-end" mb={8} alignItems="center" gap={4}>
          {userRole === Roles.USER && (
            <Box width="200px">
              <BranchDropdown
                value={selectedBranch}
                onChange={setSelectedBranch}
                label=""
              />
            </Box>
          )}
          <YearDropdown
            selectedYear={selectedYear}
            onSelectYear={setSelectedYear}
            maxCurrentYear={true}
          />
        </Flex>

        {isLoading ? (
          <ShimmerLoader count={6} />
        ) : !hasAssessments ? (
          <EmptyState />
        ) : (
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
            {assessments.map((assessment: any) => (
              <SelfAssessmentCard
                key={assessment?.id || Math.random()}
                assessment={assessment}
                onClick={() => {
                  const assessmentId = assessment?.assessment?.id;
                  if (assessmentId) {
                    router.push(
                      `/dashboard/self-assessment/start/${assessmentId}`
                    );
                  }
                }}
              />
            ))}
          </SimpleGrid>
        )}

        <CreateNewSelfAssessment isOpen={isOpen} onClose={onClose} />
        {/* Floating Action Button for New Assessment */}
        {!isLoading && hasAssessments && (
          <Button
            position="fixed"
            bottom={{ base: 6, md: 10 }}
            right={{ base: 6, md: 10 }}
            zIndex={100}
            size="lg"
            colorScheme="primary"
            onClick={onOpen}
            leftIcon={<Plus size={20} color="white" />}
            fontWeight="bold"
            borderRadius="full"
            px={8}
            py={6}
            boxShadow="lg"
            _hover={{
              boxShadow: "xl",
              transform: "translateY(-2px)",
              bg: "primary.600",
            }}
            transition="all 0.2s"
          >
            New Assessment
          </Button>
        )}
      </Container>
    </Layout>
  );
};

export default FreeAssessment;
