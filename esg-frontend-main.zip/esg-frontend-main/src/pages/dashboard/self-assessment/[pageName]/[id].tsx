import Layout from "@/ui/layouts/DashboardLayout";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/router";
import { Box, Text } from "@chakra-ui/react";
import {
  getQuestionsQuestionsGetOptions,
  syncValueSyncPostMutation,
} from "../../../../api/@tanstack/react-query.gen";
import Loader from "@/ui/molecules/Loader";
import AssessmentDynamicForm from "@/ui/organisms/DynamicForm";
import SubHeaderUI from "@/ui/molecules/subHeaderUI";

const FreeAssessmentPage = () => {
  const { setValue } = useForm();
  const router = useRouter();

  const [totalQuestions, setTotalQuestions] = useState<number>();
  const [answeredQuestions, setAnswersWeredQuestions] = useState<number>();
  const [completionPercentage, setCompletionPercentage] = useState<number>();

  const { isLoading, data } = useQuery({
    ...getQuestionsQuestionsGetOptions({
      query: {
        type:
          router.query.pageName === "environment"
            ? "ENVIRONMENT"
            : router.query.pageName === "social"
            ? "SOCIAL"
            : "GOVERNANCE",
        question_of: "SELF_ASSESSMENT",
        // @ts-ignore
        assessment_id: router.query.id,
      },
    }),
  });

  const {
    mutate,
    isPending: isSyncing,
    isSuccess: isSyncingDone,
  } = useMutation({
    ...syncValueSyncPostMutation(),
  });

  const handleSync = (data: { questionId: string; values: any }) => {
    // Handle the update logic here
    console.log("Update button clicked");

    console.log("data", data);
    mutate(
      {
        body: {
          question_id: data.questionId,
          values: data.values,
          // @ts-ignore
          assessment_id: router.query.id,
        },
      },
      {
        onSuccess: () => {
          // @ts-ignore
          setAnswersWeredQuestions((prev) => prev + 1);
          setCompletionPercentage(
            // @ts-ignore
            (prev) => (answeredQuestions / totalQuestions) * 100
          );
        },
      }
    );
  };

  useEffect(() => {
    if (data) {
      // @ts-ignore
      setTotalQuestions(data.total_questions);
      // @ts-ignore
      setAnswersWeredQuestions(data.answered_questions);
      // @ts-ignore
      setCompletionPercentage(data.completion_percentage);
    }
  }, [data]);

  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  let groupedData: Record<string, any[]> = {};
  if ((data as any) && (data as any).questions) {
    // Group data by question category
    groupedData = (data as any).questions.reduce((acc: any, question: any) => {
      const category = question.category;
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(question);
      return acc;
    }, {});
  }

  return (
    <Box
      sx={{
        "&::-webkit-scrollbar": {
          display: "none",
        },
        "&": {
          scrollbarWidth: "none",
          msOverflowStyle: "none",
        },
      }}
    >
      <Layout
        activePage={"/dashboard/self-assessment"}
        backButtonURL={"/dashboard/self-assessment/start/" + router.query.id}
        headerTitle={
          typeof router.query.pageName === "string"
            ? router.query.pageName.charAt(0).toUpperCase() +
              router.query.pageName.slice(1) +
              " Assessment"
            : ""
        }
        isLoading={isLoading || !isClient}
        subHeaderTitle={
          isClient && (data as any)?.assessment ? (
            <SubHeaderUI assessment={(data as any)?.assessment} />
          ) : null
        }
      >
        <Box
          bg="white"
          borderRadius="md"
          boxShadow="sm"
          p={6}
          overflow="hidden"
          sx={{
            "&::-webkit-scrollbar": {
              display: "none",
            },
            "&": {
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            },
          }}
        >
          <AssessmentDynamicForm
            assessmentId={router.query.id as string}
            data={data as any}
            assessmentFor={
              "SELF_ASSESSMENT_" +
              (router.query.pageName as string)?.toUpperCase().replace(" ", "_")
            }
          />
        </Box>
      </Layout>
    </Box>
  );
};

export default FreeAssessmentPage;
