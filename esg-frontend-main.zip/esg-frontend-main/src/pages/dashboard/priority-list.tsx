import React, { useState, useEffect } from "react";
import {
  Box,
  Flex,
  Text,
  Input,
  InputGroup,
  InputLeftElement,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Button,
  Image,
} from "@chakra-ui/react";
import { SearchIcon, ViewIcon } from "@chakra-ui/icons";
import Layout from "@/ui/layouts/DashboardLayout";
import withAuth from "../../utils/withAuth";

function PriorityList() {
  const [priorityList, setPriorityList] = useState([]);

  useEffect(() => {
    const token = localStorage.getItem("token");
    fetch("https://backend.paudyals.com/api/priority-list", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    })
      .then((res) => res.json())
      .then((data) => {
        setPriorityList(data.priority_list || []);
      })
      .catch((error) => {
        console.error("Error fetching priority list:", error);
      });
  }, []);

  return (
    <Layout>
      <Box flex="1" p={4}>
        <Text fontSize="2xl" fontWeight="bold" mb={4}>
          Priority List
        </Text>

        <Box bg="white" borderRadius="md" boxShadow="sm" p={4}>
          <Text fontWeight="semibold" mb={4}>
            Below is the list of priority actions. Click the eye icon for more
            details.
          </Text>
          <Box overflowX="auto">
            <Table variant="simple" size="md">
              <Thead>
                <Tr>
                  <Th>S.N.</Th>
                  <Th>Action</Th>
                  <Th>Priority</Th>
                  <Th>Details</Th>
                </Tr>
              </Thead>
              <Tbody>
                {/* {priorityList.map((item, index) => (
                  <Tr key={item.id}>
                    <Td>{index + 1}</Td>
                    <Td>{item.title}</Td>
                    <Td>{item.priority}</Td>
                    <Td>
                      <Button size="sm" variant="ghost" colorScheme="blue">
                        <ViewIcon />
                      </Button>
                    </Td>
                  </Tr>
                ))} */}
              </Tbody>
            </Table>
          </Box>
        </Box>
      </Box>
    </Layout>
  );
}
export default withAuth(PriorityList);
