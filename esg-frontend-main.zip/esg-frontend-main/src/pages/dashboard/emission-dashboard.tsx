import Layout from "@/ui/layouts/DashboardLayout";
import {
  Box,
  Card,
  CardBody,
  Flex,
  Heading,
  Skeleton,
  Text,
  VStack,
  HStack,
  Container,
  Icon,
  Popover,
  PopoverTrigger,
  PopoverContent,
  PopoverBody,
  PopoverArrow,
} from "@chakra-ui/react";
import React, { useState, useEffect } from "react";
import { Activity, Cloud, TrendingUp } from "lucide-react";
import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  LabelList,
} from "recharts";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import DateRangeFilter from "@/ui/molecules/DateRangeFilter";
import Image from "next/image";

interface EmissionData {
  upstream_emission: number;
  downstream_emission: number;
  total_emission: number;
}

interface Scope1Data {
  name: string;
  value: number;
  fill: string;
}

interface Scope2Data {
  name: string;
  value: number;
  fill: string;
}

const EmissionDashboard = () => {
  const [upstreamBranch, setUpstreamBranch] = useState<string | null>(null);
  const [scope1Branch, setScope1Branch] = useState<string | null>(null);
  const [upstreamDateRange, setUpstreamDateRange] = useState<{
    startDate: string | undefined;
    endDate: string | undefined;
  }>({
    startDate: undefined,
    endDate: undefined,
  });
  const [scope1DateRange, setScope1DateRange] = useState<{
    startDate: string | undefined;
    endDate: string | undefined;
  }>({
    startDate: undefined,
    endDate: undefined,
  });
  const [scope1Data, setScope1Data] = useState<Scope1Data[]>([]);
  const [scope2Data, setScope2Data] = useState<Scope2Data[]>([]);

  const { data, isLoading, isError, refetch } =
    useUserAnalyticsAPI().getUpstreamDownstreamEmissions(
      upstreamBranch,
      upstreamDateRange.startDate,
      upstreamDateRange.endDate
    ) as {
      data: EmissionData | undefined;
      isLoading: boolean;
      isError: boolean;
      refetch: () => void;
    };

  const getScope1Emission = useUserAnalyticsAPI().getScope1Emission(
    scope1Branch,
    scope1DateRange.startDate,
    scope1DateRange.endDate
  );

  const getScope2Emission = useUserAnalyticsAPI().getScope2Emission();

  const COLORS = ["#38A169", "#48BB78"];

  const pieData = data
    ? [
        { name: "Upstream", value: data.upstream_emission },
        { name: "Downstream", value: data.downstream_emission },
      ]
    : [];

  const handleUpstreamBranchChange = (branchId: string | null) => {
    setUpstreamBranch(branchId);
  };

  const handleScope1BranchChange = (branchId: string | null) => {
    setScope1Branch(branchId);
  };

  const handleUpstreamDateRangeChange = (
    startDate: string | undefined,
    endDate: string | undefined
  ) => {
    setUpstreamDateRange({ startDate, endDate });
  };

  const handleScope1DateRangeChange = (
    startDate: string | undefined,
    endDate: string | undefined
  ) => {
    setScope1DateRange({ startDate, endDate });
  };

  useEffect(() => {
    refetch();
  }, [upstreamBranch, upstreamDateRange, refetch]);

  useEffect(() => {
    if (getScope1Emission.data) {
      const data = getScope1Emission.data as {
        "Stationary Fuel Consumption": number;
        "Mobile Fuel Consumption": number;
        "Process Emission": number;
        "Fugitive Emission": number;
        total_consumption: number;
      };

      const formattedData: Scope1Data[] = [
        {
          name: "Stationary Fuel",
          value: data["Stationary Fuel Consumption"],
          fill: "#38A169",
        },
        {
          name: "Mobile Fuel",
          value: data["Mobile Fuel Consumption"],
          fill: "#48BB78",
        },
        {
          name: "Process Emission",
          value: data["Process Emission"],
          fill: "#68D391",
        },
        {
          name: "Fugitive Emission",
          value: data["Fugitive Emission"],
          fill: "#9AE6B4",
        },
      ];
      setScope1Data(formattedData);
    }
  }, [getScope1Emission.data]);

  useEffect(() => {
    if (getScope2Emission.data) {
      const data = getScope2Emission.data as {
        renewable_emission: number;
        renewable_total_kwh_value: number;
        non_renewable_emission: number;
        non_renewable_total_kwh_value: number;
        total_emission: number;
      };

      const formattedData: Scope2Data[] = [
        {
          name: "Renewable",
          value: data.renewable_emission,
          fill: "#38A169",
        },
        {
          name: "Non-Renewable",
          value: data.non_renewable_emission,
          fill: "#E53E3E",
        },
      ];
      setScope2Data(formattedData);
    }
  }, [getScope2Emission.data]);

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <Box
          bg="white"
          p={4}
          borderRadius="lg"
          boxShadow="xl"
          border="1px solid"
          borderColor="gray.200"
        >
          <Text fontWeight="bold" fontSize="md" mb={2}>
            {payload[0].name}
          </Text>
          <Text fontSize="lg" color="green.500" fontWeight="semibold">
            {`${payload[0].value.toFixed(2)} tons CO2e`}
          </Text>
          <Text color="gray.600" fontSize="sm" mt={1}>
            {`${(
              (payload[0].value / (data?.total_emission || 1)) *
              100
            ).toFixed(2)}% of total`}
          </Text>
        </Box>
      );
    }
    return null;
  };

  const Scope1Tooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <Box
          bg="white"
          p={4}
          borderRadius="lg"
          boxShadow="xl"
          border="1px solid"
          borderColor="gray.200"
        >
          <Text fontWeight="bold" fontSize="md" mb={2}>
            {payload[0].payload.name}
          </Text>
          <Text fontSize="lg" color="green.500" fontWeight="semibold">
            {`${payload[0].value.toFixed(2)} tons CO2e`}
          </Text>
        </Box>
      );
    }
    return null;
  };

  const Scope2Tooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      return (
        <Box
          bg="white"
          p={4}
          borderRadius="lg"
          boxShadow="xl"
          border="1px solid"
          borderColor="gray.200"
        >
          <Text fontWeight="bold" fontSize="md" mb={2}>
            {payload[0].payload.name}
          </Text>
          <Text fontSize="lg" color="green.500" fontWeight="semibold">
            {`${payload[0].value.toFixed(2)} tons CO2e`}
          </Text>
        </Box>
      );
    }
    return null;
  };

  return (
    <Layout
      headerTitle="Emission Dashboard"
      subHeaderTitle="Track and analyze your organization's emission metrics"
      backButtonURL={"/dashboard?tab=environment"}
      activePage={"/dashboard"}
    >
      <div className="emission-dashboard-minimal">
        {/* Trademark Images Row */}
        <div
          aria-label="Trademark/License Images"
          style={{
            // position: "absolute",
            top: "-1rem",
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            gap: "0.5rem",
            background: "rgba(255, 255, 255, 0.95)",
            border: "1px solid #e2e8f0",
            borderRadius: "9px",
            boxShadow: "0 4px 16px rgba(0, 0, 0, 0.07)",
            padding: "15px",
            zIndex: 10,
            minHeight: "48px",
            minWidth: "full",
            // maxWidth: "279px",
            marginBottom: "20px",
          }}
        >
          <Image
            src="/images/emission-dashboard/1.png"
            alt="Trademark License 1"
            width={52}
            height={52}
            className="emission-dashboard-image"
            style={{ objectFit: "contain" }}
          />
          <Image
            src="/images/emission-dashboard/2.png"
            alt="Trademark License 2"
            width={52}
            height={52}
            className="emission-dashboard-image"
            style={{ objectFit: "contain" }}
          />
          <Image
            src="/images/emission-dashboard/3.png"
            alt="Trademark License 3"
            width={52}
            height={52}
            className="emission-dashboard-image"
            style={{ objectFit: "contain" }}
          />
          <Image
            src="/images/emission-dashboard/4.png"
            alt="Trademark License 4"
            width={52}
            height={52}
            className="emission-dashboard-image"
            style={{ objectFit: "contain" }}
          />
        </div>

        {/* Stats Row */}
        <div className="stats-row">
          <div className="stat-card-minimal">
            <Icon as={Cloud} className="stat-icon-minimal scope1-icon" />
            <div>
              <div className="stat-value-minimal">
                {getScope1Emission.data
                  ? `${Number(
                      (getScope1Emission.data as any).total_consumption || 0
                    ).toFixed(2)} tons CO₂e`
                  : "0 tons CO₂e"}
              </div>
              <div className="stat-title-minimal">Scope 1 Emissions</div>
            </div>
          </div>
          <div className="stat-card-minimal">
            <Icon as={TrendingUp} className="stat-icon-minimal scope2-icon" />
            <div>
              <div className="stat-value-minimal">
                {getScope2Emission.data
                  ? `${Number(
                      (getScope2Emission.data as any).total_emission || 0
                    ).toFixed(2)} tons CO₂e`
                  : "0 tons CO₂e"}
              </div>
              <div className="stat-title-minimal">Scope 2 Emissions</div>
            </div>
          </div>
          <div className="stat-card-minimal">
            <Icon as={Activity} className="stat-icon-minimal scope3-icon" />
            <div>
              <div className="stat-value-minimal">
                {data
                  ? `${Number(data.total_emission || 0).toFixed(2)} tons CO₂e`
                  : "0 tons CO₂e"}
              </div>
              <div className="stat-title-minimal">Scope 3 Emissions</div>
            </div>
          </div>
        </div>

        {/* Charts Section */}
        <div className="charts-section">
          {/* All Charts in Single Row */}
          <div className="compact-cards-row">
            <div className="compact-card">
              <div className="compact-card-header">
                <span className="compact-card-title">
                  Scope 1 Emission Breakdown
                </span>
              </div>

              {/* Scope 1 Filters */}
              <div className="compact-card-filters">
                <HStack spacing={3} mb={3}>
                  <Box flex="1">
                    <BranchDropdown
                      value={scope1Branch || ""}
                      onChange={handleScope1BranchChange}
                    />
                  </Box>
                  <Box flex="1">
                    <DateRangeFilter
                      onApply={handleScope1DateRangeChange}
                      onCancel={() =>
                        setScope1DateRange({
                          startDate: undefined,
                          endDate: undefined,
                        })
                      }
                    />
                  </Box>
                </HStack>
              </div>

              {getScope1Emission.isLoading ? (
                <div className="compact-card-loading">
                  <Skeleton height="200px" borderRadius="lg" />
                  <Text
                    fontSize="sm"
                    color="gray.500"
                    textAlign="center"
                    mt={2}
                  >
                    Loading Scope 1 emission data...
                  </Text>
                </div>
              ) : (
                <div className="compact-card-chart">
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart
                      data={scope1Data}
                      margin={{ left: 5, right: 5, top: 24, bottom: 0 }}
                    >
                      <XAxis
                        dataKey="name"
                        fontSize={10}
                        stroke="#A0AEC0"
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        type="number"
                        fontSize={10}
                        stroke="#A0AEC0"
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `${value}`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "white",
                          border: "none",
                          borderRadius: "0.5rem",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                          fontSize: 10,
                        }}
                        cursor={{ fill: "rgba(0,0,0,0.03)" }}
                        formatter={(value) => `${value} tons CO₂e`}
                      />
                      <Bar
                        dataKey="value"
                        radius={[6, 6, 0, 0]}
                        maxBarSize={20}
                      >
                        {scope1Data?.map((c, i) => (
                          <Cell key={i} fill={c.fill} />
                        ))}
                        <LabelList
                          dataKey="value"
                          position="top"
                          content={({ x, y, width, value, index }) => {
                            return (
                              <text
                                // @ts-ignore
                                x={x + width / 2}
                                // @ts-ignore
                                y={y - 8}
                                textAnchor="middle"
                                fontSize={10}
                                fontWeight={400}
                                fill="#2F855A"
                                style={{ pointerEvents: "none" }}
                              >
                                {value}
                              </text>
                            );
                          }}
                        />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            <div className="compact-card">
              <div className="compact-card-header">
                <span className="compact-card-title">
                  Scope 2 Emission Breakdown
                </span>
              </div>

              {/* Scope 2 Filters */}
              <div className="compact-card-filters">
                <HStack spacing={3} mb={3}>
                  <Box flex="1">
                    <BranchDropdown
                      value={scope1Branch || ""}
                      onChange={handleScope1BranchChange}
                    />
                  </Box>
                  <Box flex="1">
                    <DateRangeFilter
                      onApply={handleScope1DateRangeChange}
                      onCancel={() =>
                        setScope1DateRange({
                          startDate: undefined,
                          endDate: undefined,
                        })
                      }
                    />
                  </Box>
                </HStack>
              </div>

              {getScope2Emission.isLoading ? (
                <div className="compact-card-loading">
                  <Skeleton height="200px" borderRadius="lg" />
                  <Text
                    fontSize="sm"
                    color="gray.500"
                    textAlign="center"
                    mt={2}
                  >
                    Loading Scope 2 emission data...
                  </Text>
                </div>
              ) : getScope2Emission.isError ? (
                <div className="compact-card-error">
                  <Text color="red.500" fontSize="sm" textAlign="center">
                    Failed to load Scope 2 emission data
                  </Text>
                </div>
              ) : (
                <div className="compact-card-chart">
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart
                      data={scope2Data}
                      margin={{ left: 5, right: 5, top: 24, bottom: 0 }}
                    >
                      <XAxis
                        dataKey="name"
                        fontSize={10}
                        stroke="#A0AEC0"
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        type="number"
                        fontSize={10}
                        stroke="#A0AEC0"
                        tickLine={false}
                        axisLine={false}
                        tickFormatter={(value) => `${value}`}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "white",
                          border: "none",
                          borderRadius: "0.5rem",
                          boxShadow: "0 2px 8px rgba(0,0,0,0.04)",
                          fontSize: 10,
                        }}
                        cursor={{ fill: "rgba(0,0,0,0.03)" }}
                        formatter={(value) => `${value} tons CO₂e`}
                      />
                      <Bar
                        dataKey="value"
                        radius={[6, 6, 0, 0]}
                        maxBarSize={20}
                      >
                        {scope2Data?.map((c, i) => (
                          <Cell key={i} fill={c.fill} />
                        ))}
                        <LabelList
                          dataKey="value"
                          position="top"
                          content={({ x, y, width, value, index }) => {
                            return (
                              <text
                                // @ts-ignore
                                x={x + width / 2}
                                // @ts-ignore
                                y={y - 8}
                                textAnchor="middle"
                                fontSize={10}
                                fontWeight={400}
                                fill="#2F855A"
                                style={{ pointerEvents: "none" }}
                              >
                                {value}
                              </text>
                            );
                          }}
                        />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            <div className="compact-card chart-card">
              <div className="compact-card-header">
                <span className="compact-card-title">
                  Scope 3 Emissions Distribution
                </span>
              </div>

              {/* Scope 3 Filters */}
              <div className="compact-card-filters">
                <HStack spacing={3} mb={3}>
                  <Box flex="1">
                    <BranchDropdown
                      value={upstreamBranch || ""}
                      onChange={handleUpstreamBranchChange}
                    />
                  </Box>
                  <Box flex="1">
                    <DateRangeFilter
                      onApply={handleUpstreamDateRangeChange}
                      onCancel={() =>
                        setUpstreamDateRange({
                          startDate: undefined,
                          endDate: undefined,
                        })
                      }
                    />
                  </Box>
                </HStack>
              </div>

              {isLoading ? (
                <div className="compact-card-loading">
                  <Skeleton height="200px" borderRadius="lg" />
                  <Text
                    fontSize="sm"
                    color="gray.500"
                    textAlign="center"
                    mt={2}
                  >
                    Loading Scope 3 emission data...
                  </Text>
                </div>
              ) : isError ? (
                <div className="compact-card-error">
                  <Text color="red.500" fontSize="sm" textAlign="center">
                    Failed to load Scope 3 emission data
                  </Text>
                </div>
              ) : (
                <div className="compact-card-chart pie-chart">
                  <ResponsiveContainer width={140} height={180}>
                    <PieChart>
                      <Pie
                        data={pieData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={40}
                        outerRadius={60}
                        labelLine={false}
                        label={({ percent }) =>
                          `${(percent * 100).toFixed(0)}%`
                        }
                      >
                        {pieData?.map((slice, i) => (
                          <Cell key={i} fill={COLORS[i % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip content={<CustomTooltip />} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="compact-card-legend pie-legend">
                    {pieData.map((d, i) => (
                      <Popover key={i} trigger="hover" placement="right">
                        <PopoverTrigger>
                          <div className="compact-legend-item">
                            <span
                              className="compact-legend-dot"
                              style={{ background: COLORS[i % COLORS.length] }}
                            />
                            <span className="compact-legend-label">
                              {d.name}
                            </span>
                          </div>
                        </PopoverTrigger>
                        <PopoverContent width="auto" p={2}>
                          <PopoverArrow />
                          <PopoverBody>
                            <Text fontSize="sm" fontWeight="medium">
                              {d.name}
                            </Text>
                            <Text fontSize="sm" color="gray.600">
                              Value: {d.value.toFixed(2)} tons CO₂e
                            </Text>
                            <Text fontSize="sm" color="gray.600">
                              Percentage:{" "}
                              {(
                                (d.value /
                                  pieData.reduce(
                                    (sum, item) => sum + item.value,
                                    0
                                  )) *
                                100
                              ).toFixed(1)}
                              %
                            </Text>
                          </PopoverBody>
                        </PopoverContent>
                      </Popover>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        <style jsx>{`
          .emission-dashboard-minimal {
            padding: 1rem 0.5rem;
            background: #fafbfc;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
          }
          .filters-section-minimal {
            margin-bottom: 1rem;
            background: none;
            border: none;
            box-shadow: none;
            padding: 0;
            display: flex;
            justify-content: flex-end;
          }
          .stats-row {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
          }
          .stat-card-minimal {
            flex: 1;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: #fff;
            border-radius: 0.75rem;
            padding: 0.75rem;
            box-shadow: none;
            border: 1px solid #f3f4f6;
            height: 80px;
            transition: all 0.2s ease-in-out;
            min-width: 200px;
          }
          .stat-card-minimal:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
              0 2px 4px -2px rgba(0, 0, 0, 0.1);
          }
          .stat-icon-minimal {
            width: 1.8rem;
            height: 1.8rem;
            opacity: 0.7;
          }
          .scope1-icon {
            color: #38a169;
          }
          .scope2-icon {
            color: #48bb78;
          }
          .scope3-icon {
            color: #68d391;
          }
          .stat-value-minimal {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2f855a;
            margin-bottom: 0.1rem;
          }
          .stat-title-minimal {
            font-size: 0.85rem;
            color: #8d99ae;
            font-weight: 400;
            letter-spacing: 0.01em;
          }
          .charts-section {
            display: flex;
            flex-direction: column;
            gap: 1rem;
          }
          .compact-cards-row {
            display: flex;
            gap: 0.75rem;
            flex-wrap: wrap;
          }
          .compact-card {
            background: #fff;
            border-radius: 0.75rem;
            border: 1px solid #f3f4f6;
            box-shadow: none;
            flex: 1 1 calc(33.333% - 0.5rem);
            min-width: 250px;
            display: flex;
            flex-direction: column;
            padding: 0.75rem;
            position: relative;
            min-height: 150px;
            transition: all 0.2s ease-in-out;
            z-index: 10;
          }
          .compact-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
              0 2px 4px -2px rgba(0, 0, 0, 0.1);
            z-index: 15;
          }
          .compact-card.chart-card {
            flex: 1 1 calc(33.333% - 0.5rem);
            min-width: 250px;
            min-height: 240px;
          }
          .compact-card-header {
            width: 100%;
            text-align: center;
            margin-bottom: 0.5rem;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0.5rem;
          }
          .compact-card-title {
            font-weight: 600;
            color: #2d3748;
            letter-spacing: 0.02em;
            font-size: 0.9rem;
            margin-bottom: 0.25rem;
          }
          .compact-card-filters {
            margin-bottom: 1rem;
            position: relative;
            z-index: 30;
          }
          .compact-card-chart {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            flex: 1;
            width: 100%;
            padding-bottom: 2rem;
            margin-bottom: 0.5rem;
          }
          .compact-card-chart.pie-chart {
            flex-direction: row;
            justify-content: space-between;
            padding: 0.75rem;
            height: 100%;
            margin-bottom: 0.5rem;
          }
          .compact-card-chart.pie-chart :global(.recharts-wrapper) {
            width: 180px !important;
            height: 180px !important;
          }
          .compact-card-legend.pie-legend {
            flex: 1;
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            padding: 0.75rem;
            max-width: 160px;
            justify-content: center;
            margin-top: 0.5rem;
          }
          .compact-legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.25rem 0;
          }
          .compact-legend-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            flex-shrink: 0;
          }
          .compact-legend-label {
            font-size: 0.75rem;
            color: #4a5568;
            line-height: 1.3;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
          }
          .compact-card-loading,
          .compact-card-error {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex: 1;
            padding: 1rem;
          }
          @media (max-width: 1200px) {
            .compact-card {
              flex: 1 1 calc(50% - 0.375rem);
              min-width: 280px;
            }
            .compact-card.chart-card {
              flex: 1 1 calc(50% - 0.375rem);
              min-width: 280px;
            }
          }
          @media (max-width: 900px) {
            .stats-row {
              flex-direction: column;
            }
            .stat-card-minimal {
              flex: 1 1 100%;
            }
            .compact-card {
              flex: 1 1 100%;
            }
            .compact-card.chart-card {
              flex: 1 1 100%;
            }
          }
          @media (max-width: 500px) {
            .stats-row {
              flex-direction: column;
            }
            .stat-card-minimal {
              flex: 1 1 100%;
            }
          }
          .emission-dashboard-image-row {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 1.25rem;
          }
          .emission-dashboard-image {
            width: 32px !important;
            height: 32px !important;
            object-fit: contain;
            border-radius: 0.25rem;
            background: #f8fafc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
          }

          /* Ensure Popovers appear above all elements */
          :global(.chakra-popover__content) {
            z-index: 9999 !important;
          }
          :global(.chakra-popover__popper) {
            z-index: 9999 !important;
          }
        `}</style>
      </div>
    </Layout>
  );
};

export default EmissionDashboard;
