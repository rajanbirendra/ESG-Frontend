"use client";
import React from "react";
import {
  Button,
  Container,
  FormControl,
  FormLabel,
  Input,
  InputGroup,
  InputRightElement,
  Text,
  VStack,
  useColorModeValue,
  Card,
  CardBody,
  Icon,
  useToast,
  Box,
  Heading,
  Flex,
  Divider,
} from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { changePasswordSchema } from "@/schemas/change-password.schema";
import Layout from "@/ui/layouts/DashboardLayout";
import { useAuthAPI } from "@/query/use-auth";
import { Eye, EyeOff, Lock, Shield } from "lucide-react";

const ChangePassword = () => {
  const [show, setShow] = React.useState(false);
  const [showNew, setShowNew] = React.useState(false);
  const [showConfirm, setShowConfirm] = React.useState(false);
  const toast = useToast();

  // Theme colors
  const cardBg = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const headingColor = useColorModeValue("gray.700", "white");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const subtextColor = useColorModeValue("gray.500", "gray.500");
  const inputBg = useColorModeValue("white", "gray.700");
  const inputBorderColor = useColorModeValue("gray.200", "gray.600");
  const inputHoverBorderColor = useColorModeValue("blue.200", "blue.300");
  const inputFocusBorderColor = useColorModeValue("blue.400", "blue.500");

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm({
    resolver: zodResolver(changePasswordSchema),
  });

  const { mutate, isPending } = useAuthAPI().changePassword;

  const onSubmit = (data: any) => {
    // @ts-ignore
    mutate(
      // @ts-ignore
      {
        // @ts-ignore
        body: {
          // @ts-ignore
          old_password: data.password,
          new_password: data.newPassword,
        },
      },
      {
        onSuccess: () => {
          toast({
            title: "Password Updated",
            description: "Your password has been successfully updated.",
            status: "success",
            duration: 5000,
            isClosable: true,
            position: "top-right",
          });
          reset();
        },
        onError: (error: any) => {
          toast({
            title: "Error",
            description: error?.message || "Failed to update password",
            status: "error",
            duration: 5000,
            isClosable: true,
            position: "top-right",
          });
        },
      }
    );
  };

  return (
    <Layout
      activePage="/dashboard/change-password"
      headerTitle="Change Password"
      subHeaderTitle="Update your account password"
    >
      <Container maxW="800px" px={6}>
        <VStack spacing={8} align="stretch">
          <Card
            bg={cardBg}
            border="1px solid"
            borderColor={borderColor}
            borderRadius="xl"
            boxShadow="sm"
            overflow="hidden"
          >
            <CardBody p={8}>
              <VStack spacing={8} align="stretch">
                <Flex align="center" gap={3}>
                  <Icon as={Shield} boxSize={6} color="blue.500" />
                  <Heading size="md" color={headingColor}>
                    Password Settings
                  </Heading>
                </Flex>
                <Divider />
                <form onSubmit={handleSubmit(onSubmit)}>
                  <VStack spacing={6}>
                    <FormControl isInvalid={!!errors.password}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color={headingColor}
                        mb={2}
                      >
                        Current Password
                      </FormLabel>
                      <InputGroup size="lg">
                        <Input
                          type={show ? "text" : "password"}
                          placeholder="Enter your current password"
                          {...register("password")}
                          bg={inputBg}
                          borderColor={inputBorderColor}
                          _hover={{ borderColor: inputHoverBorderColor }}
                          _focus={{
                            borderColor: inputFocusBorderColor,
                            boxShadow: `0 0 0 1px ${inputFocusBorderColor}`,
                          }}
                          pl={10}
                        />
                        <InputRightElement width="4.5rem">
                          <Button
                            h="1.75rem"
                            size="sm"
                            onClick={() => setShow(!show)}
                            variant="ghost"
                            _hover={{ bg: "transparent" }}
                          >
                            {show ? (
                              <Icon as={EyeOff} color={subtextColor} />
                            ) : (
                              <Icon as={Eye} color={subtextColor} />
                            )}
                          </Button>
                        </InputRightElement>
                        <Box
                          position="absolute"
                          left={3}
                          top="50%"
                          transform="translateY(-50%)"
                        >
                          <Icon as={Lock} color="gray.400" boxSize={4} />
                        </Box>
                      </InputGroup>
                      {errors.password && (
                        <Text color="red.500" fontSize="sm" mt={1}>
                          {errors.password.message}
                        </Text>
                      )}
                    </FormControl>

                    <FormControl isInvalid={!!errors.newPassword}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color={headingColor}
                        mb={2}
                      >
                        New Password
                      </FormLabel>
                      <InputGroup size="lg">
                        <Input
                          type={showNew ? "text" : "password"}
                          placeholder="Enter your new password"
                          {...register("newPassword")}
                          bg={inputBg}
                          borderColor={inputBorderColor}
                          _hover={{ borderColor: inputHoverBorderColor }}
                          _focus={{
                            borderColor: inputFocusBorderColor,
                            boxShadow: `0 0 0 1px ${inputFocusBorderColor}`,
                          }}
                          pl={10}
                        />
                        <InputRightElement width="4.5rem">
                          <Button
                            h="1.75rem"
                            size="sm"
                            onClick={() => setShowNew(!showNew)}
                            variant="ghost"
                            _hover={{ bg: "transparent" }}
                          >
                            {showNew ? (
                              <Icon as={EyeOff} color={subtextColor} />
                            ) : (
                              <Icon as={Eye} color={subtextColor} />
                            )}
                          </Button>
                        </InputRightElement>
                        <Box
                          position="absolute"
                          left={3}
                          top="50%"
                          transform="translateY(-50%)"
                        >
                          <Icon as={Lock} color="gray.400" boxSize={4} />
                        </Box>
                      </InputGroup>
                      {errors.newPassword && (
                        <Text color="red.500" fontSize="sm" mt={1}>
                          {errors.newPassword.message}
                        </Text>
                      )}
                    </FormControl>

                    <FormControl isInvalid={!!errors.reNewPassword}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color={headingColor}
                        mb={2}
                      >
                        Confirm New Password
                      </FormLabel>
                      <InputGroup size="lg">
                        <Input
                          type={showConfirm ? "text" : "password"}
                          placeholder="Confirm your new password"
                          {...register("reNewPassword")}
                          bg={inputBg}
                          borderColor={inputBorderColor}
                          _hover={{ borderColor: inputHoverBorderColor }}
                          _focus={{
                            borderColor: inputFocusBorderColor,
                            boxShadow: `0 0 0 1px ${inputFocusBorderColor}`,
                          }}
                          pl={10}
                        />
                        <InputRightElement width="4.5rem">
                          <Button
                            h="1.75rem"
                            size="sm"
                            onClick={() => setShowConfirm(!showConfirm)}
                            variant="ghost"
                            _hover={{ bg: "transparent" }}
                          >
                            {showConfirm ? (
                              <Icon as={EyeOff} color={subtextColor} />
                            ) : (
                              <Icon as={Eye} color={subtextColor} />
                            )}
                          </Button>
                        </InputRightElement>
                        <Box
                          position="absolute"
                          left={3}
                          top="50%"
                          transform="translateY(-50%)"
                        >
                          <Icon as={Lock} color="gray.400" boxSize={4} />
                        </Box>
                      </InputGroup>
                      {errors.reNewPassword && (
                        <Text color="red.500" fontSize="sm" mt={1}>
                          {errors.reNewPassword.message}
                        </Text>
                      )}
                    </FormControl>

                    <Button
                      type="submit"
                      colorScheme="blue"
                      size="lg"
                      width="full"
                      isLoading={isPending}
                      fontWeight="medium"
                      mt={4}
                      leftIcon={<Icon as={Shield} boxSize={4} />}
                      _hover={{
                        transform: "translateY(-1px)",
                        boxShadow: "md",
                      }}
                      transition="all 0.2s"
                    >
                      Update Password
                    </Button>
                  </VStack>
                </form>
              </VStack>
            </CardBody>
          </Card>
        </VStack>
      </Container>
    </Layout>
  );
};

export default ChangePassword;
