// for displaying the scopes 1,2, and 3.
import { useState, useEffect, useRef } from "react";
import {
  Box,
  Text,
  Link,
  useToast,
  Tabs,
  TabList,
  Tab,
} from "@chakra-ui/react";
import Layout from "@/ui/layouts/DashboardLayout";
import withAuth from "@/utils/withAuth";
import NextLink from "next/link";
import { useRouter } from "next/router";
import { useQuestionAPI } from "@/query/use-question";
import AssessmentDynamicForm from "@/ui/organisms/DynamicForm";
import Loader from "@/ui/molecules/Loader";
import { QuestionCategory } from "@/api/types.gen";
import SubHeaderUI from "@/ui/molecules/subHeaderUI";

function ScopeThree() {
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [selectedPeriod, setSelectedPeriod] = useState("March 2025");
  const [questionAnswers, setQuestionAnswers] = useState({});
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [uploadKeys, setUploadKeys] = useState({});
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [guideOpen, setGuideOpen] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<{
    [key: string]: string;
  }>({});
  const [formData, setFormData] = useState<{ [key: string]: any }>({});
  const fileInputRefs = useRef({});

  const router = useRouter();
  // render this page, only when router is loaded.
  //   if (!router.isReady) return <Loader />;

  const toast = useToast();
  console.log("router", router);

  const { getQuestions } = useQuestionAPI();

  const { isLoading, data } = getQuestions({
    query: {
      question_of: "ASSESSMENT",
      type: "GOVERNANCE",
      assessment_id: router.query.id as string,
    },
  });

  console.log("data", data);

  useEffect(() => {}, [data, router.query.scope]);

  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  return (
    <Layout
      headerTitle={`Governance `}
      subHeaderTitle={
        isClient && (data as any)?.assessment ? (
          <SubHeaderUI assessment={(data as any)?.assessment} />
        ) : null
      }
      isLoading={isLoading || !isClient}
      backButtonURL={"/dashboard/assessment/start/" + router.query.id}
      activePage={"/dashboard/assessment"}
    >
      <Box flex="1" p={6}>
        <Box bg="white" borderRadius="md" boxShadow="sm" p={6}>
          {errorMessage && (
            <Box bg="red.100" borderRadius="md" p={4} mb={4}>
              <Text color="red.800" textAlign="center">
                {errorMessage}
              </Text>
            </Box>
          )}
          {successMessage && (
            <Box bg="green.100" borderRadius="md" p={4} mb={4}>
              <Text color="green.800" textAlign="center" fontWeight="semibold">
                {successMessage}
              </Text>
              <Box textAlign="center" mt={3}>
                <NextLink href="/assessment/assessment" passHref>
                  <Link color="blue.600" textDecoration="underline">
                    Back to assessments page
                  </Link>
                </NextLink>
              </Box>
            </Box>
          )}

          <center>{isLoading && <Loader />}</center>
          {!isLoading &&
            data &&
            // @ts-ignore
            data?.questions &&
            // @ts-ignore
            (data.questions as any).length > 0 && (
              <>
                <AssessmentDynamicForm
                  // @ts-ignore
                  data={data}
                  assessmentId={router.query.id as string}
                  assessmentFor={"ASSESSMENT_GOVERNANCE"}
                />
              </>
            )}
        </Box>
      </Box>
    </Layout>
  );
}

export default withAuth(ScopeThree);
