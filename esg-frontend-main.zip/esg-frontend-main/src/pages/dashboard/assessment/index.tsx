import { useAssessmentsAPI } from "@/query/use-assessments";
import { AssessmentType, Roles } from "@/types/index.types";
import Layout from "@/ui/layouts/DashboardLayout";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";
import React, { useState, useEffect } from "react";
import {
  AlertDialog,
  AlertDialogBody,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogFooter,
  useDisclosure,
  SimpleGrid,
  Text,
  Button,
  Input,
  Flex,
  Divider,
  Container,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  InputGroup,
  InputLeftElement,
  AlertDialogOverlay,
  AlertDialogCloseButton,
  Box,
} from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { CreateAssessmentSchema } from "@/schemas/assessment.schema";
import { Plus, Building2, Search, ChevronDown } from "lucide-react";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";
import { useCompanyAPI } from "@/query/use-company";
import { getParsedToken } from "@/utils/withAuth";
import { useQueryClient } from "@tanstack/react-query";
import CreateNewAssessmentModel from "@/ui/organisms/dashboard/assessment/CreateNewAssessmentModel";
import AssessmentCard from "@/ui/molecules/cards/AssessmentCard";
import EmptyAssessmentList from "@/ui/organisms/dashboard/assessment/EmptyAssessmentList";
import AssessmentHistoryDrawer from "@/ui/organisms/dashboard/assessment/AssessmentHistoryDrawer";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";

const Assessment = () => {
  const { getAssessments, createAssessment } = useAssessmentsAPI();
  const { getAllCompanyBranches } = useCompanyAPI();
  const {
    register,
    handleSubmit,
    setValue,
    watch,
    getValues,
    formState: { errors },
  } = useForm({
    defaultValues: {
      month: 1,
      year: new Date().getFullYear(),
    },
    resolver: zodResolver(CreateAssessmentSchema),
  });
  const [selectedYear, setSelectedYear] = React.useState(
    new Date().getFullYear().toString()
  );
  const [selectedBranch, setSelectedBranch] = React.useState<string | null>(
    null
  );
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [selectedAssessmentId, setSelectedAssessmentId] = useState<string>("");

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
    }, 300);
    return () => clearTimeout(handler);
  }, [search]);

  const { data: branches, isLoading: isLoadingBranches } =
    getAllCompanyBranches(
      // @ts-ignore
      {}
    ) as {
      data: {
        data: Array<{
          id: string;
          branch_name: string;
          country: string;
          state: string;
        }>;
      };
      isLoading: boolean;
    };

  const filteredBranches = React.useMemo(() => {
    if (!branches?.data) return [];
    return branches.data.filter((branch) =>
      branch.branch_name.toLowerCase().includes(debouncedSearch.toLowerCase())
    );
  }, [branches?.data, debouncedSearch]);

  // @ts-ignore
  const { isLoading, data } = getAssessments({
    query: {
      assessment_type: AssessmentType.ASSESSMENT,
      year: parseInt(selectedYear),
      // @ts-ignore
      branch: selectedBranch || undefined,
    },
  }) as { isLoading: boolean; data: any[] };

  const [isMounted, setIsMounted] = useState(false);
  const [userRole, setUserRole] = useState<Roles | null>(null);

  // Load user role on mount
  useEffect(() => {
    setIsMounted(true);
    const token = getParsedToken();
    if (token?.role) {
      setUserRole(token.role as Roles);
    }
  }, []);

  const assessments = data || [];

  const { isOpen, onOpen, onClose } = useDisclosure();
  const {
    isOpen: isHistoryOpen,
    onOpen: onHistoryOpen,
    onClose: onHistoryClose,
  } = useDisclosure();

  const {
    isOpen: isForwardOpen,
    onOpen: onForwardOpen,
    onClose: onForwardClose,
  } = useDisclosure();
  const closeRef = React.useRef(null);
  const forwardRef = React.useRef(null);

  const { mutate: updateAssessmentStatus, isPending } =
    useAssessmentsAPI().updateAssessmentStatus;

  const queryClient = useQueryClient();
  const handleForwardForReview = () => {
    // Add your forward for review logic here
    console.log("Forwarding assessment:", selectedAssessmentId);

    updateAssessmentStatus(
      // @ts-ignore
      {
        body: {
          assessment_id: selectedAssessmentId,
          status: (() => {
            if (userRole === Roles.SUB_USER) return "FORWARD_FOR_REVIEW";
            else if (userRole === Roles.USER) return "APPROVED";
          })(),
        },
      },
      {
        onSuccess: () => {
          onForwardClose();
          // @ts-ignore
          queryClient.invalidateQueries(
            // @ts-ignore
            getAssessments({
              query: {
                assessment_type: AssessmentType.ASSESSMENT,
                year: parseInt(selectedYear),
              },
            })
          );
        },
      }
    );
  };

  const [selectedAssessment, setSelectedAssessment] = useState<any>(null);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const quickAction = localStorage.getItem("dashboard_quick_action");
    if (quickAction === "assessment") {
      onOpen();
      localStorage.removeItem("dashboard_quick_action");
    }
  }, []);

  return (
    <Layout
      activePage={"/dashboard/assessment"}
      headerTitle="ESG Assessments"
      subHeaderTitle="Track and manage your environmental, social, and governance assessments"
    >
      <Container maxW="1600px" px={6}>
        <Flex justifyContent="flex-end" mb={8} alignItems="center" gap={4}>
          {userRole === Roles.USER && (
            <Box width="200px">
              <BranchDropdown
                value={selectedBranch}
                onChange={(branchId) => setSelectedBranch(branchId)}
                label=""
              />
            </Box>
          )}
          <YearDropdown
            selectedYear={selectedYear}
            onSelectYear={(year) => {
              setSelectedYear(year);
            }}
            maxCurrentYear={true}
          />
        </Flex>

        {isLoading ? (
          <ShimmerLoader count={6} />
        ) : assessments.length === 0 ? (
          <EmptyAssessmentList
            selectedBranch={selectedBranch}
            onOpen={onOpen}
          />
        ) : (
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
            {assessments.map((assessment: any) => (
              <AssessmentCard
                assessment={assessment}
                userRole={userRole?.toString() ?? ""}
                selectedAssessment={selectedAssessment}
                setSelectedAssessment={setSelectedAssessment}
                setSelectedAssessmentId={setSelectedAssessmentId}
                key={assessment._id}
                onForwardOpen={onForwardOpen}
                isForwardOpen={isForwardOpen}
                onHistoryOpen={onHistoryOpen}
              />
            ))}
          </SimpleGrid>
        )}

        {!isLoading && assessments.length > 0 && (
          <Box position="fixed" bottom="2rem" right="2rem" zIndex={10}>
            <Button
              size="lg"
              colorScheme="primary"
              onClick={onOpen}
              leftIcon={<Plus size={20} color="white" />}
              fontWeight="bold"
              borderRadius="full"
              px={8}
              py={6}
              boxShadow="lg"
              _hover={{
                boxShadow: "xl",
                transform: "translateY(-2px)",
                bg: "primary.600",
              }}
              transition="all 0.2s"
            >
              New Assessment
            </Button>
          </Box>
        )}

        <CreateNewAssessmentModel isOpen={isOpen} onClose={onClose} />

        <AssessmentHistoryDrawer
          selectedAssessment={selectedAssessment}
          isHistoryOpen={isHistoryOpen}
          onHistoryClose={onHistoryClose}
        />

        <AlertDialog
          isOpen={isForwardOpen}
          leastDestructiveRef={forwardRef}
          onClose={onForwardClose}
          isCentered
        >
          <AlertDialogOverlay>
            <AlertDialogContent>
              <AlertDialogHeader fontSize="lg" fontWeight="bold">
                Forward for Review
              </AlertDialogHeader>
              <AlertDialogCloseButton />
              <AlertDialogBody>
                <Text>
                  Are you sure you want to forward this assessment for review?
                </Text>
              </AlertDialogBody>
              <AlertDialogFooter>
                <Button ref={forwardRef} onClick={onForwardClose}>
                  Cancel
                </Button>
                <Button
                  colorScheme="green"
                  onClick={handleForwardForReview}
                  ml={3}
                >
                  Forward
                </Button>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialogOverlay>
        </AlertDialog>
      </Container>
    </Layout>
  );
};

export default Assessment;
