// for displaying the scopes 1,2, and 3.
import { useState, useEffect, useRef } from "react";
import {
  useToast,
  Text,
  Box,
  Flex,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Button,
} from "@chakra-ui/react";
import Layout from "@/ui/layouts/DashboardLayout";
import { useRouter } from "next/router";
import { useQuestionAPI } from "@/query/use-question";
import { QuestionCategory } from "@/api/types.gen";
import { ChevronDownIcon, Link } from "lucide-react";
import withAuth from "@/utils/withAuth";
import Loader from "@/ui/molecules/Loader";
import AssessmentDynamicForm from "@/ui/organisms/DynamicForm";
import SubHeaderUI from "@/ui/molecules/subHeaderUI";
import NextLink from "next/link";

function ScopeThree() {
  const [selectedBranch, setSelectedBranch] = useState(null);
  const [selectedPeriod, setSelectedPeriod] = useState("March 2025");
  const [questionAnswers, setQuestionAnswers] = useState({});
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [uploadKeys, setUploadKeys] = useState({});
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [guideOpen, setGuideOpen] = useState(false);
  const [selectedOptions, setSelectedOptions] = useState<{
    [key: string]: string;
  }>({});
  const [formData, setFormData] = useState<{ [key: string]: any }>({});
  const fileInputRefs = useRef({});

  const router = useRouter();
  // render this page, only when router is loaded.
  //   if (!router.isReady) return <Loader />;

  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const toast = useToast();
  console.log("router", router);

  const { getQuestions } = useQuestionAPI();

  const { isLoading, data } = getQuestions({
    query: {
      question_of: "ASSESSMENT",
      type: "ENVIRONMENT",
      category: router.query.scope as QuestionCategory,
      assessment_id: router.query.id as string,
    },
  });

  console.log("data", data);

  useEffect(() => {}, [data, router.query.scope]);

  console.log("selectedOptions", selectedOptions);
  return (
    <Layout
      isLoading={isLoading || !isClient}
      headerTitle={`Environment - ${
        router?.query?.scope?.toString().replace("SCOPE_", "Scope ") ?? ""
      }`}
      subHeaderTitle={
        isClient && (data as any)?.assessment ? (
          <SubHeaderUI assessment={(data as any)?.assessment} />
        ) : null
      }
      backButtonURL={"/dashboard/assessment/start/" + router.query.id}
      activePage={"/dashboard/assessment"}
    >
      <Box flex="1" p={6}>
        <Box bg="white" borderRadius="md" boxShadow="sm" p={6}>
          {errorMessage && (
            <Box bg="red.100" borderRadius="md" p={4} mb={4}>
              <Text color="red.800" textAlign="center">
                {errorMessage}
              </Text>
            </Box>
          )}
          {successMessage && (
            <Box bg="green.100" borderRadius="md" p={4} mb={4}>
              <Text color="green.800" textAlign="center" fontWeight="semibold">
                {successMessage}
              </Text>
              <Box textAlign="center" mt={3}>
                <NextLink href="/assessment/assessment" passHref>
                  <Link color="blue.600" textDecoration="underline">
                    Back to assessments page
                  </Link>
                </NextLink>
              </Box>
            </Box>
          )}

          {/* Top row: Scope dropdown, Branch, and Date selectors */}
          <Flex
            align="center"
            justify="space-between"
            mb={4}
            fontWeight="semibold"
          >
            {/* according to router.query.scope value make the default value of menuItem selected */}
            <Menu>
              <MenuButton
                as={Button}
                variant="outline"
                colorScheme="blue"
                rightIcon={<ChevronDownIcon />}
              >
                {router?.query?.scope?.toString().replace("SCOPE_", "Scope ")}
              </MenuButton>
              <MenuList>
                <MenuItem
                  onClick={() => {
                    router.push(
                      "/dashboard/assessment/environment/" +
                        router.query.id +
                        "/SCOPE_1"
                    );
                  }}
                  isDisabled={router.query.scope === "SCOPE_1"}
                  bg={router.query.scope === "SCOPE_1" ? "blue.50" : undefined}
                  _hover={
                    router.query.scope === "SCOPE_1"
                      ? { bg: "blue.50" }
                      : undefined
                  }
                >
                  Scope 1
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    router.push(
                      "/dashboard/assessment/environment/" +
                        router.query.id +
                        "/SCOPE_2"
                    );
                  }}
                  isDisabled={router.query.scope === "SCOPE_2"}
                  bg={router.query.scope === "SCOPE_2" ? "blue.50" : undefined}
                  _hover={
                    router.query.scope === "SCOPE_2"
                      ? { bg: "blue.50" }
                      : undefined
                  }
                >
                  Scope 2
                </MenuItem>
                <MenuItem
                  onClick={() => {
                    router.push(
                      "/dashboard/assessment/environment/" +
                        router.query.id +
                        "/SCOPE_3"
                    );
                  }}
                  isDisabled={router.query.scope === "SCOPE_3"}
                  bg={router.query.scope === "SCOPE_3" ? "blue.50" : undefined}
                  _hover={
                    router.query.scope === "SCOPE_3"
                      ? { bg: "blue.50" }
                      : undefined
                  }
                >
                  Scope 3
                </MenuItem>
              </MenuList>
            </Menu>
          </Flex>

          <center>{isLoading && <Loader />}</center>
          {!isLoading &&
            data &&
            // @ts-ignore
            data?.questions &&
            // @ts-ignore
            (data.questions as any).length > 0 && (
              <>
                <AssessmentDynamicForm
                  // @ts-ignore
                  data={data}
                  assessmentId={router.query.id as string}
                />
              </>
            )}
        </Box>
      </Box>
    </Layout>
  );
}

export default withAuth(ScopeThree);
