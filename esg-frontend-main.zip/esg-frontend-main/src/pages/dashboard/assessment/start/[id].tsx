"use client";

import {
  Box,
  Text,
  Button,
  Icon,
  Container,
  Heading,
  SimpleGrid,
  useColorModeValue,
  VStack,
  HStack,
} from "@chakra-ui/react";
import { useRouter } from "next/router";
import { FiUsers, FiShield } from "react-icons/fi";
import { FaLeaf } from "react-icons/fa";
import Layout from "@/ui/layouts/DashboardLayout";
import { useAssessmentsAPI } from "@/query/use-assessments";
import { MiniProgressBox } from "@/ui/molecules/ProgressBox";
import { LucideCalendar, LucideFile, LucideGitBranch } from "lucide-react";
import { useState, useEffect } from "react";
import withAuth from "@/utils/withAuth";

function AssessmentPage() {
  const router = useRouter();
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
  }, []);

  const { data: percentageInfo, isLoading } =
    useAssessmentsAPI().getPercentageOfAssessment({
      query: {
        assessment_id: router.query.id as string,
      },
    });
  console.log("percentageInfo", percentageInfo);
  // Theme colors
  const cardBg = useColorModeValue("white", "gray.800");
  const boxBg = useColorModeValue("gray.50", "gray.700");
  const headingColor = useColorModeValue("gray.700", "white");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const borderColor = useColorModeValue("gray.200", "gray.600");
  const envColor = useColorModeValue("green.500", "green.300");
  const socialColor = useColorModeValue("blue.500", "blue.300");
  const govColor = useColorModeValue("purple.500", "purple.300");

  const handleStart = (categoryId: number) => {
    if (typeof window !== "undefined") {
      localStorage.setItem("categoryId", String(categoryId));
    }
    if (categoryId === 1) {
      router.push(
        "/dashboard/assessment/environment/" + router.query.id + "/SCOPE_1"
      );
    } else if (categoryId === 2) {
      router.push("/dashboard/assessment/social/" + router.query.id);
    } else if (categoryId === 3) {
      router.push("/dashboard/assessment/governance/" + router.query.id);
    }
  };

  const AssessmentCard = ({
    title,
    description,
    icon,
    color,
    onClick,
  }: {
    title: string;
    description: string;
    icon: any;
    color: string;
    onClick: () => void;
  }) => (
    <Box
      bg={boxBg}
      p={6}
      borderRadius="lg"
      border="1px solid"
      borderColor={borderColor}
      transition="all 0.2s"
      _hover={{
        transform: "translateY(-4px)",
        boxShadow: "lg",
        borderColor: color,
      }}
    >
      <VStack align="start" spacing={4}>
        <HStack justify="space-between" w="full">
          <Heading size="md" color={headingColor} fontWeight="600">
            {title}
          </Heading>
          <Box
            p={2}
            bg={`${color}10`}
            borderRadius="full"
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            <Icon as={icon} boxSize={6} color={color} />
          </Box>
        </HStack>
        <Text fontSize="md" color={textColor} lineHeight="tall">
          {description}
        </Text>
        <Text style={{ width: "100%" }}>
          {isClient && (percentageInfo as any)?.data && (
            <MiniProgressBox
              completion_percentage={
                (percentageInfo as any)?.data[title.toString().toUpperCase()]
                  ?.completion_percentage
              }
              answered_questions={
                (percentageInfo as any)?.data[title.toString().toUpperCase()]
                  ?.answered_questions
              }
              total_questions={
                (percentageInfo as any)?.data[title.toString().toUpperCase()]
                  ?.total_questions
              }
            />
          )}
        </Text>
        <Button
          colorScheme={color.split(".")[0]}
          onClick={onClick}
          size="lg"
          width="full"
          fontWeight="medium"
          _hover={{
            transform: "translateY(-1px)",
            boxShadow: "md",
          }}
          transition="all 0.2s"
        >
          {(percentageInfo as any)?.data[title.toString().toUpperCase()]
            ?.answered_questions > 0
            ? "View"
            : "Start"}{" "}
          Assessment
        </Button>
      </VStack>
    </Box>
  );

  return (
    <Layout
      isLoading={isLoading || !isClient}
      activePage={"/dashboard/assessment"}
      backButtonURL={"/dashboard/assessment"}
      headerTitle="ESG Assessment Categories"
      subHeaderTitle={
        isClient && (
          <HStack>
            <div style={{ display: "flex", gap: "5px" }}>
              <LucideFile size={"20"} />
              <Text>{(percentageInfo as any)?.meta?.title}</Text>
            </div>
            <div style={{ display: "flex", gap: "5px" }}>
              <LucideGitBranch size={"20"} />
              <Text>{(percentageInfo as any)?.meta?.branch?.branch_name}</Text>
            </div>
            <div style={{ display: "flex", marginLeft: "10px", gap: "5px" }}>
              <LucideCalendar size={"20"} />
              <Text>
                {(percentageInfo as any)?.meta?.assessment_year}/
                {(percentageInfo as any)?.meta?.assessment_month}
              </Text>
            </div>
          </HStack>
        )
      }
    >
      <Container maxW="1200px" px={6}>
        <VStack spacing={8} align="stretch">
          <VStack align="start" spacing={2}>
            {/* <Heading size="lg" color={headingColor} fontWeight="600">
            Select a category to begin your assessment 
            </Heading> */}
            <Text color={textColor} fontSize="md">
              Select a category to begin your assessment
            </Text>
          </VStack>

          <SimpleGrid columns={{ base: 1, md: 3 }} spacing={6}>
            <AssessmentCard
              title="Environment"
              description="Record and monitor your monthly environmental metrics (energy use, waste, emissions)."
              icon={FaLeaf}
              color={envColor}
              onClick={() => handleStart(1)}
            />

            <AssessmentCard
              title="Social"
              description="Capture your social impact data, from community programs to employee well‑being."
              icon={FiUsers}
              color={socialColor}
              onClick={() => handleStart(2)}
            />

            <AssessmentCard
              title="Governance"
              // empty line to make the description look good
              description={`Answer governance questions on policies, risk management, and board oversight. Use Help for information on each question.
               
              `}
              icon={FiShield}
              color={govColor}
              onClick={() => handleStart(3)}
            />
          </SimpleGrid>
        </VStack>
      </Container>
    </Layout>
  );
}

export default withAuth(AssessmentPage);
