import Layout from "@/ui/layouts/DashboardLayout";
import {
  VStack,
  CardBody,
  Container,
  Card,
  Text,
  Heading,
  HStack,
  Box,
  Icon,
  Divider,
  Badge,
  SimpleGrid,
  Avatar,
  useToast,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  useDisclosure,
  Flex,
  Image,
  Center,
} from "@chakra-ui/react";
import React from "react";
import { useAuthAPI } from "@/query/use-auth";
import Loader from "@/ui/molecules/Loader";
import {
  Mail,
  Phone,
  Building2,
  MapPin,
  Users,
  Briefcase,
  Calendar,
  Shield,
} from "lucide-react";
import { useForm } from "react-hook-form";
import { useUserAPI } from "@/query/use-user";
import EditProfile from "@/ui/organisms/profile/EditProfile";

const Profile = () => {
  const toast = useToast();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const {
    isOpen: isImageOpen,
    onOpen: onImageOpen,
    onClose: onImageClose,
  } = useDisclosure();

  // @ts-ignore
  const { data: me, isLoading, refetch } = useAuthAPI().getMe();
  const { mutate: updateProfile, isPending: isUpdating } =
    useUserAPI().updateProfile;

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm();

  React.useEffect(() => {
    if (me) {
      reset({
        first_name: (me as any).first_name,
        last_name: (me as any).last_name,
        email: (me as any).email,
        phone_number: (me as any).phone_number,
        company_role: (me as any).company_role,
        profile_picture: (me as any).profile_picture,
      });
    }
  }, [me, reset]);

  const onSubmit = (data) => {
    updateProfile(
      // @ts-ignore
      { body: data },
      {
        onSuccess: () => {
          refetch();
          onClose();
        },
      }
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const InfoItem = ({ icon, label, value }) => (
    <HStack spacing={3} align="start">
      <Box
        p={2}
        borderRadius="full"
        display="flex"
        alignItems="center"
        justifyContent="center"
      >
        <Icon as={icon} w={5} h={5} color="iconColor" />
      </Box>
      <VStack align="start" spacing={0}>
        <Text fontSize="sm" color="subtextColor">
          {label}
        </Text>
        <Text color="headingColor" fontWeight="medium">
          {value}
        </Text>
      </VStack>
    </HStack>
  );

  return (
    <Layout
      activePage="/dashboard/profile"
      headerTitle="Profile"
      subHeaderTitle="View and manage your personal and company information"
    >
      <Container maxW="1200px" px={6}>
        <VStack spacing={8} align="stretch">
          {isLoading ? (
            <Loader />
          ) : (
            (me as any) && (
              <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
                {/* Personal Information */}
                <Card
                  bg="sidebarBg"
                  border="1px solid"
                  borderColor="borderColor"
                >
                  <CardBody>
                    <VStack spacing={6} align="stretch">
                      <HStack spacing={4}>
                        <Avatar
                          size="xl"
                          name={`${(me as any)?.first_name} ${
                            (me as any)?.last_name
                          }`}
                          src={(me as any)?.profile_picture}
                          cursor="pointer"
                          onClick={onImageOpen}
                          _hover={{ opacity: 0.8 }}
                          transition="all 0.2s"
                        />
                        <VStack align="start" spacing={1}>
                          <Heading size="md" color="headingColor">
                            {(me as any)?.first_name} {(me as any)?.last_name}
                          </Heading>
                          <Text color="subtextColor">
                            @{(me as any)?.username}
                          </Text>
                          <Badge
                            bg="activeBg"
                            color="activeColor"
                            px={2}
                            py={1}
                            borderRadius="full"
                            fontSize="xs"
                          >
                            {(me as any)?.role}
                          </Badge>
                        </VStack>
                      </HStack>
                      <Flex justifyContent="flex-end">
                        <EditProfile values={me as any} />
                      </Flex>
                      <Divider borderColor="borderColor" />
                      <VStack spacing={4} align="stretch">
                        <InfoItem
                          icon={Mail}
                          label="Email Address"
                          value={(me as any)?.email}
                        />
                        <InfoItem
                          icon={Phone}
                          label="Phone Number"
                          value={(me as any)?.phone_number}
                        />
                        <InfoItem
                          icon={Briefcase}
                          label="Company Role"
                          value={(me as any)?.company_role}
                        />
                        <InfoItem
                          icon={Calendar}
                          label="Member Since"
                          value={formatDate((me as any)?.created_at)}
                        />
                      </VStack>
                    </VStack>
                  </CardBody>
                </Card>
                {/* Company Information */}
                <Card
                  bg="sidebarBg"
                  border="1px solid"
                  borderColor="borderColor"
                >
                  <CardBody>
                    <VStack spacing={6} align="stretch">
                      <HStack spacing={4} align="center">
                        <Box
                          w="80px"
                          h="80px"
                          borderRadius="lg"
                          overflow="hidden"
                          bg="white"
                          border="1px solid"
                          borderColor="borderColor"
                          display="flex"
                          alignItems="center"
                          justifyContent="center"
                          p={2}
                        >
                          {(me as any)?.company?.logo ? (
                            <Image
                              src={(me as any)?.company?.logo}
                              alt="Company Logo"
                              w="full"
                              h="full"
                              objectFit="cover"
                            />
                          ) : (
                            <Icon
                              as={Building2}
                              w={10}
                              h={10}
                              color="gray.400"
                            />
                          )}
                        </Box>
                        <VStack align="start" spacing={1}>
                          <Heading size="md" color="headingColor">
                            {(me as any)?.company?.company_name}
                          </Heading>
                          <Text color="subtextColor" fontSize="sm">
                            Industry: {(me as any)?.company?.industry_vertical}
                          </Text>
                          <Badge
                            bg="activeBg"
                            color="activeColor"
                            px={2}
                            py={1}
                            borderRadius="full"
                            fontSize="xs"
                          >
                            Branch :{" "}
                            {(me as any)?.branch?.branch_name || "Main Branch"}
                          </Badge>
                        </VStack>
                      </HStack>
                      <Divider borderColor="borderColor" />
                      <VStack spacing={4} align="stretch">
                        <InfoItem
                          icon={Building2}
                          label="Company Name"
                          value={(me as any)?.company?.company_name}
                        />
                        <InfoItem
                          icon={MapPin}
                          label="Location"
                          value={(me as any)?.company?.location}
                        />
                        <InfoItem
                          icon={Users}
                          label="Number of Employees"
                          value={(me as any)?.company?.number_of_employees}
                        />
                        <InfoItem
                          icon={Shield}
                          label="CO2 Accounting"
                          value={
                            (me as any)?.company?.co2_accounted
                              ? "Enabled"
                              : "Disabled"
                          }
                        />
                      </VStack>
                    </VStack>
                  </CardBody>
                </Card>
              </SimpleGrid>
            )
          )}
        </VStack>
      </Container>

      {/* Profile Image Modal */}
      <Modal isOpen={isImageOpen} onClose={onImageClose} isCentered size="xl">
        <ModalOverlay backdropFilter="blur(4px)" />
        <ModalContent bg="white" borderRadius="xl" overflow="hidden">
          <ModalHeader borderBottom="1px" borderColor="gray.200" pb={4}>
            Profile Picture
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody p={0}>
            {(me as any)?.profile_picture ? (
              <Image
                src={(me as any)?.profile_picture}
                alt="Profile"
                w="full"
                h="auto"
                objectFit="contain"
                maxH="70vh"
              />
            ) : (
              <Center p={8}>
                <Text color="gray.500">No profile picture available</Text>
              </Center>
            )}
          </ModalBody>
        </ModalContent>
      </Modal>
    </Layout>
  );
};

export default Profile;
