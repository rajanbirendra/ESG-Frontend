// src/pages/dashboard/index.js   ← rename from dashboards.js so it maps to /dashboard
import { useAuthAPI } from "@/query/use-auth";
import { Roles } from "@/types/index.types";
import Layout from "@/ui/layouts/DashboardLayout";
import SubUserDashboard from "@/ui/organisms/dashboard/SubUserDashboard";
import UserDashboardPage from "@/ui/organisms/dashboard/UserDashboardPage";
import { getParsedToken } from "@/utils/withAuth";
import { useEffect, useState } from "react";

function Dashboards() {


  return (
    <Layout
      headerTitle="Dashboard"
      subHeaderTitle="Welcome to Dashboard !"
      activePage={"/dashboard"}
    >
      <UserDashboardPage />
    </Layout>
  );
}

export default Dashboards;
