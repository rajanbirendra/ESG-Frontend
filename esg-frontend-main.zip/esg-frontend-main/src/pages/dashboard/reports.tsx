import React from "react";
import {
  Box,
  Text,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Link,
  Button,
  AlertDialog,
  useDisclosure,
  AlertDialogOverlay,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogCloseButton,
  AlertDialogBody,
  Container,
  Flex,
  VStack,
  Heading,
  Spinner,
} from "@chakra-ui/react";
import { ViewIcon, DownloadIcon } from "@chakra-ui/icons";
import { Plus, Download as LucideDownload } from "lucide-react";

// Import the Layout component that has the sidebar/topbar
import Layout from "@/ui/layouts/DashboardLayout";
import withAuth from "../../utils/withAuth";
import RequestReport from "@/ui/organisms/dashboard/reports/RequestReport";
import { useReportsList } from "@/query/use-report";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";

// Define the expected report API response type
interface ReportCreator {
  id: string;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
}
interface ReportStatus {
  status: string;
  date: string;
  remarks?: string;
}
interface ReportItem {
  id: string;
  type: string;
  starting_year_month: string;
  ending_year_month: string;
  legal_company_name: string;
  cin_number: string;
  report_person_name: string;
  status: ReportStatus[];
  file: string | null;
  created_by: string;
  company_id: string;
  created_at: string;
  updated_at: string;
  creator?: ReportCreator;
}
interface ReportsApiResponse {
  reports: ReportItem[];
  total_count: number;
  limit: number;
  offset: number;
}

function Reports() {
  // Pass required headers (authorization handled by API client, so empty string is fine)
  const { data, isLoading } = useReportsList({
    headers: { authorization: "" },
  });
  const reportList = data as ReportsApiResponse | undefined;

  const { isOpen, onOpen, onClose } = useDisclosure();
  const cancelRef = React.useRef(null);

  // Helper to format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString();
  };

  // Helper to format period display
  const formatPeriod = (startPeriod: string, endPeriod: string) => {
    const startYear = startPeriod.split("-")[0];
    const startMonth = startPeriod.split("-")[1];
    const endYear = endPeriod.split("-")[0];
    const endMonth = endPeriod.split("-")[1];

    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];

    const startMonthName = monthNames[parseInt(startMonth) - 1];
    const endMonthName = monthNames[parseInt(endMonth) - 1];

    if (startYear === endYear) {
      return `${startMonthName} - ${endMonthName} ${startYear}`;
    } else {
      return `${startMonthName} ${startYear} - ${endMonthName} ${endYear}`;
    }
  };

  return (
    <Layout
      activePage={"/dashboard/reports"}
      headerTitle="Request Custom Reports"
      subHeaderTitle="Generate comprehensive ESG reports in various frameworks including GRI, SASB, TCFD, ISSB, CDP, ESRS, BRSR, and more."
    >
      <Container maxW="1600px" px={6}>
        {/* Reports Table */}
        <Box mt={8}>
          {isLoading ? (
            <ShimmerLoader variant="reports" count={5} />
          ) : Array.isArray((reportList as ReportsApiResponse)?.reports) &&
            (reportList as ReportsApiResponse).reports.length > 0 ? (
            <Box
              bg="white"
              borderRadius="2xl"
              boxShadow="lg"
              overflowX="auto"
              px={{ base: 2, md: 6 }}
              py={6}
              maxW="100%"
              border="1px solid"
              borderColor="gray.100"
            >
              <Table
                variant="striped"
                colorScheme="gray"
                size="md"
                sx={{
                  "th, td": { whiteSpace: "nowrap" },
                  th: {
                    position: "sticky",
                    top: 0,
                    zIndex: 1,
                    bg: "primary.50",
                  },
                }}
              >
                <Thead>
                  <Tr>
                    <Th fontSize="sm" color="gray.600" fontWeight="bold">
                      Framework
                    </Th>
                    <Th fontSize="sm" color="gray.600" fontWeight="bold">
                      Period
                    </Th>
                    <Th fontSize="sm" color="gray.600" fontWeight="bold">
                      Status
                    </Th>
                    <Th fontSize="sm" color="gray.600" fontWeight="bold">
                      Remarks
                    </Th>
                    <Th fontSize="sm" color="gray.600" fontWeight="bold">
                      Requested At
                    </Th>
                    <Th fontSize="sm" color="gray.600" fontWeight="bold">
                      Requested By
                    </Th>
                    <Th
                      fontSize="sm"
                      color="gray.600"
                      fontWeight="bold"
                      textAlign="center"
                    >
                      Download
                    </Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {(reportList as ReportsApiResponse).reports.map((report) => {
                    const latestStatus =
                      report.status?.[report.status.length - 1] || {};
                    return (
                      <Tr
                        key={report.id}
                        _hover={{
                          bg: "primary.25",
                          boxShadow: "sm",
                          transition: "all 0.2s",
                        }}
                      >
                        <Td fontWeight="medium" color="gray.700">
                          {report.type}
                        </Td>
                        <Td color="gray.600">
                          {formatPeriod(
                            report.starting_year_month,
                            report.ending_year_month
                          )}
                        </Td>
                        <Td>
                          <Box
                            px={3}
                            py={1}
                            borderRadius="md"
                            bg={
                              latestStatus.status === "APPROVED"
                                ? "green.50"
                                : latestStatus.status === "REJECTED"
                                ? "red.50"
                                : latestStatus.status === "REQUESTED"
                                ? "yellow.50"
                                : "gray.50"
                            }
                            color={
                              latestStatus.status === "APPROVED"
                                ? "green.600"
                                : latestStatus.status === "REJECTED"
                                ? "red.600"
                                : latestStatus.status === "REQUESTED"
                                ? "yellow.700"
                                : "gray.600"
                            }
                            fontWeight="semibold"
                            fontSize="sm"
                            display="inline-block"
                          >
                            {latestStatus.status || "-"}
                          </Box>
                        </Td>
                        <Td
                          color="gray.600"
                          maxW="220px"
                          overflow="hidden"
                          textOverflow="ellipsis"
                        >
                          {latestStatus.remarks || (
                            <Text color="gray.400">-</Text>
                          )}
                        </Td>
                        <Td color="gray.500" fontSize="sm">
                          {formatDate(report.created_at)}
                        </Td>
                        <Td color="gray.700" fontSize="sm">
                          {report.creator ? (
                            <Box>
                              <Text fontWeight="semibold">
                                {report.creator.first_name}{" "}
                                {report.creator.last_name}
                              </Text>
                              <Text color="gray.400" fontSize="xs">
                                {report.creator.email}
                              </Text>
                            </Box>
                          ) : (
                            <Text color="gray.400">-</Text>
                          )}
                        </Td>
                        <Td textAlign="center">
                          {report.file ? (
                            <Link href={report.file} isExternal>
                              <Button
                                leftIcon={<LucideDownload size={18} />}
                                colorScheme="blue"
                                size="sm"
                                variant="outline"
                                borderRadius="md"
                                fontWeight="semibold"
                                _hover={{ bg: "blue.50" }}
                              >
                                Download
                              </Button>
                            </Link>
                          ) : (
                            <Text color="gray.300" fontSize="sm">
                              -
                            </Text>
                          )}
                        </Td>
                      </Tr>
                    );
                  })}
                </Tbody>
              </Table>
            </Box>
          ) : (
            <Flex
              direction="column"
              justify="center"
              align="center"
              minH="300px"
              py={12}
            >
              <Box mb={4}>
                <svg
                  width="80"
                  height="80"
                  viewBox="0 0 80 80"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <rect width="80" height="80" rx="20" fill="#F3F6FB" />
                  <path
                    d="M24 56V24H56V56H24Z"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M32 32H48"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                  <path
                    d="M32 40H48"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                  <path
                    d="M32 48H40"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                </svg>
              </Box>
              <Text color="gray.500" fontSize="lg" fontWeight="medium">
                No reports found. Request a new report to get started.
              </Text>
            </Flex>
          )}
        </Box>

        {/* Floating Action Button for Request Report */}
        <Box position="fixed" bottom="2rem" right="2rem" zIndex={10}>
          <RequestReport buttonText="Request Report" />
        </Box>
      </Container>
    </Layout>
  );
}
export default withAuth(Reports);
