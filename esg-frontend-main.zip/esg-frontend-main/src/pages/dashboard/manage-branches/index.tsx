import Layout from "@/ui/layouts/DashboardLayout";
import { useState } from "react";
import {
  Box,
  Button,
  Text,
  useDisclosure,
  VStack,
  HStack,
  Heading,
  Card,
  CardBody,
  useColorModeValue,
  Flex,
  Badge,
} from "@chakra-ui/react";
import { useCompanyAPI } from "@/query/use-company";
import { Plus, Building2, Building, MapPin } from "lucide-react";
import CreateNewBranch from "@/ui/organisms/dashboard/manage-branches/CreateNewBranch";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";

interface Branch {
  id: string;
  branch_name: string;
  state: string;
  country: string;
  created_at: string;
  updated_at: string;
  company_id: string;
}

const ManageBranches = () => {
  const { getAllCompanyBranches } = useCompanyAPI();
  const { data, isLoading: isLoadingCompanyBranches } = getAllCompanyBranches(
    // @ts-ignore
    {}
  ) as any;

  const { isOpen, onOpen, onClose } = useDisclosure();
  const cardBg = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");

  const EmptyState = () => (
    <VStack spacing={6} py={12} px={4} textAlign="center">
      <Building size={16} color="gray.400" />
      <VStack spacing={3}>
        <Heading size="lg" color="gray.700">
          No Branches Yet
        </Heading>
        <Text color="gray.500" maxW="md">
          Add your company branches to better organize and manage your ESG
          assessments.
        </Text>
      </VStack>
    </VStack>
  );

  return (
    <Layout
      headerTitle="Manage Branches"
      subHeaderTitle="Manage your company branches and locations"
      activePage="/dashboard/manage-branches"
    >
      <Box py={0} px={4}>
        {isLoadingCompanyBranches ? (
          <ShimmerLoader count={4} variant="branch" />
        ) : !data || data.length === 0 ? (
          <EmptyState />
        ) : (
          <VStack spacing={4} align="stretch">
            {data?.map((branch: Branch) => (
              <Card
                key={branch.id}
                bg={cardBg}
                border="1px solid"
                borderColor={borderColor}
                transition="all 0.2s"
                _hover={{
                  transform: "translateY(-2px)",
                  boxShadow: "md",
                }}
              >
                <CardBody>
                  <Flex justify="space-between" align="center">
                    <HStack spacing={4}>
                      <Building2
                        size={24}
                        color="var(--chakra-colors-blue-500)"
                      />
                      <VStack align="start" spacing={1}>
                        <Text
                          fontSize="lg"
                          fontWeight="semibold"
                          color="gray.700"
                        >
                          {branch.branch_name}
                        </Text>
                        <HStack spacing={2} color="gray.500">
                          <MapPin size={16} />
                          <Text fontSize="sm">
                            {branch.state}, {branch.country}
                          </Text>
                        </HStack>
                      </VStack>
                    </HStack>
                    <Badge colorScheme="blue" fontSize="sm">
                      {new Date(branch.created_at).toLocaleDateString()}
                    </Badge>
                  </Flex>
                </CardBody>
              </Card>
            ))}
          </VStack>
        )}
      </Box>

      {/* Floating Add Branch Button */}
      <Box position="fixed" bottom="2rem" right="2rem" zIndex={10}>
        <Button
          size="lg"
          colorScheme="blue"
          onClick={onOpen}
          leftIcon={<Plus size={20} />}
          borderRadius="full"
          fontWeight="bold"
          px={8}
          py={6}
          boxShadow="lg"
          _hover={{
            boxShadow: "xl",
            transform: "translateY(-2px)",
            bg: "blue.600",
          }}
          transition="all 0.2s"
        >
          Add Branch
        </Button>
      </Box>

      <CreateNewBranch isOpen={isOpen} onClose={onClose} />
    </Layout>
  );
};

export default ManageBranches;
