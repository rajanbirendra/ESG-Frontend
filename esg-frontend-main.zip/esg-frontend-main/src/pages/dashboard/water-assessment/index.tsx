import Layout from "@/ui/layouts/DashboardLayout";
import React from "react";

const index = () => {
  return (
    <Layout
      headerTitle="Water Assessment"
      activePage={"/dashboard/water-assessment"}
    >
      Under Development
    </Layout>
  );
};

export default index;
