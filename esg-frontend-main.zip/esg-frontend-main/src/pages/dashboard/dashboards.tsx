// src/pages/dashboard/index.js   ← rename from dashboards.js so it maps to /dashboard
import React, { useState, useEffect } from "react";
import {
  Box,
  Flex,
  Text,
  Icon,
  useColorModeValue,
  SimpleGrid,
  VStack,
  HStack,
  Badge,
  useDisclosure,
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  IconButton,
  Button,
  usePrefersReducedMotion,
} from "@chakra-ui/react";
import { keyframes } from "@emotion/react";
import {
  Users,
  Shield,
  ChevronRight,
  Menu,
  Activity,
  Sparkles,
} from "lucide-react";
import Layout from "@/ui/layouts/DashboardLayout";
import withAuth from "@/utils/withAuth";

import Environment from "@/ui/organisms/dashboard/home/EnvironmentAnalytics";
import Social from "@/ui/organisms/dashboard/home/social";
import Governance from "@/ui/organisms/dashboard/home/GovernanceAnalytics";

type MetricColor = "blue" | "green" | "purple" | null;

const floatAnimation = keyframes`
  0% { transform: translateY(0px); }
  50% { transform: translateY(-10px); }
  100% { transform: translateY(0px); }
`;

const pulseAnimation = keyframes`
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.05); opacity: 0.8; }
  100% { transform: scale(1); opacity: 1; }
`;

const AnalyticsCard = ({
  title,
  value,
  icon,
  trend,
  color,
  onClick,
  isActive,
}) => {
  const cardBg = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const prefersReducedMotion = usePrefersReducedMotion();
  const float = prefersReducedMotion
    ? undefined
    : `${floatAnimation} 3s ease-in-out infinite`;
  const pulse = prefersReducedMotion
    ? undefined
    : `${pulseAnimation} 2s ease-in-out infinite`;

  return (
    <Box
      bg={cardBg}
      p={6}
      borderRadius="2xl"
      border="1px solid"
      borderColor={isActive ? color : borderColor}
      cursor="pointer"
      transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
      position="relative"
      overflow="hidden"
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: `linear-gradient(135deg, ${color}.50 0%, transparent 100%)`,
        opacity: isActive ? 0.1 : 0,
        transition: "opacity 0.3s",
      }}
      _hover={{
        transform: "translateY(-4px) scale(1.02)",
        boxShadow: "xl",
        borderColor: color,
      }}
      onClick={onClick}
      animation={isActive ? float : undefined}
    >
      <Flex justify="space-between" align="center" mb={4}>
        <HStack spacing={3}>
          <Box
            p={2}
            borderRadius="lg"
            bg={`${color}.50`}
            animation={isActive ? pulse : undefined}
          >
            <Icon as={icon} boxSize={5} color={color} />
          </Box>
          <Text fontSize="sm" fontWeight="medium" color="gray.500">
            {title}
          </Text>
        </HStack>
        <Badge
          colorScheme={trend > 0 ? "green" : "red"}
          variant="subtle"
          px={3}
          py={1}
          borderRadius="full"
          fontSize="xs"
          fontWeight="bold"
          letterSpacing="wider"
        >
          {trend > 0 ? "+" : ""}
          {trend}%
        </Badge>
      </Flex>
      <Text
        fontSize="3xl"
        fontWeight="bold"
        bgGradient={`linear(to-r, ${color}.500, ${color}.300)`}
        bgClip="text"
        letterSpacing="tight"
      >
        {value}
      </Text>
      {isActive && (
        <Icon
          as={Sparkles}
          position="absolute"
          bottom={2}
          right={2}
          color={color}
          opacity={0.5}
          boxSize={4}
        />
      )}
    </Box>
  );
};

const NavigationButton = ({ icon, label, isActive, onClick, color }) => {
  const buttonBg = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");

  return (
    <Button
      variant="ghost"
      w="full"
      h="auto"
      p={4}
      onClick={onClick}
      bg={isActive ? `${color}.50` : buttonBg}
      border="1px solid"
      borderColor={isActive ? color : borderColor}
      borderRadius="xl"
      transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
      position="relative"
      overflow="hidden"
      _hover={{
        bg: `${color}.50`,
        borderColor: color,
        transform: "translateX(4px)",
      }}
      _before={{
        content: '""',
        position: "absolute",
        left: 0,
        top: 0,
        bottom: 0,
        width: "4px",
        bg: color,
        opacity: isActive ? 1 : 0,
        transition: "opacity 0.3s",
      }}
    >
      <HStack spacing={3} w="full" justify="flex-start">
        <Box
          p={2}
          borderRadius="lg"
          bg={isActive ? `${color}.100` : "gray.100"}
          transition="all 0.3s"
        >
          <Icon as={icon} boxSize={5} color={isActive ? color : "gray.500"} />
        </Box>
        <Text
          fontWeight={isActive ? "semibold" : "medium"}
          color={isActive ? color : "gray.600"}
          transition="all 0.3s"
        >
          {label}
        </Text>
        {isActive && (
          <Icon
            as={ChevronRight}
            boxSize={4}
            color={color}
            transition="transform 0.3s"
            _groupHover={{ transform: "translateX(4px)" }}
          />
        )}
      </HStack>
    </Button>
  );
};

function Dashboards() {
  const [activeTab, setActiveTab] = useState("environment");
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [selectedMetric, setSelectedMetric] = useState<MetricColor>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading state
    const timer = setTimeout(() => setIsLoading(false), 1000);
    return () => clearTimeout(timer);
  }, []);

  const metrics = [
    {
      title: "Total Emissions",
      value: "2,345 tCO₂e",
      icon: Activity,
      trend: 12.5,
      color: "blue" as const,
      component: Environment,
    },
    {
      title: "Social Impact Score",
      value: "85/100",
      icon: Users,
      trend: 8.2,
      color: "green" as const,
      component: Social,
    },
    {
      title: "Governance Rating",
      value: "A+",
      icon: Shield,
      trend: 5.7,
      color: "purple" as const,
      component: Governance,
    },
  ];

  const renderContent = () => {
    const Component =
      metrics.find((m) => m.color === selectedMetric)?.component || Environment;
    return <Component />;
  };

  return (
    <Layout>
      <Box
        maxW="1400px"
        mx="auto"
        px={4}
        py={8}
        position="relative"
        _before={{
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: "400px",
          background:
            "linear-gradient(180deg, primary.50 0%, transparent 100%)",
          opacity: 0.5,
          zIndex: -1,
        }}
      >
        <Flex gap={8} direction={{ base: "column", lg: "row" }}>
          {/* Left Sidebar - Hidden on mobile */}
          <Box
            w={{ base: "full", lg: "300px" }}
            display={{ base: "none", lg: "block" }}
            position="sticky"
            top={8}
            h="fit-content"
          >
            <VStack spacing={4} align="stretch">
              {metrics.map((metric) => (
                <NavigationButton
                  key={metric.color}
                  icon={metric.icon}
                  label={metric.title}
                  isActive={selectedMetric === metric.color}
                  onClick={() => setSelectedMetric(metric.color)}
                  color={metric.color}
                />
              ))}
            </VStack>
          </Box>

          {/* Mobile Menu Button */}
          <IconButton
            aria-label="Open menu"
            icon={<Menu />}
            display={{ base: "flex", lg: "none" }}
            position="fixed"
            bottom={4}
            right={4}
            zIndex={1000}
            colorScheme="primary"
            borderRadius="full"
            boxShadow="lg"
            onClick={onOpen}
            _hover={{
              transform: "scale(1.1)",
              boxShadow: "xl",
            }}
          />

          {/* Main Content */}
          <Box flex="1">
            <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6} mb={8}>
              {metrics.map((metric) => (
                <AnalyticsCard
                  key={metric.color}
                  {...metric}
                  isActive={selectedMetric === metric.color}
                  onClick={() => setSelectedMetric(metric.color)}
                />
              ))}
            </SimpleGrid>

            <Box
              bg="white"
              borderRadius="2xl"
              boxShadow="xl"
              border="1px solid"
              borderColor="gray.200"
              overflow="hidden"
              transition="all 0.3s"
              _hover={{
                boxShadow: "2xl",
                transform: "translateY(-2px)",
              }}
            >
              {renderContent()}
            </Box>
          </Box>
        </Flex>
      </Box>

      {/* Mobile Drawer */}
      <Drawer isOpen={isOpen} placement="right" onClose={onClose}>
        <DrawerOverlay backdropFilter="blur(4px)" />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader borderBottomWidth="1px">
            Analytics Navigation
          </DrawerHeader>
          <DrawerBody>
            <VStack spacing={4} align="stretch" mt={4}>
              {metrics.map((metric) => (
                <NavigationButton
                  key={metric.color}
                  icon={metric.icon}
                  label={metric.title}
                  isActive={selectedMetric === metric.color}
                  onClick={() => {
                    setSelectedMetric(metric.color);
                    onClose();
                  }}
                  color={metric.color}
                />
              ))}
            </VStack>
          </DrawerBody>
        </DrawerContent>
      </Drawer>
    </Layout>
  );
}

export default withAuth(Dashboards);
