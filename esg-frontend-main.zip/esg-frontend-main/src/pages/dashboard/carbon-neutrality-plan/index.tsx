import Layout from "@/ui/layouts/DashboardLayout";
import React, { useEffect } from "react";
import PlanList from "@/ui/organisms/dashboard/carbon-neutrality-plan/PlanList";
import CreatePlan from "@/ui/organisms/dashboard/carbon-neutrality-plan/CreatePlan";
import { useDisclosure, Box, Button, Flex } from "@chakra-ui/react";
import { Plus } from "lucide-react";

const Index = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  useEffect(() => {
    if (typeof window === "undefined") return;
    const quickAction = localStorage.getItem("dashboard_quick_action");
    if (quickAction === "cnp") {
      onOpen();
      localStorage.removeItem("dashboard_quick_action");
    }
  }, []);

  return (
    <Layout
      activePage={"/dashboard/carbon-neutrality-plan"}
      headerTitle="Carbon Neutrality Plan"
      subHeaderTitle="Manage and track your carbon neutrality plans"
    >
      <Box p={6} position="relative" minH="calc(100vh - 200px)">
        <PlanList />
        <Box position="fixed" bottom={6} right={6} zIndex={1000}>
          <Button
            leftIcon={<Plus size={18} />}
            colorScheme="teal"
            borderRadius="full"
            fontWeight="bold"
            px={6}
            py={4}
            onClick={onOpen}
            _hover={{
              bg: "teal.600",
              color: "white",
              transform: "translateY(-2px)",
              boxShadow: "xl",
            }}
            transition="all 0.2s"
            boxShadow="lg"
          >
            Add Carbon Neutrality Plan
          </Button>
        </Box>
      </Box>
      <CreatePlan isOpen={isOpen} onClose={onClose} />
    </Layout>
  );
};

export default Index;
