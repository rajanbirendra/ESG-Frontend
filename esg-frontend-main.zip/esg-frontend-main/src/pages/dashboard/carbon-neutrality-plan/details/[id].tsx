import { useQuestionAPI } from "@/query/use-question";
import Layout from "@/ui/layouts/DashboardLayout";
import AssessmentDynamicForm from "@/ui/organisms/DynamicForm";
import { PageNotFoundError } from "next/dist/shared/lib/utils";
import { useRouter } from "next/router";
import React, { useState, useEffect } from "react";
import {
  Box,
  Flex,
  Text,
  Heading,
  Icon,
  Button,
  VStack,
  HStack,
  Badge,
  useColorModeValue,
  Radio,
  RadioGroup,
  FormControl,
  FormLabel,
  Input,
  Select,
  InputGroup,
  InputRightElement,
} from "@chakra-ui/react";
import { AttachmentIcon } from "@chakra-ui/icons";
import {
  Factory,
  Zap,
  Truck,
  ArrowRight,
  FileText,
  CheckCircle,
  Clock,
  Calendar,
} from "lucide-react";
import Link from "next/link";
import { useCNPAPI } from "@/query/use-cnp";
import { useAssessmentsAPI } from "@/query/use-assessments";
import { MiniProgressBox } from "@/ui/molecules/ProgressBox";
import path from "path";

const CarbonNeutralityPlanDetails = () => {
  const router = useRouter();
  const planId = router.query.id;

  if (!planId) {
    return;
  }

  const { data, isLoading } = useQuestionAPI().getQuestions({
    query: {
      question_of: "CARBON_NEUTRALITY_PLAN",
      cnp_id: planId as string,
    },
  });

  const { data: planData, isLoading: isPlanLoading } =
    useCNPAPI().getOne(planId);

  // Get progress data for scope assessment
  const { data: progressData, isLoading: isProgressLoading } =
    useCNPAPI().getPercentageOfCNPScopeAssessment(
      // @ts-ignore
      {
        path: {
          // @ts-ignore
          id: planId as string,
        },
      }
    );

  const [carbonOffset, setCarbonOffset] = useState<string | null>(
    typeof router.query.carbon_offset === "string"
      ? router.query.carbon_offset
      : null
  );
  const [avoidanceOffsets, setAvoidanceOffsets] = useState<string | null>(
    typeof router.query.avoidance_offset === "string"
      ? router.query.avoidance_offset
      : null
  );

  const [formData, setFormData] = useState<{
    avoidanceValue?: string;
    avoidanceVerifiedBy?: string;
    avoidanceProof?: File;
    removalValue?: string;
    removalVerifiedBy?: string;
    removalProof?: File;
  }>({});

  const updateCNPMutation = useCNPAPI().update;

  // Set form values when plan data loads
  useEffect(() => {
    if (planData && (planData as any)?.data?.[0]) {
      const plan = (planData as any).data[0];
      setCarbonOffset(plan.carbon_offset || null);
      setAvoidanceOffsets(plan.avoidance_offset || null);
    }
  }, [planData]);

  if (!planId) {
    return <>Page Not Found</>;
  }

  const cardBg = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const hoverBg = useColorModeValue("gray.50", "gray.700");

  const handleFileUpload = (
    event: React.ChangeEvent<HTMLInputElement>,
    fieldLabel: string,
    questionId: string
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      setFormData((prev) => ({
        ...prev,
        [fieldLabel]: file,
      }));
    }
  };

  const handleSync = (data: any) => {
    setFormData((prev) => ({
      ...prev,
      [data.questionId]: data.values,
    }));
  };

  const handleUpdate = (data: any) => {
    updateCNPMutation.mutate(
      // @ts-ignore
      {
        body: data,
        path: {
          id: planId as string,
        },
      }
    );
  };

  console.log("planData", planData);

  // Get plan data safely
  const plan = planData && (planData as any)?.data?.[0];

  return (
    <Layout
      activePage={"/dashboard/carbon-neutrality-plan"}
      backButtonURL={"/dashboard/carbon-neutrality-plan"}
      isLoading={isLoading || isPlanLoading}
      headerTitle={`Carbon Neutrality Plan ${plan?.year || ""}`}
      subHeaderTitle={
        isPlanLoading ? (
          "Loading plan details..."
        ) : (
          <HStack>
            <div style={{ display: "flex", gap: "5px" }}>
              <FileText size={"20"} />
              <Text>Carbon Neutrality Plan {plan?.year}</Text>
            </div>
            <div style={{ display: "flex", gap: "5px" }}>
              <Calendar size={"20"} />
              <Text>
                Created:{" "}
                {plan?.created_at
                  ? new Date(plan.created_at).toLocaleDateString("en-US", {
                      year: "numeric",
                      month: "short",
                      day: "numeric",
                    })
                  : "N/A"}
              </Text>
            </div>
          </HStack>
        )
      }
    >
      <VStack spacing={6} align="stretch">
        {/* Carbon Offset Question */}
        <Box
          bg={cardBg}
          p={8}
          borderRadius="xl"
          border="1px"
          borderColor={borderColor}
          boxShadow="sm"
          w="80%"
          mx="auto"
        >
          <VStack spacing={6} align="stretch">
            <Heading size="lg" color="gray.700" textAlign="center">
              Are you doing carbon offset?
            </Heading>

            <RadioGroup
              value={carbonOffset || ""}
              onChange={() => {
                setCarbonOffset((prev) => (prev === "yes" ? "no" : "yes"));
                handleUpdate({
                  carbon_offset: carbonOffset === "yes" ? "no" : "yes",
                });
              }}
            >
              <HStack spacing={8} justify="center">
                <Radio value="yes" size="lg">
                  <Text fontSize="lg" fontWeight="medium">
                    Yes
                  </Text>
                </Radio>
                <Radio value="no" size="lg">
                  <Text fontSize="lg" fontWeight="medium">
                    No
                  </Text>
                </Radio>
              </HStack>
            </RadioGroup>

            {/* Scope Assessment Card - Only show if Yes is selected */}
            {carbonOffset === "yes" && (
              <Box
                mt={6}
                p={6}
                borderRadius="lg"
                border="1px"
                borderColor="blue.200"
                bg="blue.50"
              >
                <VStack spacing={4} align="stretch">
                  {/* Header */}
                  <Flex align="center" gap={3}>
                    <Box p={3} borderRadius="lg" bg="blue.100" color="blue.600">
                      <FileText size={24} />
                    </Box>
                    <VStack align="start" spacing={0}>
                      <Heading size="md" color="gray.700">
                        Scope Assessment
                      </Heading>
                      <Text fontSize="sm" color="gray.500" fontWeight="medium">
                        Complete your emissions evaluation
                      </Text>
                    </VStack>
                  </Flex>

                  {/* Progress Bar */}
                  {progressData && (progressData as any)?.data && (
                    <Box>
                      <MiniProgressBox
                        completion_percentage={
                          (progressData as any).data?.completion_percentage || 0
                        }
                        answered_questions={
                          (progressData as any).data?.answered_questions || 0
                        }
                        total_questions={
                          (progressData as any).data?.total_questions || 0
                        }
                      />
                    </Box>
                  )}

                  {/* Action Button */}
                  <Link
                    href={`/dashboard/carbon-neutrality-plan/details/${planId}/scope`}
                  >
                    <Button
                      rightIcon={<ArrowRight size={16} />}
                      colorScheme="blue"
                      size="md"
                      w="full"
                      _hover={{
                        transform: "translateX(2px)",
                      }}
                      transition="all 0.2s ease"
                    >
                      {(progressData as any)?.data?.answered_questions > 0
                        ? "View"
                        : "Start"}{" "}
                      Assessment
                    </Button>
                  </Link>
                </VStack>
              </Box>
            )}
          </VStack>
        </Box>

        {/* Avoidance Offsets Question - Show after carbon offset question */}
        <Box
          bg={cardBg}
          p={8}
          borderRadius="xl"
          border="1px"
          borderColor={borderColor}
          boxShadow="sm"
          w="80%"
          mx="auto"
        >
          <VStack spacing={6} align="stretch">
            <Heading size="lg" color="gray.700" textAlign="center">
              Do you have avoidance offsets?
            </Heading>

            <RadioGroup
              value={avoidanceOffsets || ""}
              onChange={() => {
                setAvoidanceOffsets((prev) => (prev === "yes" ? "no" : "yes"));
                handleUpdate({
                  avoidance_offset: avoidanceOffsets === "yes" ? "no" : "yes",
                });
              }}
            >
              <HStack spacing={8} justify="center">
                <Radio value="yes" size="lg">
                  <Text fontSize="lg" fontWeight="medium">
                    Yes
                  </Text>
                </Radio>
                <Radio value="no" size="lg">
                  <Text fontSize="lg" fontWeight="medium">
                    No
                  </Text>
                </Radio>
              </HStack>
            </RadioGroup>

            {/* Offset Input Fields - Only show if Yes is selected */}
            {avoidanceOffsets === "yes" && (
              <>
                <Box borderTop="1px" borderColor="gray.200" pt={6}>
                  <AssessmentDynamicForm
                    // @ts-ignore
                    data={{
                      questions: (data as any)?.questions?.filter(
                        (q) => q.category == "CNP_OFFSET"
                      ),
                    }}
                    cnpId={planId as string}
                    assessmentFor="CARBON_NEUTRALITY_PLAN"
                    showProgressBar={false}
                  />
                </Box>
              </>
            )}
          </VStack>
        </Box>
      </VStack>
    </Layout>
  );
};

export default CarbonNeutralityPlanDetails;
