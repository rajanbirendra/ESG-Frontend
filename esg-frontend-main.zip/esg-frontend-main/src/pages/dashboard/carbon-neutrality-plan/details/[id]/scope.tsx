import { useQuestionAPI } from "@/query/use-question";
import Layout from "@/ui/layouts/DashboardLayout";
import AssessmentDynamicForm from "@/ui/organisms/DynamicForm";
import { PageNotFoundError } from "next/dist/shared/lib/utils";
import { useRouter } from "next/router";
import React, { useState, useEffect, useRef } from "react";
import {
  Box,
  Flex,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Button,
} from "@chakra-ui/react";
import { ChevronDownIcon } from "lucide-react";

const CarbonNeutralityPlanDetails = () => {
  const [isClient, setIsClient] = useState(false);
  const router = useRouter();
  const planId = router.query.id;
  const isInitialLoad = useRef(true);

  // Get scope from URL query or default to SCOPE_1
  const getInitialScope = () => {
    const qParam = router.query.q as string;
    if (qParam === "1") return "SCOPE_1";
    if (qParam === "2") return "SCOPE_2";
    if (qParam === "3") return "SCOPE_3";
    return "SCOPE_1";
  };

  const [selectedScope, setSelectedScope] = useState(getInitialScope());

  useEffect(() => {
    setIsClient(true);
  }, []);

  // Update URL when scope changes
  useEffect(() => {
    if (isClient && planId && !isInitialLoad.current) {
      const scopeToQ = {
        SCOPE_1: "1",
        SCOPE_2: "2",
        SCOPE_3: "3",
      };
      const qValue = scopeToQ[selectedScope as keyof typeof scopeToQ];
      const newQuery = { ...router.query, q: qValue };
      router.replace(
        {
          pathname: router.pathname,
          query: newQuery,
        },
        undefined,
        { shallow: true }
      );
    }
  }, [selectedScope, isClient, planId]);

  // Update selectedScope when URL query changes (only on initial load)
  useEffect(() => {
    if (isClient && router.query.q && isInitialLoad.current) {
      const qParam = router.query.q as string;
      if (qParam === "1") setSelectedScope("SCOPE_1");
      if (qParam === "2") setSelectedScope("SCOPE_2");
      if (qParam === "3") setSelectedScope("SCOPE_3");
      isInitialLoad.current = false;
    }
  }, [router.query.q, isClient]);

  const { data, isLoading } = useQuestionAPI().getQuestions({
    query: {
      question_of: "CARBON_NEUTRALITY_PLAN",
      cnp_id: planId as string,
      category:
        selectedScope === "SCOPE_1"
          ? "CNP_SCOPE_1"
          : selectedScope === "SCOPE_2"
          ? "CNP_SCOPE_2"
          : "CNP_SCOPE_3",
    },
  });

  if (!planId || typeof planId !== "string") {
    return <>Page Not Found</>;
  }

  const handleScopeChange = (scope: string) => {
    setSelectedScope(scope);
  };

  console.log("data", data);
  return (
    <Layout
      activePage={"/dashboard/carbon-neutrality-plan"}
      backButtonURL={`/dashboard/carbon-neutrality-plan/details/${planId}`}
      headerTitle={
        `Carbon Neutrality Plan - ${selectedScope.replace(
          "SCOPE_",
          "Scope "
        )}` as string
      }
      subHeaderTitle="Complete your emissions assessment"
      isLoading={isLoading}
    >
      <Box flex="1" p={6}>
        <Box bg="white" borderRadius="md" boxShadow="sm" p={6}>
          {/* Top row: Scope dropdown */}
          <Flex
            align="center"
            justify="space-between"
            mb={4}
            fontWeight="semibold"
          >
            <Menu>
              <MenuButton
                as={Button}
                variant="outline"
                colorScheme="blue"
                rightIcon={<ChevronDownIcon />}
              >
                {selectedScope.replace("SCOPE_", "Scope ")}
              </MenuButton>
              <MenuList>
                <MenuItem
                  onClick={() => handleScopeChange("SCOPE_1")}
                  isDisabled={selectedScope === "SCOPE_1"}
                  bg={selectedScope === "SCOPE_1" ? "blue.50" : undefined}
                  _hover={
                    selectedScope === "SCOPE_1" ? { bg: "blue.50" } : undefined
                  }
                >
                  Scope 1
                </MenuItem>
                <MenuItem
                  onClick={() => handleScopeChange("SCOPE_2")}
                  isDisabled={selectedScope === "SCOPE_2"}
                  bg={selectedScope === "SCOPE_2" ? "blue.50" : undefined}
                  _hover={
                    selectedScope === "SCOPE_2" ? { bg: "blue.50" } : undefined
                  }
                >
                  Scope 2
                </MenuItem>
                <MenuItem
                  onClick={() => handleScopeChange("SCOPE_3")}
                  isDisabled={selectedScope === "SCOPE_3"}
                  bg={selectedScope === "SCOPE_3" ? "blue.50" : undefined}
                  _hover={
                    selectedScope === "SCOPE_3" ? { bg: "blue.50" } : undefined
                  }
                >
                  Scope 3
                </MenuItem>
              </MenuList>
            </Menu>
          </Flex>

          {!isLoading &&
            data &&
            (data as any)?.questions &&
            (data as any).questions.length > 0 && (
              <AssessmentDynamicForm
                data={{
                  questions: (data as any).questions,
                  completion_percentage: (data as any).completion_percentage,
                  answered_questions: (data as any).answered_questions,
                  total_questions: (data as any).total_questions,
                }}
                cnpId={planId}
                assessmentFor="CARBON_NEUTRALITY_PLAN"
              />
            )}
        </Box>
      </Box>
    </Layout>
  );
};

export default CarbonNeutralityPlanDetails;
