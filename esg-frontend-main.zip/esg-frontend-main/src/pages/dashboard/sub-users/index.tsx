import Layout from "@/ui/layouts/DashboardLayout";
import {
  Box,
  Heading,
  Text,
  Button,
  Flex,
  IconButton,
  ModalHeader,
  ModalContent,
  Modal,
  useDisclosure,
  ModalOverlay,
  ModalBody,
  FormLabel,
  Input,
  Select,
  VStack,
  HStack,
  Badge,
  useColorModeValue,
  FormControl,
  FormErrorMessage,
  SimpleGrid,
  Card,
  CardBody,
  Avatar,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  useToast,
  ModalCloseButton,
  InputGroup,
  InputLeftElement,
} from "@chakra-ui/react";
import { EditIcon, DeleteIcon } from "@chakra-ui/icons";
import { Building2, Mail, Phone } from "lucide-react";
import { useState, useEffect } from "react";
import { useCompanyAPI } from "@/query/use-company";
import { useAuthAPI } from "@/query/use-auth";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { LucideUser, UserPlus, Users } from "lucide-react";
import { createUserSchema } from "@/schemas/createUser.schema";
import BranchDropdown from "@/ui/molecules/dropdown/BranchDropdown";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";

const SubUsers = () => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sort, setSort] = useState("latest");
  const [selectedBranch, setSelectedBranch] = useState<string | null>(null);
  const toast = useToast();
  const cardBg = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
    }, 300);
    return () => clearTimeout(handler);
  }, [search]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const quickAction = localStorage.getItem("dashboard_quick_action");
    if (quickAction === "sub-user") {
      onOpen();
      localStorage.removeItem("dashboard_quick_action");
    }
  }, []);

  const { data: branches, isLoading: isLoadingBranches } =
    // @ts-ignore
    useCompanyAPI().getAllCompanyBranches({});

  const queryObj =
    debouncedSearch || sort || selectedBranch
      ? { query: { search: debouncedSearch, sort, branch: selectedBranch } }
      : undefined;
  const { data: companyUsers, isLoading: isLoadingCompanyUsers } =
    // @ts-ignore
    useCompanyAPI().getCompanyUsers(queryObj);

  const { mutate: addSubUser, isPending: isAddingSubUser } =
    useAuthAPI().addSubUser;

  const {
    register,
    handleSubmit,
    reset,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(createUserSchema),
  });

  const EmptyState = () => (
    <VStack spacing={6} py={12} px={4} textAlign="center">
      <LucideUser size={16} color="gray.400" />
      <VStack spacing={3}>
        <Heading size="lg" color="gray.700">
          No Sub Users Yet
        </Heading>
        <Text color="gray.500" maxW="md">
          Add sub-users to help manage your company's ESG assessments and data.
        </Text>
      </VStack>
    </VStack>
  );

  return (
    <Layout
      headerTitle="Sub Users"
      subHeaderTitle="Manage your company's sub-users and their access levels"
      activePage="/dashboard/sub-users"
    >
      <Box py={0} px={4}>
        <Flex justify="space-between" align="center" mb={8} gap={4}>
          <InputGroup size="lg" flex={1} maxW="800px">
            <InputLeftElement pointerEvents="none">
              <Users size={20} color="var(--chakra-colors-blue-500)" />
            </InputLeftElement>
            <Input
              placeholder="Search sub-users by name, email, or branch..."
              bg={useColorModeValue("gray.50", "gray.700")}
              variant="filled"
              borderRadius="full"
              border="1px solid"
              borderColor={useColorModeValue("gray.200", "gray.600")}
              fontSize="md"
              fontWeight="medium"
              px={6}
              py={3}
              _placeholder={{
                color: useColorModeValue("gray.400", "gray.500"),
                fontSize: "md",
              }}
              _hover={{
                borderColor: "blue.300",
                bg: useColorModeValue("gray.100", "gray.600"),
              }}
              _focus={{
                borderColor: "blue.500",
                boxShadow: "0 0 0 2px var(--chakra-colors-blue-100)",
                bg: useColorModeValue("white", "gray.800"),
              }}
              transition="all 0.2s"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              autoComplete="off"
            />
          </InputGroup>
          <Box minW="220px" ml={{ base: 0, md: 4 }}>
            <BranchDropdown
              value={selectedBranch}
              onChange={setSelectedBranch}
            />
          </Box>
        </Flex>

        {isLoadingCompanyUsers ? (
          <ShimmerLoader count={6} variant="sub-user" />
        ) : !companyUsers || (companyUsers as any).length === 0 ? (
          <EmptyState />
        ) : (
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
            {(companyUsers as any)?.data &&
              (companyUsers as any)?.data?.length > 0 &&
              (companyUsers as any)?.data?.map((user, index) => (
                <Card
                  key={user.id}
                  bg={cardBg}
                  border="1px solid"
                  borderColor={borderColor}
                  transition="all 0.2s"
                  _hover={{
                    transform: "translateY(-2px)",
                    boxShadow: "lg",
                    borderColor: "blue.200",
                  }}
                  borderRadius="xl"
                  overflow="hidden"
                >
                  <CardBody p={6}>
                    <Flex justify="space-between" align="start">
                      <HStack spacing={4}>
                        <Avatar
                          name={`${user.first_name} ${user.last_name}`}
                          size="lg"
                          src={user.profile_picture}
                          bg="blue.500"
                          color="white"
                          fontWeight="bold"
                          border="2px solid"
                          borderColor="blue.100"
                          _hover={{
                            borderColor: "blue.300",
                            transform: "scale(1.05)",
                          }}
                          transition="all 0.2s"
                        />
                        <VStack align="start" spacing={1}>
                          <Text
                            fontSize="lg"
                            fontWeight="bold"
                            color="gray.700"
                            lineHeight="tight"
                          >
                            {user.first_name} {user.last_name}
                          </Text>
                          <Text fontSize="sm" color="gray.500" noOfLines={1}>
                            {user.email}
                          </Text>
                          <HStack spacing={2} mt={1}>
                            <Badge
                              colorScheme="blue"
                              fontSize="xs"
                              px={2}
                              py={1}
                              borderRadius="full"
                              fontWeight="medium"
                            >
                              {user.company_role}
                            </Badge>
                            <Badge
                              colorScheme="green"
                              fontSize="xs"
                              px={2}
                              py={1}
                              borderRadius="full"
                              fontWeight="medium"
                            >
                              {user.role}
                            </Badge>
                          </HStack>
                        </VStack>
                      </HStack>
                      <Menu>
                        <MenuButton
                          as={IconButton}
                          variant="ghost"
                          size="sm"
                          icon={<EditIcon />}
                          aria-label="Edit user"
                          color="gray.500"
                          _hover={{
                            bg: "gray.100",
                            color: "blue.500",
                          }}
                        />
                        <MenuList>
                          <MenuItem
                            icon={<EditIcon />}
                            _hover={{
                              bg: "blue.50",
                              color: "blue.500",
                            }}
                          >
                            Edit User
                          </MenuItem>
                          <MenuItem
                            icon={<DeleteIcon />}
                            color="red.500"
                            _hover={{
                              bg: "red.50",
                              color: "red.500",
                            }}
                          >
                            Delete User
                          </MenuItem>
                        </MenuList>
                      </Menu>
                    </Flex>
                    <VStack
                      align="start"
                      spacing={2}
                      mt={6}
                      pt={4}
                      borderTop="1px solid"
                      borderColor={borderColor}
                    >
                      {user.role === "SUB_USER" && (
                        <Flex
                          align="center"
                          gap={2}
                          color="gray.500"
                          fontSize="sm"
                        >
                          <Building2 size={16} />
                          <Text>
                            Branch:{" "}
                            <Text
                              as="span"
                              color="gray.700"
                              fontWeight="medium"
                            >
                              {user?.branch?.branch_name}
                            </Text>
                          </Text>
                        </Flex>
                      )}
                      <Flex
                        align="center"
                        gap={2}
                        color="gray.500"
                        fontSize="sm"
                      >
                        <Mail size={16} />
                        <Text>
                          Email:{" "}
                          <Text as="span" color="gray.700" fontWeight="medium">
                            {user.email}
                          </Text>
                        </Text>
                      </Flex>
                      <Flex
                        align="center"
                        gap={2}
                        color="gray.500"
                        fontSize="sm"
                      >
                        <Phone size={16} />
                        <Text>
                          Phone:{" "}
                          <Text as="span" color="gray.700" fontWeight="medium">
                            {user.phone_number || "Not provided"}
                          </Text>
                        </Text>
                      </Flex>
                    </VStack>
                  </CardBody>
                </Card>
              ))}
          </SimpleGrid>
        )}

        {/* Floating Add Sub User Button */}
        <Box position="fixed" bottom="2rem" right="2rem" zIndex={10}>
          <Button
            size="lg"
            colorScheme="blue"
            onClick={onOpen}
            leftIcon={<UserPlus size={20} />}
            borderRadius="full"
            fontWeight="bold"
            px={8}
            py={6}
            boxShadow="lg"
            _hover={{
              boxShadow: "xl",
              transform: "translateY(-2px)",
              bg: "blue.600",
            }}
            transition="all 0.2s"
          >
            Add Sub User
          </Button>
        </Box>

        {/* Add Sub User Modal */}
        <Modal isOpen={isOpen} onClose={onClose} size="xl">
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Add New Sub User</ModalHeader>
            <ModalCloseButton />
            <ModalBody pb={6}>
              <form
                onSubmit={handleSubmit((data) =>
                  addSubUser(
                    // @ts-ignore
                    {
                      body: {
                        first_name: data.first_name,
                        last_name: data.last_name,
                        phone_number: data.phone_number,
                        email: data.email,
                        username: data.username,
                        password: data.password,
                        company_role: data.company_role,
                        branch: data.branch || "",
                      },
                    },
                    {
                      onSuccess: () => {
                        //close dialog
                        onClose();
                      },
                    }
                  )
                )}
              >
                <VStack spacing={4}>
                  <FormControl isInvalid={!!errors.first_name}>
                    <FormLabel>First Name</FormLabel>
                    <Input
                      {...register("first_name")}
                      placeholder="Enter first name"
                    />
                    <FormErrorMessage>
                      {errors.first_name && errors.first_name.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.last_name}>
                    <FormLabel>Last Name</FormLabel>
                    <Input
                      {...register("last_name")}
                      placeholder="Enter last name"
                    />
                    <FormErrorMessage>
                      {errors.last_name && errors.last_name.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.email}>
                    <FormLabel>Email</FormLabel>
                    <Input
                      {...register("email")}
                      type="email"
                      placeholder="Enter email"
                    />
                    <FormErrorMessage>
                      {errors.email && errors.email.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.phone_number}>
                    <FormLabel>Phone</FormLabel>
                    <Input
                      {...register("phone_number")}
                      placeholder="Enter phone number"
                    />
                    <FormErrorMessage>
                      {errors.phone_number && errors.phone_number.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.username}>
                    <FormLabel>Username</FormLabel>
                    <Input
                      {...register("username")}
                      placeholder="Enter username"
                    />
                    <FormErrorMessage>
                      {errors.username && errors.username.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.password}>
                    <FormLabel>Password</FormLabel>
                    <Input
                      {...register("password")}
                      type="password"
                      placeholder="Enter password"
                    />
                    <FormErrorMessage>
                      {errors.password && errors.password.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.company_role}>
                    <FormLabel>Company Role</FormLabel>
                    <Input
                      {...register("company_role")}
                      placeholder="Enter company role"
                    />
                    <FormErrorMessage>
                      {errors.company_role && errors.company_role.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.branch}>
                    <FormLabel>Branch</FormLabel>
                    <BranchDropdown
                      value={selectedBranch}
                      onChange={(value) => {
                        setSelectedBranch(value);
                        setValue("branch", value || "");
                      }}
                    />
                    <FormErrorMessage>
                      {errors.branch && errors.branch.message}
                    </FormErrorMessage>
                  </FormControl>

                  <Button
                    type="submit"
                    colorScheme="blue"
                    width="full"
                    isLoading={isAddingSubUser}
                    borderRadius="full"
                    fontWeight="bold"
                    size="lg"
                    px={8}
                    py={6}
                    boxShadow="sm"
                    _hover={{
                      boxShadow: "md",
                      transform: "translateY(-2px)",
                      bg: "blue.600",
                    }}
                    transition="all 0.2s"
                  >
                    Add Sub User
                  </Button>
                </VStack>
              </form>
            </ModalBody>
          </ModalContent>
        </Modal>
      </Box>
    </Layout>
  );
};

export default SubUsers;
