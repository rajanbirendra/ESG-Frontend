import { useUserAnalyticsAPI } from "@/query/use-user-analytics";
import Layout from "@/ui/layouts/DashboardLayout";
import React, { useEffect, useState } from "react";
import {
  Box,
  Card,
  CardBody,
  Flex,
  Heading,
  Skeleton,
  Text,
  VStack,
  HStack,
  Container,
  Icon,
} from "@chakra-ui/react";
import { Activity, Zap, TrendingUp } from "lucide-react";
import Image from "next/image";
import { format } from "date-fns";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LabelList,
  Cell,
  Legend,
} from "recharts";
import DateRangeFilter from "@/ui/molecules/DateRangeFilter";

interface BranchData {
  name: string;
  renewable: number;
  nonRenewable: number;
  total: number;
}

const EnergyDashboard = () => {
  const [energyByBranch, setEnergyByBranch] = useState<BranchData[]>([]);
  const [energyTotals, setEnergyTotals] = useState({
    renewable: 0,
    nonRenewable: 0,
    total: 0,
  });
  const [dateRange, setDateRange] = useState<{
    from: string | undefined;
    to: string | undefined;
  }>(() => {
    const today = new Date();
    const startOfYear = new Date(today.getFullYear(), 0, 1);
    return {
      from: format(startOfYear, "yyyy/MM/dd"),
      to: format(today, "yyyy/MM/dd"),
    };
  });

  const getBranchWiseEnergyMixData =
    useUserAnalyticsAPI().getBranchWiseEnergyMixData(
      dateRange.from,
      dateRange.to
    );

  const getEnergyMixData = useUserAnalyticsAPI().getEnergyMixData();

  useEffect(() => {
    if (getBranchWiseEnergyMixData.data) {
      const branchData = Object.entries(getBranchWiseEnergyMixData.data).map(
        ([branchName, data]: [string, any]) => ({
          name: branchName,
          renewable: data.renewable_total_consumption || 0,
          nonRenewable: data.non_renewable_total_consumption || 0,
          total:
            (data.renewable_total_consumption || 0) +
            (data.non_renewable_total_consumption || 0),
        })
      );
      setEnergyByBranch(branchData);

      // Calculate totals from all branches
      const totals = branchData.reduce(
        (acc, branch) => ({
          renewable: acc.renewable + branch.renewable,
          nonRenewable: acc.nonRenewable + branch.nonRenewable,
          total: acc.total + branch.total,
        }),
        { renewable: 0, nonRenewable: 0, total: 0 }
      );
      setEnergyTotals(totals);
    }
  }, [getBranchWiseEnergyMixData.data, dateRange]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <Box
          bg="white"
          p={3}
          borderRadius="md"
          boxShadow="lg"
          border="1px solid"
          borderColor="gray.200"
        >
          <Text fontWeight="bold" mb={1}>
            {label}
          </Text>
          <VStack align="start" spacing={1}>
            <HStack>
              <Box w={3} h={3} bg="#38A169" borderRadius="sm" />
              <Text>Renewable: {payload[0].value} KWH</Text>
            </HStack>
            <HStack>
              <Box w={3} h={3} bg="#3182CE" borderRadius="sm" />
              <Text>Non-renewable: {payload[1].value} KWH</Text>
            </HStack>
            <Text fontWeight="bold" mt={1}>
              Total: {payload[0].value + payload[1].value} KWH
            </Text>
          </VStack>
        </Box>
      );
    }
    return null;
  };

  const handleDateRangeApply = (
    from: string | undefined,
    to: string | undefined
  ) => {
    setDateRange({ from, to });
  };

  const handleDateRangeCancel = () => {
    const today = new Date();
    const startOfYear = new Date(today.getFullYear(), 0, 1);
    setDateRange({
      from: format(startOfYear, "yyyy/MM/dd"),
      to: format(today, "yyyy/MM/dd"),
    });
  };

  return (
    <Layout
      headerTitle="Energy Dashboard"
      backButtonURL={"/dashboard?tab=environment"}
      activePage={"/dashboard"}
    >
      <div className="energy-dashboard-minimal">
        {/* Trademark Images Floating Badge */}
        <div
          className="energy-dashboard-image-badge"
          aria-label="Trademark/License Images"
          style={{
            position: "absolute",
            top: "-1rem",
            display: "flex",
            flexDirection: "row",
            alignItems: "center",
            gap: "0.5rem",
            background: "rgba(255, 255, 255, 0.95)",
            border: "1px solid #e2e8f0",
            borderRadius: "9px",
            boxShadow: "0 4px 16px rgba(0, 0, 0, 0.07)",
            padding: "15px",
            zIndex: 10,
            minHeight: "48px",
            minWidth: "full",
            maxWidth: "100%",
          }}
        >
          <Image
            src="/images/energy-dashboard/1.png"
            alt="Trademark License 1"
            width={50}
            height={50}
            className="energy-dashboard-image"
            style={{ objectFit: "contain" }}
          />
          <Image
            src="/images/energy-dashboard/2.png"
            alt="Trademark License 2"
            width={50}
            height={50}
            className="energy-dashboard-image"
            style={{ objectFit: "contain" }}
          />
          <Image
            src="/images/energy-dashboard/3.png"
            alt="Trademark License 3"
            width={50}
            height={50}
            className="energy-dashboard-image"
            style={{ objectFit: "contain" }}
          />
        </div>

        {/* Filters Section */}
        <div className="filters-section-minimal">
          <HStack spacing={4}>
            <DateRangeFilter
              onApply={handleDateRangeApply}
              onCancel={handleDateRangeCancel}
            />
          </HStack>
        </div>

        {/* Stats Row */}
        <div className="stats-row">
          <div className="stat-card-minimal">
            <Icon as={Zap} className="stat-icon-minimal energy-icon" />
            <div>
              <div className="stat-value-minimal">
                {getBranchWiseEnergyMixData?.data
                  ? `${energyTotals.total} KWH`
                  : "0 KWH"}
              </div>
              <div className="stat-title-minimal">Total Energy</div>
            </div>
          </div>
          <div className="stat-card-minimal">
            <Icon
              as={TrendingUp}
              className="stat-icon-minimal renewable-icon"
            />
            <div>
              <div className="stat-value-minimal">
                {getBranchWiseEnergyMixData?.data
                  ? `${energyTotals.renewable} KWH`
                  : "0 KWH"}
              </div>
              <div className="stat-title-minimal">Renewable Energy</div>
            </div>
          </div>
          <div className="stat-card-minimal">
            <Icon
              as={Activity}
              className="stat-icon-minimal non-renewable-icon"
            />
            <div>
              <div className="stat-value-minimal">
                {getBranchWiseEnergyMixData?.data
                  ? `${energyTotals.nonRenewable} KWH`
                  : "0 KWH"}
              </div>
              <div className="stat-title-minimal">Non-Renewable Energy</div>
            </div>
          </div>
        </div>

        {/* Chart Section */}
        <div className="charts-section">
          <div className="compact-cards-row">
            <div className="compact-card full-width-card">
              <div className="compact-card-header">
                <span className="compact-card-title">
                  Branch-wise Energy Consumption
                </span>
              </div>
              {getBranchWiseEnergyMixData.isLoading ? (
                <div className="compact-card-loading">
                  <Skeleton height="300px" borderRadius="lg" />
                  <Text
                    fontSize="sm"
                    color="gray.500"
                    textAlign="center"
                    mt={2}
                  >
                    Loading energy consumption data...
                  </Text>
                </div>
              ) : (
                <div className="compact-card-chart">
                  <ResponsiveContainer width="100%" height={350}>
                    <BarChart
                      data={energyByBranch}
                      margin={{ left: 20, right: 20, top: 5, bottom: 5 }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke="#E2E8F0"
                        opacity={0.5}
                      />
                      <XAxis
                        dataKey="name"
                        fontSize={12}
                        stroke="#A0AEC0"
                        tick={{ fill: "#4A5568", fontWeight: 500 }}
                        tickLine={false}
                        axisLine={false}
                      />
                      <YAxis
                        type="number"
                        fontSize={12}
                        stroke="#A0AEC0"
                        tickLine={false}
                        axisLine={false}
                        label={{
                          value: "KWH",
                          angle: -90,
                          position: "insideLeft",
                          dx: -20,
                          dy: 20,
                          textAnchor: "middle",
                          fill: "#4A5568",
                        }}
                      />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend
                        verticalAlign="bottom"
                        height={36}
                        wrapperStyle={{
                          fontSize: 12,
                          paddingTop: "20px",
                        }}
                        iconType="circle"
                        iconSize={8}
                      />
                      <Bar
                        dataKey="renewable"
                        name="Renewable"
                        stackId="a"
                        fill="#38A169"
                        radius={[4, 4, 0, 0]}
                        maxBarSize={50}
                      >
                        <LabelList
                          dataKey="renewable"
                          position="top"
                          fontSize={12}
                          fill="#4A5568"
                          formatter={(value: number) =>
                            value > 0 ? `${value} KWH` : ""
                          }
                        />
                      </Bar>
                      <Bar
                        dataKey="nonRenewable"
                        name="Non-Renewable"
                        stackId="a"
                        fill="#3182CE"
                        radius={[4, 4, 0, 0]}
                        maxBarSize={50}
                      >
                        <LabelList
                          dataKey="total"
                          position="top"
                          fontSize={12}
                          fill="#4A5568"
                          formatter={(value: number) => `${value} KWH`}
                        />
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>
        </div>

        <style jsx>{`
          .energy-dashboard-minimal {
            padding: 1rem 0.5rem;
            background: #fafbfc;
            min-height: 100vh;
            font-family: "Inter", sans-serif;
            position: relative;
          }

          .energy-dashboard-image {
            width: 32px !important;
            height: 32px !important;
            object-fit: contain;
            border-radius: 0.25rem;
            background: #f8fafc;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.03);
          }
          .filters-section-minimal {
            margin-bottom: 1rem;
            background: none;
            border: none;
            box-shadow: none;
            padding: 0;
            display: flex;
            justify-content: flex-end;
          }
          .stats-row {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1rem;
            flex-wrap: wrap;
          }
          .stat-card-minimal {
            flex: 1;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            background: #fff;
            border-radius: 0.75rem;
            padding: 0.75rem;
            box-shadow: none;
            border: 1px solid #f3f4f6;
            height: 80px;
            transition: all 0.2s ease-in-out;
            min-width: 200px;
          }
          .stat-card-minimal:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
              0 2px 4px -2px rgba(0, 0, 0, 0.1);
          }
          .stat-icon-minimal {
            width: 1.8rem;
            height: 1.8rem;
            opacity: 0.7;
          }
          .energy-icon {
            color: #38a169;
          }
          .renewable-icon {
            color: #48bb78;
          }
          .non-renewable-icon {
            color: #68d391;
          }
          .stat-value-minimal {
            font-size: 1.2rem;
            font-weight: 600;
            color: #2f855a;
            margin-bottom: 0.1rem;
          }
          .stat-title-minimal {
            font-size: 0.85rem;
            color: #8d99ae;
            font-weight: 400;
            letter-spacing: 0.01em;
          }
          .charts-section {
            display: flex;
            flex-direction: column;
            gap: 1rem;
          }
          .compact-cards-row {
            display: flex;
            gap: 0.75rem;
            flex-wrap: wrap;
          }
          .compact-card {
            background: #fff;
            border-radius: 0.75rem;
            border: 1px solid #f3f4f6;
            box-shadow: none;
            flex: 1 1 calc(33.333% - 0.5rem);
            min-width: 250px;
            display: flex;
            flex-direction: column;
            padding: 0.75rem;
            position: relative;
            min-height: 150px;
            transition: all 0.2s ease-in-out;
            z-index: 10;
          }
          .compact-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1),
              0 2px 4px -2px rgba(0, 0, 0, 0.1);
            z-index: 15;
          }
          .compact-card.full-width-card {
            flex: 1 1 100%;
            min-width: 100%;
          }
          .compact-card-header {
            width: 100%;
            text-align: center;
            margin-bottom: 0.25rem;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 0.5rem;
          }
          .compact-card-title {
            font-weight: 600;
            color: #2d3748;
            letter-spacing: 0.02em;
            font-size: 0.9rem;
          }
          .compact-card-chart {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            flex: 1;
            width: 100%;
            padding-bottom: 2rem;
          }
          .compact-card-loading,
          .compact-card-error {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            flex: 1;
            padding: 1rem;
          }
          @media (max-width: 1200px) {
            .compact-card {
              flex: 1 1 calc(50% - 0.375rem);
              min-width: 280px;
            }
            .compact-card.full-width-card {
              flex: 1 1 100%;
              min-width: 100%;
            }
          }
          @media (max-width: 900px) {
            .stats-row {
              flex-direction: column;
            }
            .stat-card-minimal {
              flex: 1 1 100%;
            }
            .compact-card {
              flex: 1 1 100%;
            }
            .compact-card.full-width-card {
              flex: 1 1 100%;
            }
            .energy-dashboard-image-badge {
              position: static;
              margin: 0 auto 1rem auto;
              justify-content: center;
              min-width: unset;
              top: unset;
              left: unset;
            }
          }
          @media (max-width: 500px) {
            .stats-row {
              flex-direction: column;
            }
            .stat-card-minimal {
              flex: 1 1 100%;
            }
          }

          /* Ensure Popovers appear above all elements */
          :global(.chakra-popover__content) {
            z-index: 9999 !important;
          }
          :global(.chakra-popover__popper) {
            z-index: 9999 !important;
          }
        `}</style>
      </div>
    </Layout>
  );
};

export default EnergyDashboard;
