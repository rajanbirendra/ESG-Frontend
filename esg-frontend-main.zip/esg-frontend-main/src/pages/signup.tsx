"use client";

import { useState, useRef, useEffect } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Box,
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Checkbox,
  Divider,
  FormControl,
  FormErrorMessage,
  FormLabel,
  Grid,
  GridItem,
  Heading,
  Image,
  Input,
  Link,
  Radio,
  RadioGroup,
  Stack,
  Text,
  useToast,
  VStack,
  HStack,
  Icon,
  InputGroup,
  InputLeftElement,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  useDisclosure,
  useOutsideClick,
  InputRightElement,
  IconButton,
} from "@chakra-ui/react";
import { useRouter } from "next/router";
import { useForm, Controller } from "react-hook-form";
import { useQuery } from "@tanstack/react-query";
import { signupSchema } from "../schemas/signup.schema";
import {
  getCompanyIndustryTypesCompanyIndustryGetOptions,
  getCompanySubIndustryTypesCompanySubIndustryGetOptions,
} from "../api/@tanstack/react-query.gen";
import {
  AtSignIcon,
  Building,
  User,
  CheckCircle,
  ChevronRight,
  Search,
  ChevronDown,
  Info,
  Eye,
  EyeOff,
  XCircle,
} from "lucide-react";
import { useAuthAPI } from "@/query/use-auth";
import CountryStateDropdown from "@/ui/molecules/dropdown/CountryStateDropdown";
import { useMediaAPI } from "@/query/use-media";

export default function SignupPage() {
  const router = useRouter();
  const toast = useToast();
  const {
    isOpen: isViewOpen,
    onOpen: onViewOpen,
    onClose: onViewClose,
  } = useDisclosure();

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [passwordCriteria, setPasswordCriteria] = useState([
    {
      label: "At least 8 characters",
      valid: false,
      regex: /.{8,}/,
      key: "length",
    },
    {
      label: "At least one uppercase letter (A-Z)",
      valid: false,
      regex: /[A-Z]/,
      key: "uppercase",
    },
    {
      label: "At least one lowercase letter (a-z)",
      valid: false,
      regex: /[a-z]/,
      key: "lowercase",
    },
    {
      label: "At least one number (0-9)",
      valid: false,
      regex: /[0-9]/,
      key: "number",
    },
    {
      label: "At least one special character",
      valid: false,
      regex: /[^A-Za-z0-9]/,
      key: "special",
    },
  ]);

  // Form setup with react-hook-form and zod validation
  const {
    register,
    handleSubmit,
    control,
    setValue,
    getValues,
    watch,
    setError,
    clearErrors,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(signupSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      companyName: "",
      companyLogo: "",
      companySize: "",
      companyVertical: "",
      companySubVertical: "",
      country: "",
      state: "",
      companyEmail: "",
      phoneNumber: "",
      username: "",
      password: "",
      repassword: "",
      co2Accounted: false,
      termsAccepted: false,
    },
  });

  const passwordValue = watch("password");
  const repasswordValue = watch("repassword");

  useEffect(() => {
    if (passwordValue) {
      setPasswordCriteria((prev) =>
        prev.map((criterion) => ({
          ...criterion,
          valid: criterion.regex.test(passwordValue),
        }))
      );
    } else {
      // Reset if password field is empty
      setPasswordCriteria((prev) =>
        prev.map((criterion) => ({ ...criterion, valid: false }))
      );
    }
  }, [passwordValue]);

  // Fetch industry verticals
  const { data: industryVerticals, isLoading: isLoadingVerticals } = useQuery({
    ...getCompanyIndustryTypesCompanyIndustryGetOptions(),
    select: (data: any) => data.data,
  });

  // Watch for industry changes to fetch sub-industries
  const selectedIndustry = watch("companyVertical");

  // Fetch sub-industry based on selected industry
  const { data: subIndustryVerticals, isLoading: isLoadingSubVerticals } =
    useQuery({
      ...getCompanySubIndustryTypesCompanySubIndustryGetOptions({
        query: {
          industry_id: selectedIndustry
            ? industryVerticals?.find((v) => v.type === selectedIndustry)?.id
            : undefined,
        },
      }),
      select: (data: any) => data.data.sub_industries,
      enabled: !!selectedIndustry, // Only fetch when industry is selected
    });

  const { mutate: signupUser, isPending } = useAuthAPI().registerUser;

  const [verticalSearch, setVerticalSearch] = useState("");
  const [isVerticalOpen, setIsVerticalOpen] = useState(false);
  const [subVerticalSearch, setSubVerticalSearch] = useState("");
  const [isSubVerticalOpen, setIsSubVerticalOpen] = useState(false);

  // Refs for dropdown outside click handling
  const verticalDropdownRef = useRef<HTMLDivElement>(null);
  const subVerticalDropdownRef = useRef<HTMLDivElement>(null);

  // Handle outside clicks for dropdowns
  useOutsideClick({
    ref: verticalDropdownRef,
    handler: () => setIsVerticalOpen(false),
  });

  useOutsideClick({
    ref: subVerticalDropdownRef,
    handler: () => setIsSubVerticalOpen(false),
  });

  // Reset search when dropdowns close
  useEffect(() => {
    if (!isVerticalOpen) {
      setVerticalSearch("");
    }
  }, [isVerticalOpen]);

  useEffect(() => {
    if (!isSubVerticalOpen) {
      setSubVerticalSearch("");
    }
  }, [isSubVerticalOpen]);

  const filteredVerticals = industryVerticals?.filter(
    (vertical: { id: number; type: string }) =>
      vertical.type.toLowerCase().includes(verticalSearch.toLowerCase())
  );

  const filteredSubVerticals = subIndustryVerticals?.filter(
    (subVertical: { id: number; name: string }) =>
      subVertical.name.toLowerCase().includes(subVerticalSearch.toLowerCase())
  );

  // Form submission handler
  const onSubmit = (data) => {
    if (!data.termsAccepted) {
      toast({
        title: "Terms & Conditions",
        description: "Please accept the Terms & Conditions to continue.",
        status: "error",
        duration: 5000,
        isClosable: true,
        position: "top",
      });
      return;
    }

    // Prepare data for API
    const payload = {
      ...data,
      first_name: data.firstName,
      last_name: data.lastName,
      company_email: data.companyEmail,
      phone_number: data.phoneNumber,
      company_name: data.companyName,
      company_logo: data.companyLogo,
      number_of_employees: Number.parseInt(data.companySize),
      industry_vertical: data.companyVertical,
      sub_industry_vertical: data.companySubVertical,
      location_country: data.country,
      location_state: data.state,
      co2_accounted: data.co2Accounted,
      company_role: data.companyRole,
    };

    // Remove fields not needed in API
    delete payload.repassword;
    delete payload.termsAccepted;
    delete payload.co2Accounted;
    delete payload.companyRole;
    delete payload.companySize;
    delete payload.companyVertical;
    delete payload.companySubVertical;
    delete payload.companyName;
    delete payload.companyRole;
    delete payload.phoneNumber;
    delete payload.companyEmail;
    delete payload.country;
    delete payload.state;
    delete payload.firstName;
    delete payload.lastName;
    delete payload.companyLogo;

    signupUser({ body: payload });
  };

  watch("country");

  const { mutate: uploadMedia, isPending: isUploadingMedia } =
    useMediaAPI().upload;
  return (
    <Box
      minH="100vh"
      bg="url(./bgsignup.webp)"
      backgroundSize="cover"
      backgroundPosition="center"
      py={8}
      px={4}
      display="flex"
      alignItems="center"
      justifyContent="center"
      position="relative"
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        bg: "rgba(0, 0, 0, 0.4)",
        backdropFilter: "blur(4px)",
      }}
    >
      <Card
        maxW="4xl"
        w="full"
        boxShadow="2xl"
        borderRadius="2xl"
        overflow="hidden"
        bg="white"
        position="relative"
        _hover={{
          transform: "translateY(-2px)",
          boxShadow: "3xl",
        }}
        transition="all 0.3s ease"
      >
        <CardHeader
          display="flex"
          flexDirection="column"
          alignItems="center"
          pb={4}
          borderBottomWidth="1px"
          borderColor="gray.100"
          bg="gray.50"
        >
          <Box
            h="60px"
            w="60px"
            position="relative"
            mb={2}
            _hover={{
              transform: "scale(1.05)",
            }}
            transition="transform 0.2s ease"
          >
            <Image
              src="/logo_transparent.png"
              alt="Company Logo"
              boxSize="60px"
              objectFit="contain"
            />
          </Box>
          <Heading
            size="lg"
            textAlign="center"
            bgGradient="linear(to-r, teal.500, blue.500)"
            bgClip="text"
            fontWeight="bold"
          >
            Create Your Account
          </Heading>
        </CardHeader>

        <form onSubmit={handleSubmit(onSubmit)}>
          <CardBody pt={8} pb={8} px={8}>
            <VStack spacing={8} align="stretch">
              {/* Personal Information Section */}
              <Box>
                <HStack mb={6} spacing={3}>
                  <Icon as={User} color="teal.500" boxSize={5} />
                  <Heading size="md" color="gray.700">
                    Personal Information
                  </Heading>
                </HStack>
                <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={6}>
                  <GridItem>
                    <FormControl isInvalid={!!errors.firstName}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color="gray.700"
                        mb={1.5}
                      >
                        First Name
                      </FormLabel>
                      <Input
                        focusBorderColor="teal.500"
                        size="md"
                        bg="white"
                        _hover={{ borderColor: "teal.400" }}
                        _focus={{
                          borderColor: "",
                          boxShadow: "0 0 0 1px teal.500",
                        }}
                        {...register("firstName")}
                      />
                      <FormErrorMessage>
                        {errors.firstName && errors.firstName.message}
                      </FormErrorMessage>
                    </FormControl>
                  </GridItem>
                  <GridItem>
                    <FormControl isInvalid={!!errors.lastName}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color="gray.700"
                        mb={1.5}
                      >
                        Last Name
                      </FormLabel>
                      <Input
                        focusBorderColor="teal.500"
                        size="md"
                        bg="white"
                        _hover={{ borderColor: "teal.400" }}
                        _focus={{
                          borderColor: "teal.500",
                          boxShadow: "0 0 0 1px teal.500",
                        }}
                        {...register("lastName")}
                      />
                      <FormErrorMessage>
                        {errors.lastName && errors.lastName.message}
                      </FormErrorMessage>
                    </FormControl>
                  </GridItem>
                </Grid>
              </Box>

              <Divider borderColor="gray.200" />

              {/* Company Information Section */}
              <Box>
                <HStack mb={6} spacing={3}>
                  <Icon as={Building} color="teal.500" boxSize={5} />
                  <Heading size="md" color="gray.700">
                    Company Information
                  </Heading>
                </HStack>
                <VStack spacing={6} align="stretch">
                  {/* Company Name and Logo Row */}
                  <Grid
                    templateColumns={{ base: "1fr", md: "1fr 1fr" }}
                    gap={6}
                  >
                    <GridItem>
                      <FormControl isInvalid={!!errors.companyName}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Company Name
                        </FormLabel>
                        <Input
                          focusBorderColor="teal.500"
                          size="md"
                          bg="white"
                          _hover={{ borderColor: "teal.400" }}
                          _focus={{
                            borderColor: "teal.500",
                            boxShadow: "0 0 0 1px teal.500",
                          }}
                          {...register("companyName")}
                        />
                        <FormErrorMessage>
                          {errors.companyName && errors.companyName.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>
                    <GridItem>
                      <FormControl isInvalid={!!errors.companyLogo}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Company Logo
                        </FormLabel>
                        <HStack spacing={4} align="flex-start">
                          <Box
                            border="2px dashed"
                            borderColor="gray.200"
                            borderRadius="lg"
                            position="relative"
                            bg="white"
                            _hover={{ borderColor: "teal.500", bg: "gray.50" }}
                            transition="all 0.2s"
                            h="80px"
                            w="80px"
                            flexShrink={0}
                          >
                            <Input
                              type="file"
                              accept="image/*"
                              position="absolute"
                              top="0"
                              left="0"
                              width="100%"
                              height="100%"
                              opacity="0"
                              cursor="pointer"
                              zIndex={2}
                              onChange={(e) => {
                                if (e.target.files && e.target.files[0]) {
                                  const file = e.target.files[0];
                                  if (file.size > 2 * 1024 * 1024) {
                                    setError("companyLogo", {
                                      type: "manual",
                                      message: "Logo must be less than 2MB",
                                    });
                                  } else {
                                    // Clear any existing errors when valid file is selected
                                    clearErrors("companyLogo");

                                    const reader = new FileReader();
                                    reader.onload = (e) => {
                                      setLogoPreview(
                                        e.target?.result as string
                                      );
                                    };
                                    reader.readAsDataURL(file);

                                    setIsUploading(true);
                                    uploadMedia(
                                      // @ts-ignore
                                      {
                                        body: {
                                          file: file,
                                          media_type: "COMPANY_LOGO",
                                        },
                                      },
                                      {
                                        onSuccess: (data: any) => {
                                          setValue(
                                            "companyLogo",
                                            data?.data?.file_key
                                          );
                                          setIsUploading(false);
                                          clearErrors("companyLogo");
                                        },
                                        onError: (err: any) => {
                                          setError("companyLogo", {
                                            type: "manual",
                                            message:
                                              err?.message ||
                                              "Failed to upload logo",
                                          });
                                          setIsUploading(false);
                                        },
                                      }
                                    );
                                  }
                                }
                              }}
                            />
                            {logoPreview ? (
                              <Box position="relative" h="80px" w="80px">
                                <Image
                                  src={logoPreview}
                                  alt="Company Logo Preview"
                                  h="80px"
                                  w="80px"
                                  objectFit="cover"
                                  borderRadius="md"
                                />
                                {isUploading && (
                                  <Box
                                    position="absolute"
                                    top="0"
                                    left="0"
                                    right="0"
                                    bottom="0"
                                    bg="rgba(0,0,0,0.5)"
                                    display="flex"
                                    alignItems="center"
                                    justifyContent="center"
                                    backdropFilter="blur(2px)"
                                    borderRadius="md"
                                  >
                                    <VStack spacing={1}>
                                      <Box
                                        animation="spin 1s linear infinite"
                                        color="white"
                                      >
                                        <Icon as={CheckCircle} boxSize={4} />
                                      </Box>
                                      <Text
                                        color="white"
                                        fontSize="xs"
                                        fontWeight="medium"
                                      >
                                        Uploading...
                                      </Text>
                                    </VStack>
                                  </Box>
                                )}
                              </Box>
                            ) : (
                              <HStack
                                spacing={2}
                                justify="center"
                                h="80px"
                                w="80px"
                                bg="gray.50"
                                borderRadius="md"
                              >
                                <Icon
                                  as={Building}
                                  boxSize={5}
                                  color="gray.400"
                                />
                              </HStack>
                            )}
                          </Box>

                          <VStack spacing={3} align="flex-start" flex={1}>
                            <Text fontSize="sm" color="gray.600">
                              {isUploading
                                ? "Uploading logo..."
                                : logoPreview
                                ? "Logo uploaded successfully"
                                : "Click to upload company logo"}
                            </Text>

                            {logoPreview && !isUploading && (
                              <Button
                                size="sm"
                                colorScheme="teal"
                                variant="outline"
                                leftIcon={<Icon as={Search} boxSize={4} />}
                                onClick={onViewOpen}
                                _hover={{
                                  transform: "translateY(-1px)",
                                  boxShadow: "sm",
                                }}
                                transition="all 0.2s ease"
                              >
                                View Logo
                              </Button>
                            )}

                            <HStack spacing={1}>
                              <Icon as={Info} boxSize={3} color="gray.400" />
                              <Text fontSize="xs" color="gray.500">
                                Max file size: 2MB
                              </Text>
                            </HStack>
                          </VStack>
                        </HStack>
                        <FormErrorMessage>
                          {errors.companyLogo && errors.companyLogo.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>
                  </Grid>

                  {/* Industry Type Row */}
                  <Grid
                    templateColumns={{ base: "1fr", md: "1fr 1fr" }}
                    gap={6}
                  >
                    <GridItem>
                      <FormControl isInvalid={!!errors.companyVertical}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Industry Type <Text as="span" color="red.500">*</Text>
                        </FormLabel>
                        <Controller
                          name="companyVertical"
                          control={control}
                          render={({ field }) => (
                            <Box
                              position="relative"
                              maxW="350px"
                              ref={verticalDropdownRef}
                            >
                              <InputGroup>
                                <InputLeftElement pointerEvents="none">
                                  <Icon
                                    as={Building}
                                    color="gray.400"
                                    boxSize={5}
                                  />
                                </InputLeftElement>
                                <Input
                                  value={field.value ?? ""}
                                  onClick={() => setIsVerticalOpen(true)}
                                  readOnly
                                  placeholder="Select Industry *"
                                  cursor="pointer"
                                  bg="white"
                                  height="40px"
                                  borderRadius="md"
                                  border="1px solid"
                                  borderColor="gray.200"
                                  _hover={{ borderColor: "gray.300" }}
                                  _focus={{
                                    borderColor: "teal.500",
                                    boxShadow: "none",
                                  }}
                                  pr="2.5rem"
                                  fontSize="sm"
                                  fontWeight="medium"
                                  color="gray.700"
                                  _placeholder={{ color: "gray.500" }}
                                />
                                <Box
                                  position="absolute"
                                  right="0.75rem"
                                  top="50%"
                                  transform="translateY(-50%)"
                                  pointerEvents="none"
                                  color="gray.400"
                                >
                                  <Icon as={ChevronDown} boxSize={4} />
                                </Box>
                              </InputGroup>

                              {isVerticalOpen && (
                                <Box
                                  position="absolute"
                                  top="calc(100% + 0.5rem)"
                                  left={0}
                                  right={0}
                                  bg="white"
                                  borderRadius="lg"
                                  boxShadow="lg"
                                  zIndex={10}
                                  maxH="320px"
                                  overflowY="auto"
                                  border="1px solid"
                                  borderColor="gray.200"
                                >
                                  <Box
                                    p={2}
                                    borderBottom="1px solid"
                                    borderColor="gray.100"
                                  >
                                    <InputGroup size="sm">
                                      <InputLeftElement pointerEvents="none">
                                        <Icon
                                          as={Search}
                                          color="gray.400"
                                          boxSize={4}
                                        />
                                      </InputLeftElement>
                                      <Input
                                        value={verticalSearch}
                                        onChange={(e) =>
                                          setVerticalSearch(e.target.value)
                                        }
                                        placeholder="Search industry..."
                                        size="sm"
                                        autoFocus
                                        bg="gray.50"
                                        borderColor="gray.200"
                                        _hover={{ borderColor: "gray.300" }}
                                        _focus={{
                                          borderColor: "teal.500",
                                          bg: "white",
                                          boxShadow: "none",
                                        }}
                                        borderRadius="md"
                                        fontSize="sm"
                                      />
                                    </InputGroup>
                                  </Box>

                                  <Box maxH="250px" overflowY="auto">
                                    {isLoadingVerticals ? (
                                      <Box px={3} py={2} textAlign="center">
                                        <Text color="gray.500" fontSize="sm">
                                          Loading...
                                        </Text>
                                      </Box>
                                    ) : filteredVerticals?.length === 0 ? (
                                      <Box px={3} py={2} textAlign="center">
                                        <Text color="gray.500" fontSize="sm">
                                          No results found
                                        </Text>
                                      </Box>
                                    ) : (
                                      filteredVerticals?.map((vertical) => (
                                        <Box
                                          key={vertical.id}
                                          px={3}
                                          py={2}
                                          cursor="pointer"
                                          bg={
                                            field.value === vertical.type
                                              ? "teal.50"
                                              : "transparent"
                                          }
                                          _hover={{
                                            bg:
                                              field.value === vertical.type
                                                ? "teal.100"
                                                : "gray.50",
                                          }}
                                          onClick={() => {
                                            field.onChange(vertical.type);
                                            setValue("companySubVertical", "");
                                            setVerticalSearch("");
                                            setIsVerticalOpen(false);
                                          }}
                                          borderBottom="1px solid"
                                          borderColor="gray.100"
                                        >
                                          <Text
                                            color={
                                              field.value === vertical.type
                                                ? "teal.700"
                                                : "gray.700"
                                            }
                                            fontWeight={
                                              field.value === vertical.type
                                                ? "medium"
                                                : "normal"
                                            }
                                            fontSize="sm"
                                          >
                                            {vertical.type}
                                          </Text>
                                        </Box>
                                      ))
                                    )}
                                  </Box>
                                </Box>
                              )}
                            </Box>
                          )}
                        />
                        <FormErrorMessage>
                          {errors.companyVertical &&
                            errors.companyVertical.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>

                    <GridItem>
                      <FormControl isInvalid={!!errors.companySubVertical}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Sub-Industry Type <Text as="span" color="red.500">*</Text>
                        </FormLabel>
                        <Controller
                          name="companySubVertical"
                          control={control}
                          render={({ field }) => (
                            <Box
                              position="relative"
                              maxW="350px"
                              ref={subVerticalDropdownRef}
                            >
                              <InputGroup>
                                <InputLeftElement pointerEvents="none">
                                  <Icon
                                    as={Building}
                                    color="gray.400"
                                    boxSize={5}
                                  />
                                </InputLeftElement>
                                <Input
                                  value={
                                    field.value
                                      ? subIndustryVerticals?.find(
                                          (v) => v.id === parseInt(field.value!)
                                        )?.name ?? field.value
                                      : ""
                                  }
                                  onClick={() => setIsSubVerticalOpen(true)}
                                  readOnly
                                  placeholder={
                                    !selectedIndustry
                                      ? "Select Industry First"
                                      : "Select Sub-Industry *"
                                  }
                                  cursor="pointer"
                                  bg="white"
                                  height="40px"
                                  borderRadius="md"
                                  border="1px solid"
                                  borderColor="gray.200"
                                  _hover={{ borderColor: "gray.300" }}
                                  _focus={{
                                    borderColor: "teal.500",
                                    boxShadow: "none",
                                  }}
                                  pr="2.5rem"
                                  fontSize="sm"
                                  fontWeight="medium"
                                  color="gray.700"
                                  _placeholder={{ color: "gray.500" }}
                                  isDisabled={
                                    !selectedIndustry || isLoadingSubVerticals
                                  }
                                />
                                <Box
                                  position="absolute"
                                  right="0.75rem"
                                  top="50%"
                                  transform="translateY(-50%)"
                                  pointerEvents="none"
                                  color="gray.400"
                                >
                                  <Icon as={ChevronDown} boxSize={4} />
                                </Box>
                              </InputGroup>

                              {isSubVerticalOpen && (
                                <Box
                                  position="absolute"
                                  top="calc(100% + 0.5rem)"
                                  left={0}
                                  right={0}
                                  bg="white"
                                  borderRadius="lg"
                                  boxShadow="lg"
                                  zIndex={10}
                                  maxH="320px"
                                  overflowY="auto"
                                  border="1px solid"
                                  borderColor="gray.200"
                                >
                                  <Box
                                    p={2}
                                    borderBottom="1px solid"
                                    borderColor="gray.100"
                                  >
                                    <InputGroup size="sm">
                                      <InputLeftElement pointerEvents="none">
                                        <Icon
                                          as={Search}
                                          color="gray.400"
                                          boxSize={4}
                                        />
                                      </InputLeftElement>
                                      <Input
                                        value={subVerticalSearch}
                                        onChange={(e) =>
                                          setSubVerticalSearch(e.target.value)
                                        }
                                        placeholder="Search sub-industry..."
                                        size="sm"
                                        autoFocus
                                        bg="gray.50"
                                        borderColor="gray.200"
                                        _hover={{ borderColor: "gray.300" }}
                                        _focus={{
                                          borderColor: "teal.500",
                                          bg: "white",
                                          boxShadow: "none",
                                        }}
                                        borderRadius="md"
                                        fontSize="sm"
                                      />
                                    </InputGroup>
                                  </Box>

                                  <Box maxH="250px" overflowY="auto">
                                    {isLoadingSubVerticals ? (
                                      <Box px={3} py={2} textAlign="center">
                                        <Text color="gray.500" fontSize="sm">
                                          Loading...
                                        </Text>
                                      </Box>
                                    ) : filteredSubVerticals?.length === 0 ? (
                                      <Box px={3} py={2} textAlign="center">
                                        <Text color="gray.500" fontSize="sm">
                                          No results found
                                        </Text>
                                      </Box>
                                    ) : (
                                      filteredSubVerticals?.map(
                                        (subVertical) => (
                                          <Box
                                            key={subVertical.name}
                                            px={3}
                                            py={2}
                                            cursor="pointer"
                                            bg={
                                              field.value ===
                                              subVertical.name.toString()
                                                ? "teal.50"
                                                : "transparent"
                                            }
                                            _hover={{
                                              bg:
                                                field.value ===
                                                subVertical.name.toString()
                                                  ? "teal.100"
                                                  : "gray.50",
                                            }}
                                            onClick={() => {
                                              field.onChange(
                                                subVertical.name.toString()
                                              );
                                              setSubVerticalSearch("");
                                              setIsSubVerticalOpen(false);
                                            }}
                                            borderBottom="1px solid"
                                            borderColor="gray.100"
                                          >
                                            <Text
                                              color={
                                                field.value ===
                                                subVertical.name.toString()
                                                  ? "teal.700"
                                                  : "gray.700"
                                              }
                                              fontWeight={
                                                field.value ===
                                                subVertical.name.toString()
                                                  ? "medium"
                                                  : "normal"
                                              }
                                              fontSize="sm"
                                            >
                                              {subVertical.name}
                                            </Text>
                                          </Box>
                                        )
                                      )
                                    )}
                                  </Box>
                                </Box>
                              )}
                            </Box>
                          )}
                        />
                        <FormErrorMessage>
                          {errors.companySubVertical &&
                            errors.companySubVertical.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>
                  </Grid>

                  <Grid
                    templateColumns={{ base: "1fr", md: "1fr 1fr" }}
                    gap={6}
                  >
                    <GridItem colSpan={2}>
                      <FormControl
                        isInvalid={!!errors.country || !!errors.state}
                      >
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Location <Text as="span" color="gray.400" fontSize="xs">(State/Province is optional)</Text>
                        </FormLabel>
                        <Controller
                          name="country"
                          control={control}
                          render={({ field: countryField }) => (
                            <Controller
                              name="state"
                              control={control}
                              render={({ field: stateField }) => (
                                <CountryStateDropdown
                                  selectedCountry={countryField.value}
                                  selectedState={stateField.value}
                                  onCountryChange={(country) => {
                                    countryField.onChange(country);
                                    setValue("state", "");
                                  }}
                                  onStateChange={stateField.onChange}
                                />
                              )}
                            />
                          )}
                        />
                        <FormErrorMessage>
                          {errors.country?.message || errors.state?.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>
                  </Grid>

                  <Grid
                    templateColumns={{ base: "1fr", md: "1fr 1fr" }}
                    gap={6}
                  >
                    <GridItem>
                      <FormControl isInvalid={!!errors.companyEmail}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Company Email
                        </FormLabel>
                        <Input
                          placeholder="contact@acme.com"
                          focusBorderColor="teal.500"
                          size="md"
                          bg="white"
                          _hover={{ borderColor: "teal.400" }}
                          _focus={{
                            borderColor: "teal.500",
                            boxShadow: "0 0 0 1px teal.500",
                          }}
                          {...register("companyEmail")}
                        />
                        <FormErrorMessage>
                          {errors.companyEmail && errors.companyEmail.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>
                    <GridItem>
                      <FormControl isInvalid={!!errors.phoneNumber}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Phone Number
                        </FormLabel>
                        <Input
                          placeholder="+1 234 567 8900"
                          focusBorderColor="teal.500"
                          size="md"
                          bg="white"
                          _hover={{ borderColor: "teal.400" }}
                          _focus={{
                            borderColor: "teal.500",
                            boxShadow: "0 0 0 1px teal.500",
                          }}
                          {...register("phoneNumber")}
                        />
                        <FormErrorMessage>
                          {errors.phoneNumber && errors.phoneNumber.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>
                  </Grid>

                  <Grid
                    templateColumns={{ base: "1fr", md: "1fr 1fr" }}
                    gap={6}
                  >
                    <GridItem>
                      <FormControl isInvalid={!!errors.companySize}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Number of Employees
                        </FormLabel>
                        <Input
                          type="number"
                          placeholder="50"
                          focusBorderColor="teal.500"
                          size="md"
                          bg="white"
                          _hover={{ borderColor: "teal.400" }}
                          _focus={{
                            borderColor: "teal.500",
                            boxShadow: "0 0 0 1px teal.500",
                          }}
                          {...register("companySize")}
                        />
                        <FormErrorMessage>
                          {errors.companySize && errors.companySize.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>

                    <GridItem>
                      <FormControl isInvalid={!!errors.companyRole}>
                        <FormLabel
                          fontSize="sm"
                          fontWeight="medium"
                          color="gray.700"
                          mb={1.5}
                        >
                          Your Role
                        </FormLabel>
                        <Input
                          placeholder="CEO, Manager, etc."
                          focusBorderColor="teal.500"
                          size="md"
                          bg="white"
                          _hover={{ borderColor: "teal.400" }}
                          _focus={{
                            borderColor: "teal.500",
                            boxShadow: "0 0 0 1px teal.500",
                          }}
                          {...register("companyRole")}
                        />
                        <FormErrorMessage>
                          {errors.companyRole && errors.companyRole.message}
                        </FormErrorMessage>
                      </FormControl>
                    </GridItem>
                  </Grid>
                </VStack>
              </Box>

              <Divider borderColor="gray.200" />

              {/* Account Information Section */}
              <Box>
                <HStack mb={6} spacing={3}>
                  <Icon as={AtSignIcon} color="teal.500" boxSize={5} />
                  <Heading size="md" color="gray.700">
                    Account Information
                  </Heading>
                </HStack>
                <Grid
                  templateColumns={{ base: "1fr", md: "1fr 1fr 1fr" }}
                  gap={6}
                >
                  <GridItem>
                    <FormControl isInvalid={!!errors.username}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color="gray.700"
                        mb={1.5}
                      >
                        Username
                      </FormLabel>
                      <Input
                        placeholder="johndoe"
                        focusBorderColor="teal.500"
                        size="md"
                        bg="white"
                        _hover={{ borderColor: "teal.400" }}
                        _focus={{
                          borderColor: "teal.500",
                          boxShadow: "0 0 0 1px teal.500",
                        }}
                        {...register("username")}
                      />
                      <FormErrorMessage>
                        {errors.username && errors.username.message}
                      </FormErrorMessage>
                    </FormControl>
                  </GridItem>

                  <GridItem>
                    <FormControl isInvalid={!!errors.password}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color="gray.700"
                        mb={1.5}
                      >
                        Password
                      </FormLabel>
                      <InputGroup size="md">
                        <Input
                          type={showPassword ? "text" : "password"}
                          focusBorderColor="teal.500"
                          bg="white"
                          _hover={{ borderColor: "teal.400" }}
                          _focus={{
                            borderColor: "teal.500",
                            boxShadow: "0 0 0 1px teal.500",
                          }}
                          {...register("password")}
                        />
                        <InputRightElement>
                          <IconButton
                            aria-label={
                              showPassword ? "Hide password" : "Show password"
                            }
                            _hover={{
                              bg: "transparent",
                              color: "blue.500",
                            }}
                            icon={
                              showPassword ? (
                                <EyeOff size={"18px"} />
                              ) : (
                                <Eye size="18px" />
                              )
                            }
                            variant="ghost"
                            onClick={() => setShowPassword(!showPassword)}
                          />
                        </InputRightElement>
                      </InputGroup>
                      {passwordValue && (
                        <VStack align="stretch" spacing={1} mt={2}>
                          {passwordCriteria.map((criterion) => (
                            <HStack
                              key={criterion.key}
                              spacing={2}
                              color={criterion.valid ? "green.500" : "gray.500"}
                              transition="color 0.2s"
                            >
                              <Icon
                                as={criterion.valid ? CheckCircle : XCircle}
                                boxSize={4}
                              />
                              <Text fontSize="xs">{criterion.label}</Text>
                            </HStack>
                          ))}
                        </VStack>
                      )}
                      <FormErrorMessage>
                        {errors.password && errors.password.message}
                      </FormErrorMessage>
                    </FormControl>
                  </GridItem>

                  <GridItem>
                    <FormControl isInvalid={!!errors.repassword}>
                      <FormLabel
                        fontSize="sm"
                        fontWeight="medium"
                        color="gray.700"
                        mb={1.5}
                      >
                        Confirm Password
                      </FormLabel>
                      <InputGroup size="md">
                        <Input
                          type={showConfirmPassword ? "text" : "password"}
                          focusBorderColor="teal.500"
                          bg="white"
                          _hover={{ borderColor: "teal.400" }}
                          _focus={{
                            borderColor: "teal.500",
                            boxShadow: "0 0 0 1px teal.500",
                          }}
                          {...register("repassword")}
                        />
                        <InputRightElement>
                          <IconButton
                            aria-label={
                              showConfirmPassword
                                ? "Hide password"
                                : "Show password"
                            }
                            _hover={{
                              bg: "transparent",
                              color: "blue.500",
                            }}
                            icon={
                              showConfirmPassword ? (
                                <EyeOff size={"18px"} />
                              ) : (
                                <Eye size={"18px"} />
                              )
                            }
                            variant="ghost"
                            onClick={() =>
                              setShowConfirmPassword(!showConfirmPassword)
                            }
                          />
                        </InputRightElement>
                      </InputGroup>
                      {repasswordValue &&
                        passwordValue === repasswordValue &&
                        !errors.repassword && (
                          <HStack spacing={2} mt={2} color="green.500">
                            <Icon as={CheckCircle} boxSize={4} />
                            <Text fontSize="xs">Passwords match!</Text>
                          </HStack>
                        )}
                      <FormErrorMessage>
                        {errors.repassword && errors.repassword.message}
                      </FormErrorMessage>
                    </FormControl>
                  </GridItem>
                </Grid>
              </Box>

              <Divider borderColor="gray.200" />

              {/* Additional Information Section */}
              <Box>
                <HStack mb={6} spacing={3}>
                  <Icon as={CheckCircle} color="teal.500" boxSize={5} />
                  <Heading size="md" color="gray.700">
                    Additional Information
                  </Heading>
                </HStack>
                <VStack spacing={6} align="stretch">
                  <FormControl isInvalid={!!errors.co2Accounted}>
                    <FormLabel
                      fontSize="sm"
                      fontWeight="medium"
                      color="gray.700"
                      mb={1.5}
                    >
                      Have you accounted for CO2 emissions before?
                    </FormLabel>
                    <Controller
                      name="co2Accounted"
                      control={control}
                      render={({ field: { onChange, value } }) => (
                        <RadioGroup
                          onChange={(val) => onChange(val === "Yes")}
                          value={value ? "Yes" : "No"}
                        >
                          <Stack direction="row" spacing={8}>
                            <Radio value="Yes" colorScheme="teal" size="md">
                              Yes
                            </Radio>
                            <Radio value="No" colorScheme="teal" size="md">
                              No
                            </Radio>
                          </Stack>
                        </RadioGroup>
                      )}
                    />
                    <FormErrorMessage>
                      {errors.co2Accounted && errors.co2Accounted.message}
                    </FormErrorMessage>
                  </FormControl>

                  <FormControl isInvalid={!!errors.termsAccepted}>
                    <Controller
                      name="termsAccepted"
                      control={control}
                      render={({ field: { onChange, value } }) => (
                        <Checkbox
                          colorScheme="teal"
                          isChecked={value}
                          size="md"
                          onChange={(e) => {
                            onChange(e.target.checked);
                            setValue("termsAccepted", e.target.checked);
                          }}
                        >
                          By checking this box, you agree to our{" "}
                          <Link
                            color="teal.500"
                            href="#"
                            textDecoration="underline"
                            _hover={{ color: "teal.600" }}
                          >
                            Terms & Conditions
                          </Link>
                          .
                        </Checkbox>
                      )}
                    />
                    <FormErrorMessage>
                      {errors.termsAccepted && errors.termsAccepted.message}
                    </FormErrorMessage>
                  </FormControl>
                </VStack>
              </Box>
            </VStack>
          </CardBody>

          <CardFooter
            flexDirection="column"
            alignItems="center"
            bg="gray.50"
            py={6}
          >
            <Button
              type="submit"
              colorScheme="teal"
              size="lg"
              width="full"
              maxW="400px"
              isLoading={isPending}
              loadingText="Creating Account..."
              rightIcon={<ChevronRight />}
              _hover={{
                transform: "translateY(-1px)",
                boxShadow: "lg",
              }}
              _active={{
                transform: "translateY(0)",
              }}
              transition="all 0.2s ease"
            >
              Create Account
            </Button>

            <Text mt={4} fontSize="sm" color="gray.600">
              Already have an account?{" "}
              <Link
                color="teal.500"
                href="/"
                _hover={{
                  color: "teal.600",
                  textDecoration: "underline",
                }}
                transition="all 0.2s ease"
              >
                Sign in
              </Link>
            </Text>
          </CardFooter>
        </form>
      </Card>

      {/* Logo View Modal */}
      <Modal isOpen={isViewOpen} onClose={onViewClose} size="md" isCentered>
        <ModalOverlay backdropFilter="blur(4px)" />
        <ModalContent
          borderRadius="xl"
          boxShadow="2xl"
          bg="white"
          maxW="500px"
          mx={4}
        >
          <ModalHeader
            display="flex"
            alignItems="center"
            gap={3}
            borderBottomWidth="1px"
            borderColor="gray.100"
            pb={4}
          >
            <Icon as={Building} color="teal.500" boxSize={5} />
            <Text>Company Logo Preview</Text>
          </ModalHeader>
          <ModalCloseButton
            size="lg"
            borderRadius="full"
            bg="gray.100"
            _hover={{ bg: "gray.200" }}
            transition="all 0.2s ease"
          />
          <ModalBody py={6}>
            <VStack spacing={4}>
              <Box
                border="2px solid"
                borderColor="gray.200"
                borderRadius="xl"
                p={4}
                bg="gray.50"
                w="full"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                {logoPreview && (
                  <Image
                    src={logoPreview}
                    alt="Company Logo"
                    maxH="300px"
                    maxW="400px"
                    objectFit="contain"
                    borderRadius="lg"
                    boxShadow="lg"
                  />
                )}
              </Box>
              <Text fontSize="sm" color="gray.600" textAlign="center">
                This is how your company logo will appear in the system
              </Text>
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </Box>
  );
}
