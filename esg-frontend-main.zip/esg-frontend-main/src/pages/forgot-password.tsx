import { useState } from "react";
import {
  Box,
  Button,
  Flex,
  Heading,
  Image,
  Input,
  Text,
  useToast,
  InputGroup,
  InputLeftElement,
  Card,
  useColorModeValue,
  FormControl,
  FormErrorMessage,
  Container,
} from "@chakra-ui/react";
import { Mail, ArrowLeft } from "lucide-react";
import { useRouter } from "next/router";
import { useAuthAPI } from "../query/use-auth";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const toast = useToast();
  const router = useRouter();
  const { forgotPassword } = useAuthAPI();

  const isEmailValid = (email: string) =>
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const cardBg = useColorModeValue("white", "gray.800");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const headingColor = useColorModeValue("gray.700", "white");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const inputBg = useColorModeValue("gray.50", "gray.700");
  const inputBorder = useColorModeValue("gray.200", "gray.600");
  const inputHoverBorder = useColorModeValue("blue.400", "blue.300");
  const inputFocusBorder = useColorModeValue("blue.500", "blue.400");

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isEmailValid(email)) {
      toast({
        title: "Invalid email address.",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    forgotPassword.mutate(
      {
        body: { email },
      },
      {
        onSuccess: () => {
          setSubmitted(true);
          setEmail("");
        },
      }
    );
  };

  return (
    <Flex
      minH="100vh"
      align="center"
      justify="center"
      bgImage="url('/bgsignup.webp')"
      bgSize="cover"
      bgPosition="center"
      bgRepeat="no-repeat"
      bgAttachment="fixed"
      position="relative"
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        bg: "rgba(0, 0, 0, 0.4)",
        backdropFilter: "blur(4px)",
      }}
    >
      {/* Back button */}
      <Button
        position="absolute"
        top={4}
        left={4}
        leftIcon={<ArrowLeft size={20} />}
        variant="ghost"
        colorScheme="gray"
        onClick={() => router.back()}
        _focus={{ boxShadow: "outline" }}
        _hover={{ bg: "whiteAlpha.200" }}
        zIndex={10}
      >
        Back
      </Button>

      <Container maxW="container.sm" position="relative" zIndex={1}>
        <Card
          bg={cardBg}
          p={8}
          borderRadius="2xl"
          boxShadow="2xl"
          maxW="md"
          w="100%"
          mx="auto"
          position="relative"
          _before={{
            content: '""',
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            borderRadius: "2xl",
            border: "1px solid",
            borderColor: "gray.200",
            opacity: 0.1,
          }}
        >
          {/* Logo */}
          <Flex justify="center" mb={8}>
            <Image
              src="/logo.webp"
              alt="Company Logo"
              boxSize="70px"
              transition="all 0.3s ease"
              _hover={{
                transform: "scale(1.1)",
              }}
            />
          </Flex>

          <Heading
            size="lg"
            mb={2}
            textAlign="center"
            color={headingColor}
            fontWeight="600"
          >
            Forgot Password?
          </Heading>
          <Text mb={8} textAlign="center" color={textColor} fontSize="md">
            Enter your email address and we'll send you a link to reset your
            password.
          </Text>

          <form onSubmit={handleReset}>
            <Box mb={6}>
              <FormControl isInvalid={!!email && !isEmailValid(email)} isRequired>
                <InputGroup size="lg">
                  <InputLeftElement pointerEvents="none">
                    <Mail size={20} color="gray" />
                  </InputLeftElement>
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    size="lg"
                    bg={inputBg}
                    borderWidth="1px"
                    borderColor={inputBorder}
                    _hover={{
                      borderColor: inputHoverBorder,
                    }}
                    _focus={{
                      borderColor: inputFocusBorder,
                      boxShadow: "0 0 0 1px var(--chakra-colors-blue-500)",
                    }}
                    transition="all 0.2s ease"
                  />
                </InputGroup>
                <FormErrorMessage>
                  Enter a valid email address.
                </FormErrorMessage>
              </FormControl>
            </Box>

            <Button
              type="submit"
              colorScheme="blue"
              size="lg"
              width="100%"
              isLoading={forgotPassword.isPending}
              loadingText="Sending..."
              isDisabled={!isEmailValid(email)}
              _hover={{
                transform: "translateY(-1px)",
                boxShadow: "lg",
              }}
              transition="all 0.2s"
            >
              Send Reset Link
            </Button>
          </form>

          {submitted && (
            <Text color="green.500" mt={6} fontWeight="medium" textAlign="center">
              If your email is registered, you'll receive a reset link shortly.
            </Text>
          )}

          <Text mt={6} textAlign="center" color={textColor} fontSize="sm">
            Remember your password?{" "}
            <Button
              variant="link"
              colorScheme="blue"
              onClick={() => router.push("/")}
              fontWeight="medium"
            >
              Back to Login
            </Button>
          </Text>
        </Card>
      </Container>

      {/* Footer */}
      <Box
        position="absolute"
        bottom={0}
        left={0}
        right={0}
        py={4}
        textAlign="center"
        zIndex={2}
      >
        <Flex
          direction={{ base: "column", md: "row" }}
          justify="center"
          align="center"
          gap={{ base: 2, md: 4 }}
        >
          <Text
            color="white"
            fontSize="sm"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
          >
            © {new Date().getFullYear()} Cleaffo. All rights reserved.
          </Text>
          <Text
            as="span"
            color="white"
            fontSize="sm"
            fontWeight="medium"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
            _hover={{
              color: "blue.200",
              textDecoration: "underline",
              textShadow: "0 1px 2px rgba(0,0,0,0.7)",
            }}
            textDecoration="none"
            transition="all 0.2s ease"
            cursor="pointer"
          >
            |
          </Text>
          <Text
            as="a"
            href="/privacy-policy"
            color="white"
            fontSize="sm"
            fontWeight="medium"
            textShadow="0 1px 2px rgba(0,0,0,0.5)"
            _hover={{
              color: "blue.200",
              textDecoration: "underline",
              textShadow: "0 1px 2px rgba(0,0,0,0.7)",
            }}
            textDecoration="none"
            transition="all 0.2s ease"
            cursor="pointer"
          >
            Privacy Policy
          </Text>
        </Flex>
      </Box>
    </Flex>
  );
} 