import LoginPage from "../ui/components/login";

const Index = () => {
  console.log("index login page");

  return <LoginPage />;
};

export default Index;
