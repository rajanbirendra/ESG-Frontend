import React from "react";
import {
  Box,
  Container,
  Heading,
  Text,
  VStack,
  HStack,
  List,
  ListItem,
  ListIcon,
  Link,
  Button,
  Flex,
  useColorModeValue,
  Divider,
} from "@chakra-ui/react";
import {
  ArrowLeft,
  Shield,
  Eye,
  Lock,
  Users,
  Database,
  Globe,
} from "lucide-react";
import { useRouter } from "next/router";

const PrivacyPolicy = () => {
  const router = useRouter();

  // Theme colors
  const bgColor = useColorModeValue("white", "gray.800");
  const textColor = useColorModeValue("gray.600", "gray.300");
  const headingColor = useColorModeValue("gray.700", "white");
  const borderColor = useColorModeValue("gray.200", "gray.600");

  return (
    <Box minH="100vh" bg="gray.50">
      <Container maxW="4xl" py={8}>
        {/* Header */}
        <Flex justify="space-between" align="center" mb={8}>
          <Button
            leftIcon={<ArrowLeft size={18} />}
            variant="ghost"
            colorScheme="primary"
            onClick={() => router.back()}
            _hover={{ bg: "primary.50" }}
          >
            Back
          </Button>
          <Heading size="lg" color={headingColor}>
            Privacy Policy
          </Heading>
          <Box w="100px" /> {/* Spacer for centering */}
        </Flex>

        {/* Content */}
        <Box
          bg={bgColor}
          borderRadius="xl"
          boxShadow="lg"
          p={8}
          border="1px solid"
          borderColor={borderColor}
        >
          <VStack spacing={8} align="stretch">
            {/* Introduction */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Shield size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Introduction
                </Heading>
              </HStack>
              <Text color={textColor} lineHeight="tall">
                Cleaffo ("we," "our," or "us") is committed to protecting your
                privacy. This Privacy Policy explains how we collect, use,
                disclose, and safeguard your information when you use our ESG
                (Environmental, Social, and Governance) Portal platform. By
                using our services, you agree to the collection and use of
                information in accordance with this policy..
              </Text>
            </Box>

            <Divider />

            {/* Information We Collect */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Database size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Information We Collect
                </Heading>
              </HStack>

              <VStack spacing={4} align="stretch">
                <Box>
                  <Text fontWeight="semibold" color={headingColor} mb={2}>
                    Personal Information
                  </Text>
                  <List spacing={2} color={textColor}>
                    <ListItem>
                      <ListIcon as={Lock} color="primary.500" />
                      Name, email address, and contact information
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Lock} color="primary.500" />
                      Company information and organizational details
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Lock} color="primary.500" />
                      User credentials and authentication data
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Lock} color="primary.500" />
                      Profile information and preferences
                    </ListItem>
                  </List>
                </Box>

                <Box>
                  <Text fontWeight="semibold" color={headingColor} mb={2}>
                    ESG Data
                  </Text>
                  <List spacing={2} color={textColor}>
                    <ListItem>
                      <ListIcon as={Globe} color="primary.500" />
                      Environmental assessment data and metrics
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Globe} color="primary.500" />
                      Social responsibility reports and evaluations
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Globe} color="primary.500" />
                      Governance compliance information
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Globe} color="primary.500" />
                      Carbon footprint and sustainability metrics
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Globe} color="primary.500" />
                      Custom reports and generated documents
                    </ListItem>
                  </List>
                </Box>

                <Box>
                  <Text fontWeight="semibold" color={headingColor} mb={2}>
                    Technical Information
                  </Text>
                  <List spacing={2} color={textColor}>
                    <ListItem>
                      <ListIcon as={Eye} color="primary.500" />
                      IP address and device information
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Eye} color="primary.500" />
                      Browser type and version
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Eye} color="primary.500" />
                      Usage patterns and analytics data
                    </ListItem>
                    <ListItem>
                      <ListIcon as={Eye} color="primary.500" />
                      Cookies and session information
                    </ListItem>
                  </List>
                </Box>
              </VStack>
            </Box>

            <Divider />

            {/* How We Use Your Information */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Users size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  How We Use Your Information
                </Heading>
              </HStack>

              <List spacing={3} color={textColor}>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  To provide and maintain our ESG portal services
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  To process and generate ESG reports and assessments
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  To communicate with you about your account and services
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  To improve our platform and user experience
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  To ensure compliance with legal and regulatory requirements
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  To provide customer support and technical assistance
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  To send important updates and notifications
                </ListItem>
              </List>
            </Box>

            <Divider />

            {/* Data Sharing and Disclosure */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Shield size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Data Sharing and Disclosure
                </Heading>
              </HStack>

              <Text color={textColor} mb={4}>
                We do not sell, trade, or otherwise transfer your personal
                information to third parties without your consent, except in the
                following circumstances:
              </Text>

              <List spacing={3} color={textColor}>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  <strong>Service Providers:</strong> We may share data with
                  trusted third-party service providers who assist us in
                  operating our platform
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  <strong>Legal Requirements:</strong> We may disclose
                  information when required by law or to protect our rights and
                  safety
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  <strong>Business Transfers:</strong> In the event of a merger,
                  acquisition, or sale of assets
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  <strong>Consent:</strong> With your explicit consent for
                  specific purposes
                </ListItem>
              </List>
            </Box>

            <Divider />

            {/* Data Security */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Lock size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Data Security
                </Heading>
              </HStack>

              <Text color={textColor} mb={4}>
                We implement appropriate technical and organizational security
                measures to protect your information:
              </Text>

              <List spacing={3} color={textColor}>
                <ListItem>
                  <ListIcon as={Shield} color="primary.500" />
                  Encryption of data in transit and at rest
                </ListItem>
                <ListItem>
                  <ListIcon as={Shield} color="primary.500" />
                  Regular security audits and vulnerability assessments
                </ListItem>
                <ListItem>
                  <ListIcon as={Shield} color="primary.500" />
                  Access controls and authentication mechanisms
                </ListItem>
                <ListItem>
                  <ListIcon as={Shield} color="primary.500" />
                  Secure data centers and infrastructure
                </ListItem>
                <ListItem>
                  <ListIcon as={Shield} color="primary.500" />
                  Employee training on data protection practices
                </ListItem>
              </List>
            </Box>

            <Divider />

            {/* Your Rights */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Users size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Your Rights
                </Heading>
              </HStack>

              <Text color={textColor} mb={4}>
                You have the following rights regarding your personal
                information:
              </Text>

              <List spacing={3} color={textColor}>
                <ListItem>
                  <ListIcon as={Eye} color="primary.500" />
                  <strong>Access:</strong> Request access to your personal data
                </ListItem>
                <ListItem>
                  <ListIcon as={Eye} color="primary.500" />
                  <strong>Correction:</strong> Request correction of inaccurate
                  data
                </ListItem>
                <ListItem>
                  <ListIcon as={Eye} color="primary.500" />
                  <strong>Deletion:</strong> Request deletion of your personal
                  data
                </ListItem>
                <ListItem>
                  <ListIcon as={Eye} color="primary.500" />
                  <strong>Portability:</strong> Request data portability
                </ListItem>
                <ListItem>
                  <ListIcon as={Eye} color="primary.500" />
                  <strong>Restriction:</strong> Request restriction of
                  processing
                </ListItem>
                <ListItem>
                  <ListIcon as={Eye} color="primary.500" />
                  <strong>Objection:</strong> Object to processing of your data
                </ListItem>
              </List>
            </Box>

            <Divider />

            {/* Data Retention */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Database size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Data Retention
                </Heading>
              </HStack>

              <Text color={textColor} lineHeight="tall">
                We retain your personal information for as long as necessary to
                provide our services and fulfill the purposes outlined in this
                Privacy Policy. ESG data and reports are retained according to
                regulatory requirements and business needs. You may request
                deletion of your data, subject to legal and contractual
                obligations.
              </Text>
            </Box>

            <Divider />

            {/* Cookies and Tracking */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Eye size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Cookies and Tracking
                </Heading>
              </HStack>

              <Text color={textColor} mb={4}>
                We use cookies and similar tracking technologies to enhance your
                experience:
              </Text>

              <List spacing={3} color={textColor}>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  <strong>Essential Cookies:</strong> Required for basic
                  platform functionality
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  <strong>Analytics Cookies:</strong> Help us understand
                  platform usage
                </ListItem>
                <ListItem>
                  <ListIcon as={Lock} color="primary.500" />
                  <strong>Preference Cookies:</strong> Remember your settings
                  and preferences
                </ListItem>
              </List>

              <Text color={textColor} mt={4}>
                You can control cookie settings through your browser
                preferences.
              </Text>
            </Box>

            <Divider />

            {/* International Transfers */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Globe size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  International Data Transfers
                </Heading>
              </HStack>

              <Text color={textColor} lineHeight="tall">
                Your information may be transferred to and processed in
                countries other than your own. We ensure appropriate safeguards
                are in place to protect your data in accordance with applicable
                data protection laws and regulations.
              </Text>
            </Box>

            <Divider />

            {/* Children's Privacy */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Users size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Children's Privacy
                </Heading>
              </HStack>

              <Text color={textColor} lineHeight="tall">
                Our services are not intended for children under 13 years of
                age. We do not knowingly collect personal information from
                children under 13. If you believe we have collected information
                from a child under 13, please contact us immediately.
              </Text>
            </Box>

            <Divider />

            {/* Changes to Privacy Policy */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Shield size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Changes to This Privacy Policy
                </Heading>
              </HStack>

              <Text color={textColor} lineHeight="tall">
                We may update this Privacy Policy from time to time. We will
                notify you of any changes by posting the new Privacy Policy on
                this page and updating the "Last Updated" date. We encourage you
                to review this Privacy Policy periodically for any changes.
              </Text>
            </Box>

            <Divider />

            {/* Contact Information */}
            <Box>
              <HStack spacing={3} mb={4}>
                <Users size={24} color="#1976d2" />
                <Heading size="md" color={headingColor}>
                  Contact Us
                </Heading>
              </HStack>

              <Text color={textColor} mb={4}>
                If you have any questions about this Privacy Policy or our data
                practices, please contact us:
              </Text>

              <VStack spacing={2} align="flex-start" color={textColor}>
                <Text>
                  <strong>Email:</strong> privacy@cleaffo.com
                </Text>
                <Text>
                  <strong>Phone:</strong> +1 (555) 123-4567
                </Text>
                <Text>
                  <strong>Address:</strong> 123 ESG Street, Sustainability City,
                  SC 12345
                </Text>
              </VStack>
            </Box>

            {/* Last Updated */}
            <Box
              bg="gray.50"
              p={4}
              borderRadius="lg"
              border="1px solid"
              borderColor="gray.200"
            >
              <Text color="gray.600" fontSize="sm" textAlign="center">
                <strong>Last Updated:</strong>{" "}
                {new Date().toLocaleDateString("en-US", {
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                })}
              </Text>
            </Box>
          </VStack>
        </Box>
      </Container>
    </Box>
  );
};

export default PrivacyPolicy;
