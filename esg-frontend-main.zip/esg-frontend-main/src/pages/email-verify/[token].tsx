import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import {
  Box,
  Container,
  Flex,
  Heading,
  Text,
  Spinner,
  useToast,
  Button,
} from "@chakra-ui/react";
import { CheckCircle, XCircle } from "lucide-react";

const EmailTokenVerification: React.FC = () => {
  const router = useRouter();
  const { token } = router.query;
  const [isLoading, setIsLoading] = useState(true);
  const [isValid, setIsValid] = useState(false);
  const [error, setError] = useState("");
  const toast = useToast();

  useEffect(() => {
    const validateToken = async () => {
      if (!token) {
        setError("No token provided");
        setIsLoading(false);
        return;
      }

      try {
        // The email link directly returns a JSON response, so we simulate that response
        // In a real scenario, this would be the actual response from the email link
        const mockResponse = {
          status: "success",
          message: "Token is valid. You can now reset your password.",
          token: token as string
        };

        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 1000));

        if (mockResponse.status === "success") {
          setIsValid(true);
          // Store the token in sessionStorage for the reset password page
          sessionStorage.setItem("resetToken", mockResponse.token);
          // Redirect to reset password page
          setTimeout(() => {
            router.push("/reset-password");
          }, 2000);
        } else {
          setError(mockResponse.message || "Invalid token");
          setIsValid(false);
        }
      } catch (err) {
        console.error("Token validation error:", err);
        setError("Failed to validate token");
        setIsValid(false);
      } finally {
        setIsLoading(false);
      }
    };

    if (token) {
      validateToken();
    }
  }, [token, router, toast]);

  if (isLoading) {
    return (
      <Flex
        minH="100vh"
        align="center"
        justify="center"
        bgImage="url('/bgsignup.webp')"
        bgSize="cover"
        bgPosition="center"
        bgRepeat="no-repeat"
        bgAttachment="fixed"
        position="relative"
        _before={{
          content: '""',
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          bg: "rgba(0, 0, 0, 0.4)",
          backdropFilter: "blur(4px)",
        }}
      >
        <Container maxW="container.sm" position="relative" zIndex={1}>
          <Box
            bg="white"
            p={8}
            borderRadius="2xl"
            boxShadow="2xl"
            maxW="md"
            w="100%"
            mx="auto"
            textAlign="center"
          >
            <Spinner size="xl" color="blue.500" mb={4} />
            <Heading size="md" mb={2}>
              Validating Reset Link...
            </Heading>
            <Text color="gray.600">
              Please wait while we verify your password reset link.
            </Text>
          </Box>
        </Container>
      </Flex>
    );
  }

  return (
    <Flex
      minH="100vh"
      align="center"
      justify="center"
      bgImage="url('/bgsignup.webp')"
      bgSize="cover"
      bgPosition="center"
      bgRepeat="no-repeat"
      bgAttachment="fixed"
      position="relative"
      _before={{
        content: '""',
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        bg: "rgba(0, 0, 0, 0.4)",
        backdropFilter: "blur(4px)",
      }}
    >
      <Container maxW="container.sm" position="relative" zIndex={1}>
        <Box
          bg="white"
          p={8}
          borderRadius="2xl"
          boxShadow="2xl"
          maxW="md"
          w="100%"
          mx="auto"
          textAlign="center"
        >
          {isValid ? (
            <>
              <CheckCircle size={48} color="green" style={{ margin: "0 auto 16px" }} />
              <Heading size="md" mb={2} color="green.500">
                Link Valid!
              </Heading>
              <Text color="gray.600" mb={4}>
                Redirecting you to the password reset page...
              </Text>
            </>
          ) : (
            <>
              <XCircle size={48} color="red" style={{ margin: "0 auto 16px" }} />
              <Heading size="md" mb={2} color="red.500">
                Invalid Link
              </Heading>
              <Text color="gray.600" mb={6}>
                {error || "This password reset link is invalid or has expired."}
              </Text>
              <Button
                colorScheme="blue"
                onClick={() => router.push("/forgotpassword")}
              >
                Request New Reset Link
              </Button>
            </>
          )}
        </Box>
      </Container>
    </Flex>
  );
};

export default EmailTokenVerification; 