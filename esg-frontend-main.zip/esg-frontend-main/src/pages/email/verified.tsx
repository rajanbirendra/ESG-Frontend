import React, { useEffect, useState } from "react";
import {
  Box,
  Flex,
  Heading,
  Image,
  Text,
  VStack,
  Icon,
  Button,
  useColorModeValue,
  useToast
} from "@chakra-ui/react";
import { ArrowLeft, Mail } from "lucide-react";
import { useRouter } from "next/router";

const Verified = () => {
  const router = useRouter();
  const toast = useToast();
  const [status, setStatus] = useState<'loading' | 'success' | 'error' | 'already_verified' | 'user_not_found'>('loading');
  const [message, setMessage] = useState('');

  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const textColor = useColorModeValue("gray.600", "gray.300");
  const headingColor = useColorModeValue("primary.900", "white");
  const successColor = useColorModeValue("success.500", "success.400");
  const errorColor = useColorModeValue("error.500", "error.400");
  const warningColor = useColorModeValue("warning.500", "warning.400");

  useEffect(() => {
    const { success, error } = router.query;
    
    if (success === 'true') {
      setStatus('success');
      setMessage('Your email address has been successfully verified. You can now log in to your account and access all features.');
    } else if (error === 'already_verified') {
      setStatus('already_verified');
      setMessage('Your email has already been verified. You can proceed to login.');
    } else if (error === 'user_not_found') {
      setStatus('user_not_found');
      setMessage('Invalid verification link. Please check your email or contact support.');
    } else {
      setStatus('error');
      setMessage('Something went wrong with the verification process. Please try again.');
    }
  }, [router.query]);

  const handleBackToLogin = () => {
    router.push("/");
  };

  const getStatusConfig = () => {
    switch (status) {
      case 'success':
        localStorage.removeItem("userEmail");   
        return {
          color: successColor,
          heading: 'Email Verified Successfully!',
          buttonText: 'Back to Login',
          showWelcome: true
        };
      case 'already_verified':
        return {
          color: warningColor,
          heading: 'Email Already Verified',
          buttonText: 'Back to Login',
          showWelcome: false
        };
      case 'user_not_found':
        return {
          color: errorColor,
          heading: 'Invalid Verification Link',
          buttonText: 'Back to Login',
          showWelcome: false
        };
      case 'error':
        return {
          color: errorColor,
          heading: 'Verification Failed',
          buttonText: 'Back to Login',
          showWelcome: false
        };
      default:
        return {
          color: successColor,
          heading: 'Email Verified Successfully!',
          buttonText: 'Back to Login',
          showWelcome: true
        };
    }
  };

  const statusConfig = getStatusConfig();

  if (status === 'loading') {
    return (
      <Flex minH="100vh" align="center" justify="center">
        <Text>Verifying your email...</Text>
      </Flex>
    );
  }

  return (
    <Flex
      minH="100vh"
      align="center"
      justify="center"
      bgImage="url('/bgsignup.webp')"
      bgSize="cover"
      bgPosition="center"
      bgRepeat="no-repeat"
      position="relative"
    >
      {/* Overlay for better readability */}
      <Box
        position="absolute"
        top="0"
        left="0"
        right="0"
        bottom="0"
        bg="blackAlpha.300"
        backdropFilter="blur(1px)"
      />

      <Box
        position="relative"
        bg={bgColor}
        p={8}
        borderRadius="xl"
        boxShadow="2xl"
        maxW="md"
        w="100%"
        mx={4}
        border="1px solid"
        borderColor={borderColor}
        backdropFilter="blur(10px)"
        bgGradient="linear(to-b, whiteAlpha.900, whiteAlpha.800)"
      >
        {/* Logo */}
        <Flex justify="center" mb={6}>
          <Image
            src="/logo.webp"
            alt="Company Logo"
            boxSize="60px"
            objectFit="contain"
          />
        </Flex>

        {/* Main Content */}
        <VStack spacing={6} textAlign="center">
          {/* Heading with colored text */}
          <Heading
            size="lg"
            color={statusConfig.color}
            fontWeight="bold"
            lineHeight="1.2"
          >
            {statusConfig.heading}
          </Heading>

          {/* Description */}
          <Text
            color={textColor}
            fontSize="md"
            lineHeight="1.6"
            maxW="sm"
          >
            {message}
          </Text>

          {/* Email Icon */}
          <Box
            p={3}
            borderRadius="lg"
            bg="primary.50"
            color="primary.500"
            border="1px solid"
            borderColor="primary.200"
          >
            <Icon as={Mail} boxSize={6} />
          </Box>

          {/* Action Button */}
          <VStack spacing={3} w="full" pt={2}>
            <Button
              colorScheme="primary"
              size="md"
              w="full"
              leftIcon={<Icon as={ArrowLeft} boxSize={4} />}
              onClick={handleBackToLogin}
              _hover={{
                transform: "translateY(-1px)",
                boxShadow: "lg"
              }}
              transition="all 0.2s"
            >
              {statusConfig.buttonText}
            </Button>
          </VStack>

          {/* Welcome Message (only for success) */}
          {statusConfig.showWelcome && (
            <Text
              fontSize="sm"
              color={textColor}
              textAlign="center"
              opacity={0.8}
            >
              Welcome to ESG Portal! 🎉
            </Text>
          )}
        </VStack>
      </Box>
    </Flex>
  );
};

export default Verified;