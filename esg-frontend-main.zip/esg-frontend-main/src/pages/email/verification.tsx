import React, { useEffect } from "react";
import {
  Box,
  Flex,
  Heading,
  Image,
  Text,
  VStack,
  Icon,
  Button,
  useColorModeValue
} from "@chakra-ui/react";
import { Mail, CheckCircle, ArrowLeft } from "lucide-react";
import { useRouter } from "next/router";
import { useEmailAPI } from "../../query/use-email";
import withAuth from "../../utils/withAuth";

function EmailVerification() {
  const router = useRouter();
  const { resendVerificationEmail } = useEmailAPI();
  const bgColor = useColorModeValue("white", "gray.800");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const textColor = useColorModeValue("gray.600", "gray.300");
  const headingColor = useColorModeValue("primary.900", "white");
  const primaryColor = useColorModeValue("primary.500", "primary.300");

  // Check for userEmail in localStorage and redirect if not found
  useEffect(() => {
    const userEmail = localStorage.getItem("userEmail");
    if (!userEmail) {
      router.push("/");
    }
  }, [router]);

  const handleBackToLogin = () => {
    router.push("/");
  };

  const handleResendEmail = () => {
    // Get email from localStorage
    const userEmail = localStorage.getItem("userEmail");
    
    if (userEmail) {
      resendVerificationEmail.mutate({
        query: {
          email: userEmail
        }
      });
    } 
  };

  return (
    <Flex
      minH="100vh"
      align="center"
      justify="center"
      bgImage="url('/bgsignup.webp')"
      bgSize="cover"
      bgPosition="center"
      bgRepeat="no-repeat"
      position="relative"
    >
      {/* Overlay for better readability */}
      <Box
        position="absolute"
        top="0"
        left="0"
        right="0"
        bottom="0"
        bg="blackAlpha.300"
        backdropFilter="blur(1px)"
      />

      <Box
        position="relative"
        bg={bgColor}
        p={8}
        borderRadius="xl"
        boxShadow="2xl"
        maxW="md"
        w="100%"
        mx={4}
        border="1px solid"
        borderColor={borderColor}
        backdropFilter="blur(10px)"
        bgGradient="linear(to-b, whiteAlpha.900, whiteAlpha.800)"
      >
        {/* Logo */}
        <Flex justify="center" mb={6}>
          <Image
            src="/logo.webp"
            alt="Company Logo"
            boxSize="60px"
            objectFit="contain"
          />
        </Flex>

        {/* Main Content */}
        <VStack spacing={6} textAlign="center">
        

          {/* Heading */}
          <Heading
            size="lg"
            color={headingColor}
            fontWeight="bold"
            lineHeight="1.2"
          >
            Check Your Email
          </Heading>

          {/* Description */}
          <Text
            color={textColor}
            fontSize="md"
            lineHeight="1.6"
            maxW="sm"
          >
            We've sent a verification link to your email address. Please check your inbox and click the link to verify your account.
          </Text>

          {/* Email Icon */}
          <Box
            p={3}
            borderRadius="lg"
            bg="primary.50"
            color="primary.500"
            border="1px solid"
            borderColor="primary.200"
          >
            <Icon as={Mail} boxSize={6} />
          </Box>

          {/* Additional Info */}
          <VStack spacing={3} w="full">
            <Text
              fontSize="sm"
              color={textColor}
              textAlign="center"
            >
              Didn't receive the email? Check your spam folder or try again.
            </Text>

            {/* Action Buttons */}
            <VStack spacing={3} w="full" pt={2}>
              <Button
                colorScheme="primary"
                size="md"
                w="full"
                onClick={handleResendEmail}
                isLoading={resendVerificationEmail.isPending}
                loadingText="Sending..."
                _hover={{
                  transform: "translateY(-1px)",
                  boxShadow: "lg"
                }}
                transition="all 0.2s"
              >
                Resend Email
              </Button>

              <Button
                variant="ghost"
                size="md"
                w="full"
                leftIcon={<Icon as={ArrowLeft} boxSize={4} />}
                onClick={handleBackToLogin}
                color={textColor}
                _hover={{
                  bg: "primary.50",
                  color: "primary.600"
                }}
                transition="all 0.2s"
              >
                Back to Login
              </Button>
            </VStack>
          </VStack>
        </VStack>
      </Box>
    </Flex>
  );
}

export default EmailVerification;