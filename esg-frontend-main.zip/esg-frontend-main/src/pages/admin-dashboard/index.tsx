import React from "react";
import {
  Flex,
  Card,
  Text,
  Box,
  Heading,
  SimpleGrid,
  useColorModeValue,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Icon,
  VStack,
  HStack,
  Badge,
  Progress,
} from "@chakra-ui/react";
import Layout from "@/ui/layouts/AdminDashboardLayout";
import Loader from "@/ui/molecules/Loader";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  LineChart,
  Line,
} from "recharts";
import { useAdminAPI } from "@/query/use-admin";
import {
  Building2,
  Users,
  GitBranch,
  ClipboardCheck,
  BarChart3,
  PieChart as PieChartIcon,
  TrendingUp,
  Globe,
  Activity,
  Target,
} from "lucide-react";

interface AnalyticsData {
  data: {
    company_count: number;
    user_count: number;
    branch_count: number;
    assessment_count: number;
    company_count_by_category: Record<string, number>;
    company_count_by_country: Record<string, number>;
  };
}

export default function Homepage() {
  const { data: analyticsData, isLoading: isLoadingAnalytics } =
    useAdminAPI().getAdminAnalytics;

  // Theme colors
  const cardBg = useColorModeValue("white", "gray.800");
  const textColor = useColorModeValue("gray.600", "gray.400");
  const headingColor = useColorModeValue("gray.700", "white");
  const borderColor = useColorModeValue("gray.200", "gray.700");
  const chartGridColor = useColorModeValue("gray.100", "gray.700");
  const tooltipBg = useColorModeValue("white", "gray.800");
  const tooltipBorder = useColorModeValue("gray.200", "gray.700");
  const bgGradient = useColorModeValue(
    "linear(to-br, blue.50, purple.50, pink.50)",
    "linear(to-br, gray.900, blue.900, purple.900)"
  );

  console.log("analyticsData", analyticsData);

  // Transform the category data for the chart
  const categoryData = React.useMemo(() => {
    if (!(analyticsData as any)?.data?.company_count_by_category) return [];
    return Object.entries(
      (analyticsData as any).data.company_count_by_category
    ).map(([name, value]) => ({
      name,
      count: value,
    }));
  }, [analyticsData]);

  // Transform the country data for the chart
  const countryData = React.useMemo(() => {
    if (!(analyticsData as any)?.data?.company_count_by_country) return [];
    return Object.entries(
      (analyticsData as any).data.company_count_by_country
    ).map(([name, value]) => ({
      name,
      count: value,
    }));
  }, [analyticsData]);

  // Modern color palette with gradients
  const COLORS = [
    "linear(to-r, blue.400, blue.600)",
    "linear(to-r, green.400, green.600)",
    "linear(to-r, purple.400, purple.600)",
    "linear(to-r, orange.400, orange.600)",
    "linear(to-r, red.400, red.600)",
    "linear(to-r, teal.400, teal.600)",
    "linear(to-r, yellow.400, yellow.600)",
    "linear(to-r, pink.400, pink.600)",
  ];

  const SOLID_COLORS = [
    "#3182CE", // blue.500
    "#38A169", // green.500
    "#805AD5", // purple.500
    "#DD6B20", // orange.500
    "#E53E3E", // red.500
    "#319795", // teal.500
    "#D69E2E", // yellow.500
    "#4A5568", // gray.600
  ];

  // Transform growth trends data from API
  const trendData = React.useMemo(() => {
    if (!(analyticsData as any)?.data?.growth_trends) return [];
    const trends = (analyticsData as any).data.growth_trends;
    return trends.labels.map((label: string, index: number) => ({
      month: label,
      companies: trends.companies[index] || 0,
      users: trends.users[index] || 0,
      assessments: trends.assessments[index] || 0,
    }));
  }, [analyticsData]);

  return (
    <Layout headerTitle="Dashboard Overview">
      {isLoadingAnalytics && <Loader />}
      {!isLoadingAnalytics && (analyticsData as any)?.data && (
        <>
          <Box
            bgGradient={bgGradient}
            minH="100vh"
            p={6}
            position="relative"
            _before={{
              content: '""',
              position: "absolute",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              bg: 'url(\'data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%239C92AC" fill-opacity="0.05"%3E%3Ccircle cx="30" cy="30" r="2"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\')',
              opacity: 0.3,
            }}
          >
            {/* Header Section */}
            <VStack spacing={6} mb={8} align="stretch">
              {/* Stats Cards */}
              <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
              <Card
                p={6}
                bg={cardBg}
                borderWidth="1px"
                borderColor={borderColor}
                  borderRadius="2xl"
                  boxShadow="xl"
                _hover={{
                    transform: "translateY(-4px)",
                    boxShadow: "2xl",
                    borderColor: "blue.300",
                }}
                  transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                position="relative"
                overflow="hidden"
                _before={{
                  content: '""',
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "4px",
                    bgGradient: "linear(to-r, blue.400, blue.600)",
                }}
              >
                <Flex alignItems="center" mb={4}>
                  <Box
                    p={3}
                      bgGradient="linear(to-br, blue.50, blue.100)"
                      borderRadius="xl"
                      color="blue.600"
                      mr={4}
                      transition="all 0.3s ease"
                    _groupHover={{
                        transform: "scale(1.1) rotate(5deg)",
                    }}
                  >
                      <Building2 size={28} />
                  </Box>
                    <VStack align="flex-start" spacing={1}>
                      <Text
                        color={textColor}
                        fontSize="sm"
                        fontWeight="600"
                        textTransform="uppercase"
                        letterSpacing="wide"
                      >
                    Total Companies
                  </Text>
                      <Badge colorScheme="blue" variant="subtle" fontSize="xs">
                        Active
                      </Badge>
                    </VStack>
                </Flex>
                  <Text
                    fontWeight="900"
                    fontSize="4xl"
                    color={headingColor}
                    mb={2}
                  >
                  {(analyticsData as any).data.company_count ?? 0}
                </Text>
              </Card>

              <Card
                p={6}
                bg={cardBg}
                borderWidth="1px"
                borderColor={borderColor}
                  borderRadius="2xl"
                  boxShadow="xl"
                _hover={{
                    transform: "translateY(-4px)",
                    boxShadow: "2xl",
                    borderColor: "green.300",
                }}
                  transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                position="relative"
                overflow="hidden"
                _before={{
                  content: '""',
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "4px",
                    bgGradient: "linear(to-r, green.400, green.600)",
                }}
              >
                <Flex alignItems="center" mb={4}>
                  <Box
                    p={3}
                      bgGradient="linear(to-br, green.50, green.100)"
                      borderRadius="xl"
                      color="green.600"
                      mr={4}
                      transition="all 0.3s ease"
                  >
                      <Users size={28} />
                  </Box>
                    <VStack align="flex-start" spacing={1}>
                      <Text
                        color={textColor}
                        fontSize="sm"
                        fontWeight="600"
                        textTransform="uppercase"
                        letterSpacing="wide"
                      >
                    Total Users
                  </Text>
                      <Badge colorScheme="green" variant="subtle" fontSize="xs">
                        Registered
                      </Badge>
                    </VStack>
                </Flex>
                  <Text
                    fontWeight="900"
                    fontSize="4xl"
                    color={headingColor}
                    mb={2}
                  >
                  {(analyticsData as any).data.user_count ?? 0}
                </Text>
              </Card>

              <Card
                p={6}
                bg={cardBg}
                borderWidth="1px"
                borderColor={borderColor}
                  borderRadius="2xl"
                  boxShadow="xl"
                _hover={{
                    transform: "translateY(-4px)",
                    boxShadow: "2xl",
                    borderColor: "purple.300",
                }}
                  transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                position="relative"
                overflow="hidden"
                _before={{
                  content: '""',
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "4px",
                    bgGradient: "linear(to-r, purple.400, purple.600)",
                }}
              >
                <Flex alignItems="center" mb={4}>
                  <Box
                    p={3}
                      bgGradient="linear(to-br, purple.50, purple.100)"
                      borderRadius="xl"
                      color="purple.600"
                      mr={4}
                      transition="all 0.3s ease"
                  >
                      <GitBranch size={28} />
                  </Box>
                    <VStack align="flex-start" spacing={1}>
                      <Text
                        color={textColor}
                        fontSize="sm"
                        fontWeight="600"
                        textTransform="uppercase"
                        letterSpacing="wide"
                      >
                    Total Branches
                  </Text>
                      <Badge
                        colorScheme="purple"
                        variant="subtle"
                        fontSize="xs"
                      >
                        Locations
                      </Badge>
                    </VStack>
                </Flex>
                  <Text
                    fontWeight="900"
                    fontSize="4xl"
                    color={headingColor}
                    mb={2}
                  >
                  {(analyticsData as any).data.branch_count ?? 0}
                </Text>
              </Card>

              <Card
                p={6}
                bg={cardBg}
                borderWidth="1px"
                borderColor={borderColor}
                  borderRadius="2xl"
                  boxShadow="xl"
                _hover={{
                    transform: "translateY(-4px)",
                    boxShadow: "2xl",
                    borderColor: "orange.300",
                }}
                  transition="all 0.3s cubic-bezier(0.4, 0, 0.2, 1)"
                position="relative"
                overflow="hidden"
                _before={{
                  content: '""',
                  position: "absolute",
                  top: 0,
                  left: 0,
                  right: 0,
                  height: "4px",
                    bgGradient: "linear(to-r, orange.400, orange.600)",
                }}
              >
                <Flex alignItems="center" mb={4}>
                  <Box
                    p={3}
                      bgGradient="linear(to-br, orange.50, orange.100)"
                      borderRadius="xl"
                      color="orange.600"
                      mr={4}
                      transition="all 0.3s ease"
                  >
                      <ClipboardCheck size={28} />
                  </Box>
                    <VStack align="flex-start" spacing={1}>
                      <Text
                        color={textColor}
                        fontSize="sm"
                        fontWeight="600"
                        textTransform="uppercase"
                        letterSpacing="wide"
                      >
                    Total Assessments
                  </Text>
                      <Badge
                        colorScheme="orange"
                        variant="subtle"
                        fontSize="xs"
                      >
                        Completed
                      </Badge>
                    </VStack>
                </Flex>
                  <Text
                    fontWeight="900"
                    fontSize="4xl"
                    color={headingColor}
                    mb={2}
                  >
                  {(analyticsData as any).data.assessment_count ?? 0}
                </Text>
              </Card>
            </SimpleGrid>

            {/* Charts Section */}
              <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={8}>
              {/* Company Categories Chart */}
              <Card
                  p={8}
                bg={cardBg}
                borderWidth="1px"
                borderColor={borderColor}
                  borderRadius="2xl"
                  boxShadow="xl"
                  height="600px"
                  _hover={{ boxShadow: "2xl" }}
                  transition="all 0.3s ease"
              >
                  <Flex alignItems="center" mb={8} justify="space-between">
                    <HStack spacing={4}>
                  <Box
                    p={3}
                        bgGradient="linear(to-br, blue.50, blue.100)"
                        borderRadius="xl"
                        color="blue.600"
                  >
                        <BarChart3 size={28} />
                  </Box>
                      <VStack align="flex-start" spacing={1}>
                        <Heading
                          size="lg"
                          color={headingColor}
                          fontWeight="700"
                        >
                    Companies by Category
                  </Heading>
                        <Text color={textColor} fontSize="sm">
                          Distribution across business sectors
                        </Text>
                      </VStack>
                    </HStack>
                    <Badge
                      colorScheme="blue"
                      variant="subtle"
                      fontSize="sm"
                      px={3}
                      py={1}
                    >
                      {categoryData.length} Categories
                    </Badge>
                </Flex>
                  <Box height="450px" width="100%" position="relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={categoryData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                          bottom: 120,
                      }}
                        barSize={50}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke={chartGridColor}
                          opacity={0.3}
                      />
                      <XAxis
                        dataKey="name"
                        angle={-45}
                        textAnchor="end"
                          height={120}
                        interval={0}
                          tick={{
                            fill: textColor,
                            fontSize: 12,
                            fontWeight: "600",
                          }}
                          tickMargin={30}
                      />
                      <YAxis
                          tick={{ fill: textColor, fontWeight: "600" }}
                        tickFormatter={(value) => value.toString()}
                      />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: tooltipBg,
                          border: `1px solid ${tooltipBorder}`,
                            borderRadius: "12px",
                            boxShadow: "xl",
                            padding: "12px",
                        }}
                        formatter={(value) => [`${value} companies`, "Count"]}
                          labelStyle={{ fontWeight: "600" }}
                      />
                        <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                        {categoryData.map((entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                              fill={SOLID_COLORS[index % SOLID_COLORS.length]}
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </Box>
              </Card>

              {/* Companies by Country Chart */}
              <Card
                  p={8}
                bg={cardBg}
                borderWidth="1px"
                borderColor={borderColor}
                  borderRadius="2xl"
                  boxShadow="xl"
                  height="600px"
                  _hover={{ boxShadow: "2xl" }}
                  transition="all 0.3s ease"
              >
                  <Flex alignItems="center" mb={8} justify="space-between">
                    <HStack spacing={4}>
                  <Box
                    p={3}
                        bgGradient="linear(to-br, green.50, green.100)"
                        borderRadius="xl"
                        color="green.600"
                  >
                        <Globe size={28} />
                  </Box>
                      <VStack align="flex-start" spacing={1}>
                        <Heading
                          size="lg"
                          color={headingColor}
                          fontWeight="700"
                        >
                    Companies by Country
                  </Heading>
                        <Text color={textColor} fontSize="sm">
                          Global distribution overview
                        </Text>
                      </VStack>
                    </HStack>
                    <Badge
                      colorScheme="green"
                      variant="subtle"
                      fontSize="sm"
                      px={3}
                      py={1}
                    >
                      {countryData.length} Countries
                    </Badge>
                </Flex>
                  <Box height="450px" width="100%" position="relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={countryData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) =>
                          `${name} (${(percent * 100).toFixed(0)}%)`
                        }
                          outerRadius={180}
                        fill="#8884d8"
                        dataKey="count"
                      >
                        {countryData.map((entry, index) => (
                          <Cell
                            key={`cell-${index}`}
                              fill={SOLID_COLORS[index % SOLID_COLORS.length]}
                          />
                        ))}
                      </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: tooltipBg,
                            border: `1px solid ${tooltipBorder}`,
                            borderRadius: "12px",
                            boxShadow: "xl",
                            padding: "12px",
                          }}
                          formatter={(value) => [`${value} companies`, "Count"]}
                          labelStyle={{ fontWeight: "600" }}
                        />
                        <Legend
                          layout="horizontal"
                          align="center"
                          verticalAlign="bottom"
                          iconType="circle"
                          wrapperStyle={{
                            paddingTop: "20px",
                          }}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </Box>
                </Card>
              </SimpleGrid>

              {/* Trend Chart */}
              <Card
                p={8}
                bg={cardBg}
                borderWidth="1px"
                borderColor={borderColor}
                borderRadius="2xl"
                boxShadow="xl"
                height="500px"
                _hover={{ boxShadow: "2xl" }}
                transition="all 0.3s ease"
              >
                <Flex alignItems="center" mb={8} justify="space-between">
                  <HStack spacing={4}>
                    <Box
                      p={3}
                      bgGradient="linear(to-br, purple.50, purple.100)"
                      borderRadius="xl"
                      color="purple.600"
                    >
                      <Activity size={28} />
                    </Box>
                    <VStack align="flex-start" spacing={1}>
                      <Heading size="lg" color={headingColor} fontWeight="700">
                        Growth Trends
                      </Heading>
                      <Text color={textColor} fontSize="sm">
                        Monthly performance overview
                      </Text>
                    </VStack>
                  </HStack>
                  <Badge
                    colorScheme="purple"
                    variant="subtle"
                    fontSize="sm"
                    px={3}
                    py={1}
                  >
                    {trendData.length} Months
                  </Badge>
                </Flex>
                <Box height="350px" width="100%" position="relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={trendData}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 20,
                      }}
                    >
                      <CartesianGrid
                        strokeDasharray="3 3"
                        stroke={chartGridColor}
                        opacity={0.3}
                      />
                      <XAxis
                        dataKey="month"
                        tick={{ fill: textColor, fontWeight: "600" }}
                      />
                      <YAxis tick={{ fill: textColor, fontWeight: "600" }} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: tooltipBg,
                          border: `1px solid ${tooltipBorder}`,
                          borderRadius: "12px",
                          boxShadow: "xl",
                          padding: "12px",
                        }}
                        labelStyle={{ fontWeight: "600" }}
                      />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="companies"
                        stroke="#3182CE"
                        strokeWidth={3}
                        dot={{ fill: "#3182CE", strokeWidth: 2, r: 6 }}
                        activeDot={{ r: 8 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="users"
                        stroke="#38A169"
                        strokeWidth={3}
                        dot={{ fill: "#38A169", strokeWidth: 2, r: 6 }}
                        activeDot={{ r: 8 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="assessments"
                        stroke="#805AD5"
                        strokeWidth={3}
                        dot={{ fill: "#805AD5", strokeWidth: 2, r: 6 }}
                        activeDot={{ r: 8 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </Box>
              </Card>
            </VStack>
          </Box>
        </>
      )}
    </Layout>
  );
}
