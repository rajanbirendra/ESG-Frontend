import { useState, useEffect, useRef } from "react";
import {
  Box,
  Button,
  Table,
  TableContainer,
  Tbody,
  Td,
  Tr,
  Flex,
  useDisclosure,
  Input,
  InputGroup,
  InputLeftElement,
  List,
  ListItem,
  Text,
  useOutsideClick,
  Thead,
  Th,
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  VStack,
  Heading,
  Divider,
  IconButton,
} from "@chakra-ui/react";
import Layout from "@/ui/layouts/AdminDashboardLayout";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  getAdminAnalyticsAnalyticsAdminGetOptions,
  syncValueSyncPostMutation,
} from "../../../api/@tanstack/react-query.gen";
import {
  LucideBarChartHorizontalBig,
  Search,
  Info,
  Send,
  Clock,
  CheckCircle2,
  FileText,
  ListIcon,
} from "lucide-react";
import Loader from "@/ui/molecules/Loader";
import { useAssessmentsAPI } from "@/query/use-assessments";
import { useRouter } from "next/router";
import YearDropdown from "@/ui/molecules/dropdown/yeardropdown";
import { AssessmentStatus } from "@/api/types.gen";

// Status Dropdown Component
const StatusDropdown = ({ selectedStatus, onSelectStatus }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const dropdownRef = useRef(null);

  const statuses = [
    "APPROVED",
    "IN_PROGRESS",
    "FORWARD_FOR_REVIEW",
    "COMPLETED",
  ];

  const filteredStatuses = statuses.filter((status) =>
    status.toLowerCase().includes(searchTerm.toLowerCase())
  );

  useOutsideClick({
    ref: dropdownRef,
    handler: () => setIsOpen(false),
  });

  const handleStatusSelect = (status: AssessmentStatus) => {
    onSelectStatus(status);
    setIsOpen(false);
    setSearchTerm("");
  };

  const statusMap = {
    APPROVED: "Approved",
    IN_PROGRESS: "In Progress",
    FORWARD_FOR_REVIEW: "Forwarded for Review",
    COMPLETED: "Completed",
  };

  return (
    <Box position="relative" ref={dropdownRef} maxW="300px">
      <InputGroup>
        <InputLeftElement pointerEvents="none">
          <LucideBarChartHorizontalBig size={16} color={"black"} />
        </InputLeftElement>
        <Input
          value={statusMap[selectedStatus] || ""}
          onClick={() => setIsOpen(true)}
          readOnly
          placeholder="Select status"
          cursor="pointer"
          bg="white"
          _hover={{ borderColor: "blue.500" }}
          _focus={{ borderColor: "blue.500", boxShadow: "none" }}
        />
      </InputGroup>

      {isOpen && (
        <Box
          position="absolute"
          top="100%"
          left={0}
          right={0}
          mt={1}
          bg="white"
          borderRadius="md"
          boxShadow="lg"
          zIndex={10}
          maxH="300px"
          overflowY="auto"
        >
          <InputGroup size="sm" p={2}>
            <InputLeftElement pointerEvents="none" mt={2} ml={2}>
              <Search size={14} color="black" />
            </InputLeftElement>
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search status..."
              size="sm"
              autoFocus
              _focus={{ borderColor: "blue.500", boxShadow: "none" }}
            />
          </InputGroup>

          <List spacing={0}>
            {filteredStatuses.map((status) => (
              <ListItem
                key={status}
                px={4}
                py={2}
                cursor="pointer"
                display="flex"
                bg={selectedStatus === status ? "blue.50" : "transparent"}
                _hover={{ bg: "blue.50" }}
                // @ts-ignore
                onClick={() => handleStatusSelect(status)}
              >
                <Text
                  color={selectedStatus === status ? "blue.600" : "gray.700"}
                  fontWeight={selectedStatus === status ? "medium" : "normal"}
                >
                  {statusMap[status] || status}
                </Text>
              </ListItem>
            ))}
          </List>
        </Box>
      )}
    </Box>
  );
};

export default function AssessmentList() {
  // Dropdown states
  const [selectedCompany, setSelectedCompany] = useState(null);
  const [selectedFocus, setSelectedFocus] = useState("Environment");
  const [selectedScope, setSelectedScope] = useState("1");

  // 1) Determine if scope should be disabled (if focus != "Environment")
  const isScopeDisabled = selectedFocus !== "Environment";

  // 2) Whenever scope is disabled, force scope to "1"
  useEffect(() => {
    if (isScopeDisabled) {
      setSelectedScope("1");
    }
  }, [isScopeDisabled]);

  // Questions array
  const [fetchedQuestions, setFetchedQuestions] = useState([]);

  // Retrieve token from localStorage

  // For toast notifications

  // Toggle modal for hide/unhide question
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [questionToToggle, setQuestionToToggle] = useState(null);

  // Inline "Add question" row states
  const [showAddQuestionRow, setShowAddQuestionRow] = useState(false);
  const [newQuestion, setNewQuestion] = useState("");
  const [newQuestionType, setNewQuestionType] = useState("");
  const [defaultPriorityHeading, setDefaultPriorityHeading] = useState("");
  const [sustainabilityGuideSuggestion, setSustainabilityGuideSuggestion] =
    useState("");
  const [selectedUnit, setSelectedUnit] = useState("");
  const [customUnit, setCustomUnit] = useState("");
  const [uploadFileOption, setUploadFileOption] = useState("");
  const [acceptedFormats, setAcceptedFormats] = useState([]);
  const [uploadMessage, setUploadMessage] = useState("");

  // Edit Modal states (for Custom questions)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Matches the "Edit Default Question" style/fields:
  const [editData, setEditData] = useState({
    questionId: "",
    question: "", // "Question"
    questionType: "", // "Question Type" (UI only)
    defaultTitle: "", // "Default Priority Heading"
    recommendation: "", // "Sustainability Guide Suggestion"
    scope: "1", // "Scope"
    uploadNeeded: "notNeeded", // "Upload file"
    uploadMessage: "", // "Upload message to the user"
    unitIds: [], // "Units"
    uploadFormatIds: [], // "Accepted formats"
    index: null, // to update local state array after saving
  });

  const { data: analyticsData, isLoading: isLoadingAnalytics } = useQuery({
    ...getAdminAnalyticsAnalyticsAdminGetOptions(),
  });

  const { getAllAssessmentForAdmin, downloadAssessmentReport } =
    useAssessmentsAPI();

  const {
    mutate,
    isPending: isSyncing,
    isSuccess: isSyncingDone,
  } = useMutation({
    ...syncValueSyncPostMutation(),
  });

  const router = useRouter();
  const [selectedYear, setSelectedYear] = useState(
    new Date().getFullYear().toString()
  );

  const [selectedStatus, setSelectedStatus] =
    useState<AssessmentStatus>("APPROVED");

  const [searchQuery, setSearchQuery] = useState("");

  // @ts-ignore
  const { data, isLoading } = getAllAssessmentForAdmin({
    query: {
      year: Number(selectedYear),
      assessment_status: selectedStatus,
      search_query: searchQuery,
    },
  });
  console.log("assessment data", data);

  const {
    isOpen: isHistoryOpen,
    onOpen: onHistoryOpen,
    onClose: onHistoryClose,
  } = useDisclosure();
  const [selectedAssessment, setSelectedAssessment] = useState<any>(null);

  const getStatusDisplay = (status: string) => {
    switch (status) {
      case "FORWARD_FOR_REVIEW":
        return "Forwarded for Review";
      case "FORWARD_TO_CLEAFFO":
        return "Forwarded to Cleaffo";
      case "IN_PROGRESS":
        return "In Progress";
      case "COMPLETED":
        return "Completed";
      default:
        return status.replace(/_/g, " ");
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "FORWARD_FOR_REVIEW":
      case "FORWARD_TO_CLEAFFO":
        return Send;
      case "IN_PROGRESS":
        return Clock;
      case "COMPLETED":
        return CheckCircle2;
      default:
        return FileText;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "FORWARD_FOR_REVIEW":
      case "FORWARD_TO_CLEAFFO":
        return "green.500";
      case "IN_PROGRESS":
        return "orange.500";
      case "COMPLETED":
        return "purple.500";
      default:
        return "blue.500";
    }
  };

  return (
    <>
      <Layout
        headerTitle="Assessment List"
        subHeaderTitle="List of assessments"
      >
        <Box p={4}>
          {/* Header Dropdowns and Search */}
          <Flex
            mb={4}
            gap={4}
            alignItems="center"
            justifyContent="space-between"
          >
            <Box flex="1">
              <InputGroup maxW="100%">
                <InputLeftElement pointerEvents="none">
                  <Search size={16} color="black" />
                </InputLeftElement>
                <Input
                  placeholder="Search assessments..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  bg="white"
                  _hover={{ borderColor: "blue.500" }}
                  _focus={{ borderColor: "blue.500", boxShadow: "none" }}
                />
              </InputGroup>
            </Box>

            <Flex gap={4} alignItems="center">
              {/* Year dropdown filter */}
              <YearDropdown
                selectedYear={selectedYear}
                onSelectYear={(year) => {
                  setSelectedYear(year);
                }}
                maxCurrentYear={true}
              />
              {/* Status dropdown filter */}
              <StatusDropdown
                selectedStatus={selectedStatus}
                onSelectStatus={(status) => {
                  setSelectedStatus(status);
                }}
              />
            </Flex>
          </Flex>

          {/* Main Table */}
          <Box bg="white" p={4} borderRadius="md" boxShadow="md">
            <TableContainer>
              <Table variant="simple">
                <Thead>
                  <Tr>
                    <Th>#</Th>
                    <Th>Assessment</Th>
                    <Th>Company</Th>
                    <Th>Requester</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {isLoading && (
                    <Tr>
                      <Td colSpan={5} textAlign="center">
                        <Loader />
                      </Td>
                    </Tr>
                  )}

                  {!isLoading &&
                    (data as any)?.map((d, index) => {
                      return (
                        <Tr key={d.id}>
                          <Td>{index + 1}</Td>
                          <Td>
                            <Flex justify="space-between" align="start">
                              <Box>
                                <Text fontWeight="medium">{d.title}</Text>
                                <Text color="gray.600" fontSize="sm">
                                  {d.description}
                                </Text>
                                <Text color="gray.500" fontSize="xs">
                                  Created at:{" "}
                                  {
                                    new Date(d.created_at)
                                      .toISOString()
                                      .split("T")[0]
                                  }
                                </Text>
                              </Box>
                              <IconButton
                                aria-label="View History"
                                icon={<Info size={16} />}
                                size="sm"
                                variant="ghost"
                                colorScheme="blue"
                                onClick={() => {
                                  setSelectedAssessment(d);
                                  onHistoryOpen();
                                }}
                              />
                            </Flex>
                          </Td>
                          <Td>
                            <Text fontWeight="medium">
                              {d.requester.company.name}
                            </Text>
                            <Text color="gray.600" fontSize="sm">
                              {d.requester.company.branch?.name}
                            </Text>
                          </Td>
                          <Td>
                            <Text fontWeight="medium">
                              {d.requester.first_name +
                                " " +
                                d.requester.last_name}
                            </Text>
                            <Text color="gray.600" fontSize="sm">
                              {d.requester.company.role}
                            </Text>
                          </Td>
                          <Td>
                            {/* <Button
                              colorScheme="blue"
                              size="sm"
                              onClick={() =>
                                router.push(
                                  "/admin-dashboard/assessment/details/" + d.id
                                )
                              }
                            >
                              View Detail
                            </Button> */}
                            <Button
                              colorScheme="blue"
                              size="sm"
                              onClick={() => {
                                downloadAssessmentReport(d.id);
                              }}
                            >
                              Download Report
                            </Button>
                          </Td>
                        </Tr>
                      );
                    })}

                  {!isLoading && (!data || (data as any)?.length === 0) && (
                    <Tr>
                      <Td colSpan={5} textAlign="center">
                        No assessments found
                      </Td>
                    </Tr>
                  )}
                </Tbody>
              </Table>
            </TableContainer>
          </Box>
        </Box>

        {/* Status History Drawer */}
        <Drawer
          isOpen={isHistoryOpen}
          placement="right"
          onClose={onHistoryClose}
          size="md"
        >
          <DrawerOverlay />
          <DrawerContent>
            <DrawerCloseButton />
            <DrawerHeader borderBottomWidth="1px">Status History</DrawerHeader>

            <DrawerBody>
              {selectedAssessment && (
                <VStack spacing={4} align="stretch">
                  <Box>
                    <Heading size="sm" mb={2}>
                      {selectedAssessment.title}
                    </Heading>
                    <Text color="gray.500" fontSize="sm">
                      {selectedAssessment.description}
                    </Text>
                  </Box>
                  <Divider />
                  <List spacing={4}>
                    {selectedAssessment?.status_history?.map(
                      (item: any, index: number) => (
                        <ListItem key={index}>
                          <Flex align="start" gap={3}>
                            <ListIcon
                              // @ts-ignore
                              as={getStatusIcon(item.status)}
                              color={getStatusColor(item.status)}
                              boxSize={5}
                              mt={1}
                            />
                            <Box flex={1}>
                              <Flex
                                justify="space-between"
                                align="center"
                                mb={1}
                              >
                                <Text fontWeight="medium">
                                  {getStatusDisplay(item.status)}
                                </Text>
                                <Text fontSize="sm" color="gray.500">
                                  {new Date(
                                    item.timestamp
                                  ).toLocaleDateString()}
                                </Text>
                              </Flex>
                              {item.updated_by && (
                                <Box bg="gray.50" p={2} borderRadius="md">
                                  <Text fontSize="sm" color="gray.600">
                                    Updated by: {item.updated_by.first_name}{" "}
                                    {item.updated_by.last_name}
                                  </Text>
                                  <Text fontSize="sm" color="gray.500">
                                    {item.updated_by.company?.name} -{" "}
                                    {item.updated_by.company?.branch}
                                  </Text>
                                  <Text fontSize="sm" color="gray.500">
                                    Role: {item.updated_by.company?.role}
                                  </Text>
                                </Box>
                              )}
                              {item.from_status && (
                                <Text fontSize="sm" color="gray.500" mt={1}>
                                  Changed from:{" "}
                                  {getStatusDisplay(item.from_status)}
                                </Text>
                              )}
                            </Box>
                          </Flex>
                        </ListItem>
                      )
                    )}
                  </List>
                </VStack>
              )}
            </DrawerBody>
          </DrawerContent>
        </Drawer>
      </Layout>
    </>
  );
}
