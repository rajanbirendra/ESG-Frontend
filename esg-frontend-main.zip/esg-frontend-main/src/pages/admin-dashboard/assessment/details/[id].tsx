import React, { useState, useEffect } from "react";
import {
  Box,
  Button,
  Flex,
  Input,
  Text,
  useToast,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  Textarea,
  VStack,
  Card,
  CardBody,
} from "@chakra-ui/react";
import Layout from "@/ui/layouts/AdminDashboardLayout";
import { useMutation } from "@tanstack/react-query";
import { syncValueSyncPostMutation } from "@/api/@tanstack/react-query.gen";
import { Send } from "lucide-react";
import Loader from "@/ui/molecules/Loader";
import { useAssessmentsAPI } from "@/query/use-assessments";
import { useRouter } from "next/router";

interface Question {
  id: string;
  question_title: string;
  type: string;
  category: string;
  answers: Array<{
    values: Record<string, any>;
    admin_values?: Record<string, any>;
  }>;
  answer_field?: {
    for_admin?: Array<{
      input_type: string;
      label: string;
    }>;
  };
}

interface AssessmentDetails {
  questions: Question[];
}

// Helper function to group questions by category
const groupQuestionsByCategory = (questions: Question[] | undefined) => {
  if (!questions) return {};
  return questions.reduce<Record<string, Question[]>>((acc, question) => {
    const category = question.category || "Uncategorized";
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(question);
    return acc;
  }, {});
};

const AssessmentDetails = () => {
  const router = useRouter();
  const toast = useToast();
  const [selectedTab, setSelectedTab] = useState(0);
  const [remarks, setRemarks] = useState("");

  const { getAllAssessmentForAdmin, getAssessmentDetails } =
    useAssessmentsAPI();

  const { mutate: updateAssessmentStatus, isPending } =
    useAssessmentsAPI().updateAssessmentStatus;
  const { data: assessmentDetails, isLoading: isLoadingDetails } =
    getAssessmentDetails(
      // @ts-ignore
      {
        path: { id: router.query.id as string },
      }
    ) as { data: AssessmentDetails | undefined; isLoading: boolean };

  const {
    mutate,
    isPending: isSyncing,
    isSuccess: isSyncingDone,
  } = useMutation({
    ...syncValueSyncPostMutation(),
  });

  const handleSync = (data: { questionId: string; admin_values: any }) => {
    mutate({
      body: {
        question_id: data.questionId,
        admin_values: data.admin_values,
        assessment_id: router.query.id as string,
      },
    });
  };

  // Filter questions by category
  const environmentQuestions = assessmentDetails?.questions?.filter(
    (q) => q.type === "ENVIRONMENT"
  );
  const socialQuestions = assessmentDetails?.questions?.filter(
    (q) => q.type === "SOCIAL"
  );
  const governanceQuestions = assessmentDetails?.questions?.filter(
    (q) => q.type === "GOVERNANCE"
  );

  const handleSubmit = () => {
    // Add your submit logic here
    if (!remarks.trim()) {
      toast({
        title: "Remarks Required",
        description: "Please add remarks before submitting",
        status: "warning",
        duration: 3000,
        isClosable: true,
      });
      return;
    }

    // Add your API call here
    console.log("Submitting remarks:", remarks);

    updateAssessmentStatus(
      // @ts-ignore
      {
        body: {
          assessment_id: router.query.id as string,
          status: "COMPLETED",
          remarks: remarks,
        },
      },
      {
        onSuccess: () => {
          // navigate
          window.location.href = "/admin-dashboard/assessment/list";
        },
      }
    );
  };

  return (
    <Layout
      headerTitle="Assessment Details"
      backButtonURL={"/admin-dashboard/assessment/list"}
      activePage={"/admin-dashboard/assessment/list"}
    >
      <Box p={4}>
        {/* Main Content */}
        <Box bg="white" p={4} borderRadius="md" boxShadow="md">
          {isLoadingDetails && <Loader />}

          {!isLoadingDetails && assessmentDetails && (
            <Tabs
              variant="soft-rounded"
              colorScheme="blue"
              onChange={(index) => setSelectedTab(index)}
              index={selectedTab}
            >
              <TabList mb={4} display="flex" justifyContent="center" gap={4}>
                <Tab
                  fontWeight="medium"
                  fontSize="sm"
                  px={6}
                  py={2}
                  _selected={{
                    bg: "blue.500",
                    color: "white",
                    boxShadow: "sm",
                  }}
                  _hover={{
                    bg: "blue.50",
                  }}
                >
                  Environment
                </Tab>
                <Tab
                  fontWeight="medium"
                  fontSize="sm"
                  px={6}
                  py={2}
                  _selected={{
                    bg: "blue.500",
                    color: "white",
                    boxShadow: "sm",
                  }}
                  _hover={{
                    bg: "blue.50",
                  }}
                >
                  Social
                </Tab>
                <Tab
                  fontWeight="medium"
                  fontSize="sm"
                  px={6}
                  py={2}
                  _selected={{
                    bg: "blue.500",
                    color: "white",
                    boxShadow: "sm",
                  }}
                  _hover={{
                    bg: "blue.50",
                  }}
                >
                  Governance
                </Tab>
              </TabList>

              <TabPanels>
                {/* Environment Questions */}
                <TabPanel>
                  {Object.entries(
                    groupQuestionsByCategory(environmentQuestions) || {}
                  ).map(([category, questions], index) => (
                    <Box key={category} mb={6}>
                      <Text
                        fontSize="lg"
                        fontWeight="semibold"
                        color="gray.700"
                        mb={4}
                        pb={2}
                        borderBottom="1px"
                      >
                        {category.replace(/_/g, " ")}
                      </Text>
                      {questions.map((q, i) => (
                        <QuestionCard
                          key={q.id}
                          question={q}
                          onSync={handleSync}
                        />
                      ))}
                    </Box>
                  ))}
                </TabPanel>

                {/* Social Questions */}
                <TabPanel>
                  {Object.entries(
                    groupQuestionsByCategory(socialQuestions) || {}
                  ).map(([category, questions]) => (
                    <Box key={category} mb={6}>
                      <Text
                        fontSize="lg"
                        fontWeight="semibold"
                        color="gray.700"
                        mb={4}
                        pb={2}
                        borderBottom="1px"
                        borderColor="gray.200"
                      >
                        {category.replace(/_/g, " ")}
                      </Text>
                      {questions.map((q) => (
                        <QuestionCard
                          key={q.id}
                          question={q}
                          onSync={handleSync}
                        />
                      ))}
                    </Box>
                  ))}
                </TabPanel>

                {/* Governance Questions */}
                <TabPanel>
                  {Object.entries(
                    groupQuestionsByCategory(governanceQuestions) || {}
                  ).map(([category, questions]) => (
                    <Box key={category} mb={6}>
                      <Text
                        fontSize="lg"
                        fontWeight="semibold"
                        color="gray.700"
                        mb={4}
                        borderColor="gray.200"
                        pb={2}
                        borderBottom="1px"
                      >
                        {category.replace(/_/g, " ")}
                      </Text>
                      {questions.map((q) => (
                        <QuestionCard
                          key={q.id}
                          question={q}
                          onSync={handleSync}
                        />
                      ))}
                    </Box>
                  ))}
                </TabPanel>
              </TabPanels>
            </Tabs>
          )}
        </Box>

        {/* Sticky Remarks Section */}
        <Box
          position="sticky"
          bottom={0}
          left={0}
          right={0}
          bg="white"
          borderTop="1px"
          borderColor="gray.200"
          p={4}
          zIndex={1000}
          boxShadow="0 -4px 6px -1px rgba(0, 0, 0, 0.1)"
        >
          <Card>
            <CardBody>
              <VStack spacing={4} align="stretch">
                <Text fontWeight="medium" color="gray.700">
                  Add Remarks
                </Text>
                <Textarea
                  placeholder="Enter your remarks here..."
                  value={remarks}
                  onChange={(e) => setRemarks(e.target.value)}
                  size="md"
                  rows={3}
                  resize="none"
                  _hover={{ borderColor: "blue.500" }}
                  _focus={{
                    borderColor: "blue.500",
                    boxShadow: "0 0 0 1px blue.500",
                  }}
                />
                <Flex justify="flex-end">
                  <Button
                    colorScheme="blue"
                    leftIcon={<Send size={16} />}
                    onClick={handleSubmit}
                    size="lg"
                    _hover={{
                      transform: "translateY(-1px)",
                      boxShadow: "md",
                    }}
                    transition="all 0.2s"
                  >
                    Mark as Complete
                  </Button>
                </Flex>
              </VStack>
            </CardBody>
          </Card>
        </Box>
      </Box>
    </Layout>
  );
};

export default AssessmentDetails;

// Question Card Component
const QuestionCard = ({ question, onSync }) => {
  let values = [];
  const [emissionFactor, setEmissionFactor] = useState("0.5");
  const [emissionValue, setEmissionValue] = useState("0");

  // Calculate initial values when component mounts
  useEffect(() => {
    if (values.length > 0) {
      const initialValue = values[0] * parseFloat(emissionFactor);
      setEmissionValue(initialValue.toString());
    }
  }, []);

  const renderValue = (key: any, value: any) => {
    if (Array.isArray(value)) {
      return value.map((item, index) => (
        <Box key={index} mb={2}>
          {Object.entries(item).map(([key, val]) => (
            <Box key={key}>
              <Text as="span" fontWeight="medium"></Text>{" "}
              {typeof val === "object" ? (
                <Box>
                  {/* @ts-ignore */}
                  {Object.entries(val).map(([subKey, subVal]) => (
                    <Text key={subKey}>
                      {subKey === "file" ? (
                        <Button
                          as="a"
                          href={subVal as string}
                          size="sm"
                          colorScheme="blue"
                          variant="outline"
                        >
                          View File
                        </Button>
                      ) : (
                        <>
                          <Text as="span">
                            {subKey}
                            {(subKey as unknown as any) && ":"}
                            {/* @ts-ignore */}
                            {subVal.trim() !== "" &&
                              !isNaN(subVal as unknown as any) &&
                              // @ts-ignore
                              (values[values.length === 0 ? 0 : values.length] =
                                subVal)}
                          </Text>
                        </>
                      )}
                    </Text>
                  ))}
                  {/* if only one length then dont br */}
                  {Object.entries(item).length > 1 && <br />}
                </Box>
              ) : (
                <>
                  <Text as="span">{String(val)}</Text>
                  {/* @ts-ignore */}
                  {val.trim() !== "" && !isNaN(val) && values.push(val)}
                </>
              )}
            </Box>
          ))}
        </Box>
      ));
    } else {
      return (
        <Text as="span">
          {key === "file" ? (
            <Button
              as="a"
              href={value as string}
              size="sm"
              colorScheme="blue"
              variant="outline"
            >
              View File
            </Button>
          ) : (
            <>
              {key === "value" ? "" : key + ":"}
              {String(value)}
              {/* @ts-ignore */}
              {value.trim() !== "" && !isNaN(value) && values.push(value)}
            </>
          )}
        </Text>
      );
    }
  };

  return (
    <Flex
      direction={"row"}
      justifyContent={"space-between"}
      gap={4}
      mb={4}
      p={4}
      bg="gray.50"
      borderRadius="md"
    >
      <Box flex="1">
        <Flex direction="row" alignItems="end" mb={2}>
          <Text fontWeight="medium" mb={5}>
            {question.question_title}
          </Text>

          {/* {question.category} */}
        </Flex>
        {question.answers &&
          question.answers.length > 0 &&
          question.answers[0].values &&
          Object.entries(question.answers[0].values).map(([key, value]) => (
            <Box key={key} mb={2}>
              {renderValue(key, value)}
            </Box>
          ))}
      </Box>

      <Box
        style={{ display: "flex", width: "30%", flexDirection: "column" }}
        gap={4}
      >
        {console.log("values", values)}

        {question.answer_field?.for_admin?.map((field, index) => {
          if (field.input_type === "number") {
            const valueField = field?.label?.includes("Value");

            return (
              <Input
                key={index}
                // disabled={valueField}
                type={field.input_type}
                placeholder={field.label}
                defaultValue={(() => {
                  let result;
                  if (valueField) {
                    result = values[0] * parseFloat(emissionFactor);
                    return result;
                  } else {
                    const defaultVal =
                      question.answers[0]?.admin_values?.[field.label] || "0.5";
                    return defaultVal;
                  }
                })()}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                  const newValue = e.target.value;

                  if (!valueField) {
                    // Update emission factor
                    setEmissionFactor(newValue);
                    // Calculate new emission value
                    const calculatedValue = values[0] * parseFloat(newValue);
                    setEmissionValue(calculatedValue.toString());

                    // Sync the emission factor
                    onSync({
                      questionId: question.id,
                      admin_values: {
                        [field.label]: newValue,
                      },
                    });
                  } else {
                    // Handle value field changes
                    setEmissionValue(newValue);
                    onSync({
                      questionId: question.id,
                      admin_values: {
                        [field.label]: newValue,
                      },
                    });
                  }
                }}
              />
            );
          }
          return null;
        })}
      </Box>
    </Flex>
  );
};
