import React, { useState, useEffect } from "react";
import {
  Container,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Text,
  Badge,
  Avatar,
  HStack,
  VStack,
  Card,
  CardBody,
  InputLeftElement,
  InputGroup,
  Input,
  Box,
  Heading,
  Flex,
  Button,
  useColorModeValue,
  Select,
} from "@chakra-ui/react";
import Layout from "@/ui/layouts/AdminDashboardLayout";
import {
  LucideBuilding,
  LucideMail,
  LucideMapPin,
  LucidePhone,
  Search,
  Plus,
  Filter,
  Pencil,
} from "lucide-react";
import { useAdminAPI } from "@/query/use-admin";
import Loader from "@/ui/molecules/Loader";
import EditUser from "@/ui/organisms/admin-dashboard/users/EditUser";

const UsersPage = () => {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [sort, setSort] = useState("latest");
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearch(search);
    }, 300);
    return () => clearTimeout(handler);
  }, [search]);

  const { data: users, isLoading } = useAdminAPI().getUsers({
    query: {
      search: debouncedSearch,
      sort,
    },
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  return (
    <Layout
      activePage="/admin-dashboard/users"
      headerTitle="Users Management"
      subHeaderTitle="View and manage user accounts and their company information"
    >
      <Container maxW="1600px" px={{ base: 2, md: 6 }}>
        {/* Header Section */}

        {/* search  + filter Section */}
        <Box
          mb={3}
          flex={1}
          display={{ base: "block", md: "flex" }}
          alignItems="center"
          gap={2}
        >
          <Box flex={1} mb={{ base: 2, md: 0 }}>
            <InputGroup size="lg">
              <InputLeftElement pointerEvents="none">
                <Search color="var(--chakra-colors-primary-500)" />
              </InputLeftElement>
              <Input
                placeholder="Search users by name, email, or company..."
                bg="searchBg"
                variant="outline"
                borderRadius="lg"
                borderColor="searchBorderColor"
                _placeholder={{ color: "textColor" }}
                _hover={{ borderColor: "activeColor" }}
                _focus={{
                  borderColor: "activeColor",
                  boxShadow: "0 0 0 1px var(--chakra-colors-activeColor)",
                }}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                autoComplete="off"
                fontSize={{ base: "sm", md: "md" }}
                py={{ base: 2, md: 4 }}
              />
            </InputGroup>
          </Box>
          <Flex justify="space-between" align="center" mb={{ base: 2, md: 8 }}>
            <HStack spacing={4}>
              <Select
                value={sort}
                onChange={(e) => setSort(e.target.value)}
                maxW={{ base: "100%", md: "180px" }}
                mt={{ base: 0, md: 8 }}
                height={{ base: "40px", md: "50px" }}
                bg="searchBg"
                borderColor="searchBorderColor"
                color="textColor"
                _focus={{ borderColor: "activeColor" }}
                _hover={{ borderColor: "activeColor" }}
                fontWeight="medium"
                size="md"
                borderRadius="lg"
                fontSize={{ base: "sm", md: "md" }}
              >
                <option value="latest">Sort by Latest</option>
                <option value="oldest">Sort by Oldest</option>
              </Select>
            </HStack>
          </Flex>
        </Box>

        {isLoading ? (
          <Loader />
        ) : (
          <>
            {/* Table Section */}
            <Box w="full" overflowX="auto">
              <Card
                bg="sidebarBg"
                border="1px solid"
                borderColor="borderColor"
                shadow="md"
                borderRadius="xl"
                overflow="hidden"
                minW={{ base: "700px", md: "unset" }}
              >
                <CardBody p={0}>
                  <Table variant="simple" size={{ base: "sm", md: "md" }}>
                    <Thead bg="searchBg">
                      <Tr>
                        <Th
                          color="headingColor"
                          fontWeight="700"
                          py={{ base: 2, md: 4 }}
                          fontSize={{ base: "sm", md: "md" }}
                        >
                          User
                        </Th>
                        <Th
                          color="headingColor"
                          fontWeight="700"
                          py={{ base: 2, md: 4 }}
                          fontSize={{ base: "sm", md: "md" }}
                        >
                          Contact
                        </Th>
                        <Th
                          color="headingColor"
                          fontWeight="700"
                          py={{ base: 2, md: 4 }}
                          fontSize={{ base: "sm", md: "md" }}
                        >
                          Company
                        </Th>
                        <Th
                          color="headingColor"
                          fontWeight="700"
                          py={{ base: 2, md: 4 }}
                          fontSize={{ base: "sm", md: "md" }}
                        >
                          Industry Vertical
                        </Th>
                        <Th
                          color="headingColor"
                          fontWeight="700"
                          py={{ base: 2, md: 4 }}
                          fontSize={{ base: "sm", md: "md" }}
                        >
                          Sub-Industry Vertical
                        </Th>
                        <Th
                          color="headingColor"
                          fontWeight="700"
                          py={{ base: 2, md: 4 }}
                          fontSize={{ base: "sm", md: "md" }}
                        >
                          Role
                        </Th>
                        <Th
                          color="headingColor"
                          fontWeight="700"
                          py={{ base: 2, md: 4 }}
                          fontSize={{ base: "sm", md: "md" }}
                        >
                          Joined
                        </Th>
                      </Tr>
                    </Thead>
                    <Tbody>
                      {isLoading && (
                        <Tr>
                          <Td colSpan={7} py={4}>
                            <Loader />
                          </Td>
                        </Tr>
                      )}
                      {!isLoading &&
                        users &&
                        (users as any)?.data &&
                        (users as any)?.data?.length > 0 &&
                        (users as any)?.data?.map((user: any) => (
                          <Tr
                            key={user.id}
                            _hover={{ bg: "hoverBg" }}
                            transition="all 0.2s"
                          >
                            <Td py={{ base: 2, md: 4 }}>
                              <HStack spacing={3}>
                                <Avatar
                                  name={`${user.first_name} ${user.last_name}`}
                                  size={{ base: "sm", md: "md" }}
                                  bg="primary.500"
                                  color="white"
                                />
                                <VStack align="start" spacing={0}>
                                  <Text
                                    fontWeight="semibold"
                                    color="headingColor"
                                    fontSize={{ base: "sm", md: "md" }}
                                  >
                                    {user.first_name} {user.last_name}
                                  </Text>
                                  <Text fontSize="xs" color="textColor">
                                    @{user.username}
                                  </Text>
                                </VStack>
                              </HStack>
                            </Td>
                            <Td py={{ base: 2, md: 4 }}>
                              <VStack align="start" spacing={2}>
                                <HStack spacing={2}>
                                  <LucideMail
                                    size={16}
                                    color="var(--chakra-colors-primary-500)"
                                  />
                                  <Text
                                    color="textColor"
                                    fontSize={{ base: "xs", md: "sm" }}
                                  >
                                    {user.email}
                                  </Text>
                                </HStack>
                                <HStack spacing={2}>
                                  <LucidePhone
                                    size={16}
                                    color="var(--chakra-colors-primary-500)"
                                  />
                                  <Text
                                    color="textColor"
                                    fontSize={{ base: "xs", md: "sm" }}
                                  >
                                    {user.phone_number}
                                  </Text>
                                </HStack>
                              </VStack>
                            </Td>
                            <Td py={{ base: 2, md: 4 }}>
                              <VStack align="start" spacing={2}>
                                <HStack spacing={2}>
                                  <LucideBuilding
                                    size={16}
                                    color="var(--chakra-colors-primary-500)"
                                  />
                                  <Text
                                    color="textColor"
                                    fontSize={{ base: "xs", md: "sm" }}
                                  >
                                    {user.company.company_name}
                                  </Text>
                                </HStack>
                                <HStack spacing={2}>
                                  <LucideMapPin
                                    size={16}
                                    color="var(--chakra-colors-primary-500)"
                                  />
                                  <Text
                                    color="textColor"
                                    fontSize={{ base: "xs", md: "sm" }}
                                  >
                                    {user.company.location_state +
                                      "," +
                                      user.company.location_country}
                                  </Text>
                                </HStack>
                              </VStack>
                            </Td>
                            <Td py={{ base: 2, md: 4 }}>
                              <Text
                                color="textColor"
                                fontSize={{ base: "xs", md: "sm" }}
                              >
                                {user.company.industry_vertical || "-"}
                              </Text>
                            </Td>
                            <Td py={{ base: 2, md: 4 }}>
                              <Text
                                color="textColor"
                                fontSize={{ base: "xs", md: "sm" }}
                              >
                                {user.company.sub_industry_vertical || "-"}
                              </Text>
                            </Td>
                            <Td py={{ base: 2, md: 4 }}>
                              <VStack align="start" spacing={2}>
                                <Badge
                                  bg="activeBg"
                                  color="activeColor"
                                  px={3}
                                  py={1}
                                  borderRadius="full"
                                  fontSize={{ base: "xs", md: "sm" }}
                                  fontWeight="semibold"
                                  letterSpacing="wide"
                                >
                                  {user.role}
                                </Badge>
                                <Text
                                  fontSize={{ base: "xs", md: "sm" }}
                                  color="textColor"
                                >
                                  {user.company_role}
                                </Text>
                              </VStack>
                            </Td>
                            <Td py={{ base: 2, md: 4 }}>
                              <VStack align="start" spacing={1}>
                                <Text
                                  color="textColor"
                                  fontWeight="medium"
                                  fontSize={{ base: "xs", md: "sm" }}
                                >
                                  {formatDate(user.created_at)}
                                </Text>
                                <Text
                                  fontSize={{ base: "xs", md: "sm" }}
                                  color="textColor"
                                >
                                  {user.company.number_of_employees} employees
                                </Text>
                              </VStack>
                              <Button
                                variant="ghost"
                                size={{ base: "xs", md: "sm" }}
                                ml={2}
                                onClick={() => {
                                  setSelectedUser(user);
                                  setIsEditOpen(true);
                                }}
                                aria-label="Edit user"
                                leftIcon={<Pencil size={16} />}
                                colorScheme="blue"
                              >
                                Edit
                              </Button>
                            </Td>
                          </Tr>
                        ))}
                    </Tbody>
                  </Table>
                </CardBody>
              </Card>
            </Box>
          </>
        )}

        {isEditOpen && (
          <EditUser
            isOpen={isEditOpen}
            onClose={() => setIsEditOpen(false)}
            user={selectedUser}
          />
        )}
      </Container>
    </Layout>
  );
};

export default UsersPage;
