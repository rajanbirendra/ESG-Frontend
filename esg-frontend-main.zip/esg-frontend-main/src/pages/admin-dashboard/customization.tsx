// import React, { useState, useEffect } from "react";
// import {
//   Box,
//   Button,
//   Table,
//   TableContainer,
//   Tbody,
//   Td,
//   Th,
//   Thead,
//   Tr,
//   Flex,
//   Input,
//   Textarea,
//   Radio,
//   RadioGroup,
//   Stack,
//   useToast,
//   Modal,
//   ModalOverlay,
//   ModalContent,
//   ModalHeader,
//   ModalBody,
//   ModalFooter,
// } from "@chakra-ui/react";
// import Layout from "@/ui/layouts/AdminDashboardLayout";
// import QuestionTypeDropdown from "@/ui/components/QuestionTypeDropdown";
// import FocusAreaDropdown from "@/ui/components/focusAreaDropdown";
// import ScopeDropdown from "@/ui/components/scopedropdown";
// import UnitDropdown from "@/ui/components/unitDropdown";
// import FormatDropdown from "@/ui/components/formatDropdown";

// export default function Customization() {
//   // Top Bar dropdown states
//   const [selectedQuestionType, setSelectedQuestionType] =
//     useState("Default Questions");
//   const [selectedFocus, setSelectedFocus] = useState("Environment");

//   // Array for fetched questions
//   const [fetchedQuestions, setFetchedQuestions] = useState([]);

//   // Show/hide inline "Add default question" form
//   const [showAddDefaultQuestionRow, setShowAddDefaultQuestionRow] =
//     useState(false);

//   // Fields for creating a new default question
//   const [newQuestion, setNewQuestion] = useState("");
//   const [newQuestionTypeValue, setNewQuestionTypeValue] = useState("");
//   const [newScope, setNewScope] = useState("1");
//   const [newDefaultTitle, setNewDefaultTitle] = useState("");
//   const [newRecommendation, setNewRecommendation] = useState("");
//   const [selectedUnit, setSelectedUnit] = useState("");
//   const [customUnit, setCustomUnit] = useState("");
//   const [acceptedFormats, setAcceptedFormats] = useState([]);
//   const [uploadFileOption, setUploadFileOption] = useState("");
//   const [uploadMessage, setUploadMessage] = useState("");

//   // Edit modal states
//   const [isEditModalOpen, setIsEditModalOpen] = useState(false);
//   const [editData, setEditData] = useState({
//     questionId: "",
//     question: "",
//     scope: "1",
//     recommendation: "",
//     defaultTitle: "",
//     uploadNeeded: "notNeeded",
//     uploadMessage: "",
//     unitIds: [],
//     uploadFormatIds: [],
//   });

//   // Retrieve token from localStorage
//   const token =
//     typeof window !== "undefined" ? localStorage.getItem("token") : "";
//   const toast = useToast();

//   // Convert focus area to category
//   const getCategoryFromFocus = (focus) => {
//     if (focus === "Environment") return 1;
//     if (focus === "Social") return 2;
//     if (focus === "Governance") return 3;
//     return 1; // fallback
//   };

//   // Fetch questions based on selected type and focus
//   const fetchQuestions = async () => {
//     const category = getCategoryFromFocus(selectedFocus);
//     let url = "";
//     if (selectedQuestionType === "Default Questions") {
//       url = `https://backend.paudyals.com/api/admin/default-questions?category=${category}`;
//     } else {
//       url = `https://backend.paudyals.com/api/admin/custom-questions?category=${category}`;
//     }
//     try {
//       const response = await fetch(url, {
//         method: "GET",
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       if (!response.ok) throw new Error("Failed to fetch questions");
//       const data = await response.json();
//       const questions =
//         selectedQuestionType === "Default Questions"
//           ? data.default_questions
//           : data.custom_questions;
//       setFetchedQuestions(questions);
//     } catch (error) {
//       console.error("Error fetching questions:", error);
//       toast({
//         title: "Error fetching questions",
//         description: error.message,
//         status: "error",
//         duration: 3000,
//         isClosable: true,
//       });
//       setFetchedQuestions([]);
//     }
//   };

//   useEffect(() => {
//     fetchQuestions();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, [selectedQuestionType, selectedFocus]);

//   // Show inline form for adding a new default question
//   const handleAddDefaultQuestion = () => setShowAddDefaultQuestionRow(true);

//   // Cancel creation inline form
//   const handleCancelAddDefaultQuestion = () => {
//     setShowAddDefaultQuestionRow(false);
//     setNewQuestion("");
//     setNewQuestionTypeValue("");
//     setNewScope("1");
//     setNewDefaultTitle("");
//     setNewRecommendation("");
//     setSelectedUnit("");
//     setCustomUnit("");
//     setAcceptedFormats([]);
//     setUploadFileOption("");
//     setUploadMessage("");
//   };

//   // Submit new default question
//   const handleSubmitNewDefaultQuestion = async () => {
//     try {
//       const category = getCategoryFromFocus(selectedFocus);
//       const unitIds = [];
//       const uploadFormatIds = [];

//       const body = {
//         questions: newQuestion,
//         scope: parseInt(newScope, 10),
//         recommendation: newRecommendation || "",
//         default_title: newDefaultTitle || "",
//         category: category,
//         upload_needed: uploadFileOption === "needed",
//         upload_message: uploadMessage || "",
//         unit_ids: unitIds,
//         upload_format_ids: uploadFormatIds,
//       };

//       const response = await fetch(
//         "https://backend.paudyals.com/api/admin/default-questions",
//         {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//             Authorization: `Bearer ${token}`,
//           },
//           body: JSON.stringify(body),
//         }
//       );
//       if (!response.ok) {
//         const errData = await response.json();
//         throw new Error(errData.message || "Failed to add default question");
//       }
//       const data = await response.json();
//       toast({
//         title:
//           data.message || "The default question has been added successfully",
//         status: "success",
//         duration: 3000,
//         isClosable: true,
//       });
//       await fetchQuestions();
//       handleCancelAddDefaultQuestion();
//     } catch (error) {
//       console.error("Error adding default question:", error);
//       toast({
//         title: "Error adding default question",
//         description: error.message,
//         status: "error",
//         duration: 3000,
//         isClosable: true,
//       });
//     }
//   };

//   // Handle "Edit" button click for a default question
//   const handleEditClick = (q) => {
//     setEditData({
//       questionId: q.id,
//       question: q.questions || "",
//       scope: String(q.scope || "1"),
//       recommendation: q.recommendation || "",
//       defaultTitle: q.default_title || "",
//       uploadNeeded: q.upload_needed ? "needed" : "notNeeded",
//       uploadMessage: q.upload_message || "",
//       unitIds: q.unit_ids || [],
//       uploadFormatIds: q.upload_format_ids || [],
//     });
//     setIsEditModalOpen(true);
//   };

//   // Cancel edit
//   const handleCloseEditModal = () => {
//     setIsEditModalOpen(false);
//   };

//   // Save edited default question using PUT with question id in the URL path
//   const handleEditSave = async () => {
//     try {
//       const category = getCategoryFromFocus(selectedFocus);
//       const body = {
//         questions: editData.question,
//         scope: parseInt(editData.scope, 10),
//         recommendation: editData.recommendation,
//         default_title: editData.defaultTitle,
//         category: category,
//         upload_needed: editData.uploadNeeded === "needed",
//         upload_message: editData.uploadMessage,
//         unit_ids: editData.unitIds,
//         upload_format_ids: editData.uploadFormatIds,
//       };

//       // URL with question ID in the path
//       const url = `https://backend.paudyals.com/api/admin/default-questions/${editData.questionId}`;
//       const response = await fetch(url, {
//         method: "PUT",
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//         body: JSON.stringify(body),
//       });
//       if (!response.ok) {
//         const errData = await response.json();
//         throw new Error(errData.message || "Failed to edit default question");
//       }
//       const data = await response.json();
//       toast({
//         title: data.message || "The question has been edited successfully",
//         status: "success",
//         duration: 3000,
//         isClosable: true,
//       });
//       await fetchQuestions();
//       setIsEditModalOpen(false);
//     } catch (error) {
//       console.error("Error editing question:", error);
//       toast({
//         title: "Error editing default question",
//         description: error.message,
//         status: "error",
//         duration: 3000,
//         isClosable: true,
//       });
//     }
//   };

//   // If focus is not Environment, disable scope
//   const isScopeDisabled = selectedFocus !== "Environment";

//   return (
//     <Layout>
//       <Box p={4}>
//         {/* Top Bar */}
//         <Flex mb={4} justify="space-between" align="center">
//           <Box>
//             <QuestionTypeDropdown
//               selectedType={selectedQuestionType}
//               onTypeSelected={setSelectedQuestionType}
//             />
//           </Box>
//           <Box>
//             <Button
//               colorScheme="blue"
//               variant="outline"
//               onClick={handleAddDefaultQuestion}
//             >
//               + Add default question
//             </Button>
//           </Box>
//           <Box>
//             <FocusAreaDropdown
//               selectedFocus={selectedFocus}
//               onFocusSelected={setSelectedFocus}
//             />
//           </Box>
//         </Flex>

//         {/* Inline creation form (appears below the top bar) */}
//         {showAddDefaultQuestionRow && (
//           <Box mb={4} p={4} bg="gray.50" borderRadius="md">
//             <Flex direction="column" gap={4}>
//               {/* Row 1: Question & Question Type */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Question
//                   </Box>
//                   <Input
//                     placeholder="Enter question"
//                     value={newQuestion}
//                     onChange={(e) => setNewQuestion(e.target.value)}
//                   />
//                 </Box>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Question Type
//                   </Box>
//                   <RadioGroup
//                     onChange={setNewQuestionTypeValue}
//                     value={newQuestionTypeValue}
//                   >
//                     <Stack direction="column">
//                       <Radio value="Number">Number</Radio>
//                       <Radio value="Text">Text</Radio>
//                     </Stack>
//                   </RadioGroup>
//                 </Box>
//               </Flex>

//               {/* Row 2: Default Priority Heading & Sustainability Guide Suggestion */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Default Priority Heading
//                   </Box>
//                   <Input
//                     placeholder="Example: Reduce Petrol Consumption"
//                     value={newDefaultTitle}
//                     onChange={(e) => setNewDefaultTitle(e.target.value)}
//                   />
//                 </Box>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Sustainability Guide Suggestion
//                   </Box>
//                   <Input
//                     placeholder="Example: Replace petrol powered cars with hybrid or EVs"
//                     value={newRecommendation}
//                     onChange={(e) => setNewRecommendation(e.target.value)}
//                   />
//                 </Box>
//               </Flex>

//               {/* Row 3: Scope & Upload file */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Scope
//                   </Box>
//                   <ScopeDropdown
//                     selectedScope={newScope}
//                     onScopeSelected={setNewScope}
//                     isDisabled={isScopeDisabled}
//                   />
//                 </Box>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Upload file
//                   </Box>
//                   <RadioGroup
//                     onChange={setUploadFileOption}
//                     value={uploadFileOption}
//                   >
//                     <Stack direction="column">
//                       <Radio value="needed">Attachment is needed</Radio>
//                       <Radio value="notNeeded">Attachment not needed</Radio>
//                     </Stack>
//                   </RadioGroup>
//                 </Box>
//               </Flex>

//               {/* Row 4: Units & Accepted formats (only if needed) */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Units
//                   </Box>
//                   <UnitDropdown
//                     selectedUnit={selectedUnit}
//                     onUnitChange={setSelectedUnit}
//                     customUnit={customUnit}
//                     onCustomUnitChange={setCustomUnit}
//                   />
//                 </Box>
//                 {uploadFileOption === "needed" && (
//                   <Box flex="1">
//                     <Box mb={2} fontWeight="semibold">
//                       Accepted formats
//                     </Box>
//                     <FormatDropdown
//                       selectedFormats={acceptedFormats}
//                       onFormatsChange={setAcceptedFormats}
//                     />
//                   </Box>
//                 )}
//               </Flex>

//               {/* Row 5: Upload message (only if needed) */}
//               {uploadFileOption === "needed" && (
//                 <Box>
//                   <Box mb={2} fontWeight="semibold">
//                     Upload message to the user
//                   </Box>
//                   <Textarea
//                     placeholder="For example: Please upload the required pdf files"
//                     value={uploadMessage}
//                     onChange={(e) => setUploadMessage(e.target.value)}
//                   />
//                 </Box>
//               )}

//               {/* Row 6: Submit & Cancel */}
//               <Flex justify="flex-end" gap={2}>
//                 <Button
//                   colorScheme="green"
//                   onClick={handleSubmitNewDefaultQuestion}
//                 >
//                   Submit
//                 </Button>
//                 <Button
//                   colorScheme="red"
//                   variant="outline"
//                   onClick={handleCancelAddDefaultQuestion}
//                 >
//                   Cancel
//                 </Button>
//               </Flex>
//             </Flex>
//           </Box>
//         )}

//         {/* Table of fetched questions */}
//         <Box bg="white" p={4} borderRadius="md" boxShadow="md">
//           <TableContainer>
//             <Table variant="simple">
//               <Thead>
//                 <Tr>
//                   <Th>S.N</Th>
//                   <Th>Questions</Th>
//                   <Th>Scope</Th>
//                   <Th>Sustainability Guide Suggestion</Th>
//                   <Th>Default Priority Heading</Th>
//                   <Th>Edit</Th>
//                 </Tr>
//               </Thead>
//               <Tbody>
//                 {fetchedQuestions.length > 0 ? (
//                   fetchedQuestions.map((q, index) => (
//                     <Tr key={q.id}>
//                       <Td>{index + 1}</Td>
//                       <Td>{q.questions}</Td>
//                       <Td>{q.scope}</Td>
//                       <Td
//                         whiteSpace="pre-wrap"
//                         wordBreak="break-word"
//                         maxW="300px"
//                       >
//                         {q.recommendation || "-"}
//                       </Td>
//                       <Td>{q.default_title || "-"}</Td>
//                       <Td>
//                         {selectedQuestionType === "Default Questions" && (
//                           <Button
//                             variant="outline"
//                             colorScheme="blue"
//                             onClick={() => handleEditClick(q)}
//                           >
//                             Edit
//                           </Button>
//                         )}
//                       </Td>
//                     </Tr>
//                   ))
//                 ) : (
//                   <Tr>
//                     <Td colSpan={6} textAlign="center">
//                       No questions found.
//                     </Td>
//                   </Tr>
//                 )}
//               </Tbody>
//             </Table>
//           </TableContainer>
//         </Box>
//       </Box>

//       {/* Edit Default Question Modal */}
//       <Modal
//         isOpen={isEditModalOpen}
//         onClose={handleCloseEditModal}
//         isCentered
//         size="xl"
//       >
//         <ModalOverlay />
//         <ModalContent>
//           <ModalHeader>Edit Default Question</ModalHeader>
//           <ModalBody>
//             <Flex direction="column" gap={4}>
//               {/* Row 1: Question & Question Type */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Question
//                   </Box>
//                   <Input
//                     placeholder="Enter question"
//                     value={editData.question}
//                     onChange={(e) =>
//                       setEditData({ ...editData, question: e.target.value })
//                     }
//                   />
//                 </Box>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Question Type
//                   </Box>
//                   <RadioGroup
//                     onChange={(val) =>
//                       console.log("Question type changed to:", val)
//                     }
//                   >
//                     <Stack direction="column">
//                       <Radio value="Number">Number</Radio>
//                       <Radio value="Text">Text</Radio>
//                     </Stack>
//                   </RadioGroup>
//                 </Box>
//               </Flex>

//               {/* Row 2: Default Priority Heading & Sustainability Guide Suggestion */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Default Priority Heading
//                   </Box>
//                   <Input
//                     placeholder="Example: Reduce Petrol Consumption"
//                     value={editData.defaultTitle}
//                     onChange={(e) =>
//                       setEditData({ ...editData, defaultTitle: e.target.value })
//                     }
//                   />
//                 </Box>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Sustainability Guide Suggestion
//                   </Box>
//                   <Input
//                     placeholder="Example: Replace petrol powered cars with hybrid or EVs"
//                     value={editData.recommendation}
//                     onChange={(e) =>
//                       setEditData({
//                         ...editData,
//                         recommendation: e.target.value,
//                       })
//                     }
//                   />
//                 </Box>
//               </Flex>

//               {/* Row 3: Scope & Upload file */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Scope
//                   </Box>
//                   <ScopeDropdown
//                     selectedScope={editData.scope}
//                     onScopeSelected={(val) =>
//                       setEditData({ ...editData, scope: val })
//                     }
//                     isDisabled={isScopeDisabled}
//                   />
//                 </Box>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Upload file
//                   </Box>
//                   <RadioGroup
//                     value={editData.uploadNeeded}
//                     onChange={(val) =>
//                       setEditData({ ...editData, uploadNeeded: val })
//                     }
//                   >
//                     <Stack direction="column">
//                       <Radio value="needed">Attachment is needed</Radio>
//                       <Radio value="notNeeded">Attachment not needed</Radio>
//                     </Stack>
//                   </RadioGroup>
//                 </Box>
//               </Flex>

//               {/* Row 4: Units & Accepted formats (only if needed) */}
//               <Flex gap={4}>
//                 <Box flex="1">
//                   <Box mb={2} fontWeight="semibold">
//                     Units
//                   </Box>
//                   <UnitDropdown
//                     selectedUnit=""
//                     onUnitChange={(val) => console.log("Unit changed to:", val)}
//                     customUnit=""
//                     onCustomUnitChange={(val) =>
//                       console.log("Custom unit changed to:", val)
//                     }
//                   />
//                 </Box>
//                 {editData.uploadNeeded === "needed" && (
//                   <Box flex="1">
//                     <Box mb={2} fontWeight="semibold">
//                       Accepted formats
//                     </Box>
//                     <FormatDropdown
//                       selectedFormats={editData.uploadFormatIds}
//                       onFormatsChange={(val) =>
//                         setEditData({ ...editData, uploadFormatIds: val })
//                       }
//                     />
//                   </Box>
//                 )}
//               </Flex>

//               {/* Row 5: Upload message (only if needed) */}
//               {editData.uploadNeeded === "needed" && (
//                 <Box>
//                   <Box mb={2} fontWeight="semibold">
//                     Upload message to the user
//                   </Box>
//                   <Textarea
//                     placeholder="For example: Please upload the required pdf files"
//                     value={editData.uploadMessage}
//                     onChange={(e) =>
//                       setEditData({
//                         ...editData,
//                         uploadMessage: e.target.value,
//                       })
//                     }
//                   />
//                 </Box>
//               )}
//             </Flex>
//           </ModalBody>
//           <ModalFooter>
//             <Button colorScheme="blue" mr={3} onClick={handleEditSave}>
//               Save
//             </Button>
//             <Button variant="ghost" onClick={handleCloseEditModal}>
//               Cancel
//             </Button>
//           </ModalFooter>
//         </ModalContent>
//       </Modal>
//     </Layout>
//   );
// }

import Layout from "@/ui/layouts/AdminDashboardLayout";
import React from "react";

const customization = () => {
  return <Layout>Updating soon.</Layout>;
};

export default customization;
