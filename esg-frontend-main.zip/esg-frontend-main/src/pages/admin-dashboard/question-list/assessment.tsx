import { useState } from "react";
import {
  Box,
  Button,
  Flex,
  useDisclosure,
  Text,
  useToast,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Textarea,
} from "@chakra-ui/react";
import Layout from "@/ui/layouts/AdminDashboardLayout";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  getQuestionsQuestionsGetOptions,
  syncValueSyncPostMutation,
} from "@/api/@tanstack/react-query.gen";
import { Pencil } from "lucide-react";
import Loader from "@/ui/molecules/Loader";
import { useRouter } from "next/router";
import { useQuestionAPI } from "@/query/use-question";
import { useAdminAPI } from "@/query/use-admin";

export default function AssessmentList() {
  const router = useRouter();
  const toast = useToast();
  const [selectedTab, setSelectedTab] = useState(0);

  const { data: questions, isLoading: isLoadingDetails } =
    useQuestionAPI().getQuestions({
      //   @ts-ignore
      query: {
        question_of: "ASSESSMENT",
      },
    });

  const {
    mutate,
    isPending: isSyncing,
    isSuccess: isSyncingDone,
  } = useMutation({
    ...syncValueSyncPostMutation(),
  });

  const handleSync = (data: { questionId: string; admin_values: any }) => {
    mutate({
      body: {
        question_id: data.questionId,
        admin_values: data.admin_values,
        assessment_id: router.query.id as string,
      },
    });
  };

  // Filter questions by category
  const environmentQuestions = (questions as any)?.questions.filter(
    (q) => q.type === "ENVIRONMENT"
  );
  const socialQuestions = (questions as any)?.questions.filter(
    (q) => q.type === "SOCIAL"
  );
  const governanceQuestions = (questions as any)?.questions.filter(
    (q) => q.type === "GOVERNANCE"
  );

  return (
    <Layout
      headerTitle="ESG Assessment Questions"
      isLoading={isLoadingDetails}
      backButtonURL="/admin-dashboard/assessment/list"
      activePage={"admin-dashboard/assessment/list"}
    >
      <Box p={4}>
        {/* Main Content */}
        <Box bg="white" p={4} borderRadius="md" boxShadow="md">
          {isLoadingDetails && <Loader />}

          {!isLoadingDetails &&
            (questions as any) &&
            (questions as any)?.questions &&
            (questions as any)!.questions!.length > 0 && (
              <Tabs
                variant="soft-rounded"
                colorScheme="blue"
                onChange={(index) => setSelectedTab(index)}
                index={selectedTab}
              >
                <TabList mb={4} display="flex" justifyContent="center" gap={4}>
                  <Tab
                    fontWeight="medium"
                    fontSize="sm"
                    px={6}
                    py={2}
                    _selected={{
                      bg: "blue.500",
                      color: "white",
                      boxShadow: "sm",
                    }}
                    _hover={{
                      bg: "blue.50",
                    }}
                  >
                    Environment
                  </Tab>
                  <Tab
                    fontWeight="medium"
                    fontSize="sm"
                    px={6}
                    py={2}
                    _selected={{
                      bg: "blue.500",
                      color: "white",
                      boxShadow: "sm",
                    }}
                    _hover={{
                      bg: "blue.50",
                    }}
                  >
                    Social
                  </Tab>
                  <Tab
                    fontWeight="medium"
                    fontSize="sm"
                    px={6}
                    py={2}
                    _selected={{
                      bg: "blue.500",
                      color: "white",
                      boxShadow: "sm",
                    }}
                    _hover={{
                      bg: "blue.50",
                    }}
                  >
                    Governance
                  </Tab>
                </TabList>

                <TabPanels>
                  {/* Environment Questions */}
                  <TabPanel>
                    {environmentQuestions?.map((q) => (
                      <QuestionCard
                        key={q.id}
                        question={q}
                        onSync={handleSync}
                      />
                    ))}
                  </TabPanel>

                  {/* Social Questions */}
                  <TabPanel>
                    {socialQuestions?.map((q) => (
                      <QuestionCard
                        key={q.id}
                        question={q}
                        onSync={handleSync}
                      />
                    ))}
                  </TabPanel>

                  {/* Governance Questions */}
                  <TabPanel>
                    {governanceQuestions?.map((q) => (
                      <QuestionCard
                        key={q.id}
                        question={q}
                        onSync={handleSync}
                      />
                    ))}
                  </TabPanel>
                </TabPanels>
              </Tabs>
            )}
        </Box>
      </Box>
    </Layout>
  );
}

// Question Card Component
const QuestionCard = ({ question, onSync }) => {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [editedQuestion, setEditedQuestion] = useState(question.question_title);
  const toast = useToast();
  const queryClient = useQueryClient();

  const { mutate, isPending } = useAdminAPI().updateQuestion;

  const handleUpdate = () => {
    // Here you would typically make an API call to update the question

    mutate(
      //   @ts-ignore
      {
        body: {
          question_id: question.id,
          question_title: editedQuestion,
        },
      },
      {
        // @ts-ignore
        onSuccess: () => {
          console.log("its a success");
          queryClient.invalidateQueries(
            getQuestionsQuestionsGetOptions({
              query: {
                question_of: "ASSESSMENT",
              },
            })
          );
        },
      }
    );
    console.log("Updating question:", editedQuestion);

    onClose();
  };

  return (
    <>
      <Flex
        direction={"row"}
        justifyContent={"space-between"}
        gap={4}
        mb={4}
        p={4}
        bg="gray.50"
        borderRadius="md"
      >
        <Box flex="1">
          <Text fontWeight="medium" mb={5}>
            {question.question_title}
          </Text>
        </Box>
        <Button
          variant="ghost"
          colorScheme="blue"
          onClick={onOpen}
          p={2}
          _hover={{ bg: "blue.50" }}
        >
          <Pencil size={18} />
        </Button>
      </Flex>

      {/* Edit Question Modal */}
      <Modal isOpen={isOpen} onClose={onClose} isCentered>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Edit Question</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Textarea
              value={editedQuestion}
              onChange={(e) => setEditedQuestion(e.target.value)}
              placeholder="Enter your question"
              size="lg"
              minH="100px"
              _focus={{
                borderColor: "blue.500",
                boxShadow: "0 0 0 1px var(--chakra-colors-blue-500)",
              }}
            />
          </ModalBody>

          <ModalFooter>
            <Button variant="ghost" mr={3} onClick={onClose}>
              Cancel
            </Button>
            <Button
              colorScheme="blue"
              onClick={handleUpdate}
              isDisabled={editedQuestion === question.question_title}
            >
              Update
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
};
