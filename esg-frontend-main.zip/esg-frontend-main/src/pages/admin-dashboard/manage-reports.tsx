import React, { useState, useMemo } from "react";
import {
  Box,
  Text,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
  Link,
  Button,
  Container,
  Flex,
  Spinner,
  Badge,
  IconButton,
  Tooltip,
  HStack,
  Input,
  InputGroup,
  InputLeftElement,
  Select,
  VStack,
  useToast,
} from "@chakra-ui/react";
import {
  Download as LucideDownload,
  Eye,
  CheckCircle,
  XCircle,
  Clock,
  Search,
} from "lucide-react";
import AdminDashboardLayout from "@/ui/layouts/AdminDashboardLayout";
import { useReportsList } from "@/query/use-report";
import ViewActionDialog from "@/ui/organisms/admin-dashboard/manage-reports/ViewActionDialog";
import ShimmerLoader from "@/ui/molecules/ShimmerLoader";

// Define the expected report API response type
interface ReportCreator {
  id: string;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
}

interface ReportStatus {
  status: string;
  date: string;
  remarks?: string;
}

interface ReportItem {
  id: string;
  type: string;
  starting_year_month: string;
  ending_year_month: string;
  legal_company_name: string;
  cin_number: string;
  report_person_name: string;
  status: ReportStatus[];
  file: string | null;
  created_by: string;
  company_id: string;
  created_at: string;
  updated_at: string;
  creator?: ReportCreator;
}

interface ReportsApiResponse {
  reports: ReportItem[];
  total_count: number;
  limit: number;
  offset: number;
}

const ManageReports = () => {
  const { data, isLoading } = useReportsList({
    headers: { authorization: "" },
  });
  const reportList = data as ReportsApiResponse | undefined;
  const toast = useToast();

  // Filter states
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedYear, setSelectedYear] = useState("");

  // Dialog states
  const [selectedReport, setSelectedReport] = useState<ReportItem | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Get unique years from reports for filter dropdown
  const availableYears = useMemo(() => {
    if (!reportList?.reports) return [];
    const years = Array.from(
      new Set(
        reportList.reports.map((report) => {
          // Extract year from starting_year_month (YYYY-MM format)
          return report.starting_year_month.split("-")[0];
        })
      )
    );
    return years.sort((a, b) => parseInt(b) - parseInt(a)); // Sort in descending order
  }, [reportList]);

  // Filter reports based on search term and year
  const filteredReports = useMemo(() => {
    if (!reportList?.reports) return [];

    return reportList.reports.filter((report) => {
      const matchesSearch =
        searchTerm === "" ||
        report.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        report.legal_company_name
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        report.cin_number?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        report.report_person_name
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        report.creator?.first_name
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        report.creator?.last_name
          ?.toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        report.creator?.email?.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesYear =
        selectedYear === "" ||
        report.starting_year_month.startsWith(selectedYear);

      return matchesSearch && matchesYear;
    });
  }, [reportList, searchTerm, selectedYear]);

  // Helper to format date
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Helper to format period display
  const formatPeriod = (startPeriod: string, endPeriod: string) => {
    const startYear = startPeriod.split("-")[0];
    const startMonth = startPeriod.split("-")[1];
    const endYear = endPeriod.split("-")[0];
    const endMonth = endPeriod.split("-")[1];

    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];

    const startMonthName = monthNames[parseInt(startMonth) - 1];
    const endMonthName = monthNames[parseInt(endMonth) - 1];

    if (startYear === endYear) {
      return `${startMonthName} - ${endMonthName} ${startYear}`;
    } else {
      return `${startMonthName} ${startYear} - ${endMonthName} ${endYear}`;
    }
  };

  // Helper to get status icon and color
  const getStatusInfo = (status: string) => {
    switch (status) {
      case "APPROVED":
        return {
          icon: CheckCircle,
          color: "success.500",
          bg: "success.50",
          textColor: "success.700",
        };
      case "REJECTED":
        return {
          icon: XCircle,
          color: "error.500",
          bg: "error.50",
          textColor: "error.700",
        };
      case "REQUESTED":
        return {
          icon: Clock,
          color: "warning.500",
          bg: "warning.50",
          textColor: "warning.700",
        };
      default:
        return {
          icon: Clock,
          color: "gray.500",
          bg: "gray.50",
          textColor: "gray.700",
        };
    }
  };

  // Dialog handlers
  const handleViewReport = (report: ReportItem) => {
    setSelectedReport(report);
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setSelectedReport(null);
  };

  const handleFileUpload = async (file: File) => {
    // TODO: Implement file upload API call
    // This is a placeholder for the actual upload functionality
    console.log("Uploading file:", file.name);

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000));

    toast({
      title: "File uploaded successfully",
      description:
        "The report file has been uploaded and the report status updated.",
      status: "success",
      duration: 3000,
      isClosable: true,
    });
  };

  return (
    <AdminDashboardLayout headerTitle="Manage Reports" isLoading={isLoading}>
      <Container maxW="1600px" px={6}>
        {/* Search and Filter Section */}
        <Box mt={8} mb={6}>
          <Flex
            direction={{ base: "column", md: "row" }}
            gap={4}
            align={{ base: "stretch", md: "center" }}
            justify="space-between"
          >
            <VStack spacing={4} align="stretch" flex={1}>
              {/* Search Bar */}
              <InputGroup>
                <InputLeftElement pointerEvents="none">
                  <Search size={18} color="#718096" />
                </InputLeftElement>
                <Input
                  placeholder="Search by framework, company name, CIN, report person, or requester..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  bg="white"
                  border="1px solid"
                  borderColor="gray.200"
                  borderRadius="lg"
                  _focus={{
                    borderColor: "primary.500",
                    boxShadow: "0 0 0 1px var(--chakra-colors-primary-500)",
                  }}
                  _hover={{ borderColor: "gray.300" }}
                />
              </InputGroup>
            </VStack>

            {/* Year Filter */}
            <Box minW={{ base: "full", md: "200px" }}>
              <Select
                placeholder="Filter by Year"
                value={selectedYear}
                onChange={(e) => setSelectedYear(e.target.value)}
                bg="white"
                border="1px solid"
                borderColor="gray.200"
                borderRadius="lg"
                _focus={{
                  borderColor: "primary.500",
                  boxShadow: "0 0 0 1px var(--chakra-colors-primary-500)",
                }}
                _hover={{ borderColor: "gray.300" }}
              >
                {availableYears.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </Select>
            </Box>
          </Flex>

          {/* Results Count */}
          <Flex justify="space-between" align="center" mt={4}>
            <Text color="gray.600" fontSize="sm">
              Showing {filteredReports.length} of {reportList?.total_count || 0}{" "}
              reports
            </Text>
            {(searchTerm || selectedYear) && (
              <Button
                size="sm"
                variant="ghost"
                color="primary.600"
                onClick={() => {
                  setSearchTerm("");
                  setSelectedYear("");
                }}
                _hover={{ bg: "primary.50" }}
              >
                Clear Filters
              </Button>
            )}
          </Flex>
        </Box>

        {/* Reports Table */}
        <Box>
          {isLoading ? (
            <ShimmerLoader variant="reports" count={5} />
          ) : filteredReports.length > 0 ? (
            <Box
              bg="white"
              borderRadius="2xl"
              boxShadow="lg"
              overflowX="auto"
              px={{ base: 2, md: 6 }}
              py={6}
              maxW="100%"
              border="1px solid"
              borderColor="gray.100"
            >
              <Table
                variant="striped"
                colorScheme="gray"
                size="sm"
                sx={{
                  "th, td": {
                    whiteSpace: "nowrap",
                    fontSize: "xs",
                    py: 2,
                    px: 2,
                  },
                  th: {
                    position: "sticky",
                    top: 0,
                    zIndex: 1,
                    bg: "primary.50",
                    fontSize: "xs",
                    fontWeight: "bold",
                    py: 3,
                    px: 2,
                  },
                }}
              >
                <Thead>
                  <Tr>
                    <Th color="primary.700" w="10%">
                      Framework
                    </Th>
                    <Th color="primary.700" w="12%">
                      Period
                    </Th>
                    <Th color="primary.700" w="20%">
                      Company Info
                    </Th>
                    <Th color="primary.700" w="12%">
                      Report Person
                    </Th>
                    <Th color="primary.700" w="8%">
                      Status
                    </Th>
                    <Th color="primary.700" w="15%">
                      Remarks
                    </Th>
                    <Th color="primary.700" w="10%">
                      Date
                    </Th>
                    <Th color="primary.700" w="10%">
                      Requester
                    </Th>
                    <Th color="primary.700" textAlign="center" w="3%">
                      Actions
                    </Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {filteredReports.map((report) => {
                    const latestStatus =
                      report.status?.[report.status.length - 1] || {};
                    const statusInfo = getStatusInfo(latestStatus.status);
                    const StatusIcon = statusInfo.icon;

                    return (
                      <Tr
                        key={report.id}
                        _hover={{
                          bg: "primary.25",
                          boxShadow: "sm",
                          transition: "all 0.2s",
                        }}
                      >
                        <Td fontWeight="medium" color="gray.700">
                          {report.type}
                        </Td>
                        <Td color="gray.600">
                          {formatPeriod(
                            report.starting_year_month,
                            report.ending_year_month
                          )}
                        </Td>
                        <Td color="gray.700">
                          <VStack spacing={1} align="flex-start">
                            <Text
                              overflow="hidden"
                              textOverflow="ellipsis"
                              whiteSpace="nowrap"
                              maxW="100%"
                              fontWeight="medium"
                            >
                              {report.legal_company_name || "-"}
                            </Text>
                            <Text
                              overflow="hidden"
                              textOverflow="ellipsis"
                              whiteSpace="nowrap"
                              maxW="100%"
                              color="gray.500"
                              fontSize="xs"
                            >
                              CIN: {report.cin_number || "-"}
                            </Text>
                          </VStack>
                        </Td>
                        <Td color="gray.700">
                          <Text
                            overflow="hidden"
                            textOverflow="ellipsis"
                            whiteSpace="nowrap"
                            maxW="100%"
                          >
                            {report.report_person_name || "-"}
                          </Text>
                        </Td>
                        <Td>
                          <HStack spacing={1}>
                            <StatusIcon size={14} color={statusInfo.color} />
                            <Badge
                              px={2}
                              py={0.5}
                              borderRadius="sm"
                              bg={statusInfo.bg}
                              color={statusInfo.textColor}
                              fontWeight="semibold"
                              fontSize="xs"
                            >
                              {latestStatus.status || "PENDING"}
                            </Badge>
                          </HStack>
                        </Td>
                        <Td color="gray.600">
                          <Text
                            overflow="hidden"
                            textOverflow="ellipsis"
                            whiteSpace="nowrap"
                            maxW="100%"
                          >
                            {latestStatus.remarks || "-"}
                          </Text>
                        </Td>
                        <Td color="gray.500">
                          {new Date(report.created_at).toLocaleDateString(
                            "en-US",
                            {
                              month: "short",
                              day: "numeric",
                              year: "numeric",
                            }
                          )}
                        </Td>
                        <Td color="gray.700">
                          {report.creator ? (
                            <Box>
                              <Text fontWeight="semibold" fontSize="xs">
                                {report.creator.first_name}{" "}
                                {report.creator.last_name}
                              </Text>
                              <Text color="gray.400" fontSize="xs">
                                {report.creator.email}
                              </Text>
                            </Box>
                          ) : (
                            <Text color="gray.400">-</Text>
                          )}
                        </Td>
                        <Td textAlign="center">
                          <HStack spacing={1} justify="center">
                            <Tooltip label="View Details">
                              <IconButton
                                aria-label="View report details"
                                icon={<Eye size={14} />}
                                size="xs"
                                variant="outline"
                                colorScheme="primary"
                                borderRadius="sm"
                                _hover={{ bg: "primary.50" }}
                                onClick={() => handleViewReport(report)}
                              />
                            </Tooltip>
                            {report.file && (
                              <Tooltip label="Download Report">
                                <Link href={report.file} isExternal>
                                  <IconButton
                                    aria-label="Download report"
                                    icon={<LucideDownload size={14} />}
                                    size="xs"
                                    variant="outline"
                                    colorScheme="success"
                                    borderRadius="sm"
                                    _hover={{ bg: "success.50" }}
                                  />
                                </Link>
                              </Tooltip>
                            )}
                          </HStack>
                        </Td>
                      </Tr>
                    );
                  })}
                </Tbody>
              </Table>
            </Box>
          ) : (
            <Flex
              direction="column"
              justify="center"
              align="center"
              minH="300px"
              py={12}
            >
              <Box mb={4}>
                <svg
                  width="80"
                  height="80"
                  viewBox="0 0 80 80"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <rect width="80" height="80" rx="20" fill="#F3F6FB" />
                  <path
                    d="M24 56V24H56V56H24Z"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M32 32H48"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                  <path
                    d="M32 40H48"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                  <path
                    d="M32 48H40"
                    stroke="#A0AEC0"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                  />
                </svg>
              </Box>
              <Text color="gray.500" fontSize="lg" fontWeight="medium">
                {searchTerm || selectedYear
                  ? "No reports match your search criteria. Try adjusting your filters."
                  : "No reports found. Reports will appear here once users request them."}
              </Text>
            </Flex>
          )}
        </Box>
      </Container>

      {/* View Action Dialog */}
      <ViewActionDialog
        isOpen={isDialogOpen}
        onClose={handleCloseDialog}
        report={selectedReport}
        onFileUpload={handleFileUpload}
      />
    </AdminDashboardLayout>
  );
};

export default ManageReports;
