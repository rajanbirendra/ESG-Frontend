import { useEFAPI } from "@/query/use-ef";
import { useState, useRef, useMemo } from "react";
import {
  Td,
  Tbody,
  Tr,
  useToast,
  useDisclosure,
  Popover,
  Button,
  HStack,
  Text,
  Badge,
  Heading,
  Flex,
  CardBody,
  Grid,
  PopoverBody,
  Card,
  Th,
  PopoverContent,
  PopoverCloseButton,
  IconButton,
  Table,
  VStack,
  InputGroup,
  PopoverArrow,
  GridItem,
  Input,
  PopoverTrigger,
  InputLeftElement,
  Thead,
} from "@chakra-ui/react";
import AdminDashboardLayout from "@/ui/layouts/AdminDashboardLayout";
import EditEFModel from "@/ui/organisms/admin-dashboard/emission-factor/EditEFModal";
import CountryStateDropdown from "@/ui/molecules/dropdown/CountryStateDropdown";
import { Download, Pencil, Search, Upload, X } from "lucide-react";
import { getEfGetOptions } from "@/api/@tanstack/react-query.gen";
import { useQueryClient } from "@tanstack/react-query";
import DownloadTemplate from "@/ui/organisms/admin-dashboard/emission-factor/DownloadTemplate";

const index = () => {
  const [country, setCountry] = useState<string | null>("");
  const [state, setState] = useState<string | null>("");
  const [categoryName, setCategoryName] = useState<string | null>("");
  const [searchQuery, setSearchQuery] = useState("");
  const toast = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedItem, setSelectedItem] = useState<any>(null);

  const { data, isLoading } = useEFAPI().getEmissionFactors(
    country,
    state,
    categoryName
  );

  const { mutate: importExcel, isPending: isImporting } =
    useEFAPI().importExcel;

  const {
    isOpen: isEditOpen,
    onOpen: onEditOpen,
    onClose: onEditClose,
  } = useDisclosure();
  const [editForm, setEditForm] = useState({
    country: "",
    state: "",
    category_name: "",
    name: "",
    ef_value: "",
  });

  // Filter data based on search query
  const filteredData = useMemo(() => {
    if (!data) return [];
    if (!searchQuery) return data;

    return (data as any[]).filter((item) =>
      item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [data, searchQuery]);

  const handleEdit = (item: any) => {
    setSelectedItem(item);
    setEditForm({
      country: item.country || "",
      state: item.state || "",
      category_name: item.category || "",
      name: item.name || "",
      ef_value: item.emission_factor || "",
    });
    onEditOpen();
  };

  const handleClearFilters = () => {
    setCountry("");
    setState("");
    setSearchQuery("");
  };

  const handleImportExcel = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    fileInputRef.current?.click();
  };

  const queryClient = useQueryClient();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Check if file is Excel
    if (!file.name.match(/\.(xlsx|xls)$/)) {
      toast({
        title: "Invalid File",
        description: "Please upload an Excel file (.xlsx or .xls)",
        status: "error",
        duration: 3000,
        isClosable: true,
      });
      // Reset file input on invalid file
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    importExcel(
      // @ts-ignore
      {
        body: {
          file: file,
        },
      },
      {
        onSettled: () => {
          // Reset file input after the request is complete (success or error)
          if (fileInputRef.current) {
            fileInputRef.current.value = "";
          }

          // @ts-ignore
          queryClient.invalidateQueries(getEfGetOptions({}));
        },
      }
    );
  };

  return (
    <AdminDashboardLayout
      isLoading={isLoading}
      activePage={"/admin-dashboard/emission-factors"}
      headerTitle="Emission Factors"
    >
      <EditEFModel
        selectedItem={selectedItem}
        isEditOpen={isEditOpen}
        onEditClose={onEditClose}
      />
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept=".xlsx,.xls"
        style={{ display: "none" }}
      />

      <Card mb={4} position={"sticky"} top={90} zIndex={1000}>
        <CardBody>
          <Flex justify="space-between" align="center" mb={4}>
            <Heading size="sm">Filters</Heading>
            <HStack spacing={2}>
              {(country || state || searchQuery) && (
                <Button
                  size="sm"
                  variant="ghost"
                  colorScheme="red"
                  leftIcon={<X size={16} />}
                  onClick={handleClearFilters}
                >
                  Clear Filters
                </Button>
              )}
              <DownloadTemplate />
              <Button
                size="sm"
                colorScheme="blue"
                leftIcon={<Upload className="h-4 w-4" />}
                onClick={handleImportExcel}
                isLoading={isImporting}
              >
                Upload Excel
              </Button>
            </HStack>
          </Flex>
          <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={4}>
            <GridItem colSpan={2}>
              <CountryStateDropdown
                selectedCountry={country || ""}
                selectedState={state || ""}
                onCountryChange={setCountry}
                onStateChange={setState}
              />
            </GridItem>
            <GridItem colSpan={2}>
              <InputGroup>
                <InputLeftElement pointerEvents="none">
                  <Search size={16} color="black" />
                </InputLeftElement>
                <Input
                  placeholder="Search by name..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  size="md"
                  variant="filled"
                  _hover={{ borderColor: "blue.500" }}
                  _focus={{
                    borderColor: "blue.500",
                    boxShadow: "0 0 0 1px blue.500",
                  }}
                />
              </InputGroup>
            </GridItem>
          </Grid>
        </CardBody>
      </Card>

      {!isLoading && (filteredData as any)?.length === 0 && (
        <Card>
          <CardBody>
            <Text textAlign="center" color="gray.500">
              No Emission Factors Found
            </Text>
          </CardBody>
        </Card>
      )}

      {!isLoading && (filteredData as any)?.length > 0 && (
        <Card height={"68vh"} overflow="scroll" overflowX={"hidden"}>
          <CardBody>
            <Table variant="simple">
              <Thead>
                <Tr>
                  <Th>Country</Th>
                  <Th>State</Th>
                  <Th>Category</Th>
                  <Th>Name</Th>
                  <Th isNumeric width={"200px"}>
                    Emission Factor (Activity Based)
                  </Th>
                  <Th isNumeric width={"200px"}>
                    Emission Factor (Spend Based)
                  </Th>
                  <Th>Actions</Th>
                </Tr>
              </Thead>
              <Tbody>
                {(filteredData as any)?.map((item: any, index: number) => (
                  <Tr key={index}>
                    <Td>
                      <Badge colorScheme="blue" variant="subtle">
                        {item.country || "N/A"}
                      </Badge>
                    </Td>
                    <Td>
                      <Badge colorScheme="green" variant="subtle">
                        {item.state || "N/A"}
                      </Badge>
                    </Td>
                    <Td>{item.category || "N/A"}</Td>
                    <Td>{item.name}</Td>
                    <Td isNumeric textAlign={"left"}>
                      {item.emission_factor_activity_based}
                    </Td>
                    <Td isNumeric textAlign={"left"}>
                      {item.emission_factor_spend_based}
                    </Td>
                    <Td>
                      <IconButton
                        aria-label="Edit"
                        icon={<Pencil size={16} />}
                        size="sm"
                        variant="ghost"
                        colorScheme="blue"
                        onClick={() => handleEdit(item)}
                      />
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </CardBody>
        </Card>
      )}
    </AdminDashboardLayout>
  );
};

export default index;
