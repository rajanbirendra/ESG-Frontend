import "../i18n";
import { ChakraProvider } from "@chakra-ui/react";
import { AppProps } from "next/app";
import { QueryClient, QueryClientProvider, queryOptions } from '@tanstack/react-query';
import { APIConfig } from "../config/api.config";
import theme from "../theme";

function MyApp({ Component, pageProps }: AppProps) {
  APIConfig();
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry:false,
      },
    },
  });

  return (
    <QueryClientProvider client={queryClient}>
      <ChakraProvider theme={theme}>
        <Component {...pageProps} />
      </ChakraProvider>
    </QueryClientProvider>
  );
}

export default MyApp;
