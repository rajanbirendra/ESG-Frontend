import { useToast } from "@chakra-ui/react";
import { client } from "../api/client.gen";
import { AppResponseStatus } from "@/utils/index.util";
import { useRouter } from "next/router";

export const APIConfig = () => {
  const toast = useToast();
  const router = useRouter();
  

  client.setConfig({
    baseUrl:
      process.env.NEXT_PUBLIC_API_URL ||
      "https://backend.paudyals.com/api" ||
      "http://localhost:8000/api",
    credentials: "include",
  });

  client.interceptors.request.use((request: Request) => {
    console.log("request gayo");
    request.headers.set(
      "Authorization",
      `Bearer ${localStorage.getItem("token")}`
    );
    return request;
  });

  client.interceptors.response.use(
    async (response: Response, request: Request) => {
      console.log("response ayo");
      
      
      if (!navigator.onLine) {
          toast({
            status: "error",
            description: "No internet connection",
          });
        return response;
      }

      const originalResponse = response.clone();
      let data;
      if (response.body instanceof ReadableStream) {
        data = await response.json();
      } else {
        data = response.body;
      }

      if (data?.status_code === 401 && data?.status === "EMAIL_NOT_VERIFIED") {
        localStorage.setItem("userEmail", data?.email);
        router.push("/email/verification");
      }
      else if (data?.status_code === 401 && (data?.status === "INVALID_CREDENTIALS" || data?.status === "USER_NOT_FOUND")) {
          toast({
            status: "error",
            title:"Error",
            description:data?.message, 
          });
          return response;
      }
      else if (
        data?.data?.status === AppResponseStatus.LOGIN_SUCCESS &&
        data?.data?.token
      ) {
        localStorage.setItem("token", data?.data?.token);
     
      }
    
      return originalResponse;
    }
  );
};
