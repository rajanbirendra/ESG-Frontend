// utils/withAuth.js
import React, { useEffect } from "react";
import { useRouter } from "next/router";

export interface ParsedToken {
  id: string;
  username: string;
  first_name: string;
  last_name: string;
  phone_number: string;
  profile_picture: string;
  company_role: string;
  branch_id: string;
  email: string;
  role: string;
  plan_type: string;
  company: {
    branch_id: string;
    co2_accounted: boolean;
    company_name: string;
    id: string;
    industry_vertical: string;
    location_country: string;
    location_state: string;
    number_of_employees: number;
  };
}

export default function withAuth<T>(WrappedComponent: React.ComponentType<T>) {
  function AuthenticatedComponent(props: T): JSX.Element {
    const router = useRouter();

    useEffect(() => {
      const token = localStorage.getItem("token");
      if (!token) {
        // Redirect to the root (login page) regardless of the domain
        router.push("/");
      }
    }, [router]);

    // @ts-ignore
    return <WrappedComponent {...props} />;
  }
  return AuthenticatedComponent;
}

export function getParsedToken(): ParsedToken | null {
  if (typeof window === "undefined") {
    return null;
  }
  const token = localStorage.getItem("token");
  if (!token) {
    return null;
  }
  try {
    return JSON.parse(atob(token?.split(".")[1]));
  } catch (error) {
    return null;
  }
}
