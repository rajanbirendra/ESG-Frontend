# Storybook Stories

This directory contains all the Storybook stories for the ESG application components.

## Structure

- `components/` - Stories for individual UI components
- `pages/` - Stories for page-level components
- `layouts/` - Stories for layout components

## Guidelines

1. **Naming Convention**: Use `.stories.tsx` extension for story files
2. **Component Organization**: Group stories by component type (atoms, molecules, organisms, pages)
3. **Props Documentation**: Use JSDoc comments to document component props
4. **Controls**: Add controls for interactive props to make stories more useful
5. **Theming**: All stories automatically use the Chakra UI theme

## Example Story Structure

```tsx
import type { Meta, StoryObj } from '@storybook/react';
import { Button } from '@/ui/components/Button';

const meta: Meta<typeof Button> = {
  title: 'Components/Button',
  component: Button,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['solid', 'outline', 'ghost'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Primary: Story = {
  args: {
    children: 'Button',
    variant: 'solid',
  },
};
```

## Running Storybook

```bash
pnpm storybook
```

This will start Storybook on `http://localhost:6006` 