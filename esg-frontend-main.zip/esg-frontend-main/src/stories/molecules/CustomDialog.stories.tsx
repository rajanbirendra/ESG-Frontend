import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Button } from '@chakra-ui/react';
import { CustomDialog } from '@/ui/molecules/CustomDialog';

const meta: Meta<typeof CustomDialog> = {
  title: 'Molecules/CustomDialog',
  component: CustomDialog,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    title: {
      control: { type: 'text' },
      description: 'Dialog title',
    },
    description: {
      control: { type: 'text' },
      description: 'Dialog description',
    },
    clickRoute: {
      control: { type: 'text' },
      description: 'Route to navigate to when confirmed',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const DialogWrapper = (args: any) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>
        Open Dialog
      </Button>
      <CustomDialog
        {...args}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onOpen={() => setIsOpen(true)}
        navigatingRoute="/dashboard"
      />
    </>
  );
};

export const Default: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    title: 'Confirm Action',
    description: 'Are you sure you want to proceed with this action? This cannot be undone.',
    clickRoute: '/dashboard',
  },
};

export const Warning: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    title: 'Warning',
    description: 'This action will permanently delete your data. Please confirm to continue.',
    clickRoute: '/dashboard',
  },
};

export const Information: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    title: 'Information',
    description: 'Your assessment has been successfully submitted. You will receive a confirmation email shortly.',
    clickRoute: '/dashboard',
  },
};

export const LongDescription: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    title: 'Terms and Conditions',
    description: 'By proceeding, you agree to our terms and conditions. This includes data processing, privacy policy, and user agreement. Please read carefully before confirming.',
    clickRoute: '/dashboard',
  },
}; 