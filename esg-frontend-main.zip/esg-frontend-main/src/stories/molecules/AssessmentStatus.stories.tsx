import type { Meta, StoryObj } from '@storybook/react';
import { Badge, HStack, Text, VStack } from '@chakra-ui/react';
import { getStatusDisplay, getStatusIcon, getStatusColor } from '@/ui/molecules/assessmentStatus';

const meta: Meta = {
  title: 'Molecules/AssessmentStatus',
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

const StatusExample = ({ status }: { status: string }) => (
  <HStack spacing={3}>
    {getStatusIcon(status)}
    <Badge colorScheme={getStatusColor(status).split('.')[0]} variant="solid">
      {getStatusDisplay(status)}
    </Badge>
  </HStack>
);

export const AllStatuses: Story = {
  render: () => (
    <VStack spacing={4} align="start">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        Assessment Status Examples
      </Text>
      <StatusExample status="FORWARD_FOR_REVIEW" />
      <StatusExample status="APPROVED" />
      <StatusExample status="IN_PROGRESS" />
      <StatusExample status="COMPLETED" />
      <StatusExample status="DRAFT" />
    </VStack>
  ),
};

export const ForwardedForReview: Story = {
  render: () => <StatusExample status="FORWARD_FOR_REVIEW" />,
};

export const Approved: Story = {
  render: () => <StatusExample status="APPROVED" />,
};

export const InProgress: Story = {
  render: () => <StatusExample status="IN_PROGRESS" />,
};

export const Completed: Story = {
  render: () => <StatusExample status="COMPLETED" />,
};

export const Draft: Story = {
  render: () => <StatusExample status="DRAFT" />,
}; 