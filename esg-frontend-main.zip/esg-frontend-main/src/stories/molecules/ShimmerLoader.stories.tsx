import type { Meta, StoryObj } from '@storybook/react';
import { VStack, Text } from '@chakra-ui/react';
import ShimmerLoader from '@/ui/molecules/ShimmerLoader';

const meta: Meta<typeof ShimmerLoader> = {
  title: 'Molecules/ShimmerLoader',
  component: ShimmerLoader,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    count: {
      control: { type: 'number', min: 1, max: 10 },
      description: 'Number of shimmer items to display',
    },
    variant: {
      control: { type: 'select' },
      options: [
        'card',
        'branch',
        'sub-user',
        'social',
        'governance',
        'environment',
        'general',
        'carbon-neutrality-plan',
        'reports'
      ],
      description: 'Type of shimmer loader variant',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Card: Story = {
  args: {
    variant: 'card',
    count: 3,
  },
};

export const Branch: Story = {
  args: {
    variant: 'branch',
    count: 2,
  },
};

export const SubUser: Story = {
  args: {
    variant: 'sub-user',
    count: 3,
  },
};

export const Social: Story = {
  args: {
    variant: 'social',
    count: 2,
  },
};

export const Governance: Story = {
  args: {
    variant: 'governance',
    count: 2,
  },
};

export const Environment: Story = {
  args: {
    variant: 'environment',
    count: 2,
  },
};

export const General: Story = {
  args: {
    variant: 'general',
    count: 2,
  },
};

export const CarbonNeutralityPlan: Story = {
  args: {
    variant: 'carbon-neutrality-plan',
    count: 2,
  },
};

export const Reports: Story = {
  args: {
    variant: 'reports',
    count: 2,
  },
};

export const AllVariants: Story = {
  render: () => (
    <VStack spacing={6} align="stretch" w="600px">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        All Shimmer Loader Variants
      </Text>
      <ShimmerLoader variant="card" count={1} />
      <ShimmerLoader variant="branch" count={1} />
      <ShimmerLoader variant="sub-user" count={1} />
      <ShimmerLoader variant="social" count={1} />
      <ShimmerLoader variant="governance" count={1} />
      <ShimmerLoader variant="environment" count={1} />
      <ShimmerLoader variant="general" count={1} />
      <ShimmerLoader variant="carbon-neutrality-plan" count={1} />
      <ShimmerLoader variant="reports" count={1} />
    </VStack>
  ),
}; 