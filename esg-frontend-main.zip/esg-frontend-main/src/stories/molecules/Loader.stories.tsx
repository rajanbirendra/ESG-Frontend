import type { Meta, StoryObj } from '@storybook/react';
import Loader from '@/ui/molecules/Loader';

const meta: Meta<typeof Loader> = {
  title: 'Molecules/Loader',
  component: Loader,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  decorators: [
    (Story) => (
      <div style={{ width: '300px', height: '200px', border: '1px solid #e2e8f0' }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const InContainer: Story = {
  args: {},
  decorators: [
    (Story) => (
      <div 
        style={{ 
          width: '400px', 
          height: '300px', 
          border: '1px solid #e2e8f0',
          borderRadius: '8px',
          backgroundColor: '#f7fafc'
        }}
      >
        <Story />
      </div>
    ),
  ],
}; 