import type { Meta, StoryObj } from '@storybook/react';
import { Button, VStack, Text } from '@chakra-ui/react';
import { CustomToast } from '@/ui/molecules/getCustomToast';

const meta: Meta = {
  title: 'Molecules/GetCustomToast',
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    message: {
      control: { type: 'text' },
      description: 'Toast message to display',
    },
    type: {
      control: { type: 'select' },
      options: ['success', 'error', 'info', 'warning'],
      description: 'Type of toast notification',
    },
    position: {
      control: { type: 'select' },
      options: ['top', 'bottom', 'top-right', 'top-left', 'bottom-right', 'bottom-left'],
      description: 'Position of the toast notification',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const ToastDemo = (args: any) => {
  const showToast = () => {
    CustomToast(args);
  };

  return (
    <VStack spacing={4}>
      <Text fontSize="sm" color="gray.600">
        Click the button to show a toast notification
      </Text>
      <Button onClick={showToast} colorScheme="blue">
        Show Toast
      </Button>
    </VStack>
  );
};

export const Success: Story = {
  render: (args) => <ToastDemo {...args} />,
  args: {
    message: 'Operation completed successfully!',
    type: 'success',
    position: 'bottom-right',
  },
};

export const Error: Story = {
  render: (args) => <ToastDemo {...args} />,
  args: {
    message: 'An error occurred while processing your request.',
    type: 'error',
    position: 'bottom-right',
  },
};

export const Info: Story = {
  render: (args) => <ToastDemo {...args} />,
  args: {
    message: 'Your assessment has been saved as draft.',
    type: 'info',
    position: 'bottom-right',
  },
};

export const Warning: Story = {
  render: (args) => <ToastDemo {...args} />,
  args: {
    message: 'Please complete all required fields before submitting.',
    type: 'warning',
    position: 'bottom-right',
  },
};

export const TopPosition: Story = {
  render: (args) => <ToastDemo {...args} />,
  args: {
    message: 'Toast notification at the top',
    type: 'success',
    position: 'top',
  },
};

export const AllPositions: Story = {
  render: () => (
    <VStack spacing={4}>
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        Toast Positions
      </Text>
      <Button onClick={() => CustomToast({ message: 'Top', type: 'success', position: 'top' })}>
        Top
      </Button>
      <Button onClick={() => CustomToast({ message: 'Top Right', type: 'info', position: 'top-right' })}>
        Top Right
      </Button>
      <Button onClick={() => CustomToast({ message: 'Bottom Left', type: 'warning', position: 'bottom-left' })}>
        Bottom Left
      </Button>
      <Button onClick={() => CustomToast({ message: 'Bottom Right', type: 'error', position: 'bottom-right' })}>
        Bottom Right
      </Button>
    </VStack>
  ),
}; 