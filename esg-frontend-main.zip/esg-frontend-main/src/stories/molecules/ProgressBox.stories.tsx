import type { Meta, StoryObj } from '@storybook/react';
import { VStack } from '@chakra-ui/react';
import ProgressBox, { MiniProgressBox } from '@/ui/molecules/ProgressBox';

const meta: Meta<typeof ProgressBox> = {
  title: 'Molecules/ProgressBox',
  component: ProgressBox,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    completion_percentage: {
      control: { type: 'range', min: 0, max: 100, step: 5 },
      description: 'Completion percentage (0-100)',
    },
    answered_questions: {
      control: { type: 'number', min: 0 },
      description: 'Number of answered questions',
    },
    total_questions: {
      control: { type: 'number', min: 1 },
      description: 'Total number of questions',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    completion_percentage: 75,
    answered_questions: 15,
    total_questions: 20,
  },
};

export const Complete: Story = {
  args: {
    completion_percentage: 100,
    answered_questions: 20,
    total_questions: 20,
  },
};

export const LowProgress: Story = {
  args: {
    completion_percentage: 25,
    answered_questions: 5,
    total_questions: 20,
  },
};

export const HighProgress: Story = {
  args: {
    completion_percentage: 90,
    answered_questions: 18,
    total_questions: 20,
  },
};

export const MiniProgress: Story = {
  render: (args) => <MiniProgressBox {...args} />,
  args: {
    completion_percentage: 60,
    answered_questions: 12,
    total_questions: 20,
  },
};

export const AllProgressStates: Story = {
  render: () => (
    <VStack spacing={6} align="stretch" w="400px">
      <ProgressBox
        completion_percentage={25}
        answered_questions={5}
        total_questions={20}
      />
      <ProgressBox
        completion_percentage={50}
        answered_questions={10}
        total_questions={20}
      />
      <ProgressBox
        completion_percentage={75}
        answered_questions={15}
        total_questions={20}
      />
      <ProgressBox
        completion_percentage={100}
        answered_questions={20}
        total_questions={20}
      />
    </VStack>
  ),
}; 