import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Button } from '@chakra-ui/react';
import DateRangePicker from '@/ui/molecules/DateRangeFilter';

const meta: Meta<typeof DateRangePicker> = {
  title: 'Molecules/DateRangeFilter',
  component: DateRangePicker,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    onApply: {
      action: 'date-range-applied',
      description: 'Callback when date range is applied',
    },
    onCancel: {
      action: 'date-range-cancelled',
      description: 'Callback when date range selection is cancelled',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const DateRangeWrapper = (args: any) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>
        Open Date Range Filter
      </Button>
      <DateRangePicker
        {...args}
        onOpen={() => setIsOpen(true)}
        onClose={() => setIsOpen(false)}
      />
    </>
  );
};

export const Default: Story = {
  render: (args) => <DateRangeWrapper {...args} />,
  args: {
    onApply: (startDate, endDate) => console.log('Applied:', { startDate, endDate }),
    onCancel: () => console.log('Cancelled'),
  },
};

export const WithCustomCallbacks: Story = {
  render: (args) => <DateRangeWrapper {...args} />,
  args: {
    onApply: (startDate, endDate) => alert(`Date range applied: ${startDate} to ${endDate}`),
    onCancel: () => alert('Date range selection cancelled'),
  },
}; 