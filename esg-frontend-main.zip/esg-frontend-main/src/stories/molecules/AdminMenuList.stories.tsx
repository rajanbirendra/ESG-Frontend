import type { Meta, StoryObj } from '@storybook/react';
import { VStack, HStack, Text, Box, VStack as ChakraVStack } from '@chakra-ui/react';
import { adminMenuList } from '@/ui/molecules/adminMenuList';

const meta: Meta = {
  title: 'Molecules/AdminMenuList',
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

const MenuItemExample = ({ item }: { item: any }) => (
  <HStack spacing={3} p={3} bg="white" borderRadius="md" border="1px solid" borderColor="gray.200" w="250px">
    {item.icon}
    <Text fontSize="sm" fontWeight="medium">
      {item.title}
    </Text>
  </HStack>
);

const MenuItemWithChildren = ({ item }: { item: any }) => (
  <Box>
    <MenuItemExample item={item} />
    {item.children && (
      <ChakraVStack spacing={1} ml={6} mt={2}>
        {item.children.map((child: any, index: number) => (
          <HStack key={index} spacing={3} p={2} bg="gray.50" borderRadius="md" w="220px">
            {child.icon}
            <Text fontSize="xs" fontWeight="medium">
              {child.title}
            </Text>
          </HStack>
        ))}
      </ChakraVStack>
    )}
  </Box>
);

export const AllMenuItems: Story = {
  render: () => (
    <VStack spacing={2} align="stretch">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        Admin Menu Items
      </Text>
      {adminMenuList.map((item, index) => (
        <MenuItemWithChildren key={index} item={item} />
      ))}
    </VStack>
  ),
};

export const IndividualItems: Story = {
  render: () => (
    <VStack spacing={4} align="stretch">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        Individual Admin Menu Items
      </Text>
      {adminMenuList.map((item, index) => (
        <Box key={index}>
          <Text fontSize="sm" color="gray.600" mb={1}>
            {item.title}
          </Text>
          <MenuItemWithChildren item={item} />
        </Box>
      ))}
    </VStack>
  ),
}; 