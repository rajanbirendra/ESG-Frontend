import type { Meta, StoryObj } from '@storybook/react';
import { VStack, Text } from '@chakra-ui/react';
import AssessmentCard from '@/ui/molecules/cards/AssessmentCard';

const meta: Meta<typeof AssessmentCard> = {
  title: 'Molecules/Cards/AssessmentCard',
  component: AssessmentCard,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    userRole: {
      control: { type: 'select' },
      options: ['USER', 'ADMIN', 'SUB_USER'],
      description: 'User role for permissions',
    },
    showStatus: {
      control: { type: 'boolean' },
      description: 'Show assessment status',
    },
    showActions: {
      control: { type: 'boolean' },
      description: 'Show action buttons',
    },
    showBranch: {
      control: { type: 'boolean' },
      description: 'Show branch information',
    },
    showRequester: {
      control: { type: 'boolean' },
      description: 'Show requester information',
    },
    showYear: {
      control: { type: 'boolean' },
      description: 'Show assessment year',
    },
    showMonth: {
      control: { type: 'boolean' },
      description: 'Show assessment month',
    },
    showCreationDate: {
      control: { type: 'boolean' },
      description: 'Show creation date',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const mockAssessment = {
  id: 'assessment-123',
  title: 'Environmental Assessment 2024',
  description: 'Comprehensive environmental impact assessment for Q1 2024',
  created_at: '2024-01-15T10:30:00Z',
  assessment_year: 2024,
  assessment_month: 3,
  assessment_status: 'IN_PROGRESS',
  requester: {
    first_name: 'John',
    last_name: 'Doe'
  },
  branch: {
    branch_name: 'Main Office'
  }
};

const mockCompletedAssessment = {
  ...mockAssessment,
  assessment_status: 'COMPLETED',
  title: 'Social Assessment 2024'
};

const mockForwardedAssessment = {
  ...mockAssessment,
  assessment_status: 'FORWARD_FOR_REVIEW',
  title: 'Governance Assessment 2024'
};

export const Default: Story = {
  args: {
    assessment: mockAssessment,
    userRole: 'USER',
    showStatus: true,
    showActions: true,
    showBranch: true,
    showRequester: true,
    showYear: true,
    showMonth: true,
    showCreationDate: true,
  },
};

export const Completed: Story = {
  args: {
    assessment: mockCompletedAssessment,
    userRole: 'USER',
    showStatus: true,
    showActions: true,
  },
};

export const Forwarded: Story = {
  args: {
    assessment: mockForwardedAssessment,
    userRole: 'ADMIN',
    showStatus: true,
    showActions: true,
  },
};

export const Minimal: Story = {
  args: {
    assessment: mockAssessment,
    userRole: 'USER',
    showStatus: false,
    showActions: false,
    showBranch: false,
    showRequester: false,
    showYear: false,
    showMonth: false,
    showCreationDate: false,
  },
};

export const AdminView: Story = {
  args: {
    assessment: mockAssessment,
    userRole: 'ADMIN',
    showStatus: true,
    showActions: true,
  },
};

export const AllVariants: Story = {
  render: () => (
    <VStack spacing={4} align="stretch" w="400px">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        Assessment Card Variants
      </Text>
      <AssessmentCard
        assessment={mockAssessment}
        userRole="USER"
        showStatus={true}
        showActions={true}
      />
      <AssessmentCard
        assessment={mockCompletedAssessment}
        userRole="USER"
        showStatus={true}
        showActions={true}
      />
      <AssessmentCard
        assessment={mockForwardedAssessment}
        userRole="ADMIN"
        showStatus={true}
        showActions={true}
      />
    </VStack>
  ),
}; 