import type { Meta, StoryObj } from '@storybook/react';
import { VStack, Text } from '@chakra-ui/react';
import SelfAssessmentCard from '@/ui/molecules/cards/SelfAssessmentCard';

const meta: Meta<typeof SelfAssessmentCard> = {
  title: 'Molecules/Cards/SelfAssessmentCard',
  component: SelfAssessmentCard,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    onClick: {
      action: 'assessment-clicked',
      description: 'Callback when assessment is clicked',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const mockSelfAssessment = {
  id: 'self-assessment-123',
  title: 'Self Assessment - Environment',
  description: 'Personal environmental impact assessment',
  created_at: '2024-01-15T10:30:00Z',
  assessment_year: 2024,
  assessment_month: 3,
  assessment_status: 'IN_PROGRESS',
  completion_percentage: 75,
  requester: {
    first_name: 'Jane',
    last_name: 'Smith'
  }
};

const mockCompletedSelfAssessment = {
  ...mockSelfAssessment,
  completion_percentage: 100,
  assessment_status: 'COMPLETED',
  title: 'Self Assessment - Social'
};

const mockNewSelfAssessment = {
  ...mockSelfAssessment,
  completion_percentage: 0,
  assessment_status: 'DRAFT',
  title: 'Self Assessment - Governance'
};

export const InProgress: Story = {
  args: {
    assessment: mockSelfAssessment,
    onClick: () => console.log('Self assessment clicked'),
  },
};

export const Completed: Story = {
  args: {
    assessment: mockCompletedSelfAssessment,
    onClick: () => console.log('Completed self assessment clicked'),
  },
};

export const New: Story = {
  args: {
    assessment: mockNewSelfAssessment,
    onClick: () => console.log('New self assessment clicked'),
  },
};

export const AllVariants: Story = {
  render: () => (
    <VStack spacing={4} align="stretch" w="400px">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        Self Assessment Card Variants
      </Text>
      <SelfAssessmentCard
        assessment={mockNewSelfAssessment}
        onClick={() => console.log('New assessment clicked')}
      />
      <SelfAssessmentCard
        assessment={mockSelfAssessment}
        onClick={() => console.log('In progress assessment clicked')}
      />
      <SelfAssessmentCard
        assessment={mockCompletedSelfAssessment}
        onClick={() => console.log('Completed assessment clicked')}
      />
    </VStack>
  ),
}; 