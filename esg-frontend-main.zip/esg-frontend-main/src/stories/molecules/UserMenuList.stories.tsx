import type { Meta, StoryObj } from '@storybook/react';
import { VStack, HStack, Text, Box } from '@chakra-ui/react';
import { userMenuList } from '@/ui/molecules/userMenuList';

const meta: Meta = {
  title: 'Molecules/UserMenuList',
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

const MenuItemExample = ({ item }: { item: any }) => (
  <HStack spacing={3} p={3} bg="white" borderRadius="md" border="1px solid" borderColor="gray.200" w="250px">
    {item.icon}
    <Text fontSize="sm" fontWeight="medium">
      {item.title}
    </Text>
  </HStack>
);

export const AllMenuItems: Story = {
  render: () => (
    <VStack spacing={2} align="stretch">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        User Menu Items
      </Text>
      {userMenuList.map((item, index) => (
        <MenuItemExample key={index} item={item} />
      ))}
    </VStack>
  ),
};

export const IndividualItems: Story = {
  render: () => (
    <VStack spacing={4} align="stretch">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        Individual Menu Items
      </Text>
      {userMenuList.map((item, index) => (
        <Box key={index}>
          <Text fontSize="sm" color="gray.600" mb={1}>
            {item.title}
          </Text>
          <MenuItemExample item={item} />
        </Box>
      ))}
    </VStack>
  ),
};