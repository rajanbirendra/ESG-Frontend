import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import CountryDropdown from '@/ui/molecules/dropdown/CountryDropdown';

const meta: Meta<typeof CountryDropdown> = {
  title: 'Molecules/Dropdown/CountryDropdown',
  component: CountryDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedCountry: {
      control: { type: 'text' },
      description: 'Currently selected country',
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the dropdown is disabled',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const CountryWrapper = (args: any) => {
  const [selectedCountry, setSelectedCountry] = useState(args.selectedCountry || '');

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedCountry || 'None'}
      </Text>
      <CountryDropdown
        {...args}
        selectedCountry={selectedCountry}
        onCountryChange={setSelectedCountry}
      />
    </VStack>
  );
};

export const Default: Story = {
  render: (args) => <CountryWrapper {...args} />,
  args: {
    selectedCountry: 'United States',
    disabled: false,
  },
};

export const Empty: Story = {
  render: (args) => <CountryWrapper {...args} />,
  args: {
    selectedCountry: '',
    disabled: false,
  },
};

export const Disabled: Story = {
  render: (args) => <CountryWrapper {...args} />,
  args: {
    selectedCountry: 'Canada',
    disabled: true,
  },
};

export const LongCountryName: Story = {
  render: (args) => <CountryWrapper {...args} />,
  args: {
    selectedCountry: 'United Kingdom of Great Britain and Northern Ireland',
    disabled: false,
  },
}; 