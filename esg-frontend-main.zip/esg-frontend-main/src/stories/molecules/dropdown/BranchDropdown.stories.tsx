import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import BranchDropdown from '@/ui/molecules/dropdown/BranchDropdown';

const meta: Meta<typeof BranchDropdown> = {
  title: 'Molecules/Dropdown/BranchDropdown',
  component: BranchDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    value: {
      control: { type: 'text' },
      description: 'Selected branch ID',
    },
    error: {
      control: { type: 'text' },
      description: 'Error message to display',
    },
    isDisabled: {
      control: { type: 'boolean' },
      description: 'Whether the dropdown is disabled',
    },
    label: {
      control: { type: 'text' },
      description: 'Label for the dropdown',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const BranchWrapper = (args: any) => {
  const [value, setValue] = useState<string | null>(args.value || null);

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected Branch ID: {value || 'None'}
      </Text>
      <BranchDropdown
        {...args}
        value={value}
        onChange={setValue}
      />
    </VStack>
  );
};

export const Default: Story = {
  render: (args) => <BranchWrapper {...args} />,
  args: {
    value: null,
    label: 'Branch',
    isDisabled: false,
  },
};

export const WithError: Story = {
  render: (args) => <BranchWrapper {...args} />,
  args: {
    value: null,
    label: 'Branch',
    error: 'Please select a branch',
    isDisabled: false,
  },
};

export const Disabled: Story = {
  render: (args) => <BranchWrapper {...args} />,
  args: {
    value: null,
    label: 'Branch',
    isDisabled: true,
  },
};

export const CustomLabel: Story = {
  render: (args) => <BranchWrapper {...args} />,
  args: {
    value: null,
    label: 'Select Branch',
    isDisabled: false,
  },
};

export const WithSelectedValue: Story = {
  render: (args) => <BranchWrapper {...args} />,
  args: {
    value: 'branch-123',
    label: 'Branch',
    isDisabled: false,
  },
}; 