import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import CountryStateDropdown from '@/ui/molecules/dropdown/CountryStateDropdown';

const meta: Meta<typeof CountryStateDropdown> = {
  title: 'Molecules/Dropdown/CountryStateDropdown',
  component: CountryStateDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedCountry: {
      control: { type: 'text' },
      description: 'Currently selected country',
    },
    selectedState: {
      control: { type: 'text' },
      description: 'Currently selected state/province',
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the dropdowns are disabled',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const CountryStateWrapper = (args: any) => {
  const [selectedCountry, setSelectedCountry] = useState(args.selectedCountry || '');
  const [selectedState, setSelectedState] = useState(args.selectedState || '');

  return (
    <VStack spacing={4} align="stretch" w="600px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedCountry} - {selectedState || 'No state selected'}
      </Text>
      <CountryStateDropdown
        {...args}
        selectedCountry={selectedCountry}
        selectedState={selectedState}
        onCountryChange={setSelectedCountry}
        onStateChange={setSelectedState}
      />
    </VStack>
  );
};

export const Default: Story = {
  render: (args) => <CountryStateWrapper {...args} />,
  args: {
    selectedCountry: 'United States',
    selectedState: 'California',
    disabled: false,
  },
};

export const Empty: Story = {
  render: (args) => <CountryStateWrapper {...args} />,
  args: {
    selectedCountry: '',
    selectedState: '',
    disabled: false,
  },
};

export const CountryOnly: Story = {
  render: (args) => <CountryStateWrapper {...args} />,
  args: {
    selectedCountry: 'Canada',
    selectedState: '',
    disabled: false,
  },
};

export const Disabled: Story = {
  render: (args) => <CountryStateWrapper {...args} />,
  args: {
    selectedCountry: 'United States',
    selectedState: 'New York',
    disabled: true,
  },
}; 