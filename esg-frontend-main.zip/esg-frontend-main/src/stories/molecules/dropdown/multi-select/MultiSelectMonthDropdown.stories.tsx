import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import MonthDropdown from '@/ui/molecules/dropdown/multi-select/MultiSelectMonthDropdown';

const meta: Meta<typeof MonthDropdown> = {
  title: 'Molecules/Dropdown/MultiSelectMonthDropdown',
  component: MonthDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedMonths: {
      control: { type: 'object' },
      description: 'Array of selected month numbers',
    },
    label: {
      control: { type: 'text' },
      description: 'Label text for the dropdown',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const MultiMonthWrapper = (args: any) => {
  const [selectedMonths, setSelectedMonths] = useState<number[]>(args.selectedMonths || []);

  const getMonthNames = (months: number[]) => {
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    return months.map(m => monthNames[m - 1]).join(', ');
  };

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedMonths.length > 0 ? getMonthNames(selectedMonths) : 'None'}
      </Text>
      <MonthDropdown
        {...args}
        selectedMonths={selectedMonths}
        onSelectMonths={setSelectedMonths}
      />
    </VStack>
  );
};

export const Default: Story = {
  render: (args) => <MultiMonthWrapper {...args} />,
  args: {
    selectedMonths: [1, 2, 3],
    label: 'Select months',
  },
};

export const Empty: Story = {
  render: (args) => <MultiMonthWrapper {...args} />,
  args: {
    selectedMonths: [],
    label: 'Select months',
  },
};

export const AllMonths: Story = {
  render: (args) => <MultiMonthWrapper {...args} />,
  args: {
    selectedMonths: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    label: 'Select months',
  },
};

export const CustomLabel: Story = {
  render: (args) => <MultiMonthWrapper {...args} />,
  args: {
    selectedMonths: [6, 7, 8],
    label: 'Choose months',
  },
}; 