import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import MultiSelectScopeDropdown from '@/ui/molecules/dropdown/multi-select/MultiSelectScopeDropdown';

const meta: Meta<typeof MultiSelectScopeDropdown> = {
  title: 'Molecules/Dropdown/MultiSelectScopeDropdown',
  component: MultiSelectScopeDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedScopes: {
      control: { type: 'object' },
      description: 'Array of selected scope values',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const MultiScopeWrapper = (args: any) => {
  const [selectedScopes, setSelectedScopes] = useState<string[]>(args.selectedScopes || []);

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedScopes.length > 0 ? selectedScopes.join(', ') : 'None'}
      </Text>
      <MultiSelectScopeDropdown
        {...args}
        selectedScopes={selectedScopes}
        onSelectScopes={setSelectedScopes}
      />
    </VStack>
  );
};

export const Default: Story = {
  render: (args) => <MultiScopeWrapper {...args} />,
  args: {
    selectedScopes: ['CNP_SCOPE_1', 'CNP_SCOPE_2'],
  },
};

export const Empty: Story = {
  render: (args) => <MultiScopeWrapper {...args} />,
  args: {
    selectedScopes: [],
  },
};

export const AllScopes: Story = {
  render: (args) => <MultiScopeWrapper {...args} />,
  args: {
    selectedScopes: ['CNP_SCOPE_1', 'CNP_SCOPE_2', 'CNP_SCOPE_3'],
  },
};

export const SingleScope: Story = {
  render: (args) => <MultiScopeWrapper {...args} />,
  args: {
    selectedScopes: ['CNP_SCOPE_1'],
  },
}; 