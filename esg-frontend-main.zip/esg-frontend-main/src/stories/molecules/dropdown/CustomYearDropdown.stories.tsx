import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import CustomYearDropdown, {  MultiSelectCustomYearDropdown } from '@/ui/molecules/dropdown/CustomYearDropdown';

const meta: Meta<typeof CustomYearDropdown> = {
  title: 'Molecules/Dropdown/CustomYearDropdown',
  component: CustomYearDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedYear: {
      control: { type: 'text' },
      description: 'Currently selected year',
    },
    placeholder: {
      control: { type: 'text' },
      description: 'Placeholder text',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const SingleYearWrapper = (args: any) => {
  const [selectedYear, setSelectedYear] = useState(args.selectedYear || '');

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedYear || 'None'}
      </Text>
      <CustomYearDropdown
        {...args}
        selectedYear={selectedYear}
        onSelectYear={setSelectedYear}
        years={['2020', '2021', '2022', '2023', '2024', '2025']}
      />
    </VStack>
  );
};

const MultiYearWrapper = (args: any) => {
  const [selectedYears, setSelectedYears] = useState<string[]>(args.selectedYears || []);

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedYears.length > 0 ? selectedYears.join(', ') : 'None'}
      </Text>
      <MultiSelectCustomYearDropdown
        {...args}
        selectedYears={selectedYears}
        onSelectYears={setSelectedYears}
        years={['2020', '2021', '2022', '2023', '2024', '2025']}
      />
    </VStack>
  );
};

export const SingleSelect: Story = {
  render: (args) => <SingleYearWrapper {...args} />,
  args: {
    selectedYear: '2024',
    placeholder: 'Select year',
  },
};

export const MultiSelect: Story = {
  render: (args) => <MultiYearWrapper {...args} />,
  args: {
    // @ts-ignore
    selectedYears: ['2023', '2024'],
    placeholder: 'Select years',
  },
};

export const Empty: Story = {
  render: (args) => <SingleYearWrapper {...args} />,
  args: {
    selectedYear: '',
    placeholder: 'Select year',
  },
};

export const CustomYears: Story = {
  render: (args) => <SingleYearWrapper {...args} />,
  args: {
    selectedYear: '2025',
    placeholder: 'Choose year',
  },
}; 