import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import YearDropdown, { MultiSelectYearDropdown } from '@/ui/molecules/dropdown/yeardropdown';

// Single Select Stories
const singleSelectMeta: Meta<typeof YearDropdown> = {
  title: 'Molecules/Dropdown/YearDropdown/SingleSelect',
  component: YearDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedYear: {
      control: { type: 'text' },
      description: 'Currently selected year',
    },
    maxCurrentYear: {
      control: { type: 'boolean' },
      description: 'Limit years to current year',
    },
  },
};

export default singleSelectMeta;
type SingleSelectStory = StoryObj<typeof singleSelectMeta>;

const SingleYearWrapper = (args: any) => {
  const [selectedYear, setSelectedYear] = useState(args.selectedYear || '');

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedYear || 'None'}
      </Text>
      <YearDropdown
        {...args}
        selectedYear={selectedYear}
        onSelectYear={setSelectedYear}
      />
    </VStack>
  );
};

export const Default: SingleSelectStory = {
  render: (args) => <SingleYearWrapper {...args} />,
  args: {
    selectedYear: '2024',
    maxCurrentYear: false,
  },
};

export const MaxCurrentYear: SingleSelectStory = {
  render: (args) => <SingleYearWrapper {...args} />,
  args: {
    selectedYear: '2024',
    maxCurrentYear: true,
  },
};

export const Empty: SingleSelectStory = {
  render: (args) => <SingleYearWrapper {...args} />,
  args: {
    selectedYear: '',
    maxCurrentYear: false,
  },
};

// Multi Select Stories
const multiSelectMeta: Meta<typeof MultiSelectYearDropdown> = {
  title: 'Molecules/Dropdown/YearDropdown/MultiSelect',
  component: MultiSelectYearDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedYears: {
      control: { type: 'object' },
      description: 'Array of selected years',
    },
  },
};

type MultiSelectStory = StoryObj<typeof multiSelectMeta>;

const MultiYearWrapper = (args: any) => {
  const [selectedYears, setSelectedYears] = useState<string[]>(args.selectedYears || []);

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedYears.length > 0 ? selectedYears.join(', ') : 'None'}
      </Text>
      <MultiSelectYearDropdown
        selectedYears={selectedYears}
        onSelectYears={setSelectedYears}
      />
    </VStack>
  );
};

export const MultiSelect: MultiSelectStory = {
  render: (args) => <MultiYearWrapper {...args} />,
  args: {
    selectedYears: ['2023', '2024'],
  },
};

export const MultiSelectEmpty: MultiSelectStory = {
  render: (args) => <MultiYearWrapper {...args} />,
  args: {
    selectedYears: [],
  },
}; 