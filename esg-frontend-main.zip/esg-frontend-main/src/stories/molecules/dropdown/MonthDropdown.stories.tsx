import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { VStack, Text } from '@chakra-ui/react';
import MonthDropdown from '@/ui/molecules/dropdown/MonthDropdown';

const meta: Meta<typeof MonthDropdown> = {
  title: 'Molecules/Dropdown/MonthDropdown',
  component: MonthDropdown,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedMonth: {
      control: { type: 'number', min: 1, max: 12 },
      description: 'Currently selected month (1-12)',
    },
    label: {
      control: { type: 'text' },
      description: 'Label for the dropdown',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const MonthWrapper = (args: any) => {
  const [selectedMonth, setSelectedMonth] = useState(args.selectedMonth || 1);

  return (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="sm" color="gray.600">
        Selected: {selectedMonth} ({getMonthName(selectedMonth)})
      </Text>
      <MonthDropdown
        {...args}
        selectedMonth={selectedMonth}
        onSelectMonth={setSelectedMonth}
      />
    </VStack>
  );
};

const getMonthName = (month: number) => {
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  return months[month - 1] || '';
};

export const Default: Story = {
  render: (args) => <MonthWrapper {...args} />,
  args: {
    selectedMonth: 3,
    label: 'Select Month',
  },
};

export const January: Story = {
  render: (args) => <MonthWrapper {...args} />,
  args: {
    selectedMonth: 1,
    label: 'Select Month',
  },
};

export const December: Story = {
  render: (args) => <MonthWrapper {...args} />,
  args: {
    selectedMonth: 12,
    label: 'Select Month',
  },
};

export const CustomLabel: Story = {
  render: (args) => <MonthWrapper {...args} />,
  args: {
    selectedMonth: 6,
    label: 'Choose Month',
  },
};

export const AllMonths: Story = {
  render: () => (
    <VStack spacing={4} align="stretch" w="300px">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        All Months
      </Text>
      {Array.from({ length: 12 }, (_, i) => i + 1).map((month) => (
        <MonthWrapper key={month} selectedMonth={month} label="Select Month" />
      ))}
    </VStack>
  ),
}; 