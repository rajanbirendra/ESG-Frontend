import type { Meta, StoryObj } from '@storybook/react';
import { VStack, Text } from '@chakra-ui/react';
import SubHeaderUI from '@/ui/molecules/subHeaderUI';

const meta: Meta<typeof SubHeaderUI> = {
  title: 'Molecules/SubHeaderUI',
  component: SubHeaderUI,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    assessment: {
      control: { type: 'object' },
      description: 'Assessment object with title, branch, and date information',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const mockAssessment = {
  title: 'Environmental Assessment 2024',
  branch: {
    branch_name: 'Main Office'
  },
  assessment_year: '2024',
  assessment_month: '03'
};

const mockAssessmentWithoutBranch = {
  title: 'Social Assessment 2024',
  assessment_year: '2024',
  assessment_month: '06'
};

const mockAssessmentWithoutDate = {
  title: 'Governance Assessment',
  branch: {
    branch_name: 'Branch Office'
  }
};

export const Default: Story = {
  args: {
    assessment: mockAssessment,
  },
};

export const WithoutBranch: Story = {
  args: {
    assessment: mockAssessmentWithoutBranch,
  },
};

export const WithoutDate: Story = {
  args: {
    assessment: mockAssessmentWithoutDate,
  },
};

export const Minimal: Story = {
  args: {
    assessment: {
      title: 'Basic Assessment'
    },
  },
};

export const AllVariants: Story = {
  render: () => (
    <VStack spacing={4} align="stretch" w="400px">
      <Text fontSize="lg" fontWeight="bold" mb={2}>
        SubHeaderUI Variants
      </Text>
      <SubHeaderUI assessment={mockAssessment} />
      <SubHeaderUI assessment={mockAssessmentWithoutBranch} />
      <SubHeaderUI assessment={mockAssessmentWithoutDate} />
      <SubHeaderUI assessment={{ title: 'Basic Assessment' }} />
    </VStack>
  ),
}; 