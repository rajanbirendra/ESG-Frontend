import type { Meta, StoryObj } from '@storybook/react';
import CreateNewSelfAssessment from '@/ui/organisms/dashboard/self-assessment/CreateNewSelfAssessment';

const meta: Meta<typeof CreateNewSelfAssessment> = {
  title: 'Organisms/CreateNewSelfAssessment',
  component: CreateNewSelfAssessment,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        assessment_types: ['Environment', 'Social', 'Governance'],
      },
    },
  },
}; 