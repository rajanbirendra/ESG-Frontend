import type { Meta, StoryObj } from '@storybook/react';
import General from '@/ui/organisms/dashboard/home/general';

const meta: Meta<typeof General> = {
  title: 'Organisms/GeneralAnalytics',
  component: General,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        total_assessments: 25,
        active_assessments: 8,
        completed_assessments: 17,
        overall_score: 82,
      },
    },
  },
}; 