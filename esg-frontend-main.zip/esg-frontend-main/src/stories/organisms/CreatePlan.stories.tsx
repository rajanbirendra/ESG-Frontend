import type { Meta, StoryObj } from '@storybook/react';
import CreatePlan from '@/ui/organisms/dashboard/carbon-neutrality-plan/CreatePlan';

const meta: Meta<typeof CreatePlan> = {
  title: 'Organisms/CreatePlan',
  component: CreatePlan,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        plan_types: ['Short-term', 'Long-term', 'Comprehensive'],
      },
    },
  },
}; 