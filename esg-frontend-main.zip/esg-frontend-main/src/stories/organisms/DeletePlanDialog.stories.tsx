import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Button } from '@chakra-ui/react';
import DeletePlanDialog from '@/ui/organisms/dashboard/carbon-neutrality-plan/DeletePlanDialog';

const meta: Meta<typeof DeletePlanDialog> = {
  title: 'Organisms/DeletePlanDialog',
  component: DeletePlanDialog,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    plan: {
      control: { type: 'object' },
      description: 'Plan object to delete',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const DialogWrapper = (args: any) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>
        Open Delete Dialog
      </Button>
      <DeletePlanDialog
        {...args}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onSuccess={() => {
          console.log('Plan deleted:', args.plan?.id);
          setIsOpen(false);
        }}
      />
    </>
  );
};

export const Default: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    plan: { id: 'plan-123', year: 2024 },
  },
};

export const LongPlanName: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    plan: { id: 'plan-456', year: 2025 },
  },
};

export const ShortPlanName: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    plan: { id: 'plan-789', year: 2026 },
  },
}; 