import SelfAssessmentAnalytics from '@/ui/organisms/dashboard/home/SelfAssessmentAnalytics';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta<typeof SelfAssessmentAnalytics> = {
  title: 'Organisms/SelfAssessmentAnalytics',
  component: SelfAssessmentAnalytics,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        total_assessments: 8,
        completed_assessments: 6,
        in_progress_assessments: 2,
        average_completion: 78,
      },
    },
  },
}; 