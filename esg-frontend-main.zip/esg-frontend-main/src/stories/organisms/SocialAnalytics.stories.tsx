import type { Meta, StoryObj } from '@storybook/react';
import SocialAnalytics from '@/ui/organisms/dashboard/home/social';

const meta: Meta<typeof SocialAnalytics> = {
  title: 'Organisms/SocialAnalytics',
  component: SocialAnalytics,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        total_employees: 150,
        diversity_score: 85,
        community_projects: 12,
        training_hours: 240,
      },
    },
  },
}; 