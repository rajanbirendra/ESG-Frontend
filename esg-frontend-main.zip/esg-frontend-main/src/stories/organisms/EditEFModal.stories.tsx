import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Button } from '@chakra-ui/react';
import EditEFModal from '@/ui/organisms/admin-dashboard/emission-factor/EditEFModal';

const meta: Meta<typeof EditEFModal> = {
  title: 'Organisms/EditEFModal',
  component: EditEFModal,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedItem: {
      control: { type: 'object' },
      description: 'Selected emission factor item to edit',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const ModalWrapper = (args: any) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>
        Open Edit Modal
      </Button>
      <EditEFModal
        {...args}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </>
  );
};

const mockEmissionFactor = {
  id: 'ef-123',
  name: 'Electricity Grid Mix',
  emission_factor: 0.5,
  category: 'Energy',
  country: 'United States',
  state: 'California',
};

export const Default: Story = {
  render: (args) => <ModalWrapper {...args} />,
  args: {
    selectedItem: mockEmissionFactor,
  },
};

export const WithHighValue: Story = {
  render: (args) => <ModalWrapper {...args} />,
  args: {
    selectedItem: {
      ...mockEmissionFactor,
      emission_factor: 2.5,
      name: 'Natural Gas',
    },
  },
};

export const WithCustomCategory: Story = {
  render: (args) => <ModalWrapper {...args} />,
  args: {
    selectedItem: {
      ...mockEmissionFactor,
      category: 'Transportation',
      name: 'Diesel Fuel',
    },
  },
}; 