import type { Meta, StoryObj } from '@storybook/react';
import CreateNewBranch from '@/ui/organisms/dashboard/manage-branches/CreateNewBranch';

const meta: Meta<typeof CreateNewBranch> = {
  title: 'Organisms/CreateNewBranch',
  component: CreateNewBranch,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        countries: ['United States', 'Canada', 'United Kingdom'],
      },
    },
  },
}; 