import type { Meta, StoryObj } from '@storybook/react';
import AssessmentDynamicForm from '@/ui/organisms/DynamicForm';

// Mock data for the dynamic form
const mockFormData = {
  questions: [
    {
      id: '1',
      question_title: 'What is your company size?',
      answer_field: {
        for_user: [
          {
            label: 'Company Size',
            input_type: 'select',
            options: ['Small (1-50)', 'Medium (51-200)', 'Large (201-1000)', 'Enterprise (1000+)']
          }
        ]
      },
      category: 'General',
      type: 'SINGLE_CHOICE'
    },
    {
      id: '2',
      question_title: 'Describe your environmental initiatives',
      answer_field: {
        for_user: [
          {
            label: 'Environmental Initiatives',
            input_type: 'textarea',
          }
        ]
      },
      category: 'Environment',
      type: 'TEXT'
    },
    {
      id: '3',
      question_title: 'Upload your sustainability report',
      answer_field: {
        for_user: [
          {
            label: 'Sustainability Report',
            input_type: 'file',
            allowedExtensions: ['.pdf', '.doc', '.docx']
          }
        ]
      },
      category: 'Documents',
      type: 'FILE'
    }
  ],
  completion_percentage: 45,
  answered_questions: 9,
  total_questions: 20
};

const meta: Meta<typeof AssessmentDynamicForm> = {
  title: 'Organisms/DynamicForm',
  component: AssessmentDynamicForm,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
  argTypes: {
    assessmentId: {
      control: { type: 'text' },
      description: 'Assessment ID',
    },
    cnpId: {
      control: { type: 'text' },
      description: 'Carbon Neutrality Plan ID',
    },
    assessmentFor: {
      control: { type: 'text' },
      description: 'Assessment type',
    },
    showProgressBar: {
      control: { type: 'boolean' },
      description: 'Show progress bar',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    data: mockFormData,
    assessmentId: 'assessment-123',
    assessmentFor: 'ENVIRONMENT',
    showProgressBar: true,
  },
};

export const WithoutProgressBar: Story = {
  args: {
    data: mockFormData,
    assessmentId: 'assessment-123',
    assessmentFor: 'ENVIRONMENT',
    showProgressBar: false,
  },
};

export const HighProgress: Story = {
  args: {
    data: {
      ...mockFormData,
      completion_percentage: 85,
      answered_questions: 17,
      total_questions: 20
    },
    assessmentId: 'assessment-123',
    assessmentFor: 'ENVIRONMENT',
    showProgressBar: true,
  },
};

export const LowProgress: Story = {
  args: {
    data: {
      ...mockFormData,
      completion_percentage: 15,
      answered_questions: 3,
      total_questions: 20
    },
    assessmentId: 'assessment-123',
    assessmentFor: 'ENVIRONMENT',
    showProgressBar: true,
  },
}; 