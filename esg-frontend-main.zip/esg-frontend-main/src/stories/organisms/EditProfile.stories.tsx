import type { Meta, StoryObj } from '@storybook/react';
import EditProfile from '@/ui/organisms/profile/EditProfile';

const meta: Meta<typeof EditProfile> = {
  title: 'Organisms/EditProfile',
  component: EditProfile,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        user: { 
          name: 'John Doe', 
          email: 'john@example.com', 
          phone: '+1234567890',
          company: 'Example Corp'
        },
      },
    },
  },
}; 