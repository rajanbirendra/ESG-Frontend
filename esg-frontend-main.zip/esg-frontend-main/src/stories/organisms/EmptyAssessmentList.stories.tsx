import type { Meta, StoryObj } from '@storybook/react';
import EmptyAssessmentList from '@/ui/organisms/dashboard/assessment/EmptyAssessmentList';

const meta: Meta<typeof EmptyAssessmentList> = {
  title: 'Organisms/EmptyAssessmentList',
  component: EmptyAssessmentList,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const WithBranch: Story = {
  args: {
    selectedBranch: 'Main Office',
    onOpen: () => console.log('Create assessment clicked'),
  },
};

export const WithoutBranch: Story = {
  args: {
    selectedBranch: null,
    onOpen: () => console.log('Create assessment clicked'),
  },
}; 