import GeneralQuickActions from '@/ui/organisms/dashboard/home/GeneralQuickActions';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta<typeof GeneralQuickActions> = {
  title: 'Organisms/GeneralQuickActions',
  component: GeneralQuickActions,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    onAssessmentOpen: {
      action: 'assessment-opened',
      description: 'Callback when assessment is opened',
    },
    onCNPPlanOpen: {
      action: 'cnp-plan-opened',
      description: 'Callback when carbon neutrality plan is opened',
    },
    onSelfAssessmentOpen: {
      action: 'self-assessment-opened',
      description: 'Callback when self assessment is opened',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    onAssessmentOpen: () => console.log('Assessment opened'),
    onCNPPlanOpen: () => console.log('CNP Plan opened'),
    onSelfAssessmentOpen: () => console.log('Self Assessment opened'),
  },
};

export const WithActions: Story = {
  args: {
    onAssessmentOpen: () => alert('Creating ESG Assessment...'),
    onCNPPlanOpen: () => alert('Creating Carbon Neutrality Plan...'),
    onSelfAssessmentOpen: () => alert('Creating Self Assessment...'),
  },
}; 