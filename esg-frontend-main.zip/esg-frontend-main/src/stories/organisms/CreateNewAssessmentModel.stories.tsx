import type { Meta, StoryObj } from '@storybook/react';
import CreateNewAssessmentModel from '@/ui/organisms/dashboard/assessment/CreateNewAssessmentModel';

const meta: Meta<typeof CreateNewAssessmentModel> = {
  title: 'Organisms/CreateNewAssessmentModel',
  component: CreateNewAssessmentModel,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        assessment_types: ['Environment', 'Social', 'Governance'],
      },
    },
  },
}; 