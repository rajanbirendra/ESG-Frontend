import type { Meta, StoryObj } from '@storybook/react';
import RequestReport from '@/ui/organisms/dashboard/reports/RequestReport';

const meta: Meta<typeof RequestReport> = {
  title: 'Organisms/RequestReport',
  component: RequestReport,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        available_reports: ['ESG Summary', 'Environmental Impact', 'Social Responsibility'],
      },
    },
  },
}; 