import type { Meta, StoryObj } from '@storybook/react';
import DownloadTemplate from '@/ui/organisms/admin-dashboard/emission-factor/DownloadTemplate';

const meta: Meta<typeof DownloadTemplate> = {
  title: 'Organisms/DownloadTemplate',
  component: DownloadTemplate,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        templates: ['Emission Factors Template', 'Custom Template'],
      },
    },
  },
}; 