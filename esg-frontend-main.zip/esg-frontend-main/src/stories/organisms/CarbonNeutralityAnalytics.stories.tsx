import type { Meta, StoryObj } from '@storybook/react';
import CarbonNeutralityAnalytics from '@/ui/organisms/dashboard/home/CarbonNeutralityAnalytics';

const meta: Meta<typeof CarbonNeutralityAnalytics> = {
  title: 'Organisms/CarbonNeutralityAnalytics',
  component: CarbonNeutralityAnalytics,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        total_emission: 1500,
        carbon_offset: 800,
        residual_emission: 700,
      },
    },
  },
}; 