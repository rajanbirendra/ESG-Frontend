import type { Meta, StoryObj } from '@storybook/react';
import SubUserDashboard from '@/ui/organisms/dashboard/SubUserDashboard';

const meta: Meta<typeof SubUserDashboard> = {
  title: 'Organisms/SubUserDashboard',
  component: SubUserDashboard,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        user: { name: 'Jane Smith', role: 'SUB_USER' },
        stats: { total_assessments: 8, completed: 6 },
      },
    },
  },
}; 