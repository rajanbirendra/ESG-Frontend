import type { Meta, StoryObj } from '@storybook/react';
import PlanList from '@/ui/organisms/dashboard/carbon-neutrality-plan/PlanList';

const meta: Meta<typeof PlanList> = {
  title: 'Organisms/PlanList',
  component: PlanList,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        plans: [
          { id: 'plan-1', name: 'Carbon Neutrality Plan 2024', status: 'active' },
          { id: 'plan-2', name: 'Carbon Neutrality Plan 2025', status: 'draft' },
        ],
      },
    },
  },
}; 