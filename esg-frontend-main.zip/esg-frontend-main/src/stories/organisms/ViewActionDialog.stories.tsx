import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Button } from '@chakra-ui/react';
import ViewActionDialog from '@/ui/organisms/admin-dashboard/manage-reports/ViewActionDialog';

const meta: Meta<typeof ViewActionDialog> = {
  title: 'Organisms/ViewActionDialog',
  component: ViewActionDialog,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    report: {
      control: { type: 'object' },
      description: 'Report object with details',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const DialogWrapper = (args: any) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>
        Open View Dialog
      </Button>
      <ViewActionDialog
        {...args}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
      />
    </>
  );
};

const mockReport = {
  id: 'report-123',
  type: 'ESG_SUMMARY',
  starting_year_month: '2024-01',
  ending_year_month: '2024-12',
  legal_company_name: 'Acme Corporation Ltd.',
  cin_number: 'L12345AB1234567890',
  report_person_name: 'John Doe',
  status: [
    {
      status: 'REQUESTED',
      date: '2024-01-15T10:30:00Z',
      remarks: 'Report requested for ESG compliance'
    }
  ],
  file: null,
  created_by: 'user-123',
  company_id: 'company-456',
  created_at: '2024-01-15T10:30:00Z',
  updated_at: '2024-01-15T10:30:00Z',
  creator: {
    id: 'user-123',
    username: 'john.doe',
    email: 'john.doe@acme.com',
    first_name: 'John',
    last_name: 'Doe'
  }
};

export const Default: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    report: mockReport,
  },
};

export const Approved: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    report: {
      ...mockReport,
      status: [
        {
          status: 'REQUESTED',
          date: '2024-01-15T10:30:00Z',
          remarks: 'Report requested for ESG compliance'
        },
        {
          status: 'APPROVED',
          date: '2024-01-16T14:20:00Z',
          remarks: 'Report approved after review'
        }
      ],
      file: 'report-file-key-123'
    },
  },
};

export const Rejected: Story = {
  render: (args) => <DialogWrapper {...args} />,
  args: {
    report: {
      ...mockReport,
      status: [
        {
          status: 'REQUESTED',
          date: '2024-01-15T10:30:00Z',
          remarks: 'Report requested for ESG compliance'
        },
        {
          status: 'REJECTED',
          date: '2024-01-16T14:20:00Z',
          remarks: 'Incomplete data provided. Please provide additional documentation.'
        }
      ]
    },
  },
}; 