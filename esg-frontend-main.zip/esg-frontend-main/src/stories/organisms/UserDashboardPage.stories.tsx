import type { Meta, StoryObj } from '@storybook/react';
import UserDashboardPage from '@/ui/organisms/dashboard/UserDashboardPage';

const meta: Meta<typeof UserDashboardPage> = {
  title: 'Organisms/UserDashboardPage',
  component: UserDashboardPage,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        user: { name: 'John Doe', role: 'USER' },
        stats: { total_assessments: 15, completed: 12 },
      },
    },
  },
}; 