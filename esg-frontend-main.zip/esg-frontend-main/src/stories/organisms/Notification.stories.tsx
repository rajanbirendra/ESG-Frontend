import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import Notification from '@/ui/organisms/dashboard/Notification';

// Mock data for stories
const mockNotifications = [
  {
    id: '1',
    title: 'Assessment Completed',
    message: 'Your environmental assessment has been completed successfully.',
    is_read: false,
    created_at: '2024-01-15T10:30:00Z',
    type: 'assessment'
  },
  {
    id: '2',
    title: 'Report Generated',
    message: 'Your monthly ESG report is ready for download.',
    is_read: true,
    created_at: '2024-01-14T15:45:00Z',
    type: 'report'
  },
  {
    id: '3',
    title: 'System Update',
    message: 'New features have been added to your dashboard.',
    is_read: false,
    created_at: '2024-01-13T09:20:00Z',
    type: 'system'
  }
];

const mockUnreadCount = {
  unread_count: 2
};

const meta: Meta<typeof Notification> = {
  title: 'Organisms/Notification',
  component: Notification,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    isOpen: {
      control: { type: 'boolean' },
      description: 'Controls the visibility of the notification modal',
    },
    unreadCount: {
      control: { type: 'object' },
      description: 'Object containing unread notification count',
    },
    isLoadingNotifications: {
      control: { type: 'boolean' },
      description: 'Shows loading state for notifications',
    },
    isMarkingAllAsRead: {
      control: { type: 'boolean' },
      description: 'Shows loading state when marking all as read',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const NotificationWrapper = (args: any) => {
  const [isOpen, setIsOpen] = useState(args.isOpen || false);
  
  return (
    <div>
      <button onClick={() => setIsOpen(true)}>
        Open Notifications
      </button>
      <Notification
        {...args}
        isOpen={isOpen}
        onClose={() => setIsOpen(false)}
        onMarkAllAsRead={() => console.log('Mark all as read')}
        onDeleteNotification={(id) => console.log('Delete notification:', id)}
      />
    </div>
  );
};

export const Default: Story = {
  render: (args) => <NotificationWrapper {...args} />,
  args: {
    notifications: mockNotifications,
    unreadCount: mockUnreadCount,
    isLoadingNotifications: false,
    isMarkingAllAsRead: false,
  },
};

export const Loading: Story = {
  render: (args) => <NotificationWrapper {...args} />,
  args: {
    notifications: [],
    unreadCount: { unread_count: 0 },
    isLoadingNotifications: true,
    isMarkingAllAsRead: false,
  },
};

export const Empty: Story = {
  render: (args) => <NotificationWrapper {...args} />,
  args: {
    notifications: [],
    unreadCount: { unread_count: 0 },
    isLoadingNotifications: false,
    isMarkingAllAsRead: false,
  },
};

export const MarkingAsRead: Story = {
  render: (args) => <NotificationWrapper {...args} />,
  args: {
    notifications: mockNotifications,
    unreadCount: mockUnreadCount,
    isLoadingNotifications: false,
    isMarkingAllAsRead: true,
  },
}; 