import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Button } from '@chakra-ui/react';
import AssessmentHistoryDrawer from '@/ui/organisms/dashboard/assessment/AssessmentHistoryDrawer';

const meta: Meta<typeof AssessmentHistoryDrawer> = {
  title: 'Organisms/AssessmentHistoryDrawer',
  component: AssessmentHistoryDrawer,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    selectedAssessment: {
      control: { type: 'object' },
      description: 'Selected assessment object with status history',
    },
    isHistoryOpen: {
      control: { type: 'boolean' },
      description: 'Whether the history drawer is open',
    },
    onHistoryClose: {
      description: 'Function to close the history drawer',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

const DrawerWrapper = (args: any) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>
        Open History Drawer
      </Button>
      <AssessmentHistoryDrawer
        {...args}
        isHistoryOpen={isOpen}
        onHistoryClose={() => setIsOpen(false)}
      />
    </>
  );
};

const mockAssessment = {
  id: 'assessment-123',
  title: 'Environmental Assessment 2024',
  description: 'Comprehensive environmental impact assessment for 2024',
  status_history: [
    {
      status: 'draft',
      timestamp: '2024-01-15T10:00:00Z',
      updated_by: {
        first_name: 'John',
        last_name: 'Doe',
        company: {
          name: 'Acme Corp',
          branch: 'Headquarters',
          role: 'Manager'
        }
      }
    },
    {
      status: 'in_progress',
      timestamp: '2024-01-16T14:30:00Z',
      from_status: 'draft',
      updated_by: {
        first_name: 'Jane',
        last_name: 'Smith',
        company: {
          name: 'Acme Corp',
          branch: 'West Coast',
          role: 'Analyst'
        }
      }
    },
    {
      status: 'completed',
      timestamp: '2024-01-17T16:45:00Z',
      from_status: 'in_progress',
      updated_by: {
        first_name: 'John',
        last_name: 'Doe',
        company: {
          name: 'Acme Corp',
          branch: 'Headquarters',
          role: 'Manager'
        }
      }
    },
  ],
};

export const Default: Story = {
  render: (args) => <DrawerWrapper {...args} />,
  args: {
    selectedAssessment: mockAssessment,
  },
};

export const EmptyHistory: Story = {
  render: (args) => <DrawerWrapper {...args} />,
  args: {
    selectedAssessment: {
      ...mockAssessment,
      status_history: [],
    },
  },
};

export const LongHistory: Story = {
  render: (args) => <DrawerWrapper {...args} />,
  args: {
    selectedAssessment: {
      ...mockAssessment,
      status_history: Array.from({ length: 20 }, (_, i) => ({
        status: ['draft', 'in_progress', 'completed', 'reviewed'][i % 4],
        timestamp: new Date(2024, 0, 15 + i).toISOString(),
        from_status: i > 0 ? ['draft', 'in_progress', 'completed', 'reviewed'][(i - 1) % 4] : undefined,
        updated_by: {
          first_name: ['John', 'Jane', 'Admin'][i % 3],
          last_name: ['Doe', 'Smith', 'User'][i % 3],
          company: {
            name: 'Acme Corp',
            branch: ['Headquarters', 'West Coast', 'East Coast'][i % 3],
            role: ['Manager', 'Analyst', 'Reviewer'][i % 3]
          }
        }
      })),
    },
  },
}; 