import type { Meta, StoryObj } from '@storybook/react';
import EditUser from '@/ui/organisms/admin-dashboard/users/EditUser';

const meta: Meta<typeof EditUser> = {
  title: 'Organisms/EditUser',
  component: EditUser,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        user: { name: 'John Doe', email: 'john@example.com', role: 'USER' },
      },
    },
  },
}; 