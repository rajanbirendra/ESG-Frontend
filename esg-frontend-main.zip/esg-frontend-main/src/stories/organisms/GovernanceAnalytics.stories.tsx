import GovernanceAnalytics from '@/ui/organisms/dashboard/home/GovernanceAnalytics';
import type { Meta, StoryObj } from '@storybook/react';

const meta: Meta<typeof GovernanceAnalytics> = {
  title: 'Organisms/GovernanceAnalytics',
  component: GovernanceAnalytics,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        total_policies: 15,
        implemented_policies: 12,
        compliance_rate: 85,
      },
    },
  },
}; 