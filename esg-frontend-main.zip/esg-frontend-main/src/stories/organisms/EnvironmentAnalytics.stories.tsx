import type { Meta, StoryObj } from '@storybook/react';
import Environment from '@/ui/organisms/dashboard/home/EnvironmentAnalytics';

const meta: Meta<typeof Environment> = {
  title: 'Organisms/EnvironmentAnalytics',
  component: Environment,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Loading: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: true,
    },
  },
};

export const WithData: Story = {
  args: {},
  parameters: {
    mockData: {
      isLoading: false,
      data: {
        total_emissions: 2500,
        scope_1_emissions: 800,
        scope_2_emissions: 1200,
        scope_3_emissions: 500,
        reduction_target: 15,
      },
    },
  },
}; 