import type { Meta, StoryObj } from '@storybook/react';
import { Box, Text } from '@chakra-ui/react';
import { Container } from '@/ui/components/Container';

const meta: Meta<typeof Container> = {
  title: 'Components/Container',
  component: Container,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  argTypes: {
    minH: {
      control: { type: 'text' },
      description: 'Minimum height of the container',
    },
    p: {
      control: { type: 'text' },
      description: 'Padding of the container',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    minH: '400px',
    p: 6,
    children: (
      <Box>
        <Text fontSize="xl" fontWeight="bold" mb={4}>
          Container Component
        </Text>
        <Text>
          This is a sample container component with centered content and responsive design.
        </Text>
      </Box>
    ),
  },
};

export const WithCustomBackground: Story = {
  args: {
    minH: '300px',
    p: 8,
    bg: 'blue.50',
    _dark: {
      bg: 'blue.900',
    },
    children: (
      <Box textAlign="center">
        <Text fontSize="2xl" fontWeight="bold" mb={4}>
          Custom Background
        </Text>
        <Text>
          This container has a custom background color that adapts to light/dark mode.
        </Text>
      </Box>
    ),
  },
};

export const Minimal: Story = {
  args: {
    minH: '200px',
    p: 4,
    children: (
      <Text fontSize="lg">
        Minimal container with basic styling
      </Text>
    ),
  },
}; 