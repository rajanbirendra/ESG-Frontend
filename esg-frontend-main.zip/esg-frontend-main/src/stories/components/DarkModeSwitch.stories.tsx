import type { Meta, StoryObj } from '@storybook/react';
import { DarkModeSwitch } from '@/ui/components/DarkModeSwitch';

const meta: Meta<typeof DarkModeSwitch> = {
  title: 'Components/DarkModeSwitch',
  component: DarkModeSwitch,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  decorators: [
    (Story) => (
      <div style={{ position: 'relative', width: '100px', height: '100px' }}>
        <Story />
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const WithBackground: Story = {
  args: {},
  decorators: [
    (Story) => (
      <div 
        style={{ 
          position: 'relative', 
          width: '200px', 
          height: '200px',
          backgroundColor: '#f0f0f0',
          border: '1px solid #ccc',
          borderRadius: '8px'
        }}
      >
        <Story />
      </div>
    ),
  ],
}; 